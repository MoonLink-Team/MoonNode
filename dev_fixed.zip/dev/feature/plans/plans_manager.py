import json
import logging
from core.config import ENABLE_PLANS

logger = logging.getLogger("moonnodes_vps_bot")

PLANS: dict = {}


def get_default_plans() -> dict:
    return {
        "premium": {
            "basic":    {"ram": 32,  "cpu": 6,  "disk": 100, "price": "₱150", "validity": "15 Days", "emoji": "🎯"},
            "premium":  {"ram": 64,  "cpu": 12, "disk": 200, "price": "₱399", "validity": "30 Days", "emoji": "💎"},
            "ultimate": {"ram": 128, "cpu": 24, "disk": 500, "price": "₱599", "validity": "60 Days", "emoji": "🚀"},
        },
        "free": {
            "basic":    {"ram": 2, "cpu": 1, "disk": 10, "price": "invite 4",  "emoji": "🎯"},
            "standard": {"ram": 4, "cpu": 2, "disk": 25, "price": "invite 10", "emoji": "💎"},
            "pro":      {"ram": 8, "cpu": 4, "disk": 50, "price": "invite 15", "emoji": "🚀"},
        },
    }


def load_plans() -> dict:
    global PLANS
    if not ENABLE_PLANS:
        PLANS = {"premium": {}, "free": {}}
        return PLANS
    try:
        with open("plans.json", "r") as f:
            data = json.load(f)
        if "premium" not in data and "free" not in data:
            defaults = get_default_plans()
            PLANS = {"premium": defaults["premium"], "free": data}
        else:
            PLANS = data
    except (FileNotFoundError, json.JSONDecodeError):
        PLANS = get_default_plans()
    return PLANS


def save_plans():
    if not ENABLE_PLANS:
        return
    try:
        with open("plans.json", "w") as f:
            json.dump(PLANS, f, indent=4)
    except Exception as e:
        logger.error(f"Failed to save plans.json: {e}")


# Initialise on import
load_plans()
