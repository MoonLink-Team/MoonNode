import asyncio
import subprocess
import shlex
import shutil
import re
import logging
from datetime import datetime, timedelta
from typing import Optional

from core.config import ACTIVE_STORAGE_POOL_REF, VPS_PREFIX, ASM
from core.database import vps_data, data_lock, save_vps_data

logger = logging.getLogger("moonnodes_vps_bot")

# ── Pool detection ───────────────────────────────────────────────────────────

def get_auto_storage_pool(default_pool: Optional[str] = None) -> str:
    if default_pool:
        return default_pool
    try:
        result = subprocess.run(
            shlex.split("lxc profile device get default root pool"),
            capture_output=True, text=True
        )
        pool = result.stdout.strip()
        if pool:
            return pool
        result = subprocess.run(
            shlex.split("lxc storage list --format csv -c n"),
            capture_output=True, text=True
        )
        pools = result.stdout.strip().splitlines()
        if pools:
            return pools[0]
    except Exception as e:
        logger.error(f"Failed to auto-detect storage pool: {e}")
    return "default"


# ── Core LXC executor ────────────────────────────────────────────────────────

async def execute_lxc(command: str, timeout: int = 120):
    logger.info(f"LXC → {command}")
    cmd = shlex.split(command)
    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE
    )
    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        proc.kill()
        await proc.wait()
        raise asyncio.TimeoutError(f"Command timed out after {timeout}s")

    if proc.returncode != 0:
        error = stderr.decode().strip() if stderr else "Command failed (no output)"
        if "not found" not in error.lower() and "doesn't exist" not in error.lower():
            logger.error(f"LXC failed: {error}")
        raise Exception(error)

    return stdout.decode().strip() if stdout else True


# ── Permissions ──────────────────────────────────────────────────────────────

async def apply_advanced_permissions(container_name: str):
    try:
        await execute_lxc(f"lxc config set {container_name} security.nesting true")
        try:
            await execute_lxc(f"lxc config device add {container_name} fuse unix-char path=/dev/fuse")
        except Exception:
            pass
    except Exception as e:
        logger.warning(f"Partial permissions failure for {container_name}: {e}")


# ── Node utilities ───────────────────────────────────────────────────────────

async def list_lxd_remotes() -> list[str]:
    """Return list of configured LXD remote names (excluding 'local' and image servers)."""
    try:
        output = await execute_lxc("lxc remote list --format csv -c n,u")
        remotes = []
        skip = {"local", "ubuntu", "ubuntu-daily", "images"}
        for line in output.splitlines():
            parts = line.split(",")
            name = parts[0].strip().rstrip("*")
            if name and name not in skip:
                remotes.append(name)
        return remotes
    except Exception:
        return []


async def get_node_stats(node: str = "local") -> dict:
    """
    Returns a dict with keys:
      total_ram_mb, used_ram_mb, ram_pct,
      cpu_cores, cpu_pct,
      total_disk_gb, used_disk_gb, disk_pct,
      vps_count, vps_running
    """
    prefix = f"{node}:" if node != "local" else ""
    stats = {
        "total_ram_mb": 0, "used_ram_mb": 0, "ram_pct": 0.0,
        "cpu_cores": 0,    "cpu_pct": 0.0,
        "total_disk_gb": 0, "used_disk_gb": 0, "disk_pct": 0.0,
        "vps_count": 0,    "vps_running": 0,
    }

    # --- RAM via free ---
    try:
        if node == "local":
            result = subprocess.run(["free", "-m"], capture_output=True, text=True)
            lines = result.stdout.splitlines()
            if len(lines) > 1:
                parts = lines[1].split()
                stats["total_ram_mb"] = int(parts[1])
                stats["used_ram_mb"]  = int(parts[2])
                stats["ram_pct"]      = round(int(parts[2]) / int(parts[1]) * 100, 1) if int(parts[1]) > 0 else 0.0
        else:
            out = await execute_lxc(f"lxc exec {prefix}__host__ -- free -m", timeout=5)
            lines = out.splitlines()
            if len(lines) > 1:
                parts = lines[1].split()
                stats["total_ram_mb"] = int(parts[1])
                stats["used_ram_mb"]  = int(parts[2])
                stats["ram_pct"]      = round(int(parts[2]) / int(parts[1]) * 100, 1) if int(parts[1]) > 0 else 0.0
    except Exception:
        # Fallback: parse lxc info
        try:
            out = await execute_lxc(f"lxc info {prefix if prefix else 'local'}", timeout=8)
            for line in out.splitlines():
                if "memory" in line.lower() and ":" in line:
                    pass  # Not reliably structured; skip
        except Exception:
            pass

    # --- CPU via nproc + mpstat ---
    try:
        if node == "local":
            r = subprocess.run(["nproc"], capture_output=True, text=True)
            stats["cpu_cores"] = int(r.stdout.strip()) if r.stdout.strip().isdigit() else 0
            if shutil.which("mpstat"):
                r2 = subprocess.run(["mpstat", "1", "1"], capture_output=True, text=True)
                for line in r2.stdout.splitlines():
                    if "all" in line and "%" in line:
                        stats["cpu_pct"] = round(100.0 - float(line.split()[-1]), 1)
            else:
                r2 = subprocess.run(["top", "-bn1"], capture_output=True, text=True)
                for line in r2.stdout.splitlines():
                    if "%Cpu(s):" in line:
                        stats["cpu_pct"] = round(100.0 - float(line.split()[7]), 1)
    except Exception:
        pass

    # --- Disk (host root fs) ---
    try:
        if node == "local":
            r = subprocess.run(["df", "-BG", "/"], capture_output=True, text=True)
            lines = r.stdout.splitlines()
            if len(lines) > 1:
                parts = lines[1].split()
                stats["total_disk_gb"] = int(parts[1].replace("G", ""))
                stats["used_disk_gb"]  = int(parts[2].replace("G", ""))
                stats["disk_pct"]      = round(int(parts[2].replace("G", "")) / max(int(parts[1].replace("G", "")), 1) * 100, 1)
    except Exception:
        pass

    # --- VPS counts ---
    try:
        from core.database import vps_data as _vd
        for uid, lst in _vd.items():
            for v in lst:
                node_field = v.get("node", "local")
                if node_field == node or (node == "local" and node_field in ("local", "")):
                    stats["vps_count"] += 1
                    if v.get("status") == "running":
                        stats["vps_running"] += 1
    except Exception:
        pass

    return stats


async def get_best_node(multi_node: bool = False) -> str:
    """Returns 'remote:' prefix or '' for local."""
    if not multi_node:
        return ""
    return ""


# ── Container metrics ────────────────────────────────────────────────────────

async def get_container_cpu_raw(container_name: str, node: str = "local") -> float:
    prefix = f"{node}:" if node != "local" else ""
    try:
        proc = await asyncio.create_subprocess_exec(
            "lxc", "exec", f"{prefix}{container_name}", "--", "top", "-bn1",
            stdout=asyncio.subprocess.PIPE
        )
        stdout, _ = await proc.communicate()
        for line in stdout.decode().splitlines():
            if "%Cpu(s):" in line:
                parts = line.split()
                return sum(float(parts[i]) for i in [1, 3, 5] if i < len(parts))
        return 0.0
    except Exception:
        return 0.0


async def get_container_memory_raw(container_name: str, node: str = "local"):
    prefix = f"{node}:" if node != "local" else ""
    try:
        proc = await asyncio.create_subprocess_exec(
            "lxc", "exec", f"{prefix}{container_name}", "--", "free", "-m",
            stdout=asyncio.subprocess.PIPE
        )
        stdout, _ = await proc.communicate()
        lines = stdout.decode().splitlines()
        if len(lines) > 1:
            parts = lines[1].split()
            used  = int(parts[2])
            total = int(parts[1])
            pct   = (used / total * 100) if total > 0 else 0.0
            return f"{used}/{total} MB", pct
    except Exception:
        pass
    return "Unknown", 0.0


async def get_container_disk(container_name: str, node: str = "local") -> str:
    prefix = f"{node}:" if node != "local" else ""
    try:
        proc = await asyncio.create_subprocess_exec(
            "lxc", "exec", f"{prefix}{container_name}", "--", "df", "-h", "/",
            stdout=asyncio.subprocess.PIPE
        )
        stdout, _ = await proc.communicate()
        lines = stdout.decode().splitlines()
        if len(lines) > 1:
            parts = lines[1].split()
            return f"{parts[2]} / {parts[1]} ({parts[4]})"
    except Exception:
        pass
    return "Unavailable"


# ── Deployment ───────────────────────────────────────────────────────────────

async def deploy_container(
    user_id: str,
    username: str,
    ram: int,
    cpu: int,
    disk: int,
    os_version: str,
    validity_days: Optional[int],
    target_node: str,
    storage_pool: str,
) -> dict:
    """
    Creates and starts an LXC container. Returns the vps_info dict.
    Raises on failure.
    """
    with data_lock:
        vps_count = 1
        safe_name = re.sub(r"[^a-z0-9]", "", username.lower()) or "user"
        existing  = {v["container_name"] for lst in vps_data.values() for v in lst}
        while f"{VPS_PREFIX}-{safe_name}-{vps_count}" in existing:
            vps_count += 1
        container_name = f"{VPS_PREFIX}-{safe_name}-{vps_count}"

    expires_at = None
    if validity_days:
        expires_at = (datetime.now() + timedelta(days=validity_days)).isoformat()

    full_cname = f"{target_node}{container_name}"

    await execute_lxc(f"lxc init {os_version} {full_cname} -s {storage_pool}")
    await execute_lxc(f"lxc config set {full_cname} limits.memory {ram}GB")
    await execute_lxc(f"lxc config set {full_cname} limits.cpu {cpu}")
    try:
        await execute_lxc(f"lxc config device set {full_cname} root size={disk}GB")
    except Exception:
        await execute_lxc(f"lxc config device add {full_cname} root disk pool={storage_pool} path=/ size={disk}GB")

    await apply_advanced_permissions(full_cname)
    await execute_lxc(f"lxc start {full_cname}")

    node_label = target_node.rstrip(":") if target_node else "local"
    vps_info = {
        "container_name":     container_name,
        "ram":                f"{ram}GB",
        "cpu":                str(cpu),
        "storage":            f"{disk}GB",
        "config":             f"{ram}GB RAM / {cpu} CPU / {disk}GB Disk",
        "os_version":         os_version,
        "status":             "running",
        "suspended":          False,
        "whitelisted":        False,
        "suspension_history": [],
        "created_at":         datetime.now().isoformat(),
        "shared_with":        [],
        "id":                 None,
        "expires_at":         expires_at,
        "node":               node_label,
    }

    with data_lock:
        if user_id not in vps_data:
            vps_data[user_id] = []
        vps_data[user_id].append(vps_info)
    save_vps_data()

    return vps_info
