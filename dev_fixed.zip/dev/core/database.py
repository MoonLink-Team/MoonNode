import sqlite3
import json
import threading
import logging
from typing import Optional

logger = logging.getLogger("moonnodes_vps_bot")

# ── In-memory VPS data ──────────────────────────────────────────────────────
vps_data: dict = {}
data_lock = threading.Lock()
admin_data: dict = {}
active_giveaways: dict = {}

VPS_DATA_FILE = "vps_data.json"
ADMIN_DATA_FILE = "admin_data.json"

# ── Resource threshold runtime values (overridable by /set) ─────────────────
CPU_THRESHOLD = 90.0
RAM_THRESHOLD = 90.0


def load_vps_data():
    global vps_data
    try:
        with open(VPS_DATA_FILE, "r") as f:
            vps_data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        vps_data = {}


def save_vps_data():
    try:
        with open(VPS_DATA_FILE, "w") as f:
            json.dump(vps_data, f, indent=2)
    except Exception as e:
        logger.error(f"Failed to save vps_data: {e}")


def load_admin_data():
    global admin_data
    try:
        with open(ADMIN_DATA_FILE, "r") as f:
            admin_data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        admin_data = {}


def save_admin_data():
    try:
        with open(ADMIN_DATA_FILE, "w") as f:
            json.dump(admin_data, f, indent=2)
    except Exception as e:
        logger.error(f"Failed to save admin_data: {e}")


# ── SQLite helpers ───────────────────────────────────────────────────────────

def get_db() -> sqlite3.Connection:
    conn = sqlite3.connect("moonnodes.db")
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    cur = conn.cursor()
    cur.executescript("""
        CREATE TABLE IF NOT EXISTS settings (
            key   TEXT PRIMARY KEY,
            value TEXT
        );
        CREATE TABLE IF NOT EXISTS users (
            user_id         TEXT PRIMARY KEY,
            credits         INTEGER DEFAULT 0,
            total_referrals INTEGER DEFAULT 0,
            referred_by     TEXT
        );
        CREATE TABLE IF NOT EXISTS admins (
            user_id TEXT PRIMARY KEY,
            role    TEXT DEFAULT 'Admin',
            pin     TEXT DEFAULT '0000'
        );
        CREATE TABLE IF NOT EXISTS payments (
            name      TEXT PRIMARY KEY,
            image_url TEXT
        );
    """)
    conn.commit()
    conn.close()
    logger.info("Database initialised.")


def get_setting(key: str) -> Optional[str]:
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT value FROM settings WHERE key=?", (key,))
    row = cur.fetchone()
    conn.close()
    return row["value"] if row else None


def set_setting(key: str, value: str):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, value))
    conn.commit()
    conn.close()


def get_payments() -> list:
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM payments")
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


def is_admin_check(user_id: int, main_admin_id: int) -> bool:
    role = admin_data.get(str(user_id))
    return role in ["Owner", "Admin", "Dev"] or str(user_id) == str(main_admin_id)
