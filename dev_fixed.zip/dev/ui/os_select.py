"""
OSSelectView  –  Step 2 of /create (and still used by /claim free)
Picks OS then deploys the container.
"""

import discord
import re
from typing import Optional

from core.config import OS_OPTIONS, ASM, VPS_PREFIX
from core.lxc import deploy_container
from core.cloudflare import create_cloudflare_subdomain
from core.database import get_db, save_vps_data
from core.theme import create_info_embed, create_success_embed, create_error_embed, add_field, Theme
from datetime import datetime


class OSSelectView(discord.ui.View):
    def __init__(
        self,
        ram: int,
        cpu: int,
        disk: int,
        user: discord.Member,
        invoker,
        plan_name: str = "Custom",
        validity_days: Optional[int] = None,
        target_node: str = "",
        storage_pool: str = "default",
    ):
        super().__init__(timeout=300)
        self.ram          = ram
        self.cpu          = cpu
        self.disk         = disk
        self.user         = user
        self.invoker      = invoker
        self.plan_name    = plan_name
        self.validity_days = validity_days
        self.target_node  = target_node
        self.storage_pool = storage_pool

        select = discord.ui.Select(
            placeholder="▼  Step 2 – Select an Operating System",
            options=[
                discord.SelectOption(
                    label=o["label"],
                    value=o["value"],
                    description=o.get("desc", ""),
                    emoji=o.get("emoji", "💿"),
                )
                for o in OS_OPTIONS
            ],
        )
        select.callback = self._on_select
        self.add_item(select)

    async def _on_select(self, interaction: discord.Interaction):
        if str(interaction.user.id) != str(self.invoker.user.id):
            return await interaction.response.send_message(
                embed=create_error_embed("Error", "You cannot select the OS for someone else's VPS."),
                ephemeral=True,
            )

        os_version = interaction.data["values"][0]
        for item in self.children:
            item.disabled = True

        await interaction.response.edit_message(
            embed=create_info_embed(f"{Theme.LOADING} Creating VPS", "Setting up your server…"),
            view=self,
        )

        try:
            vps_info = await deploy_container(
                user_id     = str(self.user.id),
                username    = self.user.name,
                ram         = self.ram,
                cpu         = self.cpu,
                disk        = self.disk,
                os_version  = os_version,
                validity_days = self.validity_days,
                target_node = self.target_node,
                storage_pool = self.storage_pool,
            )
        except Exception as e:
            return await interaction.edit_original_response(
                embed=create_error_embed("Deployment Failed", str(e)[:4000]),
                view=None,
            )

        container_name = vps_info["container_name"]

        # Assign VPS User role
        if interaction.guild:
            try:
                role = discord.utils.get(interaction.guild.roles, name="VPS User")
                if role:
                    await self.user.add_roles(role)
            except Exception:
                pass

        # Cloudflare ASM
        subdomain_url = "None"
        if ASM:
            clean = re.sub(r"[^a-zA-Z0-9-]", "", container_name).lower()
            result = await create_cloudflare_subdomain(clean)
            if result:
                subdomain_url = result

        # DB record
        try:
            conn = get_db()
            cur  = conn.cursor()
            cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (str(self.user.id),))
            conn.commit()
            conn.close()
        except Exception:
            pass

        # Success embed
        node_label = self.target_node.rstrip(":") or "local"
        embed = create_success_embed(
            "🚀 VPS Deployed!",
            f"Your VPS `{container_name}` is online on node **{node_label}**.",
        )
        add_field(embed, "📦 Specs",
                  f"```yaml\nRAM:  {self.ram}GB\nCPU:  {self.cpu} Cores\nDisk: {self.disk}GB\nOS:   {os_version}\n```")
        add_field(embed, "🖥️ Node", f"`{node_label}`", True)
        if subdomain_url != "None":
            add_field(embed, "🌐 Domain", f"http://{subdomain_url}", True)
        if vps_info.get("expires_at"):
            ts = int(datetime.fromisoformat(vps_info["expires_at"]).timestamp())
            add_field(embed, "⏳ Expires", f"<t:{ts}:R>", True)

        await interaction.edit_original_response(embed=embed, view=None)

        # DM owner
        try:
            dm_embed = create_success_embed("🎉 VPS Created!", f"Your VPS `{container_name}` is ready.")
            add_field(dm_embed, "Specs", f"```yaml\nRAM: {self.ram}GB\nCPU: {self.cpu} Cores\nDisk: {self.disk}GB\n```")
            add_field(dm_embed, "Node",  f"`{node_label}`", True)
            if subdomain_url != "None":
                add_field(dm_embed, "Domain", f"http://{subdomain_url}", True)
            await self.user.send(embed=dm_embed)
        except Exception:
            pass
