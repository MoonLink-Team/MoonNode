import discord
from discord import app_commands
from discord.ext import commands

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, set_setting, get_setting
from core.theme import create_success_embed, create_error_embed, create_embed, add_field


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if uid == str(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure(f"Required role: {', '.join(roles)}")
    return app_commands.check(predicate)


SETTINGS_KEYS = ["log_channel", "payment_channel", "ticket_channel", "cpu_threshold", "ram_threshold"]


class SetCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="set", description="[ADMIN] Configure bot settings (channels, thresholds)")
    @app_commands.choices(setting=[
        app_commands.Choice(name="Log Channel",     value="log_channel"),
        app_commands.Choice(name="Payment Channel", value="payment_channel"),
        app_commands.Choice(name="Ticket Channel",  value="ticket_channel"),
        app_commands.Choice(name="CPU Threshold %", value="cpu_threshold"),
        app_commands.Choice(name="RAM Threshold %", value="ram_threshold"),
    ])
    @app_commands.describe(setting="Which setting", value="New value (channel ID or number)")
    @has_role("Owner", "Admin")
    async def set_cmd(self, interaction: discord.Interaction, setting: str, value: str):
        await interaction.response.defer(ephemeral=True)
        set_setting(setting, value)
        await interaction.followup.send(embed=create_success_embed("Setting Updated", f"`{setting}` → `{value}`"))

    @app_commands.command(name="payment", description="[ADMIN] Manage payment methods shown in /plans")
    @app_commands.choices(action=[
        app_commands.Choice(name="Add/Edit", value="add"),
        app_commands.Choice(name="Remove",   value="remove"),
        app_commands.Choice(name="List",     value="list"),
    ])
    @app_commands.describe(payment_name="Name of the payment method", image="QR / payment image")
    @has_role("Owner", "Admin")
    async def payment_cmd(
        self, interaction: discord.Interaction,
        action: str, payment_name: str = None, image: discord.Attachment = None,
    ):
        await interaction.response.defer(ephemeral=True)
        from core.database import get_db, get_payments
        conn = get_db()
        cur  = conn.cursor()

        if action == "list":
            rows = get_payments()
            if not rows:
                conn.close()
                return await interaction.followup.send(embed=create_error_embed("Empty", "No payment methods saved."))
            embed = create_embed("💳 Payment Methods")
            for r in rows:
                add_field(embed, r["name"], r["image_url"][:200], False)
            conn.close()
            return await interaction.followup.send(embed=embed)

        if not payment_name:
            conn.close()
            return await interaction.followup.send(embed=create_error_embed("Error", "Provide a payment_name."))

        if action == "add":
            if not image or not image.content_type.startswith("image/"):
                conn.close()
                return await interaction.followup.send(embed=create_error_embed("Error", "Attach a valid image file."))
            cur.execute("INSERT OR REPLACE INTO payments (name, image_url) VALUES (?,?)", (payment_name, image.url))
            conn.commit()
            conn.close()
            return await interaction.followup.send(embed=create_success_embed("Saved", f"Payment method **{payment_name}** saved."))

        elif action == "remove":
            cur.execute("DELETE FROM payments WHERE name=?", (payment_name,))
            conn.commit()
            conn.close()
            return await interaction.followup.send(embed=create_success_embed("Removed", f"Payment method **{payment_name}** removed."))


async def setup(bot):
    await bot.add_cog(SetCog(bot))
