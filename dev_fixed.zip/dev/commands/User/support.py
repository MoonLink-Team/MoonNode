import discord
from discord import app_commands
from discord.ext import commands

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock, get_setting
from core.theme import create_success_embed, create_error_embed, create_info_embed, create_warning_embed, add_field


def is_admin_check(user_id):
    role = admin_data.get(str(user_id))
    return role in ["Owner", "Admin", "Dev", "Mod"] or str(user_id) == str(MAIN_ADMIN_ID)


class SupportCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="support", description="Open a support ticket for one of your VPS")
    @app_commands.choices(ticket_action=[
        app_commands.Choice(name="Close Ticket", value="close"),
        app_commands.Choice(name="Claim Ticket", value="claim"),
    ])
    @app_commands.describe(
        vps_number    = "Your VPS number (1, 2, 3…)",
        issue         = "Describe your issue in detail",
        ticket_action = "Staff only — manage this ticket from inside the thread",
    )
    async def support_cmd(
        self, interaction: discord.Interaction,
        vps_number: int,
        issue: str,
        ticket_action: str = None,
    ):
        await interaction.response.defer(ephemeral=True)

        # ── Staff actions inside a thread ────────────────────────────────────
        if ticket_action in ("close", "claim"):
            if not isinstance(interaction.channel, discord.Thread):
                return await interaction.followup.send(
                    embed=create_error_embed("Wrong Channel", "Run ticket actions inside a support thread."),
                    ephemeral=True
                )
            if not is_admin_check(interaction.user.id):
                return await interaction.followup.send(
                    embed=create_error_embed("Access Denied", "Only staff can manage tickets."),
                    ephemeral=True
                )
            if ticket_action == "close":
                await interaction.followup.send(
                    embed=create_info_embed("Ticket Closed", "This ticket has been marked as resolved and archived.")
                )
                await interaction.channel.edit(archived=True, locked=True)
            elif ticket_action == "claim":
                await interaction.followup.send(
                    embed=create_success_embed("Ticket Claimed", f"{interaction.user.mention} is now handling this ticket.")
                )
            return

        # ── Create a new ticket ──────────────────────────────────────────────
        uid = str(interaction.user.id)
        with data_lock:
            user_list = vps_data.get(uid, [])
            if not user_list or vps_number < 1 or vps_number > len(user_list):
                return await interaction.followup.send(
                    embed=create_error_embed("Invalid VPS", f"VPS #{vps_number} not found. Use `/list` to see your VPS."),
                    ephemeral=True
                )
            vps = user_list[vps_number - 1]

        ticket_ch_id = get_setting("ticket_channel")
        if not ticket_ch_id or ticket_ch_id == "0":
            return await interaction.followup.send(
                embed=create_error_embed("Not Configured", "No ticket channel has been set. Ask an admin to run `/set`."),
                ephemeral=True
            )

        channel = interaction.guild.get_channel(int(ticket_ch_id))
        if not channel:
            return await interaction.followup.send(
                embed=create_error_embed("Channel Not Found", "The configured ticket channel no longer exists."),
                ephemeral=True
            )

        thread_name = f"ticket-{interaction.user.name}-vps{vps_number}"[:100]
        embed = create_warning_embed(
            f"🎫 Support Ticket — {interaction.user.display_name}",
            f"**VPS #{vps_number}:** `{vps['container_name']}`\n\n**Issue:**\n{issue}"
        )
        add_field(embed, "Specs",  vps.get("config", "Custom"), True)
        add_field(embed, "Status", vps.get("status", "unknown").upper(), True)
        add_field(embed, "Node",   vps.get("node", "local"),    True)
        embed.set_footer(text=f"User ID: {uid}")

        try:
            thread = await channel.create_thread(
                name=thread_name,
                type=discord.ChannelType.private_thread,
                invitable=False,
            )
            await thread.send(content=f"<@{MAIN_ADMIN_ID}> {interaction.user.mention}", embed=embed)
            await thread.add_user(interaction.user)
            await interaction.followup.send(
                embed=create_success_embed(
                    "Ticket Opened ✅",
                    f"Your support thread has been created: {thread.mention}\n\n"
                    "Staff will respond shortly. Please be patient."
                )
            )
        except Exception as e:
            await interaction.followup.send(
                embed=create_error_embed("Failed to Create Ticket", f"{str(e)[:2000]}")
            )


async def setup(bot):
    await bot.add_cog(SupportCog(bot))

