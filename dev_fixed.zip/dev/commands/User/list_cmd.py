import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.database import vps_data, data_lock
from core.theme import create_embed, create_error_embed, add_field, Theme


class ListCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="list", description="View your active VPS instances")
    async def list_cmd(self, interaction: discord.Interaction):
        await interaction.response.defer()
        uid = str(interaction.user.id)

        with data_lock:
            vps_list = vps_data.get(uid, [])

        if not vps_list:
            return await interaction.followup.send(embed=create_error_embed("No VPS", "You have no VPS instances. Use `/claim` to get one."))

        embed = create_embed(f"🖥️ Your VPS Instances", f"You have **{len(vps_list)}** VPS instance(s).")

        for i, vps in enumerate(vps_list, 1):
            status    = vps.get("status", "stopped")
            suspended = vps.get("suspended", False)
            icon      = "⛔" if suspended else ("🟢" if status == "running" else "🔴")
            node      = vps.get("node", "local")

            expire_str = ""
            if vps.get("expires_at"):
                try:
                    ts = int(datetime.fromisoformat(vps["expires_at"]).timestamp())
                    expire_str = f"\n⏳ Expires: <t:{ts}:R>"
                except Exception:
                    pass

            value = (
                f"{icon} **{status.upper()}{'  ⛔ SUSPENDED' if suspended else ''}**\n"
                f"⚙️ {vps.get('config','Custom')}\n"
                f"🌐 Node: `{node}`\n"
                f"💿 OS: `{vps.get('os_version','?')}`"
                f"{expire_str}"
            )
            add_field(embed, f"VPS #{i} — `{vps['container_name']}`", value, False)

        embed.set_footer(text="Use /manage to control your VPS • /backup to snapshot")
        await interaction.followup.send(embed=embed)


async def setup(bot):
    await bot.add_cog(ListCog(bot))
