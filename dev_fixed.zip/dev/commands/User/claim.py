import re
import discord
from discord import app_commands
from discord.ext import commands

from core.config import CLAIM_PREMIUM, CLAIM_FREE, CPCS, MAIN_ADMIN_ID
from core.database import admin_data, get_db, get_setting
from core.theme import create_success_embed, create_error_embed, create_info_embed
from feature.plans.plans_manager import PLANS
from feature.codes.codes_manager import load_codes, save_codes
from ui.os_select import OSSelectView


class ClaimCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="claim", description="Claim a Free/Premium VPS or redeem a promo code")
    @app_commands.choices(claim_type=[
        app_commands.Choice(name="Premium",    value="premium"),
        app_commands.Choice(name="Free",       value="free"),
        app_commands.Choice(name="Promo Code", value="code"),
    ])
    @app_commands.describe(
        claim_type    = "What you want to claim",
        code_or_plan  = "Promo code OR plan name (e.g. basic, premium)",
        proof         = "Payment screenshot (required for Premium)",
    )
    async def claim_cmd(
        self, interaction: discord.Interaction,
        claim_type: str,
        code_or_plan: str,
        proof: discord.Attachment = None,
    ):
        await interaction.response.defer(ephemeral=True)

        # ── Promo Code ───────────────────────────────────────────────────────
        if claim_type == "code":
            if not CPCS:
                return await interaction.followup.send(embed=create_error_embed("Disabled", "Promo codes are disabled."))
            codes = load_codes()
            code  = code_or_plan.upper().strip()
            if code not in codes:
                return await interaction.followup.send(embed=create_error_embed("Invalid Code", "That code does not exist."))
            cdata = codes[code]
            if cdata["used"] >= cdata["uses"]:
                return await interaction.followup.send(embed=create_error_embed("Expired", "That code has reached its usage limit."))

            conn = get_db()
            cur  = conn.cursor()
            cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (str(interaction.user.id),))
            if cdata["type"] == "credits":
                cur.execute("UPDATE users SET credits = credits + ? WHERE user_id = ?", (cdata["value"], str(interaction.user.id)))
            conn.commit()
            conn.close()
            cdata["used"] += 1
            save_codes(codes)
            return await interaction.followup.send(
                embed=create_success_embed("Code Redeemed!", f"You received **{cdata['value']} Credits**! 🎉")
            )

        # ── Plan guards ──────────────────────────────────────────────────────
        if claim_type == "premium" and not CLAIM_PREMIUM:
            return await interaction.followup.send(embed=create_error_embed("Disabled", "Premium claims are currently disabled."))
        if claim_type == "free" and not CLAIM_FREE:
            return await interaction.followup.send(embed=create_error_embed("Disabled", "Free claims are currently disabled."))

        plan_name = code_or_plan.lower().strip()
        if plan_name not in PLANS.get(claim_type, {}):
            return await interaction.followup.send(embed=create_error_embed("Invalid Plan", "Check `/plans` to see available plan names."))

        p = PLANS[claim_type][plan_name]

        # ── Premium: send proof to payment channel ───────────────────────────
        if claim_type == "premium":
            if not proof:
                return await interaction.followup.send(embed=create_error_embed("Error", "Attach a screenshot of your payment receipt."))
            if not proof.content_type.startswith("image/"):
                return await interaction.followup.send(embed=create_error_embed("Error", "Attachment must be an image."))

            pay_ch_id = get_setting("payment_channel")
            if not pay_ch_id or pay_ch_id == "0":
                return await interaction.followup.send(embed=create_error_embed("Error", "No payment channel configured by admins."))

            embed = create_info_embed("New Premium VPS Request")
            embed.add_field(name="User",         value=interaction.user.mention, inline=True)
            embed.add_field(name="Plan",          value=plan_name.title(),       inline=True)
            embed.add_field(name="Specs",         value=f"`{p['ram']}GB RAM / {p['cpu']} CPU / {p['disk']}GB Disk`", inline=False)
            embed.set_image(url=proof.url)

            channel = interaction.guild.get_channel(int(pay_ch_id))
            if channel:
                await channel.send(f"<@{MAIN_ADMIN_ID}>", embed=embed)
            return await interaction.followup.send(
                embed=create_success_embed("Request Sent", "Your claim and payment proof have been forwarded to the admins.")
            )

        # ── Free: check invite requirement then OS select ────────────────────
        req_match = re.search(r"invite\s+(\d+)", p.get("price", "").lower())
        if req_match:
            req = int(req_match.group(1))
            invites = await interaction.guild.invites()
            total   = sum(i.uses for i in invites if i.inviter == interaction.user)
            if total < req:
                return await interaction.followup.send(
                    embed=create_error_embed("Not Enough Invites", f"You need **{req}** server invites. You have **{total}**.")
                )

        validity_days = None
        if "validity" in p:
            m = re.search(r"(\d+)", p["validity"])
            if m:
                validity_days = int(m.group(1))

        from core import ACTIVE_STORAGE_POOL
        view = OSSelectView(
            ram=p["ram"], cpu=p["cpu"], disk=p["disk"],
            user=interaction.user, invoker=interaction,
            plan_name=plan_name, validity_days=validity_days,
            target_node="", storage_pool=ACTIVE_STORAGE_POOL,
        )
        await interaction.edit_original_response(
            embed=create_info_embed("Select Your OS", f"Claiming **{plan_name.title()}** plan. Pick an OS below:"),
            view=view,
        )


async def setup(bot):
    await bot.add_cog(ClaimCog(bot))
