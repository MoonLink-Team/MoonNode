import discord
from discord import app_commands
from discord.ext import commands

from core.config import MAIN_ADMIN_ID
from core.database import admin_data
from core.theme import create_embed, add_field


def is_admin_check(user_id):
    role = admin_data.get(str(user_id))
    return role in ["Owner", "Admin", "Dev"] or str(user_id) == str(MAIN_ADMIN_ID)


class HelpCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="help", description="Show all available commands")
    async def help_cmd(self, interaction: discord.Interaction):
        await interaction.response.defer()

        embed = create_embed("📚 MoonNodes — Command Reference", "Your VPS management assistant.")

        user_cmds = (
            "> 🖥️ `/list` — View your active VPS instances\n"
            "> 🎛️ `/manage` — Open VPS control panel\n"
            "> 💾 `/backup` — Create or restore snapshots\n"
            "> 🤝 `/share` — Grant access to another user\n"
            "> 💳 `/plans` — Browse Free & Premium plans\n"
            "> 🚀 `/claim` — Claim a VPS or redeem a code\n"
            "> 👥 `/affiliate` — Referral credits & stats\n"
            "> 💱 `/transfer` — Sell or gift your VPS\n"
            "> ⬆️ `/upgrade` — Upgrade plan with credits\n"
            "> 🎫 `/support` — Open a support ticket\n"
            "> 📡 `/status` — Live host node stats"
        )
        add_field(embed, "👤 User Commands", user_cmds, False)

        if is_admin_check(interaction.user.id):
            owner_cmds = (
                "> 👑 `/admin` — Assign staff roles\n"
                "> ⚙️ `/set` — Configure bot settings\n"
                "> 💳 `/payment` — Manage payment methods\n"
                "> 🔨 `/create` — Deploy VPS for a user (Node → OS)\n"
                "> 🗑️ `/delete` — Permanently delete a VPS\n"
                "> 🎉 `/giveaway` — Start a VPS giveaway\n"
                "> 🌐 `/nodes` — Cluster status with live stats\n"
                "> ⚙️ `/system-admin` — Toggles, migrate, A2FA\n"
                "> 📋 `/list-all` — View all VPS network-wide\n"
                "> ⚖️ `/vps` — Suspend / unsuspend a VPS"
            )
            add_field(embed, "🛡️ Admin Commands", owner_cmds, False)

        embed.set_footer(text="MoonNodes VPS Manager • Use /plans to get started")
        await interaction.followup.send(embed=embed)


async def setup(bot):
    await bot.add_cog(HelpCog(bot))
