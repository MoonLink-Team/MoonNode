import discord
from discord import app_commands
from discord.ext import commands

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock
from core.theme import create_error_embed
from ui.manage_view import ManageView


def is_admin_check(user_id, main_admin_id):
    role = admin_data.get(str(user_id))
    return role in ["Owner", "Admin", "Dev"] or str(user_id) == str(main_admin_id)


class ManageCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="manage", description="Open the control panel for your VPS")
    @app_commands.describe(user="[ADMIN] Manage another user's VPS")
    async def manage_vps(self, interaction: discord.Interaction, user: discord.Member = None):
        await interaction.response.defer()

        if user:
            if not is_admin_check(interaction.user.id, MAIN_ADMIN_ID):
                return await interaction.followup.send(
                    embed=create_error_embed("Denied", "You don't have permission to manage other users."),
                    ephemeral=True,
                )
            uid = str(user.id)
            with data_lock:
                vps_list = list(vps_data.get(uid, []))
            if not vps_list:
                return await interaction.followup.send(
                    embed=create_error_embed("No VPS", f"{user.mention} has no VPS instances."),
                    ephemeral=True,
                )
            view = ManageView(str(interaction.user.id), vps_list, is_admin=True, owner_id=uid)
        else:
            uid = str(interaction.user.id)
            with data_lock:
                vps_list = list(vps_data.get(uid, []))
            if not vps_list:
                return await interaction.followup.send(
                    embed=create_error_embed("No VPS", "You have no VPS instances. Use `/claim` to get one."),
                    ephemeral=True,
                )
            view = ManageView(uid, vps_list)

        await interaction.followup.send(embed=await view.get_initial_embed(), view=view)

    @app_commands.command(name="manage-shared", description="Manage a VPS that was shared with you")
    @app_commands.describe(owner="The VPS owner", vps_number="VPS number (1, 2…)")
    async def manage_shared(self, interaction: discord.Interaction, owner: discord.Member, vps_number: int):
        await interaction.response.defer()
        oid = str(owner.id)
        with data_lock:
            if oid not in vps_data or vps_number < 1 or vps_number > len(vps_data[oid]):
                return await interaction.followup.send(
                    embed=create_error_embed("Error", "Invalid owner or VPS number."), ephemeral=True
                )
            vps = vps_data[oid][vps_number - 1]

        if str(interaction.user.id) not in vps.get("shared_with", []):
            return await interaction.followup.send(
                embed=create_error_embed("Denied", "You don't have access to this VPS."), ephemeral=True
            )

        view = ManageView(
            str(interaction.user.id), [vps],
            is_shared=True, owner_id=oid, actual_index=vps_number - 1,
        )
        await interaction.followup.send(embed=await view.get_initial_embed(), view=view)


async def setup(bot):
    await bot.add_cog(ManageCog(bot))
