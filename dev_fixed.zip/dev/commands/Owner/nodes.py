"""
/nodes  –  [OWNER/ADMIN] View the multi-node cluster status.

Shows live stats per node:
  • RAM used / total (progress bar)
  • CPU usage %
  • Disk used / total
  • VPS count (running / total)
"""

import discord
from discord import app_commands
from discord.ext import commands

from core.config import MULTI_NODE, MAIN_ADMIN_ID
from core.database import admin_data
from core.lxc import list_lxd_remotes, get_node_stats
from core.theme import (
    create_embed, create_error_embed, create_info_embed,
    add_field, Theme
)


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if uid == str(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure(f"Required role: {', '.join(roles)}")
    return app_commands.check(predicate)


class NodesCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="node", description="[ADMIN] View multi-node cluster status & live resource usage")
    @has_role("Owner", "Admin")
    async def nodes_cmd(self, interaction: discord.Interaction):
        await interaction.response.defer()

        # Always show local node. Add remotes only when Multi-Node is enabled.
        nodes_to_check = ["local"]
        if MULTI_NODE:
            remotes = await list_lxd_remotes()
            nodes_to_check += remotes

        if len(nodes_to_check) == 1 and not MULTI_NODE:
            # Single-node but still show useful stats
            pass

        embed = create_embed(
            "🌐 Node Cluster Overview",
            f"Showing **{len(nodes_to_check)}** node(s) in your cluster.",
        )

        for node in nodes_to_check:
            stats = await get_node_stats(node)

            ram_used  = stats["used_ram_mb"]
            ram_total = stats["total_ram_mb"]
            ram_pct   = stats["ram_pct"]
            cpu_pct   = stats["cpu_pct"]
            cpu_cores = stats["cpu_cores"]
            disk_used = stats["used_disk_gb"]
            disk_total= stats["total_disk_gb"]
            disk_pct  = stats["disk_pct"]
            vps_total = stats["vps_count"]
            vps_run   = stats["vps_running"]

            # Build mini progress bars
            ram_bar  = Theme.progress_bar(ram_pct,  size=10)
            cpu_bar  = Theme.progress_bar(cpu_pct,  size=10)
            disk_bar = Theme.progress_bar(disk_pct, size=10)

            # RAM display
            if ram_total > 0:
                ram_line = f"{ram_bar}\n`{ram_used} MB / {ram_total} MB`"
            else:
                ram_line = "`N/A`"

            # Disk display
            if disk_total > 0:
                disk_line = f"{disk_bar}\n`{disk_used} GB / {disk_total} GB`"
            else:
                disk_line = "`N/A`"

            icon   = "🏠" if node == "local" else "🌐"
            status = "🟢 Online"

            value = (
                f"**Status:** {status}\n"
                f"\n{Theme.CPU} **CPU** ({cpu_cores} cores)\n{cpu_bar}\n"
                f"\n{Theme.RAM} **RAM**\n{ram_line}\n"
                f"\n{Theme.DISK} **Disk**\n{disk_line}\n"
                f"\n🖥️ **VPS:** `{vps_run} running / {vps_total} total`"
            )

            add_field(embed, f"{icon} Node: `{node}`", value, inline=False)

        if MULTI_NODE and len(nodes_to_check) == 1:
            embed.set_footer(text="Multi-Node enabled but no additional remotes configured yet.")

        await interaction.followup.send(embed=embed)


async def setup(bot):
    await bot.add_cog(NodesCog(bot))
