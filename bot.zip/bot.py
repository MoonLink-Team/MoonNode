import discord
from discord import app_commands
from discord.ext import commands, tasks
import asyncio
import aiohttp 
import subprocess
import json
from datetime import datetime, timedelta
import shlex
import logging
import shutil
import os
import io
from typing import Optional, List, Dict, Any
import threading
import time
import sqlite3
import traceback
import random
import sys
import re
import uuid
from dotenv import load_dotenv

# Load the .env file automatically
load_dotenv()

# --- Configuration & Environment ---

# Load environment variables
DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")
MAIN_ADMIN_ID = int(os.getenv('BOT_OWNER_ID', '0'))
VPS_USER_ROLE_ID = int(os.getenv('VPS_USER_ROLE_ID', '0')) 

# Custom Bot Color
_raw_color = os.getenv('BOT_COLOR', '5865F2').replace('#', '')
try:
    CUSTOM_BOT_COLOR = int(_raw_color, 16)
except ValueError:
    CUSTOM_BOT_COLOR = 0x5865F2

# We will auto-detect this, but you can override it in .env
DEFAULT_STORAGE_POOL = os.getenv('DEFAULT_STORAGE_POOL', None)

# Custom Container Prefix
VPS_PREFIX = os.getenv('VPS_PREFIX', 'vps')

# PLANS Feature Toggle
ENABLE_PLANS = os.getenv('PLANS', 'True').lower() == 'true'

# --- SECURITY LIMITS ---
ENFORCE_RESOURCE_LIMITS = os.getenv('ENFORCE_RESOURCE_LIMITS', 'True').lower() == 'true'
MAX_RAM_LIMIT = int(os.getenv('MAX_RAM_GB', '16'))
MAX_CPU_LIMIT = int(os.getenv('MAX_CPU_CORES', '8'))

# --- CLAIM TOGGLES ---
CLAIM_PREMIUM = os.getenv('CLAIM_PREMIUM', 'True').lower() == 'true'
CLAIM_FREE = os.getenv('CLAIM_FREE', 'True').lower() == 'true'

# --- INITIAL EXTENSION TOGGLES (Will be overwritten by DB) ---
ASM = os.getenv('ASM', 'False').lower() == 'true'
MULTI_NODE = os.getenv('Multi-Node', 'False').lower() == 'true'
SOSB = os.getenv('SOSB', 'False').lower() == 'true'
ABEI = os.getenv('ABEI', 'False').lower() == 'true'
ISTS = os.getenv('ISTS', 'False').lower() == 'true'
AES = os.getenv('AES', 'False').lower() == 'true'
RR = os.getenv('RR', 'False').lower() == 'true'
RA = os.getenv('RA', 'False').lower() == 'true'
A2FA = os.getenv('A2FA', 'False').lower() == 'true'

# --- NEW ECONOMY & ADVANCED MANAGEMENT EXTENSIONS ---
CPCS = os.getenv('CPCS', 'False').lower() == 'true'
MSTC = os.getenv('MSTC', 'False').lower() == 'true'
PUDC = os.getenv('PUDC', 'False').lower() == 'true'
UBL_ENABLED = os.getenv('UBL_ENABLED', 'False').lower() == 'true'
UBL_LIMIT = int(os.getenv('BACKUP_LIMIT', '1'))

# --- NETWORKING & PORT MANAGEMENT ---
ANTI_SPAM_POLICY = os.getenv('ANTI_SPAM_POLICY', 'False').lower() == 'true'
DDoS_MONITORING = os.getenv('DDoS_MONITORING', 'False').lower() == 'true'
REVERSE_PROXY_INTEGRATION = os.getenv('REVERSE_PROXY_INTEGRATION', 'False').lower() == 'true'

# --- AUTOMATED BILLING & ECONOMY ---
AUTOMATED_BILLING = os.getenv('AUTOMATED_BILLING', 'False').lower() == 'true'
PROMO_CODES_DB = os.getenv('PROMO_CODES_DB', 'False').lower() == 'true'

# --- CONTAINER & OS ENHANCEMENTS ---
MORE_OS_TEMPLATES = os.getenv('MORE_OS_TEMPLATES', 'False').lower() == 'true'
FTP_SFTP_QUICK_SETUP = os.getenv('FTP_SFTP_QUICK_SETUP', 'False').lower() == 'true'
WEB_SSH_REPLACEMENT = os.getenv('WEB_SSH_REPLACEMENT', 'False').lower() == 'true'
AUTO_BOOT_CONFIGURATION = os.getenv('AUTO_BOOT_CONFIGURATION', 'False').lower() == 'true'

# --- GAME SERVER & SOFTWARE INSTALLERS ---
PTERODACTYL_INSTALLER = os.getenv('PTERODACTYL_INSTALLER', 'False').lower() == 'true'
INSTALLER_SYSTEMD_HANDLING = os.getenv('INSTALLER_SYSTEMD_HANDLING', 'False').lower() == 'true'

# --- MULTI-NODE & CLUSTER AUTOMATION ---
AUTO_BALANCING = os.getenv('AUTO_BALANCING', 'False').lower() == 'true'
NODE_MAINTENANCE_MODE = os.getenv('NODE_MAINTENANCE_MODE', 'False').lower() == 'true'
STORAGE_POOL_SELECTION = os.getenv('STORAGE_POOL_SELECTION', 'False').lower() == 'true'
CROSS_NODE_NETWORKING = os.getenv('CROSS_NODE_NETWORKING', 'False').lower() == 'true'

# --- SECURITY & MODERATION ---
COMMAND_RATE_LIMITING = os.getenv('COMMAND_RATE_LIMITING', 'False').lower() == 'true'
DATABASE_ENGINE_POSTGRESQL = os.getenv('DATABASE_ENGINE_POSTGRESQL', 'False').lower() == 'true'
USER_2FA = os.getenv('USER_2FA', 'False').lower() == 'true'

# --- CODE ARCHITECTURE & STRUCTURE ---
ORM_INTEGRATION = os.getenv('ORM_INTEGRATION', 'False').lower() == 'true'
ERROR_HANDLING_LOGGING = os.getenv('ERROR_HANDLING_LOGGING', 'False').lower() == 'true'
UNIT_TESTS = os.getenv('UNIT_TESTS', 'False').lower() == 'true'

# --- USER EXPERIENCE (UX) & DISCORD UI ---
PAGINATION = os.getenv('PAGINATION', 'False').lower() == 'true'
INSTALLER_PROGRESS_BARS = os.getenv('INSTALLER_PROGRESS_BARS', 'False').lower() == 'true'
TICKET_CATEGORIES = os.getenv('TICKET_CATEGORIES', 'False').lower() == 'true'
LANGUAGE_SUPPORT = os.getenv('LANGUAGE_SUPPORT', 'False').lower() == 'true'

# --- MONITORING & ANALYTICS ---
GRAFANA_INTEGRATION = os.getenv('GRAFANA_INTEGRATION', 'False').lower() == 'true'
USER_ACTIVITY_LOGGING = os.getenv('USER_ACTIVITY_LOGGING', 'False').lower() == 'true'
UPTIME_FORMAT = os.getenv('UPTIME_FORMAT', 'False').lower() == 'true'
ADMIN_WEEKLY_REPORTS = os.getenv('ADMIN_WEEKLY_REPORTS', 'False').lower() == 'true'

# --- CLOUDFLARE CONFIGURATION ---
CF_API_TOKEN = os.getenv('CF_API_TOKEN')
CF_ZONE_ID = os.getenv('CF_ZONE_ID')
CF_DOMAIN = os.getenv('CF_DOMAIN', 'moonlink.qzz.io')
HOST_PUBLIC_IP = os.getenv('HOST_PUBLIC_IP')

# --- STORAGE POOLS ---
NVME_POOL = os.getenv('NVME_POOL', 'nvme')
HDD_POOL = os.getenv('HDD_POOL', 'hdd')

# --- OS OPTIONS ---
OS_OPTIONS = [
    {"label": "Ubuntu 20.04 LTS", "value": "ubuntu:20.04", "emoji": "🐧", "desc": "Stable, widely supported"},
    {"label": "Ubuntu 22.04 LTS", "value": "ubuntu:22.04", "emoji": "🐧", "desc": "Standard recommendation"},
    {"label": "Ubuntu 24.04 LTS", "value": "ubuntu:24.04", "emoji": "🐧", "desc": "Latest LTS release"},
    {"label": "Debian 10 (Buster)", "value": "images:debian/10", "emoji": "🍥", "desc": "Legacy stable"},
    {"label": "Debian 11 (Bullseye)", "value": "images:debian/11", "emoji": "🍥", "desc": "Old stable"},
    {"label": "Debian 12 (Bookworm)", "value": "images:debian/12", "emoji": "🍥", "desc": "Current stable"},
    {"label": "Debian 13 (Trixie)", "value": "images:debian/13", "emoji": "🍥", "desc": "Testing/Next stable"},
    {"label": "Alpine Linux 3.18", "value": "images:alpine/3.18", "emoji": "🏔️", "desc": "Lightweight, security-focused"},
    {"label": "Rocky Linux 8", "value": "images:rockylinux/8", "emoji": "🪨", "desc": "RHEL-compatible, stable"},
    {"label": "AlmaLinux 8", "value": "images:almalinux/8", "emoji": "🌽", "desc": "RHEL-compatible, community-driven"},
]

# --- SOFTWARE INSTALLER SCRIPTS ---
SOFTWARE_SCRIPTS = {
    "docker": {
        "name": "Docker",
        "cmd": "curl -fsSL https://get.docker.com | sh",
        "check": "docker --version"
    },
    "nodejs": {
        "name": "Node.js (LTS)",
        "cmd": "curl -fsSL https://deb.nodesource.com/setup_lts.x | bash - && apt-get install -y nodejs",
        "check": "node --version"
    },
    "nginx": {
        "name": "Nginx Web Server",
        "cmd": "apt-get update && apt-get install -y nginx",
        "check": "nginx -v"
    },
    "python": {
        "name": "Python 3 & Pip",
        "cmd": "apt-get update && apt-get install -y python3 python3-pip",
        "check": "python3 --version"
    },
    "java": {
        "name": "Java (OpenJDK 17)",
        "cmd": "apt-get update && apt-get install -y openjdk-17-jre-headless",
        "check": "java -version"
    },
    "security": {
        "name": "UFW Firewall & Security",
        "cmd": "apt-get update && apt-get install -y ufw fail2ban && ufw default deny incoming && ufw default allow outgoing && ufw allow ssh && ufw --force enable && systemctl enable fail2ban && systemctl start fail2ban",
        "check": "ufw status"
    },
    "minecraft": {
        "name": "Minecraft Java (LGSM)",
        "cmd": "dpkg --add-architecture i386 && apt update && apt install default-jre curl wget file tar bzip2 gzip unzip bsdmainutils python3 util-linux ca-certificates binutils bc jq tmux netcat-openbsd -y && adduser --disabled-password --gecos '' mcserver && su - mcserver -c 'curl -Lo linuxgsm.sh https://linuxgsm.sh && chmod +x linuxgsm.sh && bash linuxgsm.sh mcserver && ./mcserver install' && echo '[Unit]\nDescription=Minecraft Server\nAfter=network.target\n\n[Service]\nType=simple\nUser=mcserver\nWorkingDirectory=/home/mcserver\nExecStart=/home/mcserver/mcserver start\nExecStop=/home/mcserver/mcserver stop\nRestart=always\n\n[Install]\nWantedBy=multi-user.target' > /etc/systemd/system/minecraft.service && systemctl enable minecraft && systemctl start minecraft",
        "check": "systemctl is-active minecraft"
    },
    "rust": {
        "name": "Rust Server (LGSM)",
        "cmd": "dpkg --add-architecture i386 && apt update && apt install curl wget file tar bzip2 gzip unzip bsdmainutils python3 util-linux ca-certificates binutils bc jq tmux netcat-openbsd lib32gcc-s1 lib32stdc++6 -y && adduser --disabled-password --gecos '' rustserver && su - rustserver -c 'curl -Lo linuxgsm.sh https://linuxgsm.sh && chmod +x linuxgsm.sh && bash linuxgsm.sh rustserver && ./rustserver install' && echo '[Unit]\nDescription=Rust Server\nAfter=network.target\n\n[Service]\nType=simple\nUser=rustserver\nWorkingDirectory=/home/rustserver\nExecStart=/home/rustserver/rustserver start\nExecStop=/home/rustserver/rustserver stop\nRestart=always\n\n[Install]\nWantedBy=multi-user.target' > /etc/systemd/system/rust.service && systemctl enable rust && systemctl start rust",
        "check": "systemctl is-active rust"
    },
    "cs2": {
        "name": "CS2 Server (LGSM)",
        "cmd": "dpkg --add-architecture i386 && apt update && apt install curl wget file tar bzip2 gzip unzip bsdmainutils python3 util-linux ca-certificates binutils bc jq tmux netcat-openbsd lib32gcc-s1 lib32stdc++6 -y && adduser --disabled-password --gecos '' cs2server && su - cs2server -c 'curl -Lo linuxgsm.sh https://linuxgsm.sh && chmod +x linuxgsm.sh && bash linuxgsm.sh cs2server && ./cs2server install' && echo '[Unit]\nDescription=CS2 Server\nAfter=network.target\n\n[Service]\nType=simple\nUser=cs2server\nWorkingDirectory=/home/cs2server\nExecStart=/home/cs2server/cs2server start\nExecStop=/home/cs2server/cs2server stop\nRestart=always\n\n[Install]\nWantedBy=multi-user.target' > /etc/systemd/system/cs2.service && systemctl enable cs2 && systemctl start cs2",
        "check": "systemctl is-active cs2"
    },
    "fivem": {
        "name": "FiveM Server",
        "cmd": "apt update && apt install xz-utils git -y && mkdir -p /home/fivem && cd /home/fivem && wget https://runtime.fivem.net/artifacts/fivem/build_proot_linux/master/6683-10d7a040b1029da2d8d8ee4c7d0d0cc151e39a51/fx.tar.xz && tar xf fx.tar.xz && rm fx.tar.xz && echo '[Unit]\nDescription=FiveM Server\nAfter=network.target\n\n[Service]\nType=simple\nWorkingDirectory=/home/fivem\nExecStart=/home/fivem/run.sh\nRestart=always\n\n[Install]\nWantedBy=multi-user.target' > /etc/systemd/system/fivem.service && systemctl enable fivem && systemctl start fivem",
        "check": "systemctl is-active fivem"
    },
    "nginx-proxy-manager": {
        "name": "Nginx Proxy Manager",
        "cmd": "apt update && apt install -y docker.io && docker run -d -p 81:81 -p 80:80 -p 443:443 -v /opt/nginx-proxy-manager:/config --name nginx-proxy-manager jc21/nginx-proxy-manager:latest",
        "check": "docker ps | grep nginx-proxy-manager"
    },
    "traefik": {
        "name": "Traefik Reverse Proxy",
        "cmd": "apt update && apt install -y docker.io && docker run -d -p 80:80 -p 443:443 -p 8080:8080 -v /var/run/docker.sock:/var/run/docker.sock -v traefik-certificates:/certificates --name traefik traefik:v2.10 --providers.docker=true --api.insecure=true --entrypoints.web.address=:80 --entrypoints.websecure.address=:443",
        "check": "docker ps | grep traefik"
    },
    "pterodactyl": {
        "name": "Pterodactyl Panel + Wings",
        "cmd": "curl -sSL https://get.docker.com/ | sh && curl -L https://github.com/pterodactyl/panel/releases/latest/download/panel.tar.gz | tar -xzv && cd panel && cp .env.example .env && composer install --no-dev --optimize-autoloader && php artisan key:generate && php artisan p:environment:setup && php artisan p:environment:database && php artisan migrate --seed && php artisan p:user:make && docker run -d --name pterodactyl-wings -e PTERODACTYL_NODE_TOKEN=your_token -p 8080:8080 -v /var/lib/pterodactyl:/data pterodactyl/wings:latest",
        "check": "docker ps | grep pterodactyl"
    },
    "sftp": {
        "name": "SFTP User Setup",
        "cmd": "apt update && apt install -y openssh-server && useradd -m -s /bin/bash sftpuser && passwd=$(openssl rand -base64 12) && echo \"sftpuser:$passwd\" | chpasswd && mkdir -p /home/sftpuser/.ssh && chmod 700 /home/sftpuser/.ssh && echo 'ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQC...' > /home/sftpuser/.ssh/authorized_keys && chmod 600 /home/sftpuser/.ssh/authorized_keys && chown -R sftpuser:sftpuser /home/sftpuser/.ssh && echo \"SFTP User: sftpuser, Password: $passwd, IP: $(hostname -I | awk '{print $1}'), Port: 22\" > /tmp/sftp_info.txt",
        "check": "id sftpuser"
    },
    "wordpress": {
        "name": "WordPress (Docker)",
        "cmd": "apt update && apt install -y docker-compose && mkdir -p /opt/wordpress && cd /opt/wordpress && echo 'version: \\'3.3\\'\\nservices:\\n  db:\\n    image: mysql:5.7\\n    volumes:\\n      - db_data:/var/lib/mysql\\n    restart: always\\n    environment:\\n      MYSQL_ROOT_PASSWORD: wordpresspassword\\n      MYSQL_DATABASE: wordpress\\n  wordpress:\\n    depends_on:\\n      - db\\n    image: wordpress:latest\\n    ports:\\n      - \\'8000:80\\'\\n    restart: always\\n    environment:\\n      WORDPRESS_DB_HOST: db:3306\\n      WORDPRESS_DB_PASSWORD: wordpresspassword\\nvolumes:\\n  db_data: {}' > docker-compose.yml && docker-compose up -d",
        "check": "docker ps | grep wordpress"
    },
    "ghost": {
        "name": "Ghost CMS (Docker)",
        "cmd": "apt update && apt install -y docker-compose && mkdir -p /opt/ghost && cd /opt/ghost && echo 'version: \\'3.3\\'\\nservices:\\n  ghost:\\n    image: ghost:latest\\n    ports:\\n      - \\'2368:2368\\'\\n    restart: always\\n    volumes:\\n      - ghost_content:/var/lib/ghost/content\\nvolumes:\\n  ghost_content: {}' > docker-compose.yml && docker-compose up -d",
        "check": "docker ps | grep ghost"
    },
    "gitea": {
        "name": "Gitea Git Service (Docker)",
        "cmd": "apt update && apt install -y docker-compose && mkdir -p /opt/gitea && cd /opt/gitea && echo 'version: \\'3\\'\\nservices:\\n  gitea:\\n    image: gitea/gitea:latest\\n    ports:\\n      - \\'3000:3000\\'\\n      - \\'2222:22\\'\\n    restart: always\\n    volumes:\\n      - gitea_data:/data' > docker-compose.yml && docker-compose up -d",
        "check": "docker ps | grep gitea"
    },
    "uptime-kuma": {
        "name": "Uptime Kuma (Docker)",
        "cmd": "apt update && apt install -y docker-compose && mkdir -p /opt/uptime-kuma && cd /opt/uptime-kuma && echo 'version: \\'3.3\\'\\nservices:\\n  uptime-kuma:\\n    image: louislam/uptime-kuma:1\\n    ports:\\n      - \\'3001:3001\\'\\n    restart: always\\n    volumes:\\n      - uptime_kuma_data:/app/data' > docker-compose.yml && docker-compose up -d",
        "check": "docker ps | grep uptime-kuma"
    }
}

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('moonnodes_vps_bot')

# --- SYSTEM CHECK ---
if not shutil.which("lxc"):
    logger.critical("LXC/LXD is not installed or not in PATH. Please install it first.")
    sys.exit(1)

# --- CLOUDFLARE API FUNCTION ---
async def create_cloudflare_subdomain(subdomain_prefix: str) -> Optional[str]:
    if not all([CF_API_TOKEN, CF_ZONE_ID, HOST_PUBLIC_IP]):
        logger.error("[ASM] Missing Cloudflare credentials or Host IP in .env file.")
        return None
        
    full_domain = f"{subdomain_prefix}.{CF_DOMAIN}"
    url = f"https://api.cloudflare.com/client/v4/zones/{CF_ZONE_ID}/dns_records"
    
    headers = {
        "Authorization": f"Bearer {CF_API_TOKEN}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "type": "A",
        "name": full_domain,
        "content": HOST_PUBLIC_IP,
        "ttl": 1,
        "proxied": True
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, headers=headers, json=payload) as response:
                if response.status == 200:
                    logger.info(f"[ASM] Successfully created DNS record: {full_domain}")
                    return full_domain
                else:
                    data = await response.json()
                    errors = data.get('errors', [])
                    if errors and errors[0].get('code') == 81057:
                        logger.warning(f"[ASM] DNS record {full_domain} already exists. Bypassing.")
                        return full_domain
                        
                    logger.error(f"[ASM] Cloudflare API Error: {data}")
                    return None
    except Exception as e:
        logger.error(f"[ASM] HTTP Request to Cloudflare failed: {e}")
        return None

# --- UI CONSTANTS ---
class Theme:
    PRIMARY = CUSTOM_BOT_COLOR    
    ACCENT = CUSTOM_BOT_COLOR     
    SUCCESS = 0x00FF7F    
    ERROR = 0xFF3366      
    WARNING = 0xFFCC00    
    DARK = 0x1E1F22       

    ONLINE = "🟢"  
    OFFLINE = "🔴"
    LOADING = "⏳"
    CPU = "💠"
    RAM = "🧬"
    DISK = "💽"
    NET = "🌐"
    SECURE = "🛡️"
    DIVIDER = "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    @staticmethod
    def get_status_color(status, suspended=False):
        if suspended: return Theme.ERROR
        if status == 'running': return Theme.SUCCESS
        if status == 'stopped': return Theme.DARK
        return Theme.WARNING

    @staticmethod
    def progress_bar(percentage: float, size: int = 12) -> str:
        percentage = max(0, min(100, percentage))
        filled = int((percentage / 100) * size)
        empty = size - filled
        fill_char = "█"
        empty_char = "▒"
        return f"`{fill_char * filled}{empty_char * empty}` **{percentage:.1f}%**"

# --- Helper Functions for UI ---

def create_embed(title, description="", color=Theme.PRIMARY):
    title = str(title)[:256]
    description = str(description)
    if len(description) > 4096:
        description = description[:4093] + "..."
        
    embed = discord.Embed(
        title=title,
        description=description,
        color=color,
        timestamp=datetime.now()
    )
    embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
    embed.set_footer(text="System Status • Online", icon_url="https://imgur.com/6yfYDTP.png")
    return embed

def add_field(embed, name, value, inline=False):
    embed.add_field(name=name, value=value, inline=inline)
    return embed

def create_success_embed(title, description=""): 
    return create_embed(f"✅  {title}", description, color=Theme.SUCCESS) 

def create_error_embed(title, description=""): 
    return create_embed(f"⚠️  {title}", description, color=Theme.ERROR) 

def create_info_embed(title, description=""): 
    return create_embed(f"ℹ️  {title}", description, color=Theme.ACCENT) 

def create_warning_embed(title, description=""): 
    return create_embed(f"⚡  {title}", description, color=Theme.WARNING) 

async def send_log(embed, file=None):
    log_channel_id = get_setting('log_channel')
    if log_channel_id and log_channel_id != '0':
        try:
            channel = bot.get_channel(int(log_channel_id))
            if channel: 
                if file: await channel.send(embed=embed, file=file)
                else: await channel.send(embed=embed)
        except Exception as e:
            logger.error(f"Failed to send log: {e}")

async def send_audit_log(embed):
    await send_log(embed)

def get_auto_storage_pool():
    if DEFAULT_STORAGE_POOL:
        return DEFAULT_STORAGE_POOL
    try:
        cmd = "lxc profile device get default root pool"
        result = subprocess.run(shlex.split(cmd), capture_output=True, text=True)
        pool = result.stdout.strip()
        if pool:
            return pool
        cmd = "lxc storage list --format csv -c n"
        result = subprocess.run(shlex.split(cmd), capture_output=True, text=True)
        pools = result.stdout.strip().splitlines()
        if pools:
            return pools[0]
    except Exception as e:
        logger.error(f"Failed to auto-detect storage pool: {e}")
    return "default"

ACTIVE_STORAGE_POOL = get_auto_storage_pool()

# --- Plans & Codes Management ---

def get_default_plans():
    return {
        "premium": {
            "basic": {"ram": 32, "cpu": 6, "disk": 100, "price": "₱150", "validity": "15 Days", "emoji": "🎯"},
            "premium": {"ram": 64, "cpu": 12, "disk": 200, "price": "₱399", "validity": "30 Days", "emoji": "💎"},
            "ultimate": {"ram": 128, "cpu": 24, "disk": 500, "price": "₱599", "validity": "60 Days", "emoji": "🚀"}
        },
        "free": {
            "basic": {"ram": 2, "cpu": 1, "disk": 10, "price": "invite 4", "emoji": "🎯"},
            "standard": {"ram": 4, "cpu": 2, "disk": 25, "price": "invite 10", "emoji": "💎"},
            "pro": {"ram": 8, "cpu": 4, "disk": 50, "price": "invite 15", "emoji": "🚀"}
        }
    }

def load_plans():
    if not ENABLE_PLANS:
        return {"premium": {}, "free": {}}
    try:
        with open('plans.json', 'r') as f:
            data = json.load(f)
            if "premium" not in data and "free" not in data:
                defaults = get_default_plans()
                return {"premium": defaults["premium"], "free": data}
            return data
    except FileNotFoundError:
        return get_default_plans()
    except json.JSONDecodeError:
        return get_default_plans()

PLANS = load_plans()

def save_plans():
    if not ENABLE_PLANS:
        return
    try:
        with open('plans.json', 'w') as f:
            json.dump(PLANS, f, indent=4)
    except Exception as e:
        logger.error(f"Failed to save plans.json: {e}")

def load_codes():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT code, type, value, uses, used FROM promo_codes")
    rows = cur.fetchall()
    conn.close()
    return {row['code']: {"type": row['type'], "value": row['value'], "uses": row['uses'], "used": row['used']} for row in rows}

def save_codes(data):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("DELETE FROM promo_codes")
    for code, cdata in data.items():
        cur.execute("INSERT INTO promo_codes (code, type, value, uses, used) VALUES (?, ?, ?, ?, ?)", (code, cdata['type'], cdata['value'], cdata['uses'], cdata['used']))
    conn.commit()
    conn.close()

# --- Database Setup ---

def get_db():
    conn = sqlite3.connect("vps.db", timeout=30, check_same_thread=False)
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cur = conn.cursor()
    cur.execute('''CREATE TABLE IF NOT EXISTS admins (
        user_id TEXT PRIMARY KEY,
        role TEXT DEFAULT 'Admin'
    )''')
    
    cur.execute('PRAGMA table_info(admins)')
    info = cur.fetchall()
    columns = [col[1] for col in info]
    if 'role' not in columns: cur.execute("ALTER TABLE admins ADD COLUMN role TEXT DEFAULT 'Admin'")
    if 'pin' not in columns: cur.execute("ALTER TABLE admins ADD COLUMN pin TEXT DEFAULT '0000'")
        
    cur.execute('INSERT OR IGNORE INTO admins (user_id, role, pin) VALUES (?, ?, ?)', (str(MAIN_ADMIN_ID), 'Owner', '0000'))

    cur.execute('''CREATE TABLE IF NOT EXISTS vps (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT NOT NULL,
        container_name TEXT UNIQUE NOT NULL,
        ram TEXT NOT NULL,
        cpu TEXT NOT NULL,
        storage TEXT NOT NULL,
        config TEXT NOT NULL,
        os_version TEXT DEFAULT 'ubuntu:22.04',
        status TEXT DEFAULT 'stopped',
        suspended INTEGER DEFAULT 0,
        whitelisted INTEGER DEFAULT 0,
        created_at TEXT NOT NULL,
        shared_with TEXT DEFAULT '[]',
        suspension_history TEXT DEFAULT '[]'
    )''')

    cur.execute('''CREATE TABLE IF NOT EXISTS payments (
        name TEXT PRIMARY KEY,
        image_url TEXT NOT NULL
    )''')

    cur.execute('''CREATE TABLE IF NOT EXISTS payment_proofs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT NOT NULL,
        method TEXT NOT NULL,
        image_url TEXT NOT NULL,
        status TEXT DEFAULT 'pending',
        submitted_at TEXT NOT NULL
    )''')
    
    cur.execute('''CREATE TABLE IF NOT EXISTS users (
        user_id TEXT PRIMARY KEY,
        credits INTEGER DEFAULT 0,
        total_referrals INTEGER DEFAULT 0
    )''')
    
    # Insert default GCash & PayPal if table is empty just in case
    cur.execute("INSERT OR IGNORE INTO payments (name, image_url) VALUES ('GCash', 'https://imgur.com/6yfYDTP.png')")
    cur.execute("INSERT OR IGNORE INTO payments (name, image_url) VALUES ('PayPal', 'https://imgur.com/your_paypal_link.png')")

    cur.execute('PRAGMA table_info(vps)')
    info = cur.fetchall()
    columns = [col[1] for col in info]
    if 'os_version' not in columns:
        cur.execute("ALTER TABLE vps ADD COLUMN os_version TEXT DEFAULT 'ubuntu:22.04'")
    if 'expires_at' not in columns:
        cur.execute("ALTER TABLE vps ADD COLUMN expires_at TEXT")
    if 'node' not in columns:
        cur.execute("ALTER TABLE vps ADD COLUMN node TEXT DEFAULT 'local'")

    cur.execute('''CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    )''')

    cur.execute('''CREATE TABLE IF NOT EXISTS promo_codes (
        code TEXT PRIMARY KEY,
        type TEXT NOT NULL,
        value INTEGER NOT NULL,
        uses INTEGER DEFAULT 1,
        used INTEGER DEFAULT 0
    )''')

    cur.execute('''CREATE TABLE IF NOT EXISTS tickets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT NOT NULL,
        channel_id TEXT NOT NULL UNIQUE,
        subject TEXT NOT NULL,
        status TEXT DEFAULT 'open',
        created_at TEXT NOT NULL,
        closed_at TEXT,
        transcript_url TEXT
    )''')

    settings_init = [
        ('cpu_threshold', '90'),
        ('ram_threshold', '90'),
        ('log_channel', '0'),
        ('payment_channel', '0'),
        ('maintenance_mode', 'false'),
        ('ticket_category_id', '0'),
        ('ticket_support_role_id', '0')
    ]
    for key, value in settings_init:
        cur.execute('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)', (key, value))

    conn.commit()
    conn.close()

def get_setting(key: str, default: Any = None):
    conn = get_db()
    cur = conn.cursor()
    cur.execute('SELECT value FROM settings WHERE key = ?', (key,))
    row = cur.fetchone()
    conn.close()
    return row[0] if row else default

def set_setting(key: str, value: str):
    conn = get_db()
    cur = conn.cursor()
    cur.execute('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', (key, value))
    conn.commit()
    conn.close()

def get_payments():
    conn = get_db()
    cur = conn.cursor()
    cur.execute('SELECT * FROM payments')
    rows = cur.fetchall()
    conn.close()
    return [{"name": row["name"], "image_url": row["image_url"]} for row in rows]

def get_vps_data() -> Dict[str, List[Dict[str, Any]]]:
    conn = get_db()
    cur = conn.cursor()
    cur.execute('SELECT * FROM vps')
    rows = cur.fetchall()
    conn.close()
    data = {}
    for row in rows:
        user_id = row['user_id']
        if user_id not in data:
            data[user_id] = []
        vps = dict(row)
        vps['shared_with'] = json.loads(vps['shared_with'])
        vps['suspension_history'] = json.loads(vps['suspension_history'])
        vps['suspended'] = bool(vps['suspended'])
        vps['whitelisted'] = bool(vps['whitelisted'])
        vps['os_version'] = vps.get('os_version', 'ubuntu:22.04')
        vps['expires_at'] = vps.get('expires_at', None)
        vps['node'] = vps.get('node', 'local')
        data[user_id].append(vps)
    return data

def get_admins() -> Dict[str, str]:
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT user_id, role FROM admins")
    rows = cur.fetchall()
    conn.close()
    return {row['user_id']: row['role'] for row in rows}

# RLock prevents self-deadlocks on nested with statements in the same thread
data_lock = threading.RLock()

def save_vps_data():
    with data_lock:
        conn = get_db()
        cur = conn.cursor()
        for user_id, vps_list in vps_data.items():
            for vps in vps_list:
                shared_json = json.dumps(vps.get('shared_with', []))
                history_json = json.dumps(vps.get('suspension_history', []))
                suspended_int = 1 if vps.get('suspended', False) else 0
                whitelisted_int = 1 if vps.get('whitelisted', False) else 0
                os_ver = vps.get('os_version', 'ubuntu:22.04')
                exp_at = vps.get('expires_at', None)
                node_str = vps.get('node', 'local')
                
                if 'id' not in vps or vps['id'] is None:
                    cur.execute('''INSERT INTO vps (user_id, container_name, ram, cpu, storage, config, os_version, status, suspended, whitelisted, created_at, shared_with, suspension_history, expires_at, node)
                                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                                (user_id, vps['container_name'], vps['ram'], vps['cpu'], vps['storage'], vps['config'],
                                 os_ver, vps.get('status', 'stopped'), suspended_int, whitelisted_int,
                                 vps['created_at'], shared_json, history_json, exp_at, node_str))
                    vps['id'] = cur.lastrowid
                else:
                    cur.execute('''UPDATE vps SET user_id = ?, ram = ?, cpu = ?, storage = ?, config = ?, os_version = ?, status = ?, suspended = ?, whitelisted = ?, shared_with = ?, suspension_history = ?, expires_at = ?, node = ?
                                   WHERE id = ?''',
                                (user_id, vps['ram'], vps['cpu'], vps['storage'], vps['config'],
                                 os_ver, vps.get('status', 'stopped'), suspended_int, whitelisted_int, shared_json, history_json, exp_at, node_str, vps['id']))
        conn.commit()
        conn.close()

def save_admin_data():
    with data_lock:
        conn = get_db()
        cur = conn.cursor()
        for uid, role in admin_data.items():
            cur.execute("INSERT OR REPLACE INTO admins (user_id, role, pin) VALUES (?, ?, COALESCE((SELECT pin FROM admins WHERE user_id = ?), '0000'))", (uid, role, uid))
        conn.commit()
        conn.close()

# Initialize database
init_db()
vps_data = get_vps_data()
admin_data = get_admins()

# Load Extensions from DB (This overrides .env values so `/system-admin` changes persist)
ASM = get_setting('ext_asm', str(ASM)).lower() == 'true'
MULTI_NODE = get_setting('ext_multi_node', str(MULTI_NODE)).lower() == 'true'
SOSB = get_setting('ext_sosb', str(SOSB)).lower() == 'true'
ABEI = get_setting('ext_abei', str(ABEI)).lower() == 'true'
ISTS = get_setting('ext_ists', str(ISTS)).lower() == 'true'
AES = get_setting('ext_aes', str(AES)).lower() == 'true'
RR = get_setting('ext_rr', str(RR)).lower() == 'true'
RA = get_setting('ext_ra', str(RA)).lower() == 'true'
A2FA = get_setting('ext_a2fa', str(A2FA)).lower() == 'true'

# Economy & Advanced Limits Settings from DB
CPCS = get_setting('ext_cpcs', str(CPCS)).lower() == 'true'
MSTC = get_setting('ext_mstc', str(MSTC)).lower() == 'true'
PUDC = get_setting('ext_pudc', str(PUDC)).lower() == 'true'
UBL_ENABLED = get_setting('ext_ubl', str(UBL_ENABLED)).lower() == 'true'
UBL_LIMIT = int(get_setting('ubl_limit', str(UBL_LIMIT)))

# Global settings
CPU_THRESHOLD = int(get_setting('cpu_threshold', 90))
RAM_THRESHOLD = int(get_setting('ram_threshold', 90))
MAINTENANCE_MODE = get_setting('maintenance_mode', 'false') == 'true'

# Global Active Giveaways Tracker
active_giveaways = {}

# --- Bot Class ---

class MoonNodesBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        intents.reactions = True  
        intents.invites = True # Required for checking free plan invites
        super().__init__(command_prefix="!", intents=intents) 

    async def setup_hook(self):
        self.tree.on_error = self.on_tree_error
        self.add_view(CloseTicketView())

        # Load commands from the 'command' directory
        for root, dirs, files in os.walk("command"):
            for file in files:
                if file.endswith(".py"):
                    path = os.path.join(root, file).replace(os.sep, ".")[:-3]
                    try:
                        await self.load_extension(path)
                        logger.info(f"Loaded command: {path}")
                    except Exception as e:
                        logger.error(f"Failed to load command {path}: {e}")
        
        try:
            synced = await self.tree.sync()
            logger.info(f"Synced {len(synced)} slash commands globally")
        except Exception as e:
            logger.error(f"Failed to sync slash commands: {e}")
        self.update_status_task.start()
        
        if SOSB:
            automated_backups.start()
        if AES or RR:
            expiration_monitor.start()

    async def on_tree_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.CheckFailure):
            embed = create_error_embed("Access Denied", str(error))
            try:
                if interaction.response.is_done(): await interaction.followup.send(embed=embed, ephemeral=True)
                else: await interaction.response.send_message(embed=embed, ephemeral=True)
            except Exception: pass
            return

        error_message = str(error.original) if isinstance(error, app_commands.CommandInvokeError) else str(error)
        logger.error(f"Command Error: {error_message}")
        traceback.print_exc()

        try:
            embed = create_error_embed("System Error", f"An error occurred: {error_message[:4000]}")
            if interaction.response.is_done(): await interaction.followup.send(embed=embed, ephemeral=True)
            else: await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception: pass

    @tasks.loop(seconds=60)
    async def update_status_task(self):
        try:
            if getattr(self, 'MAINTENANCE_MODE', False):
                 await self.change_presence(status=discord.Status.dnd, activity=discord.Activity(type=discord.ActivityType.watching, name="System Maintenance"))
                 return

            total_vps = sum(len(v) for v in vps_data.values())
            statuses = [
                f"System Status: Online",
                f"Managing {total_vps} VPS Nodes",
                f"MoonNodes System",
                f"Type /help for commands"
            ]
            await self.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name=random.choice(statuses)))
        except: pass

bot = MoonNodesBot()
resource_monitor_active = True

# --- Scheduled & Off-Site Backups (Feature 6) ---
@tasks.loop(hours=24)
async def automated_backups():
    if not getattr(bot, 'SOSB', False): return
    logger.info("[SOSB] Running scheduled automated backups...")
    with data_lock:
        current_data = vps_data.copy()
    for uid, vps_list in current_data.items():
        for vps in vps_list:
            cname = vps['container_name']
            node_prefix = f"{vps.get('node', 'local')}:" if vps.get('node', 'local') != 'local' else ""
            snap_name = f"auto-backup-{datetime.now().strftime('%Y%m%d')}"
            try:
                # Check if the snapshot already exists to prevent an LXC error loop
                info_output = await execute_lxc(f"lxc info {node_prefix}{cname}")
                if snap_name in info_output:
                    logger.info(f"[SOSB] Snapshot {snap_name} already exists for {cname}. Skipping.")
                    continue
                    
                await execute_lxc(f"lxc snapshot {node_prefix}{cname} {snap_name}")
                logger.info(f"[SOSB] Automated backup created for {cname}")
            except Exception as e:
                logger.error(f"[SOSB] Failed auto-backup for {cname}: {e}")

# --- Automated Expiration & Renewal Reminders ---
@tasks.loop(hours=12)
async def expiration_monitor():
    if not getattr(bot, 'AES', False) and not getattr(bot, 'RR', False): return
    logger.info("[AES/RR] Running expiration checks...")
    now = datetime.now()
    
    with data_lock:
        current_data = vps_data.copy()
        
    for uid, vps_list in current_data.items():
        for vps in vps_list:
            exp_str = vps.get('expires_at')
            if not exp_str: continue
            
            try:
                exp_date = datetime.fromisoformat(exp_str)
            except ValueError: continue
            
            days_left = (exp_date - now).days
            node_prefix = f"{vps.get('node', 'local')}:" if vps.get('node', 'local') != 'local' else ""
            
            if days_left <= 0 and AES and not vps.get('suspended', False):
                try:
                    await execute_lxc(f"lxc stop {node_prefix}{vps['container_name']}")
                    with data_lock:
                        vps['suspended'] = True
                        vps['status'] = 'stopped'
                        vps['suspension_history'].append({'time': datetime.now().isoformat(), 'reason': 'Automated Expiration', 'by': 'System'})
                    save_vps_data()
                    
                    user = bot.get_user(int(uid))
                    if user:
                        await user.send(embed=create_error_embed("VPS Expired", f"Your VPS `{vps['container_name']}` has expired and has been automatically suspended.\n\nPlease open a ticket or purchase a renewal via `/plans` to reactivate it."))
                        
                        # Remove role on expiration
                        for plan_name, plan_data in PLANS.get("premium", {}).items():
                            if str(plan_data.get('ram')) in vps.get('ram', '') and str(plan_data.get('cpu')) == str(vps.get('cpu', '')) and plan_data.get('role_id'):
                                for guild in bot.guilds:
                                    try:
                                        role_to_remove = guild.get_role(int(plan_data['role_id']))
                                        member = guild.get_member(user.id)
                                        if role_to_remove and member and role_to_remove in member.roles:
                                            await member.remove_roles(role_to_remove, reason="VPS Plan Expired")
                                    except Exception as e:
                                        logger.error(f"Failed to remove expired role for {user.name} in {guild.name}: {e}")
                                break # Assume first match is correct
                except Exception as e:
                    logger.error(f"[AES] Failed to auto-suspend {vps['container_name']}: {e}")
            
            elif days_left == 3 and getattr(bot, 'RR', False):
                user = bot.get_user(int(uid))
                if user:
                    try:
                        await user.send(embed=create_warning_embed("Renewal Reminder", f"Your VPS `{vps['container_name']}` will expire in **3 days**!\n\nPlease use the `/plans` command to renew your subscription and avoid downtime."))
                    except: pass

# --- Checks & Permissions ---

def is_admin_check(user_id):
    role = admin_data.get(str(user_id))
    return role in ['Owner', 'Admin', 'Dev'] or str(user_id) == str(MAIN_ADMIN_ID)

def check_maintenance():
    async def predicate(interaction: discord.Interaction):
        if getattr(bot, 'MAINTENANCE_MODE', False):
            if is_admin_check(interaction.user.id):
                return True
            raise app_commands.CheckFailure("⚠️ System is currently under maintenance. Please try again later.")
        return True
    return app_commands.check(predicate)

def has_role(*allowed_roles):
    async def predicate(interaction: discord.Interaction):
        user_id = str(interaction.user.id)
        if user_id == str(MAIN_ADMIN_ID):
            return True
        role = admin_data.get(user_id)
        if role == 'Owner' or role in allowed_roles:
            return True
        raise app_commands.CheckFailure(f"You do not have the required permissions: {', '.join(allowed_roles)} or Server Owner.")
    return app_commands.check(predicate)

# --- LXC Execution & Deployment Logic ---

async def execute_lxc(command, timeout=120):
    logger.info(f"Executing LXC: {command}")
    try:
        cmd = shlex.split(command)
        proc = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            raise asyncio.TimeoutError(f"Command timed out after {timeout} seconds")
        
        if proc.returncode != 0:
            error = stderr.decode().strip() if stderr else "Command failed with no error output"
            if "not found" in error.lower() or "doesn't exist" in error.lower(): pass
            else: logger.error(f"LXC Failed: {error}")
            raise Exception(error)
        
        return stdout.decode().strip() if stdout else True
    except Exception as e:
        if "not found" not in str(e).lower(): logger.error(f"LXC Error in execution: {command} - {str(e)}")
        raise

async def apply_advanced_permissions(container_name):
    try:
        await execute_lxc(f"lxc config set {container_name} security.nesting true")
        try:
            await execute_lxc(f"lxc config device add {container_name} fuse unix-char path=/dev/fuse")
        except: pass
        try:
             await execute_lxc(f"lxc config device set {container_name} root limits.read 50MB") 
             await execute_lxc(f"lxc config device set {container_name} root limits.write 50MB")
        except: pass
    except Exception as e:
        logger.warning(f"Failed to apply full permissions to {container_name}: {e}")

async def get_best_node():
    """Smart Auto-Balancing for Multi-Node Architecture.
    Returns 'remote_name:' or '' for local based on available resources.
    """
    if not AUTO_BALANCING: 
        return ""
    try:
        # Get list of nodes
        result = await execute_lxc("lxc cluster list --format csv -c n")
        nodes = result.strip().split('\n')
        if not nodes or nodes == ['']:
            return ""
        best_node = ""
        min_ram = float('inf')
        for node in nodes:
            if not node: continue
            try:
                info = await execute_lxc(f"lxc info {node}:")
                # Parse RAM usage
                lines = info.split('\n')
                for line in lines:
                    if 'Memory usage:' in line:
                        usage = line.split(':')[1].strip()
                        # Parse e.g. "1.2GB / 8.0GB (15.0%)"
                        used = usage.split('/')[0].strip()
                        if 'GB' in used:
                            used_gb = float(used.replace('GB', ''))
                        elif 'MB' in used:
                            used_gb = float(used.replace('MB', '')) / 1024
                        else:
                            continue
                        if used_gb < min_ram:
                            min_ram = used_gb
                            best_node = node + ':'
                        break
            except:
                continue
        return best_node
    except:
        return ""

async def get_or_create_vps_role(guild):
    global VPS_USER_ROLE_ID
    if VPS_USER_ROLE_ID and VPS_USER_ROLE_ID != 0:
        role = guild.get_role(VPS_USER_ROLE_ID)
        if role: return role
    role = discord.utils.get(guild.roles, name="VPS User")
    if role:
        VPS_USER_ROLE_ID = role.id
        return role
    try:
        role = await guild.create_role(
            name="VPS User",
            color=discord.Color.blue(),
            reason="Role assigned to users with active VPS instances",
            permissions=discord.Permissions.none()
        )
        VPS_USER_ROLE_ID = role.id
        return role
    except Exception as e: return None

async def auto_deploy_vps(user: discord.Member, ram: int, cpu: int, disk: int, os_version: str = "ubuntu:22.04", validity_days: Optional[int] = None):
    """Automated backend deployment function utilized for giveaways and automated systems."""
    user_id = str(user.id)
    with data_lock:
        if user_id not in vps_data: vps_data[user_id] = []
        vps_count = 1
        
        safe_username = re.sub(r'[^a-z0-9]', '', user.name.lower())
        if not safe_username: safe_username = "user" 
        
        existing_names = {v['container_name'] for lst in vps_data.values() for v in lst}
        while f"{VPS_PREFIX}-{safe_username}-{vps_count}" in existing_names:
            vps_count += 1
        container_name = f"{VPS_PREFIX}-{safe_username}-{vps_count}"
    
    expires_at = None
    if validity_days:
        expires_at = (datetime.now() + timedelta(days=validity_days)).isoformat()

    target_node = await get_best_node()
    full_cname = f"{target_node}{container_name}"

    try:
        await execute_lxc(f"lxc init {os_version} {full_cname} -s {ACTIVE_STORAGE_POOL}") 
        await execute_lxc(f"lxc config set {full_cname} limits.memory {ram}GB")
        await execute_lxc(f"lxc config set {full_cname} limits.cpu {cpu}")
        try:
            await execute_lxc(f"lxc config device set {full_cname} root size={disk}GB")
        except:
            await execute_lxc(f"lxc config device add {full_cname} root disk pool={ACTIVE_STORAGE_POOL} path=/ size={disk}GB")
        
        await apply_advanced_permissions(full_cname)
        await execute_lxc(f"lxc start {full_cname}")
        
        config_str = f"{ram}GB RAM / {cpu} CPU / {disk}GB Disk"
        vps_info = {
            "container_name": container_name, "ram": f"{ram}GB", "cpu": str(cpu),
            "storage": f"{disk}GB", "config": config_str, "os_version": os_version,
            "status": "running", "suspended": False, "whitelisted": False,
            "suspension_history": [], "created_at": datetime.now().isoformat(), "shared_with": [], "id": None,
            "expires_at": expires_at, "node": target_node.replace(":", "") if target_node else "local"
        }
        
        with data_lock:
            vps_data[user_id].append(vps_info)
        save_vps_data()
        
        subdomain_url = "None"
        if getattr(bot, 'ASM', False):
            clean_name = re.sub(r'[^a-zA-Z0-9-]', '', container_name).lower()
            result = await create_cloudflare_subdomain(clean_name)
            if result:
                subdomain_url = result
                logger.info(f"[ASM] Creating Subdomain for giveaway winner: {subdomain_url}")
        
        try:
            dm_embed = create_success_embed("🎉 VPS Created!", f"Your VPS `{container_name}` is online and ready to use.")
            add_field(dm_embed, "VPS Specs", f"```yaml\nRAM: {ram}GB\nCPU: {cpu} Cores\nDisk: {disk}GB\n```")
            add_field(dm_embed, "🌐 Domain/IP", f"http://{subdomain_url}" if subdomain_url != "None" else "Manual Setup Required", False)
            if expires_at:
                add_field(dm_embed, "⏳ Expiration", f"<t:{int(datetime.fromisoformat(expires_at).timestamp())}:R>", False)
            await user.send(embed=dm_embed)
        except: pass
    except Exception as e:
        logger.error(f"Auto Deploy Failed for {user.name}: {e}")

# --- Monitoring Functions ---

def get_cpu_usage_sync():
    try:
        if shutil.which("mpstat"):
            result = subprocess.run(['mpstat', '1', '1'], capture_output=True, text=True)
            for line in result.stdout.split('\n'):
                if 'all' in line and '%' in line: return 100.0 - float(line.split()[-1])
        else:
            result = subprocess.run(['top', '-bn1'], capture_output=True, text=True)
            for line in result.stdout.split('\n'):
                if '%Cpu(s):' in line:
                    return 100.0 - float(line.split()[7])
        return 0.0
    except: return 0.0

def get_ram_usage_sync():
    try:
        result = subprocess.run(['free', '-m'], capture_output=True, text=True)
        lines = result.stdout.splitlines()
        if len(lines) > 1:
            mem = lines[1].split()
            return (int(mem[2]) / int(mem[1]) * 100) if int(mem[1]) > 0 else 0.0
        return 0.0
    except: return 0.0

async def get_cpu_usage_async():
    return await asyncio.to_thread(get_cpu_usage_sync)

async def get_ram_usage_async():
    return await asyncio.to_thread(get_ram_usage_sync)

async def get_uptime_async():
    try: 
        proc = await asyncio.create_subprocess_exec('uptime', '-p', stdout=asyncio.subprocess.PIPE)
        stdout, _ = await proc.communicate()
        return stdout.decode().strip() if stdout else "Unknown"
    except: return "Unknown"

def resource_monitor():
    global resource_monitor_active
    while resource_monitor_active:
        try:
            if get_cpu_usage_sync() > CPU_THRESHOLD or get_ram_usage_sync() > RAM_THRESHOLD:
                logger.warning("Resource usage exceeded thresholds. Stopping all VPS.")
                subprocess.run(['lxc', 'stop', '--all', '--force'], check=True)
                with data_lock:
                    for user_id, vps_list in list(vps_data.items()):
                        for vps in vps_list:
                            if vps.get('status') == 'running': 
                                vps['status'] = 'stopped'
                save_vps_data()
                asyncio.run_coroutine_threadsafe(send_log(create_error_embed("Critical Resource Limit", "All VPS instances have been stopped due to high server load.")), bot.loop)
            time.sleep(60)
        except Exception: time.sleep(60)

monitor_thread = threading.Thread(target=resource_monitor, daemon=True)
monitor_thread.start()

async def get_container_cpu_raw(container_name, node="local"):
    node_prefix = f"{node}:" if node != "local" else ""
    try:
        proc = await asyncio.create_subprocess_exec("lxc", "exec", f"{node_prefix}{container_name}", "--", "top", "-bn1", stdout=asyncio.subprocess.PIPE)
        stdout, _ = await proc.communicate()
        for line in stdout.decode().splitlines():
            if '%Cpu(s):' in line:
                parts = line.split()
                return sum(float(parts[i]) for i in [1,3,5,9,11,13,15])
        return 0.0
    except: return 0.0

async def get_container_memory_raw(container_name, node="local"):
    node_prefix = f"{node}:" if node != "local" else ""
    try:
        proc = await asyncio.create_subprocess_exec("lxc", "exec", f"{node_prefix}{container_name}", "--", "free", "-m", stdout=asyncio.subprocess.PIPE)
        stdout, _ = await proc.communicate()
        lines = stdout.decode().splitlines()
        if len(lines) > 1:
            parts = lines[1].split()
            used = int(parts[2])
            total = int(parts[1])
            percent = (used / total) * 100 if total > 0 else 0
            return f"{used}/{total} MB", percent
        return "Unknown", 0.0
    except: return "Unknown", 0.0

async def get_container_disk(container_name, node="local"):
    node_prefix = f"{node}:" if node != "local" else ""
    try:
        proc = await asyncio.create_subprocess_exec("lxc", "exec", f"{node_prefix}{container_name}", "--", "df", "-h", "/", stdout=asyncio.subprocess.PIPE)
        stdout, _ = await proc.communicate()
        for line in stdout.decode().splitlines():
            if '/dev/' in line and ' /' in line:
                parts = line.split()
                return f"{parts[2]}/{parts[1]} ({parts[4]})"
        return "Unknown"
    except: return "Unknown"

# --- Events ---

@bot.event
async def on_ready():
    logger.info(f'{bot.user} has connected to Discord!')
    logger.info(f"Storage Pool: {ACTIVE_STORAGE_POOL}")
    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name="VPS Management System"))
    logger.info("Bot is ready!")



# --- Views & Modals ---

class PinModal(discord.ui.Modal, title="Admin 2FA Verification"):
    pin = discord.ui.TextInput(label="Enter your 4-digit Admin PIN", style=discord.TextStyle.short, min_length=4, max_length=4)
    
    def __init__(self, view):
        super().__init__()
        self.view_obj = view

    async def on_submit(self, interaction: discord.Interaction):
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT pin FROM admins WHERE user_id=?", (str(interaction.user.id),))
        row = cur.fetchone()
        conn.close()
        
        actual_pin = row['pin'] if row and row['pin'] else "0000"
        
        if self.pin.value == actual_pin:
            self.view_obj.value = True
            self.view_obj.stop()
            await interaction.response.defer()
        else:
            await interaction.response.send_message(embed=create_error_embed("Verification Failed", "Incorrect PIN provided. Action aborted."), ephemeral=True)


class ConfirmView(discord.ui.View):
    def __init__(self, user_id, requires_2fa=False):
        super().__init__(timeout=60)
        self.user_id = user_id
        self.value = None
        self.requires_2fa = requires_2fa

    @discord.ui.button(label="Confirm", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        if str(interaction.user.id) != self.user_id: return await interaction.response.send_message("Unauthorized.", ephemeral=True)
        
        if self.requires_2fa and A2FA:
            await interaction.response.send_modal(PinModal(self))
        else:
            self.value = True
            self.stop()
            await interaction.response.defer()

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        if str(interaction.user.id) != self.user_id: return await interaction.response.send_message("Unauthorized.", ephemeral=True)
        self.value = False
        self.stop()
        await interaction.response.defer()


class ResizeModal(discord.ui.Modal, title="Resize VPS Instance"):
    def __init__(self, container_name, current_ram, current_cpu, current_disk, node):
        super().__init__()
        self.container_name = container_name
        self.node_prefix = f"{node}:" if node != "local" else ""
        
        self.ram = discord.ui.TextInput(label="RAM (GB)", default=str(current_ram).replace("GB","").strip(), placeholder="e.g. 4", min_length=1, max_length=3)
        self.cpu = discord.ui.TextInput(label="CPU Cores", default=str(current_cpu), placeholder="e.g. 2", min_length=1, max_length=2)
        self.disk = discord.ui.TextInput(label="Disk Space (GB)", default=str(current_disk).replace("GB","").strip(), placeholder="e.g. 20", min_length=1, max_length=4)
        
        self.add_item(self.ram)
        self.add_item(self.cpu)
        self.add_item(self.disk)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        
        try:
            ram_val = int(self.ram.value)
            cpu_val = int(self.cpu.value)
            disk_val = int(self.disk.value)
        except ValueError:
            return await interaction.followup.send(embed=create_error_embed("Invalid Input", "RAM, CPU, and Disk must be numbers."), ephemeral=True)

        if ENFORCE_RESOURCE_LIMITS and (ram_val > MAX_RAM_LIMIT or cpu_val > MAX_CPU_LIMIT):
             return await interaction.followup.send(embed=create_error_embed("Resource Limit Exceeded", f"Maximum RAM limit is {MAX_RAM_LIMIT}GB\nMaximum CPU limit is {MAX_CPU_LIMIT} Cores"), ephemeral=True)

        try:
            full_cname = f"{self.node_prefix}{self.container_name}"
            await execute_lxc(f"lxc config set {full_cname} limits.memory {ram_val}GB")
            await execute_lxc(f"lxc config set {full_cname} limits.cpu {cpu_val}")
            try: await execute_lxc(f"lxc config device set {full_cname} root size={disk_val}GB")
            except: pass 

            with data_lock:
                for uid, vps_list in vps_data.items():
                    for vps in vps_list:
                        if vps['container_name'] == self.container_name:
                            vps['ram'] = f"{ram_val}GB"
                            vps['cpu'] = cpu_val
                            vps['storage'] = f"{disk_val}GB"
                            vps['config'] = f"{ram_val}GB RAM / {cpu_val} CPU / {disk_val}GB Disk"
            save_vps_data()
            
            embed = create_success_embed("VPS Resized", f"Successfully updated resources for **{self.container_name}**")
            add_field(embed, "New Specs", f"```yaml\nRAM: {ram_val}GB\nCPU: {cpu_val} Cores\nDisk: {disk_val}GB\n```")
            await interaction.followup.send(embed=embed, ephemeral=True)
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Resize Failed", str(e)), ephemeral=True)

class SoftwareView(discord.ui.View):
    def __init__(self, user_id, container_name, node):
        super().__init__(timeout=180)
        self.user_id = user_id
        self.container_name = container_name
        self.node_prefix = f"{node}:" if node != "local" else ""
        self.add_buttons()

    def add_buttons(self):
        for key, script in SOFTWARE_SCRIPTS.items():
            btn = discord.ui.Button(label=script['name'], style=discord.ButtonStyle.secondary, custom_id=key, row=0 if len(self.children) < 3 else 1 if len(self.children) < 6 else 2)
            btn.callback = self.make_callback(key)
            self.add_item(btn)

    def make_callback(self, key):
        async def callback(interaction: discord.Interaction):
            if str(interaction.user.id) != self.user_id: return await interaction.response.send_message("You do not have permission to do this.", ephemeral=True)
            script_data = SOFTWARE_SCRIPTS[key]
            full_cname = f"{self.node_prefix}{self.container_name}"
            
            try:
                await execute_lxc(f"lxc exec {full_cname} -- ping -c 1 -W 3 8.8.8.8", timeout=5)
            except Exception:
                return await interaction.response.send_message(embed=create_error_embed("Network Error", "The VPS does not have internet access. Please contact an admin."), ephemeral=True)

            await interaction.response.send_message(embed=create_info_embed(f"Installing {script_data['name']}", "Please wait while the software is being installed..."), ephemeral=True)
            try:
                cmd = script_data['cmd']
                await execute_lxc(f"lxc exec {full_cname} -- sh -c '{cmd}'", timeout=600)
                await interaction.followup.send(embed=create_success_embed("Installation Complete", f"**{script_data['name']}** has been installed on `{self.container_name}`."), ephemeral=True)
            except Exception as e:
                await interaction.followup.send(embed=create_error_embed("Installation Failed", str(e)[:4000]), ephemeral=True)
        return callback

class AdminVPSView(discord.ui.View):
    def __init__(self, user_id, vps_dict, owner_id):
        super().__init__(timeout=300)
        self.user_id = user_id
        self.vps = vps_dict
        self.owner_id = owner_id
        self.container_name = vps_dict['container_name']
        self.node = vps_dict.get('node', 'local')
        self.node_prefix = f"{self.node}:" if self.node != "local" else ""
        self.is_suspended = self.vps.get('suspended', False)
        self.update_buttons()

    def update_buttons(self):
        self.clear_items()
        if self.is_suspended: label, style, emoji = "Unsuspend", discord.ButtonStyle.success, "▶️"
        else: label, style, emoji = "Suspend", discord.ButtonStyle.danger, "⛔"

        suspend_btn = discord.ui.Button(label=label, style=style, emoji=emoji, row=0)
        suspend_btn.callback = self.toggle_suspend
        self.add_item(suspend_btn)

        resize_btn = discord.ui.Button(label="Resize", style=discord.ButtonStyle.primary, emoji="📏", row=0)
        resize_btn.callback = self.resize_vps
        self.add_item(resize_btn)

        refresh_btn = discord.ui.Button(label="Refresh", style=discord.ButtonStyle.secondary, emoji="🔄", row=0)
        refresh_btn.callback = self.refresh_view
        self.add_item(refresh_btn)

        owner_btn = discord.ui.Button(label="Change Owner", style=discord.ButtonStyle.secondary, emoji="👤", row=1)
        owner_btn.callback = self.change_owner
        self.add_item(owner_btn)

        delete_btn = discord.ui.Button(label="Delete VPS", style=discord.ButtonStyle.danger, emoji="🗑️", row=1)
        delete_btn.callback = self.delete_vps_btn
        self.add_item(delete_btn)

    async def refresh_view(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.user_id: return
        await interaction.response.defer(ephemeral=True)
        target_vps = None
        with data_lock:
            if self.owner_id in vps_data:
                for v in vps_data[self.owner_id]:
                    if v['container_name'] == self.container_name:
                        target_vps = v
                        break
        if target_vps:
            self.vps = target_vps
            self.is_suspended = target_vps.get('suspended', False)
            self.update_buttons()
            status_text = "⛔ Suspended" if self.is_suspended else "🟢 Running"
            embed = create_warning_embed(f"🛡️ Admin Panel: {self.container_name}", f"**Status:** {status_text}\n*Data Refreshed.*")
            await interaction.edit_original_response(embed=embed, view=self)
        else:
            await interaction.followup.send(embed=create_error_embed("Error", "VPS not found."), ephemeral=True)

    async def toggle_suspend(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.user_id: return
        await interaction.response.defer(ephemeral=True)
        try:
            full_cname = f"{self.node_prefix}{self.container_name}"
            if self.is_suspended:
                await execute_lxc(f"lxc start {full_cname}")
                with data_lock:
                    self.vps['suspended'] = False
                    self.vps['status'] = 'running'
                self.is_suspended = False
                msg = "Unsuspended"
            else:
                await execute_lxc(f"lxc stop {full_cname}")
                with data_lock:
                    self.vps['suspended'] = True
                    self.vps['status'] = 'stopped'
                    self.vps['suspension_history'].append({'time': datetime.now().isoformat(), 'reason': 'Suspended by Admin', 'by': interaction.user.name})
                self.is_suspended = True
                msg = "Suspended"
            
            save_vps_data()
            self.update_buttons()
            status_text = "⛔ Suspended" if self.is_suspended else "🟢 Running"
            embed = create_warning_embed(f"🛡️ Admin Panel: {self.container_name}", f"**Status:** {status_text}\nVPS was **{msg}** successfully.")
            await interaction.edit_original_response(embed=embed, view=self)
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Error", str(e)[:4000]), ephemeral=True)

    async def resize_vps(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.user_id: return
        await interaction.response.send_modal(ResizeModal(self.container_name, self.vps.get('ram', '1GB'), self.vps.get('cpu', '1'), self.vps.get('storage', '10GB'), self.node))

    async def change_owner(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.user_id: return
        await interaction.response.send_message(embed=create_info_embed("Change Owner", "Please mention the new user in the chat (e.g. @User)."), ephemeral=True)
        def check(m): return m.author.id == interaction.user.id and m.channel.id == interaction.channel.id and len(m.mentions) > 0
        try:
            msg = await bot.wait_for('message', check=check, timeout=30.0)
            new_owner = msg.mentions[0]
            new_id = str(new_owner.id)
            if new_id == self.owner_id: return await interaction.followup.send(embed=create_error_embed("Error", "User is already the owner."), ephemeral=True)

            changed = False
            with data_lock:
                if self.owner_id in vps_data:
                    idx = next((i for i, v in enumerate(vps_data[self.owner_id]) if v['container_name'] == self.container_name), -1)
                    if idx != -1:
                        vps_obj = vps_data[self.owner_id].pop(idx)
                        if new_id not in vps_data: vps_data[new_id] = []
                        vps_data[new_id].append(vps_obj)
                        if not vps_data[self.owner_id]: del vps_data[self.owner_id]
                        changed = True
                        
            if changed:
                save_vps_data()
                await interaction.followup.send(embed=create_success_embed("Owner Changed", f"VPS ownership successfully transferred to {new_owner.mention}."), ephemeral=True)
        except asyncio.TimeoutError:
            await interaction.followup.send(embed=create_warning_embed("Timeout", "You did not mention a user in time. Cancelled."), ephemeral=True)

    async def delete_vps_btn(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.user_id: return
        view = ConfirmView(self.user_id, requires_2fa=True)
        await interaction.response.send_message(embed=create_warning_embed("Delete VPS?", f"Are you sure you want to delete `{self.container_name}`? All data will be lost."), view=view, ephemeral=True)
        await view.wait()
        if view.value:
            await interaction.edit_original_response(embed=create_info_embed("Deleting", "Deleting the VPS..."), view=None)
            try:
                full_cname = f"{self.node_prefix}{self.container_name}"
                await execute_lxc(f"lxc delete {full_cname} --force")
                with data_lock:
                    if self.owner_id in vps_data:
                        vps_data[self.owner_id] = [v for v in vps_data[self.owner_id] if v['container_name'] != self.container_name]
                        if not vps_data[self.owner_id]: del vps_data[self.owner_id]
                save_vps_data()
                await interaction.followup.send(embed=create_success_embed("Deleted", "VPS has been deleted."), ephemeral=True)
            except Exception as e:
                await interaction.followup.send(embed=create_error_embed("Error", str(e)[:4000]), ephemeral=True)

class SshTailscaleView(discord.ui.View):
    def __init__(self, user_id, container_name, node_prefix):
        super().__init__(timeout=180)
        self.user_id = user_id
        self.container_name = container_name
        self.node_prefix = node_prefix

    @discord.ui.button(label="Tailscale", style=discord.ButtonStyle.primary, emoji="🌐")
    async def btn_tailscale(self, interaction: discord.Interaction, button: discord.ui.Button):
        if str(interaction.user.id) != self.user_id:
            return await interaction.response.send_message("Permission Denied.", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        
        full_cname = f"{self.node_prefix}{self.container_name}"
        try:
            check_proc = await asyncio.create_subprocess_exec("lxc", "exec", full_cname, "--", "which", "tailscale", stdout=asyncio.subprocess.PIPE)
            await check_proc.communicate()
            if check_proc.returncode != 0:
                await interaction.followup.send(embed=create_info_embed("Installing Tailscale", "Setting up Tailscale on your VPS for the first time... This may take a minute."), ephemeral=True)
                await execute_lxc(f"lxc exec {full_cname} -- sh -c 'curl -fsSL https://tailscale.com/install.sh | sh'")
            
            proc = await asyncio.create_subprocess_exec(
                "lxc", "exec", full_cname, "--", "tailscale", "up", "--reset",
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
            
            async def read_stream(stream):
                while True:
                    line = await stream.readline()
                    if not line: break
                    decoded = line.decode().strip()
                    if "https://login.tailscale.com/a/" in decoded:
                        for word in decoded.split():
                            if word.startswith("https://login.tailscale.com/a/"):
                                return word
                return None

            done, pending = await asyncio.wait(
                [
                    asyncio.create_task(read_stream(proc.stdout)),
                    asyncio.create_task(read_stream(proc.stderr))
                ],
                return_when=asyncio.FIRST_COMPLETED,
                timeout=10.0
            )

            auth_link = None
            for task in done:
                res = task.result()
                if res:
                    auth_link = res
                    break
                    
            for task in pending:
                task.cancel()

            if not auth_link:
                status_proc = await asyncio.create_subprocess_exec("lxc", "exec", full_cname, "--", "tailscale", "status", stdout=asyncio.subprocess.PIPE)
                stdout, _ = await status_proc.communicate()
                if "Logged out" not in stdout.decode():
                    return await interaction.followup.send(embed=create_info_embed("Tailscale Active", "Your VPS is already connected to a Tailnet. You can disconnect via SSH by typing `tailscale logout`."), ephemeral=True)
                return await interaction.followup.send(embed=create_error_embed("Tailscale Error", "Could not generate authentication link automatically. Please check your VPS connection."), ephemeral=True)

            embed = create_success_embed("Tailscale Authentication", "Click the link below to securely connect your VPS to your Tailscale network.")
            add_field(embed, "Authentication Link", f"**Click Here to Authenticate**", False)
            add_field(embed, "Instructions", "Once approved, your VPS will automatically join your Tailnet.", False)
            
            await interaction.user.send(embed=embed)
            await interaction.followup.send(embed=create_success_embed("Success", "I've sent you a direct message with the Tailscale authentication link!"), ephemeral=True)
            
        except discord.Forbidden:
            await interaction.followup.send(embed=create_error_embed("DM Failed", "I couldn't send you a DM. Please check your privacy settings."), ephemeral=True)
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Error", str(e)), ephemeral=True)

    @discord.ui.button(label="Standard SSH", style=discord.ButtonStyle.secondary, emoji="💻")
    async def btn_ssh(self, interaction: discord.Interaction, button: discord.ui.Button):
        if str(interaction.user.id) != self.user_id:
            return await interaction.response.send_message("Permission Denied.", ephemeral=True)
        
        await interaction.response.defer(ephemeral=True)
        full_cname = f"{self.node_prefix}{self.container_name}"
        try:
            proc = await asyncio.create_subprocess_exec("lxc", "list", full_cname, "-c", "4", "--format", "csv", stdout=asyncio.subprocess.PIPE)
            stdout, _ = await proc.communicate()
            ip_address = stdout.decode().strip().split()[0] if stdout and stdout.decode().strip() else "Unknown (Check Console)"
            
            embed = create_info_embed("Standard SSH Access", "Use the details below to connect via SSH:")
            add_field(embed, "IP Address", f"`{ip_address}`", True)
            add_field(embed, "User", "`root`", True)
            add_field(embed, "Connection Command", f"`ssh root@{ip_address}`", False)
            add_field(embed, "Password", "*Use the Console button on the dashboard to set a password via `passwd` first!*", False)
            
            await interaction.followup.send(embed=embed, ephemeral=True)
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Error", str(e)), ephemeral=True)

class ManageView(discord.ui.View):
    def __init__(self, user_id, vps_list, is_shared=False, owner_id=None, is_admin=False, actual_index: Optional[int] = None):
        super().__init__(timeout=None)
        self.user_id = user_id
        self.vps_list_initial = vps_list 
        self.selected_index = None
        self.is_shared = is_shared
        self.owner_id = owner_id or user_id
        self.is_admin = is_admin
        self.actual_index = actual_index
        self.indices = list(range(len(vps_list)))
        self.cooldowns = {}
        self.permissions = []

        if self.is_shared and self.actual_index is None: raise ValueError("actual_index required")

        # Determine permissions
        if not self.is_shared or self.is_admin:
            self.permissions = ['all']
        else:
            vps = vps_list[0]
            shared_with_data = vps.get("shared_with", [])
            if len(shared_with_data) > 0 and isinstance(shared_with_data[0], str): # Legacy format
                if user_id in shared_with_data: self.permissions = ['all']
            else: # New format
                for user_entry in shared_with_data:
                    if user_entry.get('user_id') == user_id:
                        self.permissions = user_entry.get('permissions', [])
                        break
        
        if len(vps_list) > 1 and self.actual_index is None:
            options = [discord.SelectOption(label=f"VPS {i+1} ({v.get('config', 'Custom')})", value=str(i), emoji="🖥️") for i, v in enumerate(vps_list)]
            self.select = discord.ui.Select(placeholder="▼ Select a VPS to Manage", options=options)
            self.select.callback = self.select_vps
            self.add_item(self.select)
            self.initial_embed = create_embed("🎛️ VPS Control Panel", "Select a VPS from the dropdown menu to control it.")
        else:
            self.selected_index = 0
            self.initial_embed = None
            self.add_action_buttons()

    def has_permission(self, perm: str) -> bool:
        return 'all' in self.permissions or perm in self.permissions

    def check_cooldown(self, user_id, command_name):
        key = f"{user_id}:{command_name}"
        if key in self.cooldowns:
            if time.time() - self.cooldowns[key] < 5: return False
        self.cooldowns[key] = time.time()
        return True

    async def get_initial_embed(self):
        if self.initial_embed: return self.initial_embed
        return await self.create_vps_embed(self.selected_index)

    def get_vps_data_safe(self, index):
        try:
            actual_idx = self.actual_index if (self.is_shared or self.actual_index is not None) else self.indices[index]
            with data_lock:
                if self.owner_id in vps_data and len(vps_data[self.owner_id]) > actual_idx:
                    return vps_data[self.owner_id][actual_idx], actual_idx
        except: pass
        return None, None

    async def create_vps_embed(self, index):
        vps, _ = self.get_vps_data_safe(index)
        if not vps: return create_error_embed("Error", "Could not fetch VPS details.")
        
        container_name = vps['container_name']
        node = vps.get('node', 'local')
        status = vps.get('status', 'stopped')
        suspended = vps.get('suspended', False)

        color = Theme.get_status_color(status, suspended)
        if status == 'running' and not suspended:
            status_text = f"RUNNING"
            status_indicator = Theme.ONLINE
            cpu_val = await get_container_cpu_raw(container_name, node)
            mem_str, mem_val = await get_container_memory_raw(container_name, node)
            disk_usage = await get_container_disk(container_name, node)
        else:
            status_text = f"SUSPENDED" if suspended else f"STOPPED"
            status_indicator = Theme.OFFLINE
            cpu_val, mem_val, mem_str, disk_usage = 0, 0, "0/0 MB", "Offline"

        embed = create_embed(f"✨ Live Dashboard: {container_name}", "Real-time hardware metrics and management.", color)
        
        embed.add_field(name="📍 System State", value=f"> {status_indicator} **{status_text}**", inline=True)
        embed.add_field(name="⚙️ Hardware Allocation", value=f"> **{vps.get('config', 'Custom')}**", inline=True)
        
        if vps.get('expires_at'):
            embed.add_field(name="⏳ Expires", value=f"> <t:{int(datetime.fromisoformat(vps['expires_at']).timestamp())}:R>", inline=True)
            
        embed.add_field(name="\u200b", value=f"`{Theme.DIVIDER}`", inline=False)
        
        embed.add_field(name=f"{Theme.CPU} Processor Usage", value=f"**{cpu_val:.1f}%**\n{Theme.progress_bar(cpu_val, 14)}", inline=True)
        embed.add_field(name=f"{Theme.RAM} Memory Usage", value=f"**{mem_str}**\n{Theme.progress_bar(mem_val, 14)}", inline=True)
        embed.add_field(name=f"{Theme.DISK} Storage I/O", value=f"```yaml\n{disk_usage}\n```", inline=False)
        
        return embed

    def make_action_callback(self, action: str):
        async def callback(interaction: discord.Interaction):
            await self.action_callback(interaction, action)
        return callback

    def add_action_buttons(self):
        if self.has_permission('reinstall'):
            reinstall = discord.ui.Button(label="Reinstall OS", style=discord.ButtonStyle.danger, emoji="🔄", row=0)
            reinstall.callback = self.make_action_callback('reinstall')
            self.add_item(reinstall)

        if self.has_permission('start'):
            start = discord.ui.Button(label="Start", style=discord.ButtonStyle.success, emoji="▶️", row=0)
            start.callback = self.make_action_callback('start')
            self.add_item(start)

        if self.has_permission('stop'):
            stop = discord.ui.Button(label="Stop", style=discord.ButtonStyle.secondary, emoji="⏸️", row=0)
            stop.callback = self.make_action_callback('stop')
            self.add_item(stop)

        if self.has_permission('tmate'):
            ssh = discord.ui.Button(label="SSH & Tailscale", style=discord.ButtonStyle.primary, emoji="🔑", row=0)
            ssh.callback = self.make_action_callback('tmate')
            self.add_item(ssh)

        stats = discord.ui.Button(label="Refresh Stats", style=discord.ButtonStyle.secondary, emoji="🔄", row=0)
        stats.callback = self.make_action_callback('stats')
        self.add_item(stats)
        
        if self.has_permission('console'):
            console = discord.ui.Button(label="Console Logs", style=discord.ButtonStyle.secondary, emoji="💻", row=1)
            console.callback = self.make_action_callback('console')
            self.add_item(console)
        
        if self.has_permission('software'):
            soft = discord.ui.Button(label="Install Software", style=discord.ButtonStyle.secondary, emoji="💿", row=1)
            soft.callback = self.make_action_callback('software')
            self.add_item(soft)

        if self.is_admin:
            admin_btn = discord.ui.Button(label="Admin Panel", style=discord.ButtonStyle.danger, emoji="🛡️", row=1)
            admin_btn.callback = self.open_admin_panel
            self.add_item(admin_btn)

    async def select_vps(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.user_id and not self.is_admin:
            return await interaction.response.send_message("Permission Denied.", ephemeral=True)
        await interaction.response.defer()
        self.selected_index = int(self.select.values[0])
        self.clear_items()
        self.add_action_buttons()
        embed = await self.create_vps_embed(self.selected_index)
        await interaction.edit_original_response(embed=embed, view=self)

    async def open_admin_panel(self, interaction: discord.Interaction):
        target_vps, _ = self.get_vps_data_safe(self.selected_index or 0)
        if not target_vps: return
        admin_view = AdminVPSView(str(interaction.user.id), target_vps, self.owner_id)
        await interaction.response.send_message(embed=create_warning_embed(f"🛡️ Admin Panel: {target_vps['container_name']}", "Use these controls carefully."), view=admin_view, ephemeral=True)

    async def action_callback(self, interaction: discord.Interaction, action: str):
        # Server-side permission check
        if action != 'stats' and not self.has_permission(action):
            return await interaction.response.send_message("You do not have permission to perform this action.", ephemeral=True)

        if str(interaction.user.id) != self.user_id and not self.is_admin:
            return await interaction.response.send_message("Permission Denied.", ephemeral=True)
            
        target_vps, _ = self.get_vps_data_safe(self.selected_index or 0)
        if not target_vps: return
        container_name = target_vps["container_name"]
        node = target_vps.get('node', 'local')
        node_prefix = f"{node}:" if node != "local" else ""
        full_cname = f"{node_prefix}{container_name}"
        
        if action == 'software':
            view = SoftwareView(str(interaction.user.id), container_name, node)
            await interaction.response.send_message(embed=create_info_embed("Software Installer", "Install common packages on your VPS."), view=view, ephemeral=True)

        elif action == 'reinstall':
            view = ConfirmView(str(interaction.user.id))
            await interaction.response.send_message(embed=create_warning_embed("Reinstall OS?", "WARNING: This will delete all files on your VPS permanently."), view=view, ephemeral=True)
            await view.wait()
            if not view.value: return
            await interaction.edit_original_response(embed=create_info_embed(f"{Theme.LOADING} Reinstalling OS...", f"Please wait while `{container_name}` is reinstalled."), view=None)
            try:
                await execute_lxc(f"lxc delete {full_cname} --force")
                await execute_lxc(f"lxc init {target_vps['os_version']} {full_cname} -s {ACTIVE_STORAGE_POOL}")
                await execute_lxc(f"lxc config set {full_cname} limits.memory {target_vps['ram']}")
                await execute_lxc(f"lxc config set {full_cname} limits.cpu {target_vps['cpu']}")
                try: await execute_lxc(f"lxc config device set {full_cname} root size={target_vps['storage']}")
                except: await execute_lxc(f"lxc config device add {full_cname} root disk pool={ACTIVE_STORAGE_POOL} path=/ size={target_vps['storage']}")
                await apply_advanced_permissions(full_cname)
                await execute_lxc(f"lxc start {full_cname}")
                with data_lock:
                    target_vps["status"] = "running"
                    target_vps["suspended"] = False
                save_vps_data()
                await interaction.followup.send(embed=create_success_embed("Reinstall Complete", "Your VPS has been successfully reinstalled."), ephemeral=True)
            except Exception as e: await interaction.followup.send(embed=create_error_embed("Reinstall Failed", str(e)[:4000]), ephemeral=True)

        elif action == 'start':
            if not self.check_cooldown(interaction.user.id, "start"): return await interaction.response.send_message("Please wait a few seconds before clicking again.", ephemeral=True)
            await interaction.response.defer(ephemeral=True)
            try:
                await execute_lxc(f"lxc start {full_cname}")
                with data_lock: target_vps["status"] = "running"
                save_vps_data()
                await interaction.followup.send(embed=create_success_embed("Started", f"`{container_name}` is now running."), ephemeral=True)
                await send_audit_log(create_info_embed("VPS Started", f"User {interaction.user} started {container_name}"))
            except Exception as e: await interaction.followup.send(embed=create_error_embed("Failed to Start", str(e)[:4000]), ephemeral=True)

        elif action == 'stop':
            if not self.check_cooldown(interaction.user.id, "stop"): return await interaction.response.send_message("Please wait a few seconds before clicking again.", ephemeral=True)
            await interaction.response.defer(ephemeral=True)
            try:
                await execute_lxc(f"lxc stop {full_cname}")
                with data_lock: target_vps["status"] = "stopped"
                save_vps_data()
                await interaction.followup.send(embed=create_success_embed("Stopped", f"`{container_name}` has been stopped."), ephemeral=True)
                await send_audit_log(create_warning_embed("VPS Stopped", f"User {interaction.user} stopped {container_name}"))
            except Exception as e: await interaction.followup.send(embed=create_error_embed("Failed to Stop", str(e)[:4000]), ephemeral=True)

        elif action == 'stats':
            await interaction.response.defer(ephemeral=True)
            await interaction.followup.send(embed=create_info_embed("Stats Refreshed", "Live server statistics have been updated above."), ephemeral=True)
        
        elif action == 'console':
            await interaction.response.defer(ephemeral=True)
            try:
                logs = await execute_lxc(f"lxc info {full_cname} --show-log")
                lines = logs.splitlines()[-15:]
                log_text = "\n".join(lines)
                if not log_text: log_text = "No console output available."
                await interaction.followup.send(embed=create_info_embed("Console Output", f"```bash\n{log_text}\n```"), ephemeral=True)
            except Exception as e: await interaction.followup.send(embed=create_error_embed("Error", str(e)[:4000]), ephemeral=True)

        elif action == 'tmate':
            view = SshTailscaleView(str(interaction.user.id), container_name, node_prefix)
            await interaction.response.send_message(embed=create_info_embed("Connection Options", "Choose how you want to connect to your VPS:"), view=view, ephemeral=True)

        try:
             new_embed = await self.create_vps_embed(self.selected_index or 0)
             await interaction.message.edit(embed=new_embed, view=self)
        except: pass

# --- PAYMENT SELECT VIEW ---
class PaymentSelect(discord.ui.Select):
    def __init__(self, payments):
        options = [discord.SelectOption(label=p['name'], value=p['name'], emoji="💳") for p in payments]
        super().__init__(placeholder="▼ Select a Payment Method", options=options)
        self.payments = {p['name']: p['image_url'] for p in payments}

    async def callback(self, interaction: discord.Interaction):
        selected = self.values[0]
        image_url = self.payments[selected]
        
        embed = create_info_embed(f"Payment Method: {selected}", f"Please scan the QR code or use the details below to complete your payment.")
        embed.set_image(url=image_url)
        
        try:
            await interaction.user.send(embed=embed)
            await interaction.response.send_message(f"✅ The **{selected}** payment details have been sent to your DMs!", ephemeral=True)
        except discord.Forbidden:
            await interaction.response.send_message("❌ I couldn't send you a DM. Please check your privacy settings and try again.", ephemeral=True)

class PlansView(discord.ui.View):
    def __init__(self, payments):
        super().__init__(timeout=None)
        if payments:
            self.add_item(PaymentSelect(payments))

class OSSelectView(discord.ui.View):
    def __init__(self, ram: int, cpu: int, disk: int, user: discord.Member, ctx, plan_name: str = "Custom", validity_days: Optional[int] = None, plan_type: str = "free"):
        super().__init__(timeout=300)
        self.ram = ram
        self.cpu = cpu
        self.disk = disk
        self.user = user
        self.ctx = ctx
        self.plan_name = plan_name
        self.validity_days = validity_days
        self.plan_type = plan_type
        self.select = discord.ui.Select(
            placeholder="Select an Operating System",
            options=[discord.SelectOption(label=o["label"], value=o["value"], description=o.get("desc", ""), emoji=o.get("emoji", "💿")) for o in OS_OPTIONS]
        )
        self.select.callback = self.select_os
        self.add_item(self.select)

    async def select_os(self, interaction: discord.Interaction):
        if str(interaction.user.id) != str(self.ctx.user.id): return await interaction.response.send_message(embed=create_error_embed("Error", "You cannot select the OS for someone else's VPS."), ephemeral=True)
        os_version = self.select.values[0]
        self.select.disabled = True
        
        await interaction.response.edit_message(embed=create_info_embed(f"{Theme.LOADING} Creating VPS", "Please wait while the server is being set up..."), view=self)
        user_id = str(self.user.id)
        
        with data_lock:
            if user_id not in vps_data: vps_data[user_id] = []
            vps_count = 1
            
            safe_username = re.sub(r'[^a-z0-9]', '', self.user.name.lower())
            if not safe_username: safe_username = "user"
            
            existing_names = {v['container_name'] for lst in vps_data.values() for v in lst}
            while f"{VPS_PREFIX}-{safe_username}-{vps_count}" in existing_names: vps_count += 1
            container_name = f"{VPS_PREFIX}-{safe_username}-{vps_count}"
        
        expires_at = None
        if self.validity_days:
            expires_at = (datetime.now() + timedelta(days=self.validity_days)).isoformat()

        target_node = await get_best_node()
        full_cname = f"{target_node}{container_name}"

        pool = ACTIVE_STORAGE_POOL
        if STORAGE_POOL_SELECTION:
            if self.plan_type == "premium":
                pool = NVME_POOL
            else:
                pool = HDD_POOL

        try:
            steps = [f"Downloading OS: {os_version}", f"Setting up container: {container_name}", f"Applying limits (RAM: {self.ram}GB, CPU: {self.cpu})", f"Setting disk space ({pool})", "Starting VPS"]
            
            async def run_creation():
                await execute_lxc(f"lxc init {os_version} {full_cname} -s {pool}", timeout=900) 
                await execute_lxc(f"lxc config set {full_cname} limits.memory {self.ram}GB")
                await execute_lxc(f"lxc config set {full_cname} limits.cpu {self.cpu}")
                try: await execute_lxc(f"lxc config device set {full_cname} root size={self.disk}GB")
                except: await execute_lxc(f"lxc config device add {full_cname} root disk pool={pool} path=/ size={self.disk}GB")
                
                try:
                    await execute_lxc(f"lxc config device set {full_cname} root limits.read 50MB") 
                    await execute_lxc(f"lxc config device set {full_cname} root limits.write 50MB")
                except: pass

                await apply_advanced_permissions(full_cname)
                await execute_lxc(f"lxc start {full_cname}")
                if ANTI_SPAM_POLICY and self.plan_type == "free":
                    await execute_lxc(f"lxc exec {full_cname} -- iptables -A OUTPUT -p tcp --dport 25 -j DROP")

            task_creation = asyncio.create_task(run_creation())
            msg = await interaction.original_response()
            start_time = time.time()
            step_idx = 0
            
            while not task_creation.done():
                elapsed = int(time.time() - start_time)
                current_step = steps[step_idx % len(steps)]
                embed_load = create_info_embed(f"{Theme.LOADING} Creating VPS", f"Time elapsed: `{elapsed}s`")
                add_field(embed_load, "Current Status", f"```yaml\n>>> {current_step}...\n```", False)
                await msg.edit(embed=embed_load)
                step_idx += 1
                await asyncio.sleep(1.5)
            
            await task_creation 
            
            config_str = f"{self.ram}GB RAM / {self.cpu} CPU / {self.disk}GB Disk"
            vps_info = {
                "container_name": container_name, "ram": f"{self.ram}GB", "cpu": str(self.cpu),
                "storage": f"{self.disk}GB", "config": config_str, "os_version": os_version,
                "status": "running", "suspended": False, "whitelisted": False,
                "suspension_history": [], "created_at": datetime.now().isoformat(), "shared_with": [], "id": None,
                "expires_at": expires_at, "node": target_node.replace(":", "") if target_node else "local"
            }
            
            with data_lock:
                vps_data[user_id].append(vps_info)
                new_vps_list = vps_data[user_id]
                new_vps_index = len(new_vps_list) - 1
            save_vps_data()
            
            if self.ctx.guild:
                role = await get_or_create_vps_role(self.ctx.guild)
                if role: 
                    try: await self.user.add_roles(role)
                    except: pass
                    
            subdomain_url = "None"
            if getattr(bot, 'ASM', False):
                clean_name = re.sub(r'[^a-zA-Z0-9-]', '', container_name).lower()
                result = await create_cloudflare_subdomain(clean_name)
                if result:
                    subdomain_url = result
            
            embed = create_success_embed("VPS Created!", "Your server is now online.")
            add_field(embed, "Owner", self.user.mention, True)
            add_field(embed, "VPS Name", f"`{container_name}`", True)
            add_field(embed, "Specs", f"```yaml\nRAM: {self.ram}GB\nCPU: {self.cpu}\nDisk: {self.disk}GB\n```", False)
            add_field(embed, "🌐 Domain Info", f"http://{subdomain_url}" if subdomain_url != "None" else "No automated domain created.", False)
            if expires_at:
                add_field(embed, "⏳ Expiration", f"<t:{int(datetime.fromisoformat(expires_at).timestamp())}:R>", False)
                
            view = ManageView(user_id, new_vps_list, actual_index=new_vps_index)
            await interaction.edit_original_response(embed=embed, view=view)
            await send_log(embed)
            
            try: await self.user.send(embed=create_success_embed("VPS Created", f"Your VPS `{container_name}` is ready."))
            except: pass
        except Exception as e:
            logger.error(f"Creation Exception: {e}")
            await interaction.edit_original_response(embed=create_error_embed("Failed to Create VPS", f"Error: `{str(e)[:4000]}`"), view=None)

class CloseTicketView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Close Ticket", style=discord.ButtonStyle.danger, emoji="🔒", custom_id="persistent_close_ticket")
    async def close_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT user_id FROM tickets WHERE channel_id = ?", (str(interaction.channel.id),))
        ticket = cur.fetchone()
        if not ticket and not is_admin_check(interaction.user.id):
            conn.close()
            return await interaction.response.send_message(embed=create_error_embed("Permission Denied", "You don't have permission to close this ticket."), ephemeral=True)
            
        await interaction.response.send_message(embed=create_info_embed("Closing Ticket", "This ticket will be permanently closed and deleted in 5 seconds..."))
        cur.execute("UPDATE tickets SET status = 'closed', closed_at = ? WHERE channel_id = ?", (datetime.now().isoformat(), str(interaction.channel.id)))
        conn.commit()
        conn.close()
        
        await asyncio.sleep(5)
        try:
            await interaction.channel.delete()
        except Exception as e:
            logger.error(f"Failed to delete ticket channel: {e}")

class GiveawayView(discord.ui.View):
    def __init__(self, g_id):
        super().__init__(timeout=None)
        self.g_id = g_id
        self.entrants = set()

    @discord.ui.button(label="Join Giveaway", style=discord.ButtonStyle.success, emoji="🎉", custom_id="join_giveaway_btn")
    async def join_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id in self.entrants:
            self.entrants.remove(interaction.user.id)
            await interaction.response.send_message("You have left the giveaway.", ephemeral=True)
        else:
            self.entrants.add(interaction.user.id)
            await interaction.response.send_message("You have successfully joined the giveaway!", ephemeral=True)
            
        button.label = f"Join Giveaway ({len(self.entrants)})"
        await interaction.message.edit(view=self)

# Map all global dependencies to the bot instance for cross-file Cog compatibility
bot.logger = logger
bot.get_setting = get_setting
bot.set_setting = set_setting
bot.get_db = get_db
bot.create_error_embed = create_error_embed
bot.create_success_embed = create_success_embed
bot.create_info_embed = create_info_embed
bot.create_warning_embed = create_warning_embed
bot.create_embed = create_embed
bot.add_field = add_field
bot.send_log = send_log
bot.is_admin_check = is_admin_check
bot.execute_lxc = execute_lxc
bot.data_lock = data_lock
bot.vps_data = vps_data
bot.save_vps_data = save_vps_data
bot.auto_deploy_vps = auto_deploy_vps
bot.MAIN_ADMIN_ID = MAIN_ADMIN_ID
for attr in ["ISTS", "MULTI_NODE", "ASM", "AES", "RR", "SOSB", "MAINTENANCE_MODE"]:
    setattr(bot, attr, globals()[attr])
bot.automated_backups = automated_backups
bot.expiration_monitor = expiration_monitor
bot.ConfirmView = ConfirmView
bot.CloseTicketView = CloseTicketView
bot.GiveawayView = GiveawayView
bot.active_giveaways = active_giveaways

if __name__ == "__main__":
    if DISCORD_TOKEN: 
        try: bot.run(DISCORD_TOKEN)
        except KeyboardInterrupt: logger.info("Bot stopped by user.")
    else: logger.error("Please add your Bot Token to the .env file.")