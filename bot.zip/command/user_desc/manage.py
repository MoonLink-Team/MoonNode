import discord
from discord import app_commands
from discord.ext import commands

class ManageCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="manage", description="Manage a specific VPS or open Admin management")
    async def manage_vps(self, interaction: discord.Interaction, user: discord.Member = None):
        await interaction.response.defer()
        if user:
            if not self.bot.is_admin_check(interaction.user.id):
                return await interaction.followup.send(embed=self.bot.create_error_embed("Denied", "You don't have permission to manage other users."), ephemeral=True)
            user_id = str(user.id)
            with self.bot.data_lock: vps_list = self.bot.vps_data.get(user_id, [])
            if not vps_list: return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "User has no VPS instances."), ephemeral=True)
            view = self.bot.ManageView(str(interaction.user.id), vps_list, is_admin=True, owner_id=user_id)
            await interaction.followup.send(embed=await view.get_initial_embed(), view=view)
        else:
            user_id = str(interaction.user.id)
            with self.bot.data_lock: vps_list = self.bot.vps_data.get(user_id, [])
            if not vps_list: return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "You have no VPS instances."), ephemeral=True)
            view = self.bot.ManageView(user_id, vps_list)
            await interaction.followup.send(embed=await view.get_initial_embed(), view=view)

async def setup(bot):
    await bot.add_cog(ManageCommand(bot))
