import discord
from discord import app_commands
from discord.ext import commands

class TransferCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="transfer", description="Marketplace: Transfer or sell your VPS to another user")
    async def transfer_vps(self, interaction: discord.Interaction, vps_number: int, target_user: discord.Member, price: int = 0):
        if not self.bot.MSTC: return await interaction.response.send_message(embed=self.bot.create_error_embed("Disabled", "Marketplace transfers are disabled."), ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        
        user_id = str(interaction.user.id)
        with self.bot.data_lock:
            if user_id not in self.bot.vps_data or vps_number < 1 or vps_number > len(self.bot.vps_data[user_id]): 
                return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "Invalid VPS number."))
            vps = self.bot.vps_data[user_id][vps_number-1]
            
        if price > 0:
            conn = self.bot.get_db()
            cur = conn.cursor()
            cur.execute("SELECT credits FROM users WHERE user_id=?", (str(target_user.id),))
            row = cur.fetchone()
            if not row or row['credits'] < price:
                conn.close()
                return await interaction.followup.send(embed=self.bot.create_error_embed("Transfer Failed", f"{target_user.mention} does not have enough credits ({price})."))
                
            cur.execute("UPDATE users SET credits = credits - ? WHERE user_id = ?", (price, str(target_user.id)))
            cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (user_id,))
            cur.execute("UPDATE users SET credits = credits + ? WHERE user_id = ?", (price, user_id))
            conn.commit()
            conn.close()

        with self.bot.data_lock:
            vps_obj = self.bot.vps_data[user_id].pop(vps_number-1)
            if not self.bot.vps_data[user_id]: 
                del self.bot.vps_data[user_id]
            new_id = str(target_user.id)
            if new_id not in self.bot.vps_data: 
                self.bot.vps_data[new_id] = []
            self.bot.vps_data[new_id].append(vps_obj)
            
        self.bot.save_vps_data()
        await interaction.followup.send(embed=self.bot.create_success_embed("Transferred", f"VPS transferred successfully to {target_user.mention} for {price} credits."))

async def setup(bot):
    await bot.add_cog(TransferCommand(bot))
