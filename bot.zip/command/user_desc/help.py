import discord
from discord.ext import commands
import os

class HelpCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.bot.remove_command('help')

    @commands.hybrid_command(name="help", description="Shows this help message.")
    async def help(self, ctx: commands.Context):
        embed = discord.Embed(title="Bot Commands", description="Here are the available commands:", color=discord.Color.blue())

        command_tree = {}
        for root, dirs, files in os.walk("command"):
            for dir_name in dirs:
                if dir_name not in command_tree:
                    command_tree[dir_name] = []
                
                cog_dir = os.path.join(root, dir_name)
                for cog_file in os.listdir(cog_dir):
                    if cog_file.endswith(".py"):
                        command_name = cog_file[:-3]
                        command_tree[dir_name].append(command_name)

        for category, commands_in_category in command_tree.items():
            if commands_in_category:
                embed.add_field(name=f"**{category.capitalize()}**", value="`" + "`, `".join(commands_in_category) + "`", inline=False)

        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(HelpCommand(bot))
