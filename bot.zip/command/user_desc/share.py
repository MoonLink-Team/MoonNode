import discord
from discord import app_commands
from discord.ext import commands

class ShareCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="share", description="Manage access to your VPS")
    @app_commands.choices(action=[
        app_commands.Choice(name="Set Permissions", value="set"),
        app_commands.Choice(name="Remove Access", value="remove")
    ])
    @app_commands.describe(permissions="Comma-separated list (e.g. start,stop,console). 'all' for full access.")
    async def share_cmd(self, interaction: discord.Interaction, action: str, shared_user: discord.Member, vps_number: int, permissions: str = None):
        await interaction.response.defer(ephemeral=True)
        user_id = str(interaction.user.id)
        with self.bot.data_lock:
            if user_id not in self.bot.vps_data or vps_number < 1 or vps_number > len(self.bot.vps_data[user_id]): 
                return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "Invalid VPS number."), ephemeral=True)
            
            vps = self.bot.vps_data[user_id][vps_number - 1]
            
            if "shared_with" not in vps:
                vps["shared_with"] = []
            elif len(vps["shared_with"]) > 0 and isinstance(vps["shared_with"][0], str):
                vps["shared_with"] = [{'user_id': uid, 'permissions': ['all']} for uid in vps["shared_with"]]

            shared_user_id = str(shared_user.id)
            
            if action == "set":
                perm_list = [p.strip().lower() for p in permissions.split(',')] if permissions else []
                
                user_found = False
                for shared_entry in vps["shared_with"]:
                    if shared_entry.get('user_id') == shared_user_id:
                        shared_entry['permissions'] = perm_list
                        user_found = True
                        break
                
                if not user_found:
                    vps["shared_with"].append({'user_id': shared_user_id, 'permissions': perm_list})
                
                msg = f"Permissions for {shared_user.mention} set to: `{', '.join(perm_list) or 'None'}`"
            
            else: # remove
                vps["shared_with"] = [entry for entry in vps["shared_with"] if entry.get('user_id') != shared_user_id]
                msg = f"Removed access for {shared_user.mention}"
                
        self.bot.save_vps_data()
        await interaction.followup.send(embed=self.bot.create_success_embed("Access Updated", msg))

async def setup(bot):
    await bot.add_cog(ShareCommand(bot))
