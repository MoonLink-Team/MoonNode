import discord
from discord import app_commands
from discord.ext import commands
import time

class BackupCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="backup", description="Create or restore a backup of your VPS")
    @app_commands.choices(action=[app_commands.Choice(name="Create Backup", value="create"), app_commands.Choice(name="Restore Backup", value="restore"), app_commands.Choice(name="List Backups", value="list")])
    async def backup(self, interaction: discord.Interaction, action: str, vps_number: int):
        await interaction.response.defer()
        uid = str(interaction.user.id)
        with self.bot.data_lock:
            if uid not in self.bot.vps_data or vps_number < 1 or vps_number > len(self.bot.vps_data[uid]):
                return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "Invalid VPS number."))
            vps = self.bot.vps_data[uid][vps_number-1]
            name = vps['container_name']
            node_prefix = f"{vps.get('node', 'local')}:" if vps.get('node', 'local') != 'local' else ""
            full_cname = f"{node_prefix}{name}"

        try:
            if action == "create":
                if self.bot.UBL_ENABLED:
                    out = await self.bot.execute_lxc(f"lxc info {full_cname}")
                    snaps = [line for line in out.splitlines() if "backup-" in line]
                    limit = self.bot.UBL_LIMIT
                    if "Premium" in vps.get('config', ''): limit = 3
                    if "Ultimate" in vps.get('config', ''): limit = 5
                    
                    if len(snaps) >= limit:
                        return await interaction.followup.send(embed=self.bot.create_error_embed("Limit Reached", f"You have reached your backup limit ({limit}). Please delete old backups via support ticket first."))
                
                snap_name = f"backup-{int(time.time())}"
                await self.bot.execute_lxc(f"lxc snapshot {full_cname} {snap_name}")
                await interaction.followup.send(embed=self.bot.create_success_embed("Backup Created", f"Backup `{snap_name}` was saved."))
            elif action == "list":
                out = await self.bot.execute_lxc(f"lxc info {full_cname}")
                snaps = [line for line in out.splitlines() if "backup-" in line]
                desc = "
".join(snaps) if snaps else "No backups found."
                await interaction.followup.send(embed=self.bot.create_info_embed(f"Backups for {name}", f"```
{desc}
```"))
            elif action == "restore":
                await self.bot.execute_lxc(f"lxc restore {full_cname} $(lxc info {full_cname} | grep backup- | tail -1 | awk '{{print $1}}')")
                await interaction.followup.send(embed=self.bot.create_success_embed("Restored", "VPS restored to the latest backup."))
        except Exception as e: await interaction.followup.send(embed=self.bot.create_error_embed("Error", str(e)[:4000]))

async def setup(bot):
    await bot.add_cog(BackupCommand(bot))
