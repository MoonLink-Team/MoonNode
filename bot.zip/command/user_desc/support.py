import discord
from discord import app_commands
from discord.ext import commands
import io

class SupportCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="support", description="Create or manage a support ticket")
    @app_commands.choices(ticket_action=[
        app_commands.Choice(name="Close Ticket", value="close"),
        app_commands.Choice(name="Claim Ticket", value="claim")
    ])
    @app_commands.describe(
        vps_number="The number of your VPS (1, 2, etc.)",
        issue="Describe your problem (if creating a ticket)",
        ticket_action="Manage this ticket (Admin/Staff in thread)"
    )
    async def support_cmd(self, interaction: discord.Interaction, vps_number: int, issue: str = None, ticket_action: str = None):
        if not self.bot.ISTS:
            return await interaction.response.send_message(embed=self.bot.create_error_embed("Disabled", "Support tickets are disabled."), ephemeral=True)
            
        await interaction.response.defer(ephemeral=True)
        
        if ticket_action in ["close", "claim"]:
            if not isinstance(interaction.channel, discord.Thread):
                return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "Ticket actions can only be used inside an active Support Thread."))
            
            if ticket_action == "close":
                try:
                    messages = [msg async for msg in interaction.channel.history(limit=500, oldest_first=True)]
                    transcript_lines = []
                    for m in messages:
                        time_str = m.created_at.strftime('%Y-%m-%d %H:%M:%S')
                        transcript_lines.append(f"[{time_str}] {m.author.name}: {m.clean_content}")
                        
                    transcript_text = "\n".join(transcript_lines)
                    file_obj = discord.File(io.BytesIO(transcript_text.encode('utf-8')), filename=f"{interaction.channel.name}-transcript.txt")
                    
                    embed = self.bot.create_success_embed("Ticket Closed", f"Transcript for {interaction.channel.name}")
                    await self.bot.send_log(embed, file=file_obj)
                    
                    await interaction.followup.send(embed=self.bot.create_success_embed("Closing", "Generating transcript and archiving thread..."))
                    await interaction.channel.edit(archived=True, locked=True)
                except Exception as e:
                    await interaction.followup.send(embed=self.bot.create_error_embed("Error", str(e)[:4000]))
                return
                
            elif ticket_action == "claim":
                if not self.bot.is_admin_check(interaction.user.id):
                    return await interaction.followup.send(embed=self.bot.create_error_embed("Denied", "Only admins can claim tickets."))
                
                new_name = f"{interaction.channel.name} [Claimed by {interaction.user.name}]"
                await interaction.channel.edit(name=new_name[:100])
                await interaction.channel.send(embed=self.bot.create_info_embed("Ticket Claimed", f"{interaction.user.mention} is now reviewing this ticket."))
                await interaction.followup.send(embed=self.bot.create_success_embed("Claimed", "You have claimed this ticket."))
                return

        if not isinstance(interaction.channel, discord.TextChannel):
            return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "Please run this in a regular channel to create a ticket."))
            
        if not issue:
            return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "You must describe the issue to create a ticket."))
            
        try:
            vps_info_str = "Invalid VPS Number."
            vps_target = None
            with self.bot.data_lock:
                uid_str = str(interaction.user.id)
                if uid_str in self.bot.vps_data and vps_number >= 1 and vps_number <= len(self.bot.vps_data[uid_str]):
                    vps_target = self.bot.vps_data[uid_str][vps_number - 1]
                    vps_info_str = f"• `{vps_target['container_name']}` (OS: {vps_target.get('os_version', 'Unknown')}, Specs: {vps_target.get('config', 'Unknown')})"
            
            if not vps_target:
                return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "Could not find a VPS with that number in your account."))

            thread = await interaction.channel.create_thread(name=f"ticket-{interaction.user.name}", type=discord.ChannelType.private_thread)
            await thread.add_user(interaction.user)
            
            embed = self.bot.create_info_embed(f"🎫 Support Ticket: {interaction.user.name}", f"**Issue:**\n{issue}\n\n**Affected VPS:**\n{vps_info_str}")
            await thread.send(f"<@{self.bot.MAIN_ADMIN_ID}> New ticket created by {interaction.user.mention}", embed=embed)
            await interaction.followup.send(embed=self.bot.create_success_embed("Ticket Created", f"Your private support thread has been created: {thread.mention}"))
        except Exception as e:
            await interaction.followup.send(embed=self.bot.create_error_embed("Error", str(e)[:4000]))

async def setup(bot):
    await bot.add_cog(SupportCommand(bot))
