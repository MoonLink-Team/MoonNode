import discord
from discord import app_commands
from discord.ext import commands
import re

class ClaimCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="claim", description="Claim a Free or Premium VPS plan, or redeem a Promo Code")
    @app_commands.choices(claim_type=[
        app_commands.Choice(name="Premium", value="premium"),
        app_commands.Choice(name="Free", value="free"),
        app_commands.Choice(name="Promo Code", value="code")
    ])
    @app_commands.describe(claim_type="Type of claim", code_or_plan="Code string OR plan name", proof="Receipt image (Premium)")
    async def claim_cmd(self, interaction: discord.Interaction, claim_type: str, code_or_plan: str, proof: discord.Attachment = None):
        await interaction.response.defer(ephemeral=True)
        
        # Promo Code Logic
        if claim_type == "code":
            if not self.bot.CPCS: 
                return await interaction.followup.send(embed=self.bot.create_error_embed("Disabled", "Promo Codes are currently disabled."))
            codes_data = self.bot.load_codes()
            code = code_or_plan.upper()
            if code not in codes_data: 
                return await interaction.followup.send(embed=self.bot.create_error_embed("Invalid Code", "That code does not exist."))
            
            cdata = codes_data[code]
            if cdata['used'] >= cdata['uses']: 
                return await interaction.followup.send(embed=self.bot.create_error_embed("Expired", "That code has reached its usage limit."))
            
            conn = self.bot.get_db()
            cur = conn.cursor()
            cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (str(interaction.user.id),))
            
            if cdata['type'] == 'credits':
                cur.execute("UPDATE users SET credits = credits + ? WHERE user_id = ?", (cdata['value'], str(interaction.user.id)))
                conn.commit()
                cdata['used'] += 1
                self.bot.save_codes(codes_data)
                await interaction.followup.send(embed=self.bot.create_success_embed("Code Redeemed", f"You have received **{cdata['value']} Credits**!"))
                
            conn.close()
            return

        # Standard VPS Claim Logic
        plan_name = code_or_plan.lower()
        
        if claim_type == "premium" and not self.bot.CLAIM_PREMIUM: return await interaction.followup.send(embed=self.bot.create_error_embed("Disabled", "Premium claims are currently disabled."))
        if claim_type == "free" and not self.bot.CLAIM_FREE: return await interaction.followup.send(embed=self.bot.create_error_embed("Disabled", "Free claims are currently disabled."))
        if plan_name not in self.bot.PLANS.get(claim_type, {}): return await interaction.followup.send(embed=self.bot.create_error_embed("Invalid Plan", "Check /plans to see available plan names."))

        p = self.bot.PLANS[claim_type][plan_name]
        if claim_type == "premium":
            if not proof: return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "You must attach a screenshot of your payment receipt."))
            if not proof.content_type.startswith("image/"): return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "Attachment must be an image file."))
            
            payment_ch = self.bot.get_setting('payment_channel')
            if not payment_ch or payment_ch == '0': return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "No payment channel setup by admins."))
            
            embed = self.bot.create_info_embed("New Premium VPS Request")
            embed.add_field(name="User", value=interaction.user.mention)
            embed.add_field(name="Plan Requested", value=plan_name)
            embed.set_image(url=proof.url)
            channel = interaction.guild.get_channel(int(payment_ch))
            if channel: await channel.send(f"<@{self.bot.MAIN_ADMIN_ID}>", embed=embed)
            await interaction.followup.send(embed=self.bot.create_success_embed("Sent", "Your claim request and proof of payment has been sent to the admins."))
            
            plan_data = self.bot.PLANS.get(claim_type, {}).get(code_or_plan.lower(), {})
            if plan_data.get('role_id'):
                try:
                    role_to_assign = interaction.guild.get_role(int(plan_data['role_id']))
                    if role_to_assign:
                        await interaction.user.add_roles(role_to_assign, reason=f"Claimed {code_or_plan} premium plan.")
                except Exception as e:
                    self.bot.logger.error(f"Failed to assign role for plan {code_or_plan}: {e}")
        else:
            req_invites = int(re.search(r'invite\s+(\d+)', p.get('price', '').lower()).group(1)) if re.search(r'invite\s+(\d+)', p.get('price', '').lower()) else 0
            if req_invites > 0:
                invites = await interaction.guild.invites()
                if sum(i.uses for i in invites if i.inviter == interaction.user) < req_invites:
                    return await interaction.followup.send(embed=self.bot.create_error_embed("Denied", f"You need {req_invites} invites to claim this VPS."))
            
            validity_days = None
            if 'validity' in p:
                v_match = re.search(r'(\d+)', p['validity'])
                if v_match: validity_days = int(v_match.group(1))

            view = self.bot.OSSelectView(p['ram'], p['cpu'], p['disk'], interaction.user, interaction, plan_name, validity_days, claim_type)
            await interaction.edit_original_response(embed=self.bot.create_info_embed("Approved", f"Please select an OS for your **{plan_name}** VPS below:"), view=view)

async def setup(bot):
    await bot.add_cog(ClaimCommand(bot))
