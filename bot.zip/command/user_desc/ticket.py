import discord
from discord import app_commands
from discord.ext import commands
import re
from datetime import datetime

class TicketCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    ticket_group = app_commands.Group(name="ticket", description="Manage support tickets.")

    @ticket_group.command(name="create", description="Create a new support ticket.")
    @app_commands.describe(subject="A brief summary of your issue.")
    async def ticket_create(self, interaction: discord.Interaction, subject: str):
        await interaction.response.defer(ephemeral=True)

        category_id = self.bot.get_setting('ticket_category_id', '0')
        support_role_id = self.bot.get_setting('ticket_support_role_id', '0')

        if category_id == '0' or support_role_id == '0':
            return await interaction.followup.send(embed=self.bot.create_error_embed("Ticket System Not Setup", "An administrator has not configured the ticket system yet."))

        category = interaction.guild.get_channel(int(category_id))
        support_role = interaction.guild.get_role(int(support_role_id))

        if not category or not support_role:
            return await interaction.followup.send(embed=self.bot.create_error_embed("Configuration Error", "The configured ticket category or support role could not be found."))

        safe_subject = re.sub(r'[^a-zA-Z0-9-]', '', subject.lower().replace(' ', '-'))[:50]
        channel_name = f"ticket-{interaction.user.name}-{safe_subject}"

        overwrites = {
            interaction.guild.default_role: discord.PermissionOverwrite(read_messages=False),
            interaction.user: discord.PermissionOverwrite(read_messages=True, send_messages=True),
            support_role: discord.PermissionOverwrite(read_messages=True, send_messages=True),
            interaction.guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True)
        }

        try:
            channel = await interaction.guild.create_text_channel(
                name=channel_name,
                category=category,
                overwrites=overwrites,
                topic=f"Ticket created by {interaction.user.name} for: {subject}"
            )
        except discord.HTTPException as e:
            self.bot.logger.error(f"Failed to create ticket channel: {e}")
            return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "Could not create the ticket channel. I may be missing permissions."))

        conn = self.bot.get_db()
        cur = conn.cursor()
        cur.execute("INSERT INTO tickets (user_id, channel_id, subject, created_at, status) VALUES (?, ?, ?, ?, ?)",
                    (str(interaction.user.id), str(channel.id), subject, datetime.now().isoformat(), 'open'))
        conn.commit()
        conn.close()

        embed = self.bot.create_info_embed(f"Support Ticket: {subject}", f"Welcome, {interaction.user.mention}! Thank you for reaching out.\n\nA staff member from {support_role.mention} will be with you shortly.")
        embed.add_field(name="Ticket Information", value=f"**Subject:** {subject}\n**Created:** <t:{int(datetime.now().timestamp())}:f>", inline=False)
        embed.add_field(name="Instructions", value="Please describe your issue in detail. You can close this ticket at any time by clicking the 'Close Ticket' button below.", inline=False)
        
        await channel.send(embed=embed, view=self.bot.CloseTicketView())
        await interaction.followup.send(embed=self.bot.create_success_embed("Ticket Created!", f"Your ticket has been created at {channel.mention}."), ephemeral=True)

    @ticket_group.command(name="adduser", description="Add a user to this ticket.")
    @app_commands.describe(user="The user to add to the ticket.")
    async def ticket_adduser(self, interaction: discord.Interaction, user: discord.Member):
        conn = self.bot.get_db()
        cur = conn.cursor()
        cur.execute("SELECT user_id FROM tickets WHERE channel_id = ?", (str(interaction.channel.id),))
        ticket = cur.fetchone()
        conn.close()

        if not ticket and not self.bot.is_admin_check(interaction.user.id):
            return await interaction.response.send_message(embed=self.bot.create_error_embed("Not a Ticket", "This command can only be used in a ticket channel."), ephemeral=True)

        await interaction.channel.set_permissions(user, read_messages=True, send_messages=True)
        await interaction.response.send_message(embed=self.bot.create_success_embed("User Added", f"{user.mention} has been added to this ticket."))

    @ticket_group.command(name="removeuser", description="Remove a user from this ticket.")
    @app_commands.describe(user="The user to remove from the ticket.")
    async def ticket_removeuser(self, interaction: discord.Interaction, user: discord.Member):
        conn = self.bot.get_db()
        cur = conn.cursor()
        cur.execute("SELECT user_id FROM tickets WHERE channel_id = ?", (str(interaction.channel.id),))
        ticket = cur.fetchone()
        conn.close()

        if not ticket and not self.bot.is_admin_check(interaction.user.id):
            return await interaction.response.send_message(embed=self.bot.create_error_embed("Not a Ticket", "This command can only be used in a ticket channel."), ephemeral=True)
        
        if str(user.id) == ticket['user_id']:
            return await interaction.response.send_message(embed=self.bot.create_error_embed("Error", "You cannot remove the ticket owner."), ephemeral=True)

        await interaction.channel.set_permissions(user, overwrite=None)
        await interaction.response.send_message(embed=self.bot.create_success_embed("User Removed", f"{user.mention} has been removed from this ticket."))

async def setup(bot):
    await bot.add_cog(TicketCommand(bot))
