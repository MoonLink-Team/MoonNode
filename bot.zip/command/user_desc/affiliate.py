import discord
from discord import app_commands
from discord.ext import commands

class AffiliateCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="affiliate", description="Check your referral credits or transfer credits")
    @app_commands.choices(admin_action=[
        app_commands.Choice(name="Add Credits", value="add"),
        app_commands.Choice(name="Remove Credits", value="remove")
    ])
    async def affiliate_cmd(self, interaction: discord.Interaction, target_user: discord.Member = None, admin_action: str = None, transfer_amount: int = None):
        await interaction.response.defer()
        conn = self.bot.get_db()
        cur = conn.cursor()
        
        if admin_action and self.bot.is_admin_check(interaction.user.id):
            if not target_user or not transfer_amount: 
                return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "You must specify a user and amount."))
                
            cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (str(target_user.id),))
            if admin_action == "add": 
                cur.execute("UPDATE users SET credits = credits + ? WHERE user_id = ?", (transfer_amount, str(target_user.id)))
            else: 
                cur.execute("UPDATE users SET credits = max(0, credits - ?) WHERE user_id = ?", (transfer_amount, str(target_user.id)))
                
            conn.commit()
            return await interaction.followup.send(embed=self.bot.create_success_embed("Success", f"Updated balance for {target_user.mention}"))
            
        if transfer_amount and target_user and not admin_action:
            if not self.bot.ABEI: 
                return await interaction.followup.send(embed=self.bot.create_error_embed("Disabled", "The economy system is disabled."))
                
            cur.execute("SELECT credits FROM users WHERE user_id=?", (str(interaction.user.id),))
            row = cur.fetchone()
            
            if not row or row['credits'] < transfer_amount: 
                return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "Insufficient credits."))
            
            cur.execute("UPDATE users SET credits = credits - ? WHERE user_id = ?", (transfer_amount, str(interaction.user.id)))
            cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (str(target_user.id),))
            cur.execute("UPDATE users SET credits = credits + ? WHERE user_id = ?", (transfer_amount, str(target_user.id)))
            conn.commit()
            return await interaction.followup.send(embed=self.bot.create_success_embed("Transferred", f"Sent {transfer_amount} credits to {target_user.mention}."))

        if not self.bot.RA and not self.bot.ABEI:
            return await interaction.followup.send(embed=self.bot.create_error_embed("Disabled", "The Affiliate and Economy systems are disabled."))
            
        cur.execute("SELECT credits, total_referrals FROM users WHERE user_id=?", (str(interaction.user.id),))
        row = cur.fetchone()
        conn.close()
        
        credits = row['credits'] if row else 0
        total_refs = row['total_referrals'] if row else 0
        
        embed = self.bot.create_embed("🤝 Your Affiliate & Economy Stats", "Invite friends to buy a Premium Plan. You will earn **100 Credits** per paid referral!")
        self.bot.add_field(embed, "💰 Balance", f"`{credits} Credits`", True)
        if self.bot.RA:
            self.bot.add_field(embed, "👥 Total Referrals", f"`{total_refs} Users`", True)
        await interaction.followup.send(embed=embed)

async def setup(bot):
    await bot.add_cog(AffiliateCommand(bot))
