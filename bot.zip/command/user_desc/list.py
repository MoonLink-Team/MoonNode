import discord
from discord import app_commands
from discord.ext import commands

class ListCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="list", description="List your VPS instances")
    async def list_vps(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        user_id = str(interaction.user.id)
        with self.bot.data_lock:
            vps_list = self.bot.vps_data.get(user_id, [])
        
        if not vps_list:
            return await interaction.followup.send(embed=self.bot.create_error_embed("No VPS Found", "You do not have any VPS instances on this server."))

        embed = self.bot.create_embed(f"📦 Your VPS Instances - {interaction.user.name}")
        for i, vps in enumerate(vps_list):
            status_raw = vps.get('status', 'unknown')
            is_suspended = vps.get('suspended', False)
            status_icon = self.bot.Theme.OFFLINE
            status_text = "Stopped"
            if status_raw == 'running' and not is_suspended:
                status_icon, status_text = self.bot.Theme.ONLINE, "Running"
            elif is_suspended:
                status_icon, status_text = self.bot.Theme.OFFLINE, "Suspended"
            
            details = f"> 🆔 **ID:** `{vps['container_name']}`
> 📊 **Status:** {status_icon} `{status_text}`
> ⚙️ **Specs:** `{vps.get('config', 'Custom')}`"
            
            if vps.get('expires_at'):
                 details += f"
> ⏳ **Expires:** <t:{int(self.bot.datetime.fromisoformat(vps['expires_at']).timestamp())}:R>"
                 
            self.bot.add_field(embed, f"VPS #{i+1}", details, False)

        self.bot.add_field(embed, self.bot.Theme.DIVIDER, "🔽 **Select a VPS from the dropdown below to manage it.**", False)
        view = self.bot.ManageView(user_id, vps_list)
        await interaction.followup.send(embed=embed, view=view)

async def setup(bot):
    await bot.add_cog(ListCommand(bot))
