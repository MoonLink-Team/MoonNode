import discord
from discord import app_commands
from discord.ext import commands

class UpgradeCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="upgrade", description="Dynamic Upgrade or Downgrade Plan")
    async def upgrade_vps(self, interaction: discord.Interaction, vps_number: int, new_plan_name: str):
        if not self.bot.PUDC: return await interaction.response.send_message(embed=self.bot.create_error_embed("Disabled", "Plan upgrades are disabled."), ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        
        plan = self.bot.PLANS.get("premium", {}).get(new_plan_name.lower())
        if not plan: 
            return await interaction.followup.send(embed=self.bot.create_error_embed("Invalid Plan", "Plan not found in the premium list."))
        
        user_id = str(interaction.user.id)
        with self.bot.data_lock:
            if user_id not in self.bot.vps_data or vps_number < 1 or vps_number > len(self.bot.vps_data[user_id]): 
                return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "Invalid VPS number."))
            vps = self.bot.vps_data[user_id][vps_number-1]
            
        
        # Dynamic cost calculation based on resource bump
        current_ram = int(str(vps.get('ram', '1GB')).replace('GB', ''))
        current_cpu = int(vps.get('cpu', '1'))
        cost = max(50, ((plan['ram'] - current_ram) * 50) + ((plan['cpu'] - current_cpu) * 20))
        
        conn = self.bot.get_db()
        cur = conn.cursor()
        cur.execute("SELECT credits FROM users WHERE user_id=?", (user_id,))
        row = cur.fetchone()
        if not row or row['credits'] < cost:
            conn.close()
            return await interaction.followup.send(embed=self.bot.create_error_embed("Upgrade Failed", f"You need at least {cost} credits to upgrade to this plan."))
            
        cur.execute("UPDATE users SET credits = credits - ? WHERE user_id = ?", (cost, user_id))
        conn.commit()
        conn.close()
        
        try:
            full_cname = f"{vps.get('node', 'local')}:{vps['container_name']}" if vps.get('node', 'local') != 'local' else vps['container_name']
            
            await self.bot.execute_lxc(f"lxc config set {full_cname} limits.memory {plan['ram']}GB")
            await self.bot.execute_lxc(f"lxc config set {full_cname} limits.cpu {plan['cpu']}")
            
            with self.bot.data_lock:
                vps['ram'] = f"{plan['ram']}GB"
                vps['cpu'] = str(plan['cpu'])
                vps['config'] = f"Upgraded to {new_plan_name.title()}"
            self.bot.save_vps_data()
            
            await interaction.followup.send(embed=self.bot.create_success_embed("Upgraded", f"VPS successfully upgraded to **{new_plan_name.title()}**."))
        except Exception as e: 
            await interaction.followup.send(embed=self.bot.create_error_embed("Error", str(e)))

async def setup(bot):
    await bot.add_cog(UpgradeCommand(bot))
