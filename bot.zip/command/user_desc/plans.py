import discord
from discord import app_commands
from discord.ext import commands

class PlansCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="plans", description="Browse or manage VPS plans")
    @app_commands.choices(plan_type=[app_commands.Choice(name="Premium", value="premium"), app_commands.Choice(name="Free", value="free")])
    @app_commands.choices(action=[
        app_commands.Choice(name="List (Public)", value="list"),
        app_commands.Choice(name="Add (Admin)", value="add"),
        app_commands.Choice(name="Edit (Admin)", value="edit"),
        app_commands.Choice(name="Remove (Admin)", value="remove")
    ])
    @app_commands.describe(
        plan_name="Name of the plan (e.g. basic, pro)",
        ram_gb="RAM in GB",
        cpu_cores="CPU Cores",
        disk_gb="Disk space in GB",
        price="Price or invite req (e.g. ₱150, invite 4)",
        validity="Validity period (e.g. 15 Days)",
        emoji="Emoji icon",
        role="The Discord role to assign for this plan."
    )
    async def manage_plans(self, interaction: discord.Interaction, plan_type: str, action: str, plan_name: str = None, ram_gb: int = None, cpu_cores: int = None, disk_gb: int = None, price: str = None, validity: str = None, emoji: str = "📦", role: discord.Role = None):
        is_list = (action == "list")
        
        await interaction.response.defer(ephemeral=not is_list)

        if not self.bot.ENABLE_PLANS:
            return await interaction.followup.send(embed=self.bot.create_error_embed("Disabled", "Plans feature is currently disabled."))

        if is_list:
            embed = self.bot.create_info_embed(f"VPS Plans")
            desc = ""
            target_dict = self.bot.PLANS.get(plan_type, {})
            view = None
            
            if plan_type == "premium":
                desc += "💰 **VPS Plans**
"
                for name, data in target_dict.items():
                    p_emoji = data.get('emoji', '📦')
                    p_price = f" - {data.get('price', '')}" if data.get('price') else ""
                    desc += f"{p_emoji} **{name.title()} Plan{p_price}**
"
                    desc += f"• {data.get('ram')}GB RAM
• {data.get('cpu')} CPU Cores
• {data.get('disk')}GB Disk
"
                    if data.get('validity'): desc += f"• {data.get('validity')} Validity
"
                    if data.get('role_id'):
                        role = interaction.guild.get_role(int(data['role_id']))
                        if role:
                            desc += f"• Role Reward: {role.mention}
"
                    desc += "• Full Root Access

"
                    
                desc += "📞 **How to Purchase**
"
                desc += "1. Select your preferred payment method from the dropdown below.
"
                desc += "2. Take a screenshot of the payment confirmation.
"
                desc += "3. Create a ticket with your payment proof.
"
                desc += "4. We'll activate your VPS within 24 hours.
"
                desc += "5. Enjoy your high-performance VPS!

"
                
                methods = self.bot.get_payments()
                if methods:
                    desc += "**Accepted Payment Methods:**
"
                    desc += "*Please use the dropdown menu below to view payment details.*
"
                    view = self.bot.PlansView(methods)
            else:
                for name, data in target_dict.items():
                    desc += f"**{data.get('emoji', '📦')} {name.title()} Plan** ({data.get('price')})
"
                    desc += f"• {data.get('ram')}GB RAM | {data.get('cpu')} CPU | {data.get('disk')}GB Disk

"
                    
            embed.description = desc
            if view:
                await interaction.followup.send(embed=embed, view=view)
            else:
                await interaction.followup.send(embed=embed)
        
        else:
            if not self.bot.is_admin_check(interaction.user.id):
                return await interaction.followup.send(embed=self.bot.create_error_embed("Denied", "You must be an admin to modify the database."))
            
            if not plan_name:
                return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "You must provide a `plan_name` for this action."))

            p_name_lower = plan_name.lower()

            if action == "remove":
                if p_name_lower in self.bot.PLANS[plan_type]:
                    del self.bot.PLANS[plan_type][p_name_lower]
                    self.bot.save_plans()
                    return await interaction.followup.send(embed=self.bot.create_success_embed("Removed", f"Plan **{plan_name}** has been removed from {plan_type} plans."))
                else:
                    return await interaction.followup.send(embed=self.bot.create_error_embed("Not Found", f"Plan **{plan_name}** not found in {plan_type} plans."))

            elif action in ["add", "edit"]:
                if ram_gb is None or cpu_cores is None or disk_gb is None:
                    return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "You must provide `ram_gb`, `cpu_cores`, and `disk_gb` to create or edit a plan."))
                
                if action == "add" and p_name_lower in self.bot.PLANS[plan_type]:
                    return await interaction.followup.send(embed=self.bot.create_error_embed("Error", f"Plan **{plan_name}** already exists. Use the `edit` action instead."))
                if action == "edit" and p_name_lower not in self.bot.PLANS[plan_type]:
                    return await interaction.followup.send(embed=self.bot.create_error_embed("Error", f"Plan **{plan_name}** does not exist. Use the `add` action instead."))

                self.bot.PLANS[plan_type][p_name_lower] = {
                    "ram": ram_gb,
                    "cpu": cpu_cores,
                    "disk": disk_gb,
                    "price": price or ("TBD" if plan_type == "premium" else ""),
                    "validity": validity,
                    "emoji": emoji,
                    "role_id": str(role.id) if role else None
                }

                self.bot.save_plans()
                await interaction.followup.send(embed=self.bot.create_success_embed("Saved", f"Plan **{plan_name}** has been successfully {action}ed in the database."))

async def setup(bot):
    await bot.add_cog(PlansCommand(bot))
