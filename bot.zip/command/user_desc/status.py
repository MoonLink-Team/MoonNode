import discord
from discord import app_commands
from discord.ext import commands

class StatusCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="status", description="Check Host Server Status")
    async def status(self, interaction: discord.Interaction):
        await interaction.response.defer()
        cpu = await self.bot.get_cpu_usage_async()
        ram = await self.bot.get_ram_usage_async()
        uptime = await self.bot.get_uptime_async()
        embed = self.bot.create_embed("🌐 Server Status")
        self.bot.add_field(embed, f"{self.bot.Theme.NET} Latency", f"`{round(self.bot.latency * 1000)}ms`", True)
        self.bot.add_field(embed, "⏱️ Uptime", f"`{uptime}`", True)
        self.bot.add_field(embed, self.bot.Theme.DIVIDER, "", False)
        self.bot.add_field(embed, f"{self.bot.Theme.CPU} Host CPU Usage", self.bot.Theme.progress_bar(cpu), False)
        self.bot.add_field(embed, f"{self.bot.Theme.RAM} Host RAM Usage", self.bot.Theme.progress_bar(ram), False)
        await interaction.followup.send(embed=embed)

async def setup(bot):
    await bot.add_cog(StatusCommand(bot))
