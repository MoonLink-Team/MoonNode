import discord
from discord import app_commands
from discord.ext import commands

class ManageSharedCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="manage-shared", description="Manage a VPS shared with you")
    async def manage_shared_vps(self, interaction: discord.Interaction, owner: discord.Member, vps_number: int):
        await interaction.response.defer()
        owner_id = str(owner.id)
        with self.bot.data_lock:
            if owner_id not in self.bot.vps_data or vps_number < 1 or vps_number > len(self.bot.vps_data[owner_id]):
                return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "Invalid User or VPS number."), ephemeral=True)
            vps = self.bot.vps_data[owner_id][vps_number - 1]

        user_has_access = False
        if isinstance(vps.get("shared_with"), list):
            for shared_user in vps.get("shared_with", []):
                if isinstance(shared_user, dict) and shared_user.get('user_id') == str(interaction.user.id):
                    user_has_access = True
                    break
                elif isinstance(shared_user, str) and shared_user == str(interaction.user.id): # Backwards compatibility
                    user_has_access = True
                    break

        if not user_has_access:
            return await interaction.followup.send(embed=self.bot.create_error_embed("Denied", "You do not have access to this VPS."), ephemeral=True)
        
        view = self.bot.ManageView(str(interaction.user.id), [vps], is_shared=True, owner_id=owner_id, actual_index=vps_number-1)
        await interaction.followup.send(embed=await view.get_initial_embed(), view=view)

async def setup(bot):
    await bot.add_cog(ManageSharedCommand(bot))
