import discord
from discord import app_commands
from discord.ext import commands

class WhitelistCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="whitelist-vps", description="[ADMIN] Toggle Anti-Shutoff Whitelist")
    @app_commands.choices(action=[app_commands.Choice(name="Add to Whitelist", value="add"), app_commands.Choice(name="Remove from Whitelist", value="remove")])
    async def whitelist_vps(self, interaction: discord.Interaction, container_name: str, action: str):
        await interaction.response.defer()
        found = False
        with self.bot.data_lock:
            for lst in self.bot.vps_data.values():
                for vps in lst:
                    if vps['container_name'] == container_name:
                        vps['whitelisted'] = (action == 'add')
                        found = True
                        break
                if found:
                    break
        
        if found:
            self.bot.save_vps_data()
            await interaction.followup.send(embed=self.bot.create_success_embed("Whitelist Updated", f"Status for `{container_name}` changed to: **{action.upper()}**"))
        else:
            await interaction.followup.send(embed=self.bot.create_error_embed("Error", "VPS not found."), ephemeral=True)

async def setup(bot):
    await bot.add_cog(WhitelistCommand(bot))
