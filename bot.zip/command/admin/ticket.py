import discord
from discord import app_commands
from discord.ext import commands

class TicketAdminCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    ticket_group = app_commands.Group(name="ticket", description="Manage support tickets.")

    @ticket_group.command(name="setup", description="[ADMIN] Setup the ticket system.")
    @app_commands.describe(category="The category to create ticket channels in.", support_role="The role that can view all tickets.")
    async def ticket_setup(self, interaction: discord.Interaction, category: discord.CategoryChannel, support_role: discord.Role):
        await interaction.response.defer(ephemeral=True)
        self.bot.set_setting('ticket_category_id', str(category.id))
        self.bot.set_setting('ticket_support_role_id', str(support_role.id))
        await interaction.followup.send(embed=self.bot.create_success_embed("Ticket System Setup", f"Ticket category set to **{category.name}**\nSupport role set to **{support_role.name}**"))

async def setup(bot):
    await bot.add_cog(TicketAdminCommand(bot))
