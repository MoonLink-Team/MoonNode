import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

class VpsCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="vps", description="[ADMIN] Manage Server Actions")
    @app_commands.choices(action=[
        app_commands.Choice(name="Suspend VPS", value="suspend"),
        app_commands.Choice(name="Unsuspend VPS", value="unsuspend")
    ])
    async def vps_action(self, interaction: discord.Interaction, action: str, container_name: str, reason: str = "Violated Rules"):
        await interaction.response.defer()
            
        target_vps = None
        with self.bot.data_lock:
            for uid, lst in self.bot.vps_data.items():
                for vps in lst:
                    if vps['container_name'] == container_name:
                        target_vps = vps
                        break
                if target_vps:
                    break

        if not target_vps:
            return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "VPS not found."), ephemeral=True)

        full_cname = f"{target_vps.get('node', 'local')}:{container_name}" if target_vps.get('node', 'local') != 'local' else container_name
        
        if action == "suspend":
            try:
                await self.bot.execute_lxc(f"lxc stop {full_cname}")
                with self.bot.data_lock:
                    target_vps['status'] = 'stopped'
                    target_vps['suspended'] = True
                    target_vps['suspension_history'].append({'time': datetime.now().isoformat(), 'reason': reason, 'by': interaction.user.name})
                self.bot.save_vps_data()
                embed = self.bot.create_warning_embed("Suspended", f"VPS `{container_name}` suspended.
Reason: {reason}")
                await interaction.followup.send(embed=embed)
            except Exception as e: await interaction.followup.send(embed=self.bot.create_error_embed("Failed", str(e)[:4000]), ephemeral=True)
            
        elif action == "unsuspend":
            try:
                await self.bot.execute_lxc(f"lxc start {full_cname}")
                with self.bot.data_lock:
                    target_vps['suspended'] = False
                    target_vps['status'] = 'running'
                self.bot.save_vps_data()
                embed = self.bot.create_success_embed("Unsuspended", f"VPS `{container_name}` is active again.")
                await interaction.followup.send(embed=embed)
            except Exception as e: await interaction.followup.send(embed=self.bot.create_error_embed("Failed", str(e)[:4000]), ephemeral=True)

async def setup(bot):
    await bot.add_cog(VpsCommand(bot))
