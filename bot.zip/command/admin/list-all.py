import discord
from discord import app_commands
from discord.ext import commands

class ListAllCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="list-all", description="[ADMIN] List all VPS instances on the server")
    async def list_all_vps(self, interaction: discord.Interaction):
        await interaction.response.defer()
        with self.bot.data_lock:
            total_users = len(self.bot.vps_data)
            total_vps = sum(len(vps_list) for vps_list in self.bot.vps_data.values())
            running = sum(1 for vps_list in self.bot.vps_data.values() for vps in vps_list if vps.get('status') == 'running' and not vps.get('suspended', False))
        
        embed = self.bot.create_embed("📂 All VPS Instances")
        stats_text = f"```yaml
Total Users: {total_users}
Total VPS:  {total_vps}
Running VPS: {running}
```"
        self.bot.add_field(embed, "Global Stats", stats_text, False)
        await interaction.followup.send(embed=embed)
        
        vps_info = []
        with self.bot.data_lock: current_data = self.bot.vps_data.copy()
        for user_id, vps_list in current_data.items():
            try: 
                user = await self.bot.fetch_user(int(user_id))
                name = user.name
            except: 
                name = f"User ID: {user_id}"
            for i, vps in enumerate(vps_list):
                status_emoji = self.bot.Theme.ONLINE if vps.get('status') == 'running' and not vps.get('suspended', False) else self.bot.Theme.OFFLINE
                vps_info.append(f"`{vps['container_name']}` • {status_emoji} • **{name}**")
        
        if vps_info:
            vps_text = "
".join(vps_info)
            for i in range(0, len(vps_text), 1024):
                chunk = vps_text[i:i+1024]
                embed = self.bot.create_embed(f"📑 List Page {i//1024 + 1}")
                self.bot.add_field(embed, "VPS List", chunk, False)
                await interaction.followup.send(embed=embed)

async def setup(bot):
    await bot.add_cog(ListAllCommand(bot))
