import discord
from discord import app_commands
from discord.ext import commands
import uuid
import time
import asyncio
import random

class GiveawayCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="giveaway", description="[ADMIN] Start a VPS Giveaway")
    @app_commands.choices(action=[
        app_commands.Choice(name="Create", value="create"),
        app_commands.Choice(name="Cancel", value="delete"),
        app_commands.Choice(name="List", value="list")
    ])
    @app_commands.describe(duration_minutes="Time (Mins)", ram="RAM(GB)", cpu="Cores", disk="Disk(GB)", winners="Winner Count", description="Message content")
    async def giveaway_cmd(self, interaction: discord.Interaction, action: str, duration_minutes: int = None, ram: int = None, cpu: int = None, disk: int = None, winners: int = None, description: str = None, target_id: str = None):
        
        await interaction.response.defer(ephemeral=True)

        if action == "create":
            if not all([duration_minutes, ram, cpu, disk, winners]):
                return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "You must provide duration, ram, cpu, disk, and winners."))
                
            g_id = uuid.uuid4().hex[:6].upper()
            end_time = int(time.time() + (duration_minutes * 60))
            
            embed = self.bot.create_embed(f"🎉 VPS Giveaway `[{g_id}]`", description or "Click the button below to win a VPS!")
            self.bot.add_field(embed, "Specs", f"```yaml\nRAM: {ram}GB\nCPU: {cpu} Cores\nDisk: {disk}GB\n```", False)
            self.bot.add_field(embed, "Details", f"**Winners:** {winners}\n**Ends:** <t:{end_time}:R> (<t:{end_time}:F>)", False)
            
            view = self.bot.GiveawayView(g_id)
            
            await interaction.followup.send(embed=self.bot.create_success_embed("Giveaway Started", f"Giveaway ID: `[{g_id}]`"))
            msg = await interaction.channel.send(embed=embed, view=view)
            
            task = asyncio.create_task(self.giveaway_task(g_id, duration_minutes * 60, winners, ram, cpu, disk, msg, view))
            
            self.bot.active_giveaways[g_id] = {
                'task': task,
                'end': end_time,
                'msg': msg.jump_url
            }
            
        elif action == "delete":
            if not target_id or target_id not in self.bot.active_giveaways:
                return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "Giveaway ID not found."))
                
            self.bot.active_giveaways[target_id]['task'].cancel()
            del self.bot.active_giveaways[target_id]
            await interaction.followup.send(embed=self.bot.create_success_embed("Cancelled", f"Giveaway `[{target_id}]` cancelled."))
            
        elif action == "list":
            if not self.bot.active_giveaways:
                return await interaction.followup.send(embed=self.bot.create_info_embed("Empty", "No active giveaways."))
                
            embed = self.bot.create_embed("⏳ Active Giveaways")
            for gid, data in self.bot.active_giveaways.items():
                self.bot.add_field(embed, f"ID: `{gid}`", f"Ends: <t:{data['end']}:R>\nLink: [View]({data['msg']})", False)
            await interaction.followup.send(embed=embed)

    async def giveaway_task(self, g_id: str, duration_sec: int, winners_count: int, ram: int, cpu: int, disk: int, message: discord.Message, view: commands.ui.View):
        await asyncio.sleep(duration_sec)
        if g_id not in self.bot.active_giveaways: return 
        del self.bot.active_giveaways[g_id]
        
        if not view.entrants:
            try: await message.reply(embed=self.bot.create_error_embed("Giveaway Ended", "Nobody entered the giveaway. No VPS deployed."))
            except: pass
            return
            
        winner_pool = list(view.entrants)
        actual_winners = min(winners_count, len(winner_pool))
        drawn = random.sample(winner_pool, actual_winners)
        winner_tags = [f"<@{uid}>" for uid in drawn]
        
        congrats = self.bot.create_success_embed("🎉 Giveaway Complete", f"Winners: {', '.join(winner_tags)}!\n\nYour VPS instances are being created. You will be DM'd shortly.")
        try: await message.reply(content=f"{', '.join(winner_tags)}", embed=congrats)
        except: pass
        
        for uid in drawn:
            user = message.guild.get_member(uid)
            if user:
                asyncio.create_task(self.bot.auto_deploy_vps(user, ram, cpu, disk))

async def setup(bot):
    await bot.add_cog(GiveawayCommand(bot))
