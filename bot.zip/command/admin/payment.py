import discord
from discord import app_commands
from discord.ext import commands

class PaymentCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="payment", description="[ADMIN] Manage payment methods for Premium plans")
    @app_commands.choices(action=[
        app_commands.Choice(name="Add", value="add"),
        app_commands.Choice(name="Remove", value="remove"),
        app_commands.Choice(name="Edit", value="edit"),
        app_commands.Choice(name="List", value="list")
    ])
    async def payment_cmd(self, interaction: discord.Interaction, action: str, payment_name: str = None, image: discord.Attachment = None):
        await interaction.response.defer(ephemeral=True)
        conn = self.bot.get_db()
        cur = conn.cursor()
        
        if action == "list":
            methods = self.bot.get_payments()
            if not methods: return await interaction.followup.send(embed=self.bot.create_info_embed("Payment Methods", "No payment methods configured."))
            desc = "
".join([f"• **{m['name']}**: [View Image]({m['image_url']})" for m in methods])
            await interaction.followup.send(embed=self.bot.create_info_embed("Payment Methods", desc))
            
        elif action in ["add", "edit"]:
            if not payment_name or not image: return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "You must provide a payment_name and attach an image."))
            if not image.content_type.startswith("image/"): return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "Attachment must be an image file."))
            cur.execute("INSERT OR REPLACE INTO payments (name, image_url) VALUES (?, ?)", (payment_name, image.url))
            conn.commit()
            await interaction.followup.send(embed=self.bot.create_success_embed("Success", f"Payment method **{payment_name}** has been saved."))
            
        elif action == "remove":
            if not payment_name: return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "Provide the name of the payment method to remove."))
            cur.execute("DELETE FROM payments WHERE name = ?", (payment_name,))
            conn.commit()
            await interaction.followup.send(embed=self.bot.create_success_embed("Success", f"Payment method **{payment_name}** removed."))
        conn.close()

async def setup(bot):
    await bot.add_cog(PaymentCommand(bot))
