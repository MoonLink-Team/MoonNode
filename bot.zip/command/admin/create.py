import discord
from discord import app_commands
from discord.ext import commands
import re

class CreateCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="create", description="[ADMIN] Manually create a VPS for a user")
    @app_commands.choices(plan_type=[
        app_commands.Choice(name="Premium", value="premium"),
        app_commands.Choice(name="Free", value="free")
    ])
    @app_commands.describe(user="The User", plan_type="Premium or Free", plans_name="Plan Name (optional)", ram="RAM in GB", cpu="CPU Cores", disk="Disk Space in GB", referrer="User who invited them (Awards RA Credits)")
    async def create_vps(self, interaction: discord.Interaction, user: discord.Member, plan_type: str = None, plans_name: str = None, ram: int = None, cpu: int = None, disk: int = None, referrer: discord.Member = None):
        final_ram, final_cpu, final_disk, p_name = 0, 0, 0, "Custom Server"
        validity_days = None
        
        if plans_name:
            if not plan_type:
                return await interaction.response.send_message(embed=self.bot.create_error_embed("Error", "You must specify Premium or Free."), ephemeral=True)
            if not self.bot.ENABLE_PLANS: return await interaction.response.send_message(embed=self.bot.create_error_embed("Error", "Plans are disabled."), ephemeral=True)
            
            target_dict = self.bot.PLANS.get(plan_type, {})
            if plans_name.lower() in target_dict:
                p = target_dict[plans_name.lower()]
                final_ram, final_cpu, final_disk, p_name = p.get('ram', 0), p.get('cpu', 0), p.get('disk', 0), plans_name
                if 'validity' in p:
                    v_match = re.search(r'(\d+)', p['validity'])
                    if v_match: validity_days = int(v_match.group(1))
            else: return await interaction.response.send_message(embed=self.bot.create_error_embed("Not Found", "Plan name is invalid."), ephemeral=True)
        else:
            if ram and cpu and disk: final_ram, final_cpu, final_disk = ram, cpu, disk
            else: return await interaction.response.send_message(embed=self.bot.create_error_embed("Syntax", "Provide custom numbers or use a plan name."), ephemeral=True)

        if final_ram <= 0 or final_cpu <= 0 or final_disk <= 0: return await interaction.response.send_message(embed=self.bot.create_error_embed("Error", "Values must be greater than 0."), ephemeral=True)
        if self.bot.ENFORCE_RESOURCE_LIMITS and (final_ram > self.bot.MAX_RAM_LIMIT or final_cpu > self.bot.MAX_CPU_LIMIT):
            return await interaction.response.send_message(embed=self.bot.create_error_embed("Limit Reached", f"Maximum allowed: **{self.bot.MAX_RAM_LIMIT}GB RAM** | **{self.bot.MAX_CPU_LIMIT} Cores**."), ephemeral=True)

        if self.bot.RA and referrer and plan_type == "premium":
            conn = self.bot.get_db()
            cur = conn.cursor()
            cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (str(referrer.id),))
            cur.execute("UPDATE users SET credits = credits + 100, total_referrals = total_referrals + 1 WHERE user_id = ?", (str(referrer.id),))
            conn.commit()
            conn.close()
            try: await referrer.send(embed=self.bot.create_success_embed("🎉 Referral Bonus!", f"You just received **100 Credits** because {user.mention} bought a premium plan using your referral!"))
            except: pass

        embed = self.bot.create_info_embed("Admin Override VPS Creation", f"**User:** {user.mention}
**Plan:** {p_name}
**Specs:** `{final_ram}GB RAM`, `{final_cpu} Cores`, `{final_disk}GB Storage`")
        view = self.bot.OSSelectView(final_ram, final_cpu, final_disk, user, interaction, p_name, validity_days, plan_type)
        await interaction.response.send_message(embed=embed, view=view)

async def setup(bot):
    await bot.add_cog(CreateCommand(bot))
