import discord
from discord import app_commands
from discord.ext import commands

class SetCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="set", description="[ADMIN] Change bot settings")
    @app_commands.choices(setting_type=[
        app_commands.Choice(name="Log Channel", value="log_channel"),
        app_commands.Choice(name="Payment Channel", value="payment_channel"),
        app_commands.Choice(name="Bot Status", value="status"),
        app_commands.Choice(name="Resource Thresholds", value="thresholds")
    ])
    @app_commands.describe(setting_type="Setting to change", channel="Select a channel", status_name="Custom status text", cpu="Max CPU%", ram="Max RAM%")
    async def set_config(self, interaction: discord.Interaction, setting_type: str, channel: discord.TextChannel = None, status_name: str = None, cpu: int = None, ram: int = None):
        await interaction.response.defer(ephemeral=True)
        
        if setting_type == "log_channel":
            if not channel: return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "You must specify a channel."), ephemeral=True)
            self.bot.set_setting('log_channel', str(channel.id))
            await interaction.followup.send(embed=self.bot.create_success_embed("Settings Updated", f"Logs will now be sent to {channel.mention}"))
            
        elif setting_type == "payment_channel":
            if not channel: return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "You must specify a channel."), ephemeral=True)
            self.bot.set_setting('payment_channel', str(channel.id))
            await interaction.followup.send(embed=self.bot.create_success_embed("Settings Updated", f"VPS Claim requests will now go to {channel.mention}"))
            
        elif setting_type == "status":
            if not status_name: return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "You must specify a status name."), ephemeral=True)
            await self.bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name=status_name))
            await interaction.followup.send(embed=self.bot.create_success_embed("Settings Updated", f"Bot status updated to: `{status_name}`"))
            
        elif setting_type == "thresholds":
            if not cpu or not ram: return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "You must provide both CPU and RAM %."), ephemeral=True)
            self.bot.CPU_THRESHOLD, self.bot.RAM_THRESHOLD = cpu, ram
            self.bot.set_setting('cpu_threshold', str(cpu))
            self.bot.set_setting('ram_threshold', str(ram))
            await interaction.followup.send(embed=self.bot.create_success_embed("Settings Updated", f"Auto-shutdown limits set to CPU: `{cpu}%` and RAM: `{ram}%`"))

async def setup(bot):
    await bot.add_cog(SetCommand(bot))
