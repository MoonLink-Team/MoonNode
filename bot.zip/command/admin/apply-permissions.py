import discord
from discord import app_commands
from discord.ext import commands

class ApplyPermissionsCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="apply-permissions", description="[ADMIN] Allow Docker/Pterodactyl inside VPS")
    async def apply_permissions_cmd(self, interaction: discord.Interaction, container_name: str, node: str = "local"):
        await interaction.response.defer()
        full_cname = f"{node}:{container_name}" if node != "local" else container_name
        await self.bot.apply_advanced_permissions(full_cname)
        await self.bot.execute_lxc(f"lxc restart {full_cname}")
        await interaction.followup.send(embed=self.bot.create_success_embed("Success", f"Advanced permissions applied to `{full_cname}`."))

async def setup(bot):
    await bot.add_cog(ApplyPermissionsCommand(bot))
