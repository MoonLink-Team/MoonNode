import discord
from discord import app_commands
from discord.ext import commands

class NodesCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="nodes", description="[ADMIN] Control multiple physical servers")
    async def nodes_cmd(self, interaction: discord.Interaction):
        if not self.bot.MULTI_NODE:
            return await interaction.response.send_message(embed=self.bot.create_error_embed("Disabled", "Multi-node feature is disabled in .env."), ephemeral=True)
        embed = self.bot.create_info_embed("🌐 Cluster Hub", "Main server network connection active.

*(Remote APIs connected)*")
        await interaction.response.send_message(embed=embed)

async def setup(bot):
    await bot.add_cog(NodesCommand(bot))
