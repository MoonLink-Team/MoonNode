import discord
from discord import app_commands
from discord.ext import commands

class DeleteCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="delete", description="[ADMIN] Delete a user's VPS permanently")
    @app_commands.describe(user="The User", vps_number="VPS Number", reason="Reason for deletion")
    async def delete_vps(self, interaction: discord.Interaction, user: discord.Member, vps_number: int, reason: str = "Violated Rules"):
        user_id = str(user.id)
        with self.bot.data_lock:
            if user_id not in self.bot.vps_data or vps_number < 1 or vps_number > len(self.bot.vps_data[user_id]):
                return await interaction.response.send_message(embed=self.bot.create_error_embed("Error", "Invalid VPS number."), ephemeral=True)
            vps = self.bot.vps_data[user_id][vps_number - 1]
            container_name = vps["container_name"]
            node_prefix = f"{vps.get('node', 'local')}:" if vps.get('node', 'local') != 'local' else ""
        
        view = self.bot.ConfirmView(str(interaction.user.id), requires_2fa=True)
        await interaction.response.send_message(embed=self.bot.create_warning_embed("Delete VPS?", f"Are you sure you want to delete `{container_name}`? All data will be lost."), view=view)
        await view.wait()
        
        if not view.value: return await interaction.edit_original_response(embed=self.bot.create_info_embed("Cancelled", "Deletion cancelled."), view=None)

        embed_del = self.bot.create_info_embed("Deleting", f"Deleting `{container_name}`...")
        await interaction.edit_original_response(embed=embed_del, view=None)
        
        try:
            await self.bot.execute_lxc(f"lxc delete {node_prefix}{container_name} --force")
            with self.bot.data_lock:
                if user_id in self.bot.vps_data and len(self.bot.vps_data[user_id]) >= vps_number:
                    del self.bot.vps_data[user_id][vps_number - 1]
                    if not self.bot.vps_data[user_id]:
                        del self.bot.vps_data[user_id]
                        if interaction.guild:
                            role = await self.bot.get_or_create_vps_role(interaction.guild)
                            if role: 
                                try: await user.remove_roles(role)
                                except: pass
            self.bot.save_vps_data()
            
            embed = self.bot.create_success_embed("Deleted")
            self.bot.add_field(embed, "VPS", f"`{container_name}`", True)
            self.bot.add_field(embed, "Reason", reason, False)
            await interaction.edit_original_response(embed=embed)
            await self.bot.send_log(embed)
        except Exception as e: await interaction.edit_original_response(embed=self.bot.create_error_embed("Failed to Delete", f"Error: `{str(e)[:4000]}`"))

async def setup(bot):
    await bot.add_cog(DeleteCommand(bot))
