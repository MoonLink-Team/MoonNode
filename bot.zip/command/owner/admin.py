import discord
from discord import app_commands
from discord.ext import commands

class AdminCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="admin", description="[ADMIN] Assign Admin Roles")
    @app_commands.choices(action=[
        app_commands.Choice(name="Add Admin", value="add"), 
        app_commands.Choice(name="Remove Admin", value="remove"), 
        app_commands.Choice(name="List Admins", value="list"),
    ])
    @app_commands.choices(permission=[
        app_commands.Choice(name="Owner Level", value="Owner"),
        app_commands.Choice(name="Admin Level", value="Admin"),
        app_commands.Choice(name="Mod Level", value="Mod"),
        app_commands.Choice(name="Developer Level", value="Dev")
    ])
    async def admin_action(self, interaction: discord.Interaction, action: str, user: discord.Member = None, permission: str = "Admin"):
        uid = str(interaction.user.id)
        role = self.bot.admin_data.get(uid)
        is_owner = role == 'Owner' or uid == str(self.bot.MAIN_ADMIN_ID)
        
        if action in ["add", "remove"] and not is_owner:
            return await interaction.response.send_message(embed=self.bot.create_error_embed("Denied", "You must be a Server Owner to do this."), ephemeral=True)

        await interaction.response.defer()
            
        if action == "list":
            embed = self.bot.create_embed("🛡️ Admin List")
            embed.add_field(name="👑 Main Owner", value=f"<@{self.bot.MAIN_ADMIN_ID}>", inline=False)
            
            main_admins = [f"<@{uid}>" for uid, r in self.bot.admin_data.items() if r == 'Owner' and str(uid) != str(self.bot.MAIN_ADMIN_ID)]
            if main_admins:
                embed.add_field(name="⭐ Owners", value="
".join(main_admins), inline=False)
                
            other_admins = {}
            for auid, arole in self.bot.admin_data.items():
                if arole != 'Owner':
                    if arole not in other_admins: other_admins[arole] = []
                    other_admins[arole].append(f"<@{auid}>")
                    
            for role_name, users in other_admins.items():
                embed.add_field(name=f"🛠️ {role_name}s", value="
".join(users), inline=False)
                
            return await interaction.followup.send(embed=embed)

        if not user: return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "You must tag a user."), ephemeral=True)
        
        target_id = str(user.id)
        if action == "add":
            self.bot.admin_data[target_id] = permission
            self.bot.save_admin_data()
            await interaction.followup.send(embed=self.bot.create_success_embed("Role Updated", f"{user.mention} is now an **{permission}**."))
            
        elif action == "remove":
            if target_id in self.bot.admin_data:
                del self.bot.admin_data[target_id]
                self.bot.save_admin_data()
                await interaction.followup.send(embed=self.bot.create_success_embed("Removed", f"{user.mention} is no longer an admin."))
            else: await interaction.followup.send(embed=self.bot.create_error_embed("Error", "User is not an admin."), ephemeral=True)

async def setup(bot):
    await bot.add_cog(AdminCommand(bot))
