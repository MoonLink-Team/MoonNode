import discord
from discord import app_commands
from discord.ext import commands

class SystemAdminCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="system-admin", description="[ADMIN] System Maintenance Tools")
    @app_commands.choices(action=[
        app_commands.Choice(name="Clean Database", value="clean"),
        app_commands.Choice(name="Extension Toggle", value="extension"),
        app_commands.Choice(name="Maintenance Mode", value="maintenance"),
        app_commands.Choice(name="A2FA Management", value="a2fa"),
        app_commands.Choice(name="Migrate Node", value="migrate")
    ])
    @app_commands.choices(extension=[
        app_commands.Choice(name="Automated Subdomains", value="asm"),
        app_commands.Choice(name="Multi-Node Architecture", value="multi_node"),
        app_commands.Choice(name="Scheduled Backups", value="sosb"),
        app_commands.Choice(name="Automated Billing", value="abei"),
        app_commands.Choice(name="Support Tickets", value="ists"),
        app_commands.Choice(name="Auto Suspension", value="aes"),
        app_commands.Choice(name="Renewal Reminders", value="rr"),
        app_commands.Choice(name="Affiliate System", value="ra"),
        app_commands.Choice(name="Admin 2FA", value="a2fa"),
        app_commands.Choice(name="Promo Codes (CPCS)", value="cpcs"),
        app_commands.Choice(name="Marketplace (MSTC)", value="mstc"),
        app_commands.Choice(name="Upgrades (PUDC)", value="pudc"),
        app_commands.Choice(name="Backup Limits (UBL)", value="ubl")
    ])
    @app_commands.choices(ext_state=[
        app_commands.Choice(name="True", value="True"),
        app_commands.Choice(name="False", value="False")
    ])
    @app_commands.choices(maint_state=[
        app_commands.Choice(name="Enable", value="Enable"),
        app_commands.Choice(name="Disable", value="Disable")
    ])
    @app_commands.choices(a2fa_action=[
        app_commands.Choice(name="Edit PIN", value="edit"),
        app_commands.Choice(name="Remove PIN", value="remove")
    ])
    async def admin_tools(self, interaction: discord.Interaction, action: str, extension: str = None, ext_state: str = None, maint_state: str = None, a2fa_action: str = None, new_pin: str = None, ubl_number: int = None, vps_name: str = None, target_node: str = None):
        if action == "clean":
            view = self.bot.ConfirmView(str(interaction.user.id), requires_2fa=True)
            await interaction.response.send_message(embed=self.bot.create_warning_embed("System Clean", "Are you sure you want to clean the DB of orphaned instances?"), view=view, ephemeral=True)
            await view.wait()
            if not view.value: return
            
            await interaction.edit_original_response(embed=self.bot.create_info_embed("Cleaning", "Analyzing database..."), view=None)
            removed = 0
            with self.bot.data_lock:
                for uid in list(self.bot.vps_data.keys()):
                    new_list = []
                    for vps in self.bot.vps_data[uid]:
                        try:
                            node_pref = f"{vps.get('node', 'local')}:" if vps.get('node', 'local') != 'local' else ""
                            await self.bot.execute_lxc(f"lxc info {node_pref}{vps['container_name']}")
                            new_list.append(vps)
                        except: removed += 1
                    self.bot.vps_data[uid] = new_list
                self.bot.save_vps_data()
            await interaction.followup.send(embed=self.bot.create_success_embed("Database Cleaned", f"Removed {removed} invalid VPS instances from the database."), ephemeral=True)
            
        elif action == "maintenance":
            await interaction.response.defer(ephemeral=True)
            if not maint_state: 
                return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "You must provide a `maint_state` (Enable or Disable) for this action."))
            
            self.bot.MAINTENANCE_MODE = (maint_state == 'Enable')
            self.bot.set_setting('maintenance_mode', 'true' if self.bot.MAINTENANCE_MODE else 'false')
            if self.bot.MAINTENANCE_MODE:
                await self.bot.change_presence(status=discord.Status.dnd, activity=discord.Activity(type=discord.ActivityType.watching, name="System Maintenance"))
                await interaction.followup.send(embed=self.bot.create_warning_embed("Maintenance Enabled", "The bot is now in maintenance mode. Only admins can use commands."))
            else:
                await self.bot.change_presence(status=discord.Status.online, activity=discord.Activity(type=discord.ActivityType.watching, name="VPS Management System"))
                await interaction.followup.send(embed=self.bot.create_success_embed("Maintenance Disabled", "The bot is back online."))
                
        elif action == "extension":
            await interaction.response.defer(ephemeral=True)
            if not extension or not ext_state: 
                return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "You must provide an `extension` and an `ext_state` (True/False) for this action."))
            
            is_enabled = (ext_state == 'True')
            setattr(self.bot, extension.upper(), is_enabled)
            self.bot.set_setting(f'ext_{extension}', str(is_enabled))

            if extension == "sosb":
                if is_enabled and not self.bot.automated_backups.is_running(): 
                    self.bot.automated_backups.start()
                elif not is_enabled and self.bot.automated_backups.is_running():
                    self.bot.automated_backups.cancel()
            elif extension in ["aes", "rr"]:
                if (self.bot.AES or self.bot.RR) and not self.bot.expiration_monitor.is_running(): self.bot.expiration_monitor.start()
                elif not (self.bot.AES or self.bot.RR) and self.bot.expiration_monitor.is_running(): self.bot.expiration_monitor.cancel()

            await interaction.followup.send(embed=self.bot.create_success_embed("Extension Updated", f"The extension `{extension}` has been set to **{ext_state}**."))

        elif action == "migrate":
            await interaction.response.defer(ephemeral=True)
            if not self.bot.MULTI_NODE: return await interaction.followup.send(embed=self.bot.create_error_embed("Disabled", "Multi-Node is disabled."))
            if not vps_name or not target_node: return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "Missing target VPS or Node name."))
            try:
                await self.bot.execute_lxc(f"lxc stop {vps_name}")
                await self.bot.execute_lxc(f"lxc move {vps_name} {target_node}:{vps_name}")
                await self.bot.execute_lxc(f"lxc start {target_node}:{vps_name}")
                with self.bot.data_lock:
                    for lst in self.bot.vps_data.values():
                        for vps in lst:
                            if vps['container_name'] == vps_name: 
                                vps['node'] = target_node
                self.bot.save_vps_data()
                await interaction.followup.send(embed=self.bot.create_success_embed("Migrated", f"Moved {vps_name} to {target_node}"))
            except Exception as e: 
                await interaction.followup.send(embed=self.bot.create_error_embed("Error", str(e)[:4000]))

        elif action == "a2fa":
            await interaction.response.defer(ephemeral=True)
            if not a2fa_action:
                return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "You must pick an A2FA action (Edit PIN / Remove PIN)."))
            
            conn = self.bot.get_db()
            cur = conn.cursor()
            
            if a2fa_action == "edit":
                if not new_pin or not new_pin.isdigit() or len(new_pin) != 4:
                    return await interaction.followup.send(embed=self.bot.create_error_embed("Error", "You must provide a valid 4-digit PIN using the `new_pin` option."))
                cur.execute("UPDATE admins SET pin = ? WHERE user_id = ?", (new_pin, str(interaction.user.id)))
                conn.commit()
                await interaction.followup.send(embed=self.bot.create_success_embed("A2FA Updated", "Your Admin 2FA PIN has been securely updated."))
                
            elif a2fa_action == "remove":
                cur.execute("UPDATE admins SET pin = '0000' WHERE user_id = ?", (str(interaction.user.id),))
                conn.commit()
                await interaction.followup.send(embed=self.bot.create_success_embed("A2FA Removed", "Your Admin 2FA PIN has been reset to default (disabled)."))
                
            conn.close()

async def setup(bot):
    await bot.add_cog(SystemAdminCommand(bot))
