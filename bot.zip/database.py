import os
from datetime import datetime
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import declarative_base, sessionmaker
from sqlalchemy import Column, Integer, String, Boolean, DateTime, JSON
from dotenv import load_dotenv

load_dotenv()

DB_USER = os.getenv("POSTGRES_USER", "moonnodes")
DB_PASS = os.getenv("POSTGRES_PASSWORD", "secure_password")
DB_HOST = os.getenv("POSTGRES_HOST", "127.0.0.1")
DB_PORT = os.getenv("POSTGRES_PORT", "5432")
DB_NAME = os.getenv("POSTGRES_DB", "vps_db")

# Fallback to sqlite if postgres is not configured properly to prevent crashing during testing
try:
    DATABASE_URL = f"postgresql+asyncpg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    engine = create_async_engine(DATABASE_URL, echo=False)
except Exception:
    DATABASE_URL = "sqlite+aiosqlite:///vps_fallback.db"
    engine = create_async_engine(DATABASE_URL, echo=False)

AsyncSessionLocal = sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)
Base = declarative_base()

class User(Base):
    __tablename__ = 'users'
    user_id = Column(String, primary_key=True)
    credits = Column(Integer, default=0)
    total_referrals = Column(Integer, default=0)

class VPS(Base):
    __tablename__ = 'vps_instances'
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(String, nullable=False)
    container_name = Column(String, unique=True, nullable=False)
    ram = Column(String, nullable=False)
    cpu = Column(String, nullable=False)
    storage = Column(String, nullable=False)
    config = Column(String, nullable=False)
    os_version = Column(String, default='ubuntu:22.04')
    status = Column(String, default='stopped')
    suspended = Column(Boolean, default=False)
    whitelisted = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=True)
    node = Column(String, default='local')
    shared_with = Column(JSON, default=list) 
    suspension_history = Column(JSON, default=list)

class Admin(Base):
    __tablename__ = 'admins'
    user_id = Column(String, primary_key=True)
    role = Column(String, default='Admin')
    pin = Column(String, default='0000')

class Payment(Base):
    __tablename__ = 'payments'
    name = Column(String, primary_key=True)
    image_url = Column(String, nullable=False)

class Setting(Base):
    __tablename__ = 'settings'
    key = Column(String, primary_key=True)
    value = Column(String, nullable=False)

class PromoCode(Base):
    __tablename__ = 'promo_codes'
    code = Column(String, primary_key=True)
    type = Column(String, nullable=False) 
    value = Column(Integer, nullable=False)
    uses = Column(Integer, default=1)
    used = Column(Integer, default=0)

class Ticket(Base):
    __tablename__ = 'tickets'
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(String, nullable=False)
    channel_id = Column(String, nullable=False, unique=True)
    subject = Column(String, nullable=False)
    status = Column(String, default='open')
    created_at = Column(DateTime, default=datetime.utcnow)
    closed_at = Column(DateTime, nullable=True)
    transcript_url = Column(String, nullable=True)

async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

async def get_db_session() -> AsyncSession:
    async with AsyncSessionLocal() as session:
        yield session