import discord
from discord.ext import commands
from discord import app_commands
from bot import (
    has_role, create_success_embed, create_error_embed, create_info_embed, create_warning_embed,
    set_setting, get_setting, MAIN_ADMIN_ID, execute_lxc, MULTI_NODE, bot as main_bot
)
from database import admin_data, save_admin_data, vps_data, save_vps_data, data_lock

class OwnerCmds(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="sync", description="[OWNER] Sync command matrix")
    @app_commands.checks.cooldown(1, 10.0, key=lambda i: i.user.id)
    async def sync_commands(self, interaction: discord.Interaction):
        if str(interaction.user.id) != str(MAIN_ADMIN_ID):
            return await interaction.response.send_message("Unauthorized.", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        self.bot.tree.copy_global_to(guild=interaction.guild)
        await self.bot.tree.sync(guild=interaction.guild)
        await interaction.followup.send(embed=create_success_embed("Protocol Complete", "Commands synced to local cluster."))

    @app_commands.command(name="maintenance", description="[ADMIN] Trigger emergency cluster freeze")
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @has_role('Owner', 'Admin')
    @app_commands.choices(state=[app_commands.Choice(name="Lockdown", value="on"), app_commands.Choice(name="Nominal", value="off")])
    async def maintenance(self, interaction: discord.Interaction, state: str):
        import bot as main_mod
        main_mod.MAINTENANCE_MODE = (state == 'on')
        set_setting('maintenance_mode', 'true' if main_mod.MAINTENANCE_MODE else 'false')
        if main_mod.MAINTENANCE_MODE:
            await self.bot.change_presence(status=discord.Status.dnd, activity=discord.Activity(type=discord.ActivityType.watching, name="Maintenance Lockdown"))
            await interaction.response.send_message(embed=create_warning_embed("Lockdown Active", "Systems halted. Non-Root identities are currently blocked from the API."))
        else:
            await self.bot.change_presence(status=discord.Status.online, activity=discord.Activity(type=discord.ActivityType.watching, name="MoonNodes Premium Architecture"))
            await interaction.response.send_message(embed=create_success_embed("Lockdown Lifted", "System Nominal. Matrix access restored."))

    @app_commands.command(name="set", description="[ADMIN] Configure Global Aegis Parameters")
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @has_role('Owner', 'Admin')
    @app_commands.choices(setting_type=[
        app_commands.Choice(name="Log Channel Target", value="log_channel"),
        app_commands.Choice(name="Payment/Claims Target", value="payment_channel"),
        app_commands.Choice(name="Bot Status RPC", value="status"),
        app_commands.Choice(name="Hardware Thresholds (CPU/RAM)", value="thresholds")
    ])
    async def set_config(self, interaction: discord.Interaction, setting_type: str, channel: discord.TextChannel = None, status_name: str = None, cpu: int = None, ram: int = None):
        await interaction.response.defer(ephemeral=True)
        if setting_type == "log_channel":
            if not channel: return await interaction.followup.send(embed=create_error_embed("Syntax", "A channel parameter is required."), ephemeral=True)
            set_setting('log_channel', str(channel.id))
            await interaction.followup.send(embed=create_success_embed("Matrix Updated", f"Audit logs securely routing to: {channel.mention}"))
        elif setting_type == "payment_channel":
            if not channel: return await interaction.followup.send(embed=create_error_embed("Syntax", "A channel parameter is required."), ephemeral=True)
            set_setting('payment_channel', str(channel.id))
            await interaction.followup.send(embed=create_success_embed("Matrix Updated", f"Premium acquisition tickets will now drop in: {channel.mention}"))
        elif setting_type == "status":
            if not status_name: return await interaction.followup.send(embed=create_error_embed("Syntax", "A status_name parameter is required."), ephemeral=True)
            await self.bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name=status_name))
            await interaction.followup.send(embed=create_success_embed("RPC Altered", f"Nodes are now projecting: `{status_name}`"))
        elif setting_type == "thresholds":
            if not cpu or not ram: return await interaction.followup.send(embed=create_error_embed("Syntax", "Both cpu and ram parameters are required."), ephemeral=True)
            import bot as main_mod
            main_mod.CPU_THRESHOLD, main_mod.RAM_THRESHOLD = cpu, ram
            set_setting('cpu_threshold', str(cpu))
            set_setting('ram_threshold', str(ram))
            await interaction.followup.send(embed=create_success_embed("Safeties Calibrated", f"Hardware Haltdown Limits -> CPU: `{cpu}%` | RAM: `{ram}%`"))

    @app_commands.command(name="admin", description="Root Access Control Framework")
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @app_commands.choices(action=[app_commands.Choice(name="Elevate", value="add"), app_commands.Choice(name="Demote", value="remove"), app_commands.Choice(name="Scan Registry", value="list"), app_commands.Choice(name="Review Logic", value="permissions")])
    @app_commands.choices(permission=[app_commands.Choice(name="Level 4 (Owner)", value="Owner"), app_commands.Choice(name="Level 3 (Admin)", value="Admin"), app_commands.Choice(name="Level 2 (Mod)", value="Mod"), app_commands.Choice(name="Level X (Dev)", value="Dev")])
    async def admin_action(self, interaction: discord.Interaction, action: str, user: discord.Member = None, permission: str = "Admin"):
        uid = str(interaction.user.id)
        is_owner = admin_data.get(uid) == 'Owner' or uid == str(MAIN_ADMIN_ID)
        if action in ["add", "remove"] and not is_owner: return await interaction.response.send_message(embed=create_error_embed("Firewall Blocked", "Root keys required."), ephemeral=True)
        await interaction.response.defer()
        if action == "permissions": return await interaction.followup.send(embed=create_info_embed("🛡️ Identity Access Nodes", "Levels defined in standard protocols."))
        elif action == "list": return await interaction.followup.send(embed=create_info_embed("🛡️ Clearance Registry", f"Logged admins mapped: {len(admin_data)} keys active."))
        
        if not user: return await interaction.followup.send(embed=create_error_embed("Logic Flaw", "Supply user identity."), ephemeral=True)
        target_id = str(user.id)
        if action == "add":
            admin_data[target_id] = permission
            save_admin_data()
            await interaction.followup.send(embed=create_success_embed("Permissions Elevated", f"{user.mention} shifted to **{permission}**."))
        elif action == "remove":
            if target_id in admin_data:
                del admin_data[target_id]
                save_admin_data()
                await interaction.followup.send(embed=create_success_embed("Keys Stripped", f"{user.mention} demoted."))

    @app_commands.command(name="system-admin", description="[ADMIN] Trigger Core Protocols")
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @has_role('Owner', 'Admin')
    @app_commands.choices(tool=[app_commands.Choice(name="Sync Database", value="sync")])
    async def admin_tools(self, interaction: discord.Interaction, tool: str):
        await interaction.response.defer()
        if tool == "sync":
            removed = 0
            with data_lock:
                for uid in list(vps_data.keys()):
                    new_list = []
                    for vps in vps_data[uid]:
                        try: await execute_lxc(f"lxc info {vps['container_name']}"); new_list.append(vps)
                        except: removed += 1
                    vps_data[uid] = new_list
                save_vps_data()
            await interaction.followup.send(embed=create_success_embed("Deep Clean Executed", f"Purged {removed} dead links from ledger."))

    @app_commands.command(name="nodes", description="[ADMIN] Interface with Hypervisor Cluster Hub")
    @has_role('Owner', 'Admin')
    async def nodes_cmd(self, interaction: discord.Interaction):
        if not MULTI_NODE: return await interaction.response.send_message(embed=create_error_embed("Cluster Offline", "Advanced multi-node syncing disabled in configs."), ephemeral=True)
        await interaction.response.send_message(embed=create_info_embed("🌐 Global Endpoint Cluster", "Routing directly to central network.\n\n*(Remote API listeners standing by...)*"))

async def setup(bot: commands.Bot):
    await bot.add_cog(OwnerCmds(bot))