import discord
from discord.ext import commands
from discord import app_commands
from bot import (
    has_role, create_success_embed, create_error_embed, create_info_embed, create_warning_embed,
    add_field, Theme, OSSelectView, execute_lxc, ENABLE_PLANS, PLANS, MAX_RAM_LIMIT, MAX_CPU_LIMIT, send_log,
    giveaway_task, GiveawayView, active_giveaways, apply_advanced_permissions
)
from database import vps_data, data_lock, save_vps_data
import uuid
import time
from datetime import datetime
import asyncio

class AdminCmds(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="list-all", description="[ADMIN] Intercept entire cluster ledger")
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @has_role('Owner', 'Admin', 'Dev')
    async def list_all_vps(self, interaction: discord.Interaction):
        await interaction.response.defer()
        with data_lock:
            total_users, total_vps = len(vps_data), sum(len(v) for v in vps_data.values())
            running = sum(1 for vlst in vps_data.values() for v in vlst if v.get('status') == 'running' and not v.get('suspended', False))
        embed = create_embed("📂 Aegis Global Ledger", "Deep-scan overview of all hypervisor elements.")
        add_field(embed, "Cluster Wide Metrics", f"```yaml\nTotal Architect IDs: {total_users}\nTotal Node Volumes:  {total_vps}\nActive Transmitting: {running}\n```", False)
        await interaction.followup.send(embed=embed)

    @app_commands.command(name="create", description="[ADMIN] Force inject a node for an identity")
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @has_role('Owner', 'Admin', 'Dev')
    @app_commands.choices(plan_type=[app_commands.Choice(name="Premium", value="premium"), app_commands.Choice(name="Free", value="free")])
    async def create_vps(self, interaction: discord.Interaction, user: discord.Member, plan_type: str = None, plans_name: str = None, ram: int = None, cpu: int = None, disk: int = None):
        final_ram, final_cpu, final_disk, p_name = 0, 0, 0, "Root Override Block"
        if plans_name:
            if not plan_type: return await interaction.response.send_message(embed=create_error_embed("Logic Flaw", "Supply Node Tier type."), ephemeral=True)
            if not ENABLE_PLANS: return await interaction.response.send_message(embed=create_error_embed("Offline", "Plan catalogs offline."), ephemeral=True)
            p = PLANS.get(plan_type, {}).get(plans_name.lower())
            if p: final_ram, final_cpu, final_disk, p_name = p.get('ram', 0), p.get('cpu', 0), p.get('disk', 0), plans_name
            else: return await interaction.response.send_message(embed=create_error_embed("Not Found", "Hardware tag invalid."), ephemeral=True)
        else:
            if ram and cpu and disk: final_ram, final_cpu, final_disk = ram, cpu, disk
            else: return await interaction.response.send_message(embed=create_error_embed("Syntax", "Inject explicit hardware integers or use a tag."), ephemeral=True)

        if final_ram <= 0 or final_cpu <= 0 or final_disk <= 0: return await interaction.response.send_message(embed=create_error_embed("Fault", "Metrics must be absolute positive."), ephemeral=True)
        if final_ram > MAX_RAM_LIMIT or final_cpu > MAX_CPU_LIMIT: return await interaction.response.send_message(embed=create_error_embed("Safety Limit", f"Overload prevented: {MAX_RAM_LIMIT}GB RAM | {MAX_CPU_LIMIT} Cores."), ephemeral=True)
        embed = create_info_embed("Root Block Override", f"**Target Matrix:** {user.mention}\n**Tag:** {p_name}\n**Sector Allocation:** `{final_ram}GB RAM`, `{final_cpu} Cores`, `{final_disk}GB Storage`")
        await interaction.response.send_message(embed=embed, view=OSSelectView(final_ram, final_cpu, final_disk, user, interaction, p_name))

    @app_commands.command(name="giveaway", description="[ADMIN] High-Level Node Distribution System")
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @has_role('Owner', 'Admin')
    @app_commands.choices(action=[app_commands.Choice(name="Create Protocol", value="create"), app_commands.Choice(name="List Active Protocols", value="list")])
    async def giveaway_cmd(self, interaction: discord.Interaction, action: str, duration_minutes: int = None, ram: int = None, cpu: int = None, disk: int = None, winners: int = None, description: str = None, channel: discord.TextChannel = None):
        if action == "create":
            if not all([duration_minutes, ram, cpu, disk, winners]): return await interaction.response.send_message(embed=create_error_embed("Syntax", "Creation requires duration, ram, cpu, disk, and winners."), ephemeral=True)
            g_id, target_ch, end_time = uuid.uuid4().hex[:6].upper(), channel or interaction.channel, int(time.time() + (duration_minutes * 60))
            embed = create_embed(f"🎁 Aegis Architecture Giveaway `[{g_id}]`", description or "Network hardware distribution initialized.")
            add_field(embed, "Sector Allocation", f"```yaml\nRAM: {ram}GB\nCPU: {cpu} Cores\nDisk: {disk}GB\n```", False)
            add_field(embed, "Distribution Rules", f"**Targets Drawn:** {winners}\n**Locks In:** <t:{end_time}:R> (<t:{end_time}:F>)", False)
            view = GiveawayView(g_id)
            await interaction.response.send_message(embed=create_success_embed("Protocol Loaded", f"Deploying logic script `[{g_id}]` to {target_ch.mention}"), ephemeral=True)
            msg = await target_ch.send(embed=embed, view=view)
            task = asyncio.create_task(giveaway_task(g_id, duration_minutes * 60, winners, ram, cpu, disk, msg, view))
            active_giveaways[g_id] = {'task': task, 'end': end_time, 'msg': msg.jump_url, 'desc': description or "Standard Distribution"}
        elif action == "list":
            if not active_giveaways: return await interaction.response.send_message(embed=create_info_embed("Silent Network", "No distribution protocols are running."), ephemeral=True)
            embed = create_embed("⏳ Matrix Distribution Readout")
            for gid, data in active_giveaways.items(): add_field(embed, f"ID: `{gid}`", f"Ends: <t:{data['end']}:R>\nLink: [View Sector]({data['msg']})", False)
            await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="vps", description="[ADMIN] Intercept active hardware")
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @has_role('Owner', 'Admin', 'Dev')
    @app_commands.choices(action=[app_commands.Choice(name="Lock Sector", value="suspend"), app_commands.Choice(name="Unlock Sector", value="unsuspend")])
    async def vps_action(self, interaction: discord.Interaction, action: str, container_name: str, reason: str = "Security Fault"):
        await interaction.response.defer()
        target_vps = None
        with data_lock:
            for lst in vps_data.values():
                for vps in lst:
                    if vps['container_name'] == container_name: target_vps = vps; break
                if target_vps: break
        if target_vps:
            try:
                if action == "suspend":
                    await execute_lxc(f"lxc stop {container_name}")
                    with data_lock: target_vps['status'], target_vps['suspended'] = 'stopped', True; target_vps['suspension_history'].append({'time': datetime.now().isoformat(), 'reason': reason, 'by': interaction.user.name})
                    embed = create_warning_embed("Sector Locked", f"Power forcibly stripped from `{container_name}`.")
                else:
                    await execute_lxc(f"lxc start {container_name}")
                    with data_lock: target_vps['status'], target_vps['suspended'] = 'running', False
                    embed = create_success_embed("Energy Restored", f"Lockout lifted for `{container_name}`.")
                save_vps_data(); await interaction.followup.send(embed=embed); await send_log(embed)
            except Exception as e: await interaction.followup.send(embed=create_error_embed("Fault", str(e)[:4000]), ephemeral=True)
        else: await interaction.followup.send(embed=create_error_embed("Null Ref", "Core not mapped."), ephemeral=True)

    @app_commands.command(name="whitelist-vps", description="[ADMIN] Toggle priority QOS filtering")
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @has_role('Owner', 'Admin')
    @app_commands.choices(action=[app_commands.Choice(name="Inject", value="add"), app_commands.Choice(name="Evict", value="remove")])
    async def whitelist_vps(self, interaction: discord.Interaction, container_name: str, action: str):
        await interaction.response.defer()
        found = False
        with data_lock:
            for lst in vps_data.values():
                for vps in lst:
                    if vps['container_name'] == container_name: vps['whitelisted'] = (action == 'add'); found = True; break
                if found: break
        if found: save_vps_data(); await interaction.followup.send(embed=create_success_embed("QOS Bypassed", f"Filter rules for `{container_name}` changed to: **{action.upper()}**"))
        else: await interaction.followup.send(embed=create_error_embed("Null Ref", "Core not mapped."), ephemeral=True)

    @app_commands.command(name="apply-permissions", description="[ADMIN] Inject deep-nesting virtualization layers")
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @has_role('Owner', 'Admin')
    async def apply_permissions(self, interaction: discord.Interaction, container_name: str):
        await interaction.response.defer()
        await apply_advanced_permissions(container_name)
        await execute_lxc(f"lxc restart {container_name}")
        await interaction.followup.send(embed=create_success_embed("Vectors Pushed", f"Docker-layer profiles forced onto `{container_name}`."))

async def setup(bot: commands.Bot): await bot.add_cog(AdminCmds(bot))