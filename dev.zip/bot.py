"""
MoonNodes VPS Manager — bot.py  (v2)

Changes from v1:
  ✅ All missing cogs now loaded (Admin/vps, User/affiliate, share, transfer)
  ✅ on_ready guard: background tasks only start once (no stacking on reconnect)
  ✅ asyncio.Lock used everywhere (threading.Lock removed)
  ✅ async_await async_save_vps_data() used in all async contexts
  ✅ MAIN_ADMIN_ID compared as int throughout
  ✅ Rate limiter on /create and other heavy commands
  ✅ import re moved to module level
  ✅ Background tasks all wrapped in try/except (one crash won't kill the loop)
  ✅ DB reconnect handled in get_db()
"""

import asyncio
import logging
import random
import re
import sys
import os
from datetime import datetime
from collections import defaultdict

import discord
from discord import app_commands
from discord.ext import commands, tasks

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.config import DISCORD_TOKEN, MAIN_ADMIN_ID, CPU_THRESHOLD, RAM_THRESHOLD
from core.database import (
    init_db, load_vps_data, load_admin_data, vps_data, data_lock,
    async_save_vps_data, save_vps_data, get_setting, admin_data, get_db
)
from core.lxc import execute_lxc, RUNTIME
from core.monitoring import start_resource_monitor
from core.theme import (
    Theme, create_error_embed, create_info_embed, create_success_embed
)
import core.config as cfg

logger = logging.getLogger("moonnodes_vps_bot")

# ── Rate limiter ──────────────────────────────────────────────────────────────
# Maps command_name → {user_id: last_used_timestamp}
_rate_limits: dict[str, dict[int, float]] = defaultdict(dict)

RATE_LIMIT_SECONDS: dict[str, int] = {
    "create":      30,   # /create  — heavy LXC deploy
    "claim":       20,   # /claim   — also deploys
    "giveaway":    10,
    "marketplace": 5,
    "backup":      15,
    "upgrade":     10,
}


def _check_rate_limit(cmd: str, user_id: int) -> float:
    """Return 0 if allowed, else seconds remaining."""
    limit = RATE_LIMIT_SECONDS.get(cmd, 0)
    if limit == 0:
        return 0
    last = _rate_limits[cmd].get(user_id, 0)
    elapsed = asyncio.get_event_loop().time() - last
    if elapsed < limit:
        return limit - elapsed
    _rate_limits[cmd][user_id] = asyncio.get_event_loop().time()
    return 0


# ── Bot class ─────────────────────────────────────────────────────────────────

class MoonNodesBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members         = True
        intents.invites         = True
        super().__init__(command_prefix="!", intents=intents, help_command=None)
        self._ready_fired      = False   # guard: only run on_ready logic once
        self._owner_confirmed  = False   # guard: commands locked until owner clicks first-boot button
        self._sync_locked      = True    # guard: block _sync_vps_states until first-boot is resolved

    async def setup_hook(self):
        # Global interaction check — blocklist and mute
        async def _global_check(interaction: discord.Interaction) -> bool:
            if interaction.user.bot:
                return True
            uid = str(interaction.user.id)
            # ── Command lock until owner completes first-boot setup ───────────
            # ── Command lock — ALL users blocked until first-boot is done ───────
            if not self._owner_confirmed:
                import os as _osck
                _flag = _osck.path.join(_osck.path.dirname(_osck.path.abspath(__file__)), ".first_boot_done")
                if not _osck.path.exists(_flag):
                    try:
                        _lock_embed = discord.Embed(
                            title="⏳ Bot Setup In Progress",
                            description=(
                                "**MoonNodes hasn't been configured yet.**\n\n"
                                "The bot owner needs to complete the **First Boot Setup** "
                                "before commands become available.\n\n"
                                "Please check back shortly — setup only takes a minute!"
                            ),
                            color=0xFEE75C,
                        )
                        _lock_embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                        _lock_embed.set_footer(text="All commands are locked until setup is complete.")
                        if not interaction.response.is_done():
                            await interaction.response.send_message(embed=_lock_embed, ephemeral=True)
                        else:
                            await interaction.followup.send(embed=_lock_embed, ephemeral=True)
                    except Exception:
                        pass
                    return False
            from core.database import get_db as _gdb
            try:
                conn = _gdb(); cur = conn.cursor()
                cur.execute("SELECT 1 FROM blocklist WHERE user_id=?", (uid,))
                if cur.fetchone():
                    embed = discord.Embed(
                        title="🚫 Account Restricted",
                        description=(
                            "Your account has been **blocked** from using this bot.\n\n"
                            "If you believe this is an error, please contact a staff member "
                            "through another channel for assistance."
                        ),
                        color=0xED4245, timestamp=datetime.now(),
                    )
                    embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                    try:
                        if not interaction.response.is_done():
                            await interaction.response.send_message(embed=embed, ephemeral=True)
                        else:
                            await interaction.followup.send(embed=embed, ephemeral=True)
                    except Exception: pass
                    return False
            except Exception: pass
            return True
        self.tree.interaction_check = _global_check

        # ── Auto-defer: for any app command that takes >2.5 s to respond,
        # automatically send a deferred "thinking" response so the token stays
        # alive and we never get 10062 Unknown Interaction.
        # We override tree.on_error but keep the command flow intact by wrapping
        # the bot's on_interaction event instead of patching internal tree attrs.
        _original_on_interaction = self.on_interaction  # may not exist yet

        async def _deferred_on_interaction(interaction: discord.Interaction):
            if interaction.type == discord.InteractionType.application_command:
                async def _auto_defer():
                    await asyncio.sleep(2.5)
                    try:
                        if not interaction.response.is_done():
                            await interaction.response.defer(ephemeral=True, thinking=True)
                    except Exception:
                        pass
                task = self.loop.create_task(_auto_defer())
                try:
                    await _original_on_interaction(interaction)
                finally:
                    task.cancel()
            else:
                await _original_on_interaction(interaction)

        self.on_interaction = _deferred_on_interaction

        # Wire tree error handler — ensures CheckFailure and other app_command errors
        # reach on_app_command_error instead of being "Ignored" by discord.py default
        async def _tree_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
            self.dispatch("app_command_error", interaction, error)
        self.tree.on_error = _tree_error

        cogs = [
            # Owner
            "commands.Owner.admin",
            "commands.Owner.create",
            "commands.Owner.delete",
            "commands.Owner.giveaway",
            "commands.Owner.nodes",
            "commands.Owner.system",
            "commands.Owner.af2f_cmd",
            # Admin
            "commands.Admin.set_cmd",
            # Dev
            "commands.Dev.dev_tools",
            # Mod
            "commands.Mod.mod_tools",
            # Staff
            "commands.Staff.staff_tools",
            # User
            "commands.User.list_cmd",
            "commands.User.manage",
            "commands.User.plans",
            "commands.User.claim",
            "commands.User.support",
            "commands.User.status",
            "commands.User.history",
            "commands.User.lang",
            "commands.User.help",
            "commands.User.marketplace",
            "commands.User.account",
        ]
        for cog in cogs:
            try:
                await self.load_extension(cog)
                logger.info(f"✅ Loaded: {cog}")
            except Exception as e:
                logger.error(f"❌ Failed to load {cog}: {e}")

        # ── Sync slash commands ──────────────────────────────────────────────
        from core.config import GUILD_ID
        try:
            if GUILD_ID:
                guild_obj = discord.Object(id=GUILD_ID)
                self.tree.copy_global_to(guild=guild_obj)
                # Guild sync is instant (no Discord propagation delay)
                synced = await self.tree.sync(guild=guild_obj)
                # Also copy commands to guild for instant availability
                self.tree.copy_global_to(guild=guild_obj)
                logger.info(f"🔗 Synced {len(synced)} command(s) to guild {GUILD_ID} (instant)")

            else:
                synced = await self.tree.sync()
                logger.info(f"🔗 Synced {len(synced)} command(s) globally")
        except Exception as e:
            logger.error(f"Failed to sync commands: {e}")

    async def _send_first_boot_dm(self):
        """
        Send owner a DM on first boot with 10 setup options.
        All commands are locked for non-owners until the owner clicks a button.
        """
        import os as _os
        import shutil as _sh
        BOT_DIR = _os.path.dirname(_os.path.abspath(__file__))
        flag    = _os.path.join(BOT_DIR, ".first_boot_done")
        if _os.path.exists(flag):
            self._owner_confirmed = True
            return
        try:
            owner = await self.fetch_user(MAIN_ADMIN_ID)
        except Exception as e:
            logger.warning(f"First-boot DM failed to fetch owner: {e}")
            self._owner_confirmed = True  # fail-open so bot still works
            return

        bot_ref = self

        def _mark_done():
            open(flag, "w").write("done")
            bot_ref._owner_confirmed = True
            bot_ref._sync_locked     = False   # allow VPS sync now that DB is finalised
            logger.info("First-boot complete — commands unlocked. Scheduling VPS state sync.")
            # Schedule sync on the event loop so it runs after this button handler returns
            asyncio.get_event_loop().create_task(bot_ref._sync_vps_states())

        async def _restore_db(inter, db_path_src):
            """Helper: reload DB after restore and return summary string."""
            from core.database import init_db, load_vps_data, load_admin_data
            init_db(); load_vps_data(); load_admin_data()
            vps_count  = sum(len(v) for v in vps_data.values())
            user_count = len(vps_data)
            recreated = 0; failed_list = []
            from core.lxc import deploy_container, execute_lxc
            from core import ACTIVE_STORAGE_POOL
            for uid2, vlist in list(vps_data.items()):
                for v in vlist:
                    cname = v.get("container_name", "")
                    if not cname: continue
                    try:
                        node   = (v.get("node") or "local").strip().rstrip(":") or "local"
                        prefix = f"{node}:" if node != "local" else ""
                        chk    = await execute_lxc(f"lxc list {prefix}{cname} --format=csv")
                        if chk and cname in str(chk): continue
                    except Exception: pass
                    try:
                        ram  = int(str(v.get("ram","1GB")).replace("GB","").strip()) if v.get("ram") else 1
                        cpu  = int(str(v.get("cpu","1")).strip()) if v.get("cpu") else 1
                        disk = int(str(v.get("storage","10GB")).replace("GB","").strip()) if v.get("storage") else 10
                        os_v = v.get("os_version","ubuntu:22.04") or "ubuntu:22.04"
                        await deploy_container(user_id=uid2, username=f"user{uid2[:6]}",
                            ram=ram, cpu=cpu, disk=disk, os_version=os_v,
                            validity_days=None, target_node=node, storage_pool=ACTIVE_STORAGE_POOL)
                        recreated += 1
                    except Exception:
                        failed_list.append(cname)
            fail_str = f"\nFailed: {', '.join(failed_list[:5])}" if failed_list else ""
            return (
                f"📊 **{user_count}** users · **{vps_count}** VPS records loaded\n"
                f"🚀 **{recreated}** containers recreated on host"
                + (f" · {len(failed_list)} failed{fail_str}" if failed_list else "")
            )

        # ── Quick Setup Channel Wizard ─────────────────────────────────────────
        SETUP_CHANNELS = [
            ("log_channel",     "📋 Log Channel",       "Where bot activity is logged"),
            ("main_chat_id",    "💬 Main Chat Channel", "For MoonCoin chat rewards"),
            ("payment_channel", "💳 Payment Channel",   "Where payment proofs are posted"),
            ("ticket_channel",  "🎫 Ticket Category",   "Discord category for support tickets"),
            ("update_channel",  "📢 Update Channel",    "Maintenance/update announcements"),
            ("af2f_channel_id", "🔐 AF2F Channel",      "Where admin 2FA codes are posted"),
            ("claim_channel",   "🎟️ Claim Channel",     "Where users claim free VPS"),
        ]

        async def _run_quick_setup(inter: discord.Interaction):
            """Walk the owner through each channel one by one via DM."""
            set_count = 0
            for key, label, desc_ch in SETUP_CHANNELS:
                ask_embed = discord.Embed(
                    title=f"⚙️ Quick Setup — {label}",
                    description=(
                        f"**{label}**\n*{desc_ch}*\n\n"
                        "📋 **Send the channel ID in this DM.**\n"
                        "Right-click the channel → **Copy ID** → paste it here.\n\n"
                        "Type `skip` to skip this channel.\n"
                        "⏳ *2-minute window per channel.*"
                    ),
                    color=0x5865F2,
                    timestamp=datetime.now(),
                )
                ask_embed.set_author(name="MoonNodes — Quick Setup", icon_url="https://imgur.com/6yfYDTP.png")
                ask_embed.set_footer(text=f"Channel {set_count + 1} of {len(SETUP_CHANNELS)}")
                await inter.channel.send(embed=ask_embed)

                def _ch_check(m):
                    return (
                        m.author.id == MAIN_ADMIN_ID
                        and isinstance(m.channel, discord.DMChannel)
                    )
                try:
                    msg = await bot_ref.wait_for("message", check=_ch_check, timeout=120)
                    val = msg.content.strip()
                    if val.lower() != "skip" and val.isdigit():
                        from core.database import set_setting as _ss
                        _ss(key, val)
                        set_count += 1
                        await inter.channel.send(
                            embed=discord.Embed(
                                description=f"✅ **{label}** set to <#{val}>",
                                color=0x57F287,
                            )
                        )
                    else:
                        await inter.channel.send(
                            embed=discord.Embed(description=f"⏭️ Skipped **{label}**", color=0xFEE75C)
                        )
                except asyncio.TimeoutError:
                    await inter.channel.send(
                        embed=discord.Embed(description=f"⏰ Timed out — skipped **{label}**", color=0xED4245)
                    )

            done_embed = discord.Embed(
                title="✅ Quick Setup Complete!",
                description=(
                    f"**{set_count}/{len(SETUP_CHANNELS)}** channels configured.\n\n"
                    "The bot is now **fully operational**! 🎉\n\n"
                    "Use `/set setting:Channel` anytime to update channels.\n"
                    "Use `/help` to explore all commands."
                ),
                color=0x57F287,
                timestamp=datetime.now(),
            )
            done_embed.set_author(name="MoonNodes — Setup Complete", icon_url="https://imgur.com/6yfYDTP.png")
            await inter.channel.send(embed=done_embed)
            _mark_done()

        # ── Start Fresh Sub-View ──────────────────────────────────────────────
        class StartFreshView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=300)

            @discord.ui.button(label="🚀 Launch Now", style=discord.ButtonStyle.success, row=0)
            async def start_now_btn(self, inter: discord.Interaction, btn: discord.ui.Button):
                for item in self.children: item.disabled = True
                emb = discord.Embed(
                    title="🚀 MoonNodes Is Live!",
                    description=(
                        "Your bot is now running with a **clean database**. 🎉\n\n"
                        "**Next steps:**\n"
                        "› Use `/set setting:Channel` to configure your channels\n"
                        "› Use `/help` to see all available commands\n"
                        "› Use `/system` to manage extensions and settings\n\n"
                        "✅ All commands are now unlocked for everyone."
                    ),
                    color=0x57F287,
                    timestamp=datetime.now(),
                )
                emb.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                emb.set_footer(text="MoonNodes · Ready to Go")
                await inter.response.edit_message(embed=emb, view=self)
                _mark_done()

            @discord.ui.button(label="⚙️ Quick Setup", style=discord.ButtonStyle.primary, row=0)
            async def quick_setup_btn(self, inter: discord.Interaction, btn: discord.ui.Button):
                for item in self.children: item.disabled = True
                emb = discord.Embed(
                    title="⚙️ Quick Setup — Let's Get Configured",
                    description=(
                        "I'll walk you through setting up each channel **one at a time**.\n\n"
                        "**How it works:**\n"
                        "› I'll ask for each channel's ID one by one\n"
                        "› Right-click a channel in Discord → **Copy ID** → paste it here\n"
                        "› Type `skip` to leave any channel unconfigured for now\n\n"
                        "⏳ Starting in just a moment…"
                    ),
                    color=0x5865F2,
                    timestamp=datetime.now(),
                )
                emb.set_author(name="MoonNodes — Quick Setup", icon_url="https://imgur.com/6yfYDTP.png")
                await inter.response.edit_message(embed=emb, view=self)
                await _run_quick_setup(inter)

            @discord.ui.button(label="← Back", style=discord.ButtonStyle.secondary, row=0)
            async def back_btn(self, inter: discord.Interaction, btn: discord.ui.Button):
                emb = discord.Embed(
                    title="👋 Welcome to MoonNodes — First Boot Setup",
                    description=(
                        "🌙 **MoonNodes VPS Manager** is online!\n\n"
                        "Choose how you want to start:\n\n"
                        "› **📤 Restore system.db** — Upload your existing database\n"
                        "  All VPS data, users, and settings will be restored.\n\n"
                        "› **🆕 Start Fresh** — Begin with a clean database\n"
                        "  Optionally run Quick Setup to configure channels.\n\n"
                        "⚠️ **All commands remain locked until you choose.**\n"
                        "⏳ *You have 10 minutes to decide.*"
                    ),
                    color=0xFFD700,
                    timestamp=datetime.now(),
                )
                emb.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                emb.set_footer(text="MoonNodes · First Boot Setup")
                await inter.response.edit_message(embed=emb, view=FirstBootView())

        # ── Main First Boot View (2 buttons only) ─────────────────────────────
        class FirstBootView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=600)

            # ── Option 1: Restore system.db ───────────────────────────────────
            @discord.ui.button(label="📤 Restore system.db", style=discord.ButtonStyle.primary, emoji="💾", row=0)
            async def upload_btn(self, inter: discord.Interaction, btn: discord.ui.Button):
                for item in self.children: item.disabled = True
                await inter.response.edit_message(
                    embed=discord.Embed(
                        title="📤 Upload Your system.db",
                        description=(
                            "**Attach `system.db` as a file in your next message here in DM.**\n\n"
                            "🔍 The bot will read its contents and show you a full summary "
                            "before applying any changes.\n\n"
                            "⏳ *You have 10 minutes to send the file.*"
                        ),
                        color=0x5865F2,
                        timestamp=datetime.now(),
                    ).set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png"),
                    view=self,
                )

                def check(m):
                    return (
                        m.author.id == MAIN_ADMIN_ID
                        and isinstance(m.channel, discord.DMChannel)
                        and m.attachments
                        and m.attachments[0].filename == "system.db"
                    )
                try:
                    msg = await bot_ref.wait_for("message", check=check, timeout=600)

                    # Save to a temp path so we can inspect before committing
                    tmp_path = _os.path.join(BOT_DIR, "system.db.tmp_inspect")
                    await msg.attachments[0].save(tmp_path)

                    # ── Read and summarise the uploaded DB ────────────────────
                    summary_lines = []
                    try:
                        import sqlite3 as _sq
                        _tc = _sq.connect(tmp_path)
                        _tc.row_factory = _sq.Row
                        _xc = _tc.cursor()
                        try:
                            _xc.execute("SELECT COUNT(*) as c FROM vps_entries")
                            vc = _xc.fetchone()["c"]
                            _xc.execute("SELECT COUNT(DISTINCT user_id) as u FROM vps_entries")
                            uc = _xc.fetchone()["u"]
                            summary_lines.append(f"🖥️ **VPS entries:** `{vc}` across `{uc}` user(s)")
                        except Exception: summary_lines.append("🖥️ VPS entries: *table not found*")
                        try:
                            _xc.execute("SELECT COUNT(*) as c FROM users")
                            summary_lines.append(f"👤 **Users:** `{_xc.fetchone()['c']}`")
                        except Exception: pass
                        try:
                            _xc.execute("SELECT COUNT(*) as c FROM admins")
                            summary_lines.append(f"🛡️ **Admins registered:** `{_xc.fetchone()['c']}`")
                        except Exception: pass
                        try:
                            _xc.execute("SELECT COUNT(*) as c FROM marketplace WHERE active=1")
                            summary_lines.append(f"🛒 **Marketplace listings:** `{_xc.fetchone()['c']}`")
                        except Exception: pass
                        try:
                            _xc.execute("SELECT COUNT(*) as c FROM settings")
                            summary_lines.append(f"⚙️ **Saved settings:** `{_xc.fetchone()['c']}`")
                        except Exception: pass
                        try:
                            _xc.execute("SELECT COUNT(*) as c FROM warnings")
                            wc = _xc.fetchone()["c"]
                            _xc.execute("SELECT COUNT(*) as c FROM staff_notes")
                            nc = _xc.fetchone()["c"]
                            summary_lines.append(f"📋 **Warnings:** `{wc}` · **Staff notes:** `{nc}`")
                        except Exception: pass
                        try:
                            _xc.execute("SELECT COUNT(*) as c FROM claim_requests WHERE status='pending'")
                            summary_lines.append(f"🎟️ **Pending claim requests:** `{_xc.fetchone()['c']}`")
                        except Exception: pass
                        _tc.close()
                    except Exception as read_err:
                        summary_lines.append(f"⚠️ Could not fully read file: `{read_err}`")

                    summary_text = "\n".join(summary_lines) if summary_lines else "*No readable data found.*"

                    # ── Confirm View ──────────────────────────────────────────
                    class RestoreConfirmView(discord.ui.View):
                        def __init__(self_rv):
                            super().__init__(timeout=300)

                        @discord.ui.button(label="✅ Continue with this data", style=discord.ButtonStyle.success, row=0)
                        async def confirm_btn(self_rv, ci: discord.Interaction, cbtn: discord.ui.Button):
                            for item in self_rv.children: item.disabled = True
                            prog_emb = discord.Embed(
                                title="⏳ Restoring Database…",
                                description="Applying your backup — this may take a moment.",
                                color=0x5865F2,
                                timestamp=datetime.now(),
                            )
                            prog_emb.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                            await ci.response.edit_message(embed=prog_emb, view=self_rv)
                            try:
                                db_path = _os.path.join(BOT_DIR, "system.db")
                                if _os.path.exists(db_path):
                                    _sh.copy2(db_path, db_path + ".pre_restore.bak")
                                _sh.move(tmp_path, db_path)
                                restore_summary = await _restore_db(ci, db_path)
                                done_emb = discord.Embed(
                                    title="✅ Database Restored Successfully",
                                    description=(
                                        restore_summary + "\n\n"
                                        "🎉 **The bot is fully operational!**\n"
                                        "All VPS data, users, and settings are back online.\n\n"
                                        "Use `/help` to explore all available commands."
                                    ),
                                    color=0x57F287,
                                    timestamp=datetime.now(),
                                )
                                done_emb.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                                done_emb.set_footer(text="MoonNodes · Setup Complete")
                                await ci.followup.send(embed=done_emb)
                                _mark_done()
                            except Exception as restore_err:
                                await ci.followup.send(embed=discord.Embed(
                                    title="❌ Restore Failed",
                                    description=f"```\n{str(restore_err)[:400]}\n```\nRestart the bot and try again.",
                                    color=0xED4245,
                                ))
                                _mark_done()

                        @discord.ui.button(label="← Back", style=discord.ButtonStyle.secondary, row=0)
                        async def back_btn(self_rv, ci: discord.Interaction, cbtn: discord.ui.Button):
                            try:
                                if _os.path.exists(tmp_path):
                                    _os.remove(tmp_path)
                            except Exception: pass
                            main_emb = discord.Embed(
                                title="👋 Welcome to MoonNodes — First Boot Setup",
                                description=(
                                    "🌙 **MoonNodes VPS Manager** is online!\n\n"
                                    "Choose how you want to start:\n\n"
                                    "› **📤 Restore system.db** — Upload your existing database\n"
                                    "  All VPS data, users, and settings will be restored.\n\n"
                                    "› **🆕 Start Fresh** — Begin with a clean database\n"
                                    "  Optionally run Quick Setup to configure channels.\n\n"
                                    "⚠️ **All commands remain locked until you choose.**\n"
                                    "⏳ *You have 10 minutes to decide.*"
                                ),
                                color=0xFFD700,
                                timestamp=datetime.now(),
                            )
                            main_emb.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                            main_emb.set_footer(text="MoonNodes · First Boot Setup")
                            await ci.response.edit_message(embed=main_emb, view=FirstBootView())

                    preview_emb = discord.Embed(
                        title="🔍 Database Preview",
                        description=(
                            "Here's a summary of what was found in your uploaded `system.db`:\n\n"
                            + summary_text +
                            "\n\n**Would you like to restore from this database?**"
                        ),
                        color=0x5865F2,
                        timestamp=datetime.now(),
                    )
                    preview_emb.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                    preview_emb.set_footer(text="This action cannot be undone once confirmed")
                    await msg.reply(embed=preview_emb, view=RestoreConfirmView())

                except asyncio.TimeoutError:
                    await inter.channel.send(embed=discord.Embed(
                        title="⏰ Upload Timed Out",
                        description=(
                            "No file was received within 10 minutes.\n\n"
                            "Restart the bot to try again, or choose **Start Fresh** to begin without a backup."
                        ),
                        color=0xED4245,
                    ).set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png"))
                    _mark_done()
                except Exception as e:
                    await inter.channel.send(embed=discord.Embed(
                        title="❌ Upload Failed",
                        description=f"```\n{str(e)[:400]}\n```\nRestart the bot and try again.",
                        color=0xED4245,
                    ))
                    _mark_done()

            # ── Option 2: Start Fresh → sub-menu ─────────────────────────────
            @discord.ui.button(label="🆕 Start Fresh", style=discord.ButtonStyle.success, emoji="✨", row=0)
            async def fresh_btn(self, inter: discord.Interaction, btn: discord.ui.Button):
                emb = discord.Embed(
                    title="🆕 Start Fresh — New Database",
                    description=(
                        "You're starting with a **clean slate**. No existing data will be loaded.\n\n"
                        "**Choose how to continue:**\n\n"
                        "› **🚀 Launch Now** — Start immediately with default settings\n"
                        "  Channels and options can be configured later via `/set`\n\n"
                        "› **⚙️ Quick Setup** — Walk through channel configuration now\n"
                        "  Recommended for a smooth first experience\n\n"
                        "› **← Back** — Return to the previous menu"
                    ),
                    color=0x57F287,
                    timestamp=datetime.now(),
                )
                emb.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                emb.set_footer(text="MoonNodes · Start Fresh")
                await inter.response.edit_message(embed=emb, view=StartFreshView())

        # ── Build and send the first-boot embed ───────────────────────────────
        embed = discord.Embed(
            title="👋 Welcome to MoonNodes — First Boot Setup",
            description=(
                "🌙 **MoonNodes VPS Manager** is now online!\n\n"
                "Choose how you want to start the bot:\n\n"
                "› **📤 Restore system.db** — Upload your existing database\n"
                "  All VPS data, users, and settings will be restored.\n\n"
                "› **🆕 Start Fresh** — Begin with a clean database\n"
                "  Optionally run Quick Setup to configure channels.\n\n"
                "⚠️ **All commands are locked until you choose.**\n"
                "⏳ *You have 10 minutes to decide.*"
            ),
            color=0xFFD700,
            timestamp=datetime.now(),
        )
        embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
        embed.set_footer(text="MoonNodes · First Boot Setup")
        try:
            await owner.send(embed=embed, view=FirstBootView())
            logger.info("First-boot DM sent to owner — ALL commands locked until setup complete.")
        except Exception as e:
            logger.warning(f"First-boot DM failed: {e}")
            self._owner_confirmed = True  # fail-open

    async def on_ready(self):
        # Guard: on_ready can fire multiple times on reconnect
        if self._ready_fired:
            return
        self._ready_fired = True

        logger.info(f"🌙 Bot ready — {self.user} ({self.user.id}) | Runtime: {RUNTIME}")

        load_vps_data()
        load_admin_data()

        # Load admin roles from DB
        try:
            conn = get_db()
            cur  = conn.cursor()
            cur.execute("SELECT user_id, role FROM admins")
            for row in cur.fetchall():
                admin_data[row["user_id"]] = row["role"]
        except Exception as e:
            logger.error(f"Admin load error: {e}")

        _load_extension_states()

        # ── First-boot DM ─────────────────────────────────────────────────────
        await self._send_first_boot_dm()

        # If first-boot was already completed on a previous run (flag file exists),
        # unlock sync now.  If still pending, _mark_done() will trigger it later.
        if self._owner_confirmed:
            self._sync_locked = False

        # Start background tasks (only once)
        update_status_task.start()
        scheduled_backup_task.start()
        expiration_task.start()
        vps_monitoring_task.start()
        mstc_health_task.start()
        ubl_cleanup_task.start()
        usage_sampling_task.start()

        # Wire audit log to the bot and log channel
        try:
            from core.audit import set_bot as _audit_set_bot
            log_ch_id = None
            try:
                from core.database import get_setting as _gs
                log_ch_val = _gs("log_channel")
                log_ch_id = int(log_ch_val) if log_ch_val else None
            except Exception:
                pass
            _audit_set_bot(self, log_ch_id)
        except Exception as _ae:
            logger.warning(f"Audit module init failed: {_ae}")

        start_resource_monitor(
            bot_loop      = self.loop,
            cpu_threshold = CPU_THRESHOLD,
            ram_threshold = RAM_THRESHOLD,
            vps_data_ref  = vps_data,
            data_lock_ref = data_lock,
            save_fn       = save_vps_data,
            send_log_fn   = _send_log,
        )

        # Only sync immediately if first-boot is already resolved
        if not self._sync_locked:
            await self._sync_vps_states()

        total   = sum(len(v) for v in vps_data.values())
        running = sum(1 for lst in vps_data.values() for v in lst if v.get("status") == "running")
        logger.info(f"🟢 All systems online — {total} VPS ({running} running)")

        await _send_log(create_info_embed(
            "🌙 MoonNodes Online",
            f"Bot is **online** and ready.\n\n"
            f"**Runtime:** `{RUNTIME}`\n"
            f"**VPS records:** `{total}` total · `{running}` running\n"
            f"**Cogs loaded:** `{len(self.cogs)}`"
        ))

    async def _sync_vps_states(self):
        """
        Reconcile in-memory vps_data with actual LXC container states.

        Rules (prevents accidental data loss):
          • Only UPDATES the status/ipv4 of containers already known in vps_data.
          • Orphaned containers (on host but not in DB) are ADOPTED, never deleted.
          • DB records with no matching host container are LEFT ALONE — the host
            may be a remote node or the container may just be stopped.  We never
            remove a DB record here.
        """
        if self._sync_locked:
            logger.info("_sync_vps_states skipped — first-boot not resolved yet.")
            return

        logger.info("🔄 Syncing VPS states from container runtime…")
        synced = adopted = 0
        try:
            raw = await execute_lxc("lxc list --format=csv")
            if not raw or raw is True:
                logger.info("✅ VPS state sync — no containers found")
                return

            actual: dict[str, dict] = {}
            for line in str(raw).strip().splitlines():
                parts = line.split(",")
                if len(parts) >= 2:
                    name   = parts[0].strip()
                    status = parts[1].strip().lower()
                    ipv4   = parts[2].strip() if len(parts) > 2 else ""
                    if name:
                        actual[name] = {"status": status, "ipv4": ipv4}

            # ── Pass 1: update known containers' live status ──────────────────
            async with data_lock:
                known_names = {
                    v.get("container_name")
                    for lst in vps_data.values()
                    for v in lst
                    if v.get("container_name")
                }
                for uid, vps_list in vps_data.items():
                    for vps in vps_list:
                        cname = vps.get("container_name", "")
                        if not cname or cname not in actual:
                            continue
                        real = actual[cname]["status"]
                        if vps.get("status") != real:
                            logger.info(f"  Status sync  {cname}: {vps.get('status')} → {real}")
                            vps["status"] = real
                            if real == "running" and vps.get("suspended"):
                                vps["suspended"] = False
                            synced += 1

            # ── Pass 2: adopt orphaned containers (on host, not in DB) ────────
            # We NEVER remove DB records — missing host containers are ignored.
            for cname, info in actual.items():
                if cname in known_names:
                    continue
                if not cname.startswith(cfg.VPS_PREFIX + "-"):
                    continue
                parts = cname.split("-")
                if len(parts) < 3:
                    continue

                try:
                    info_out  = await execute_lxc(f"lxc config show {cname}")
                    info_text = str(info_out) if info_out and info_out is not True else ""
                except Exception:
                    info_text = ""

                ram_mb  = 0
                cpu_cnt = "1"
                m = re.search(r"limits\.memory:\s*(\d+)MB", info_text)
                if m: ram_mb = int(m.group(1))
                m = re.search(r"limits\.cpu:\s*(\d+)", info_text)
                if m: cpu_cnt = m.group(1)
                ram_gb = (ram_mb // 1024) if ram_mb else 1

                orphan = {
                    "container_name":     cname,
                    "ram":                f"{ram_gb}GB",
                    "cpu":                cpu_cnt,
                    "storage":            "10GB",
                    "config":             f"{ram_gb}GB RAM / {cpu_cnt} CPU / 10GB Disk",
                    "os_version":         "ubuntu:22.04",
                    "status":             info["status"],
                    "suspended":          False,
                    "whitelisted":        False,
                    "node":               "local",
                    "created_at":         datetime.now().isoformat(),
                    "expiry":             None,
                    "shared_with":        [],
                    "suspension_history": [],
                    "id":                 None,
                }
                owner_uid = str(MAIN_ADMIN_ID)
                async with data_lock:
                    # Double-check under lock before appending
                    already = any(
                        v.get("container_name") == cname
                        for v in vps_data.get(owner_uid, [])
                    )
                    if not already:
                        vps_data.setdefault(owner_uid, []).append(orphan)
                        adopted += 1
                        logger.warning(f"  Adopted orphan container `{cname}` → owner {owner_uid}")

            if synced or adopted:
                await async_save_vps_data()

            logger.info(f"✅ VPS sync complete — updated {synced} status(es), adopted {adopted} orphan(s)")
        except Exception as e:
            logger.warning(f"VPS state sync failed (non-fatal): {e}")

    async def on_app_command_error(self, interaction: discord.Interaction, error):
        """
        Global slash-command error handler.

        Wraps every send in _safe_respond so that expired interaction tokens
        (Discord error 10062 — Unknown Interaction) are caught silently instead
        of filling the log with noise.
        """

        async def _safe_respond(embed: discord.Embed):
            """Try response → followup → DM, eating 10062 at every step."""
            try:
                if not interaction.response.is_done():
                    await interaction.response.send_message(embed=embed, ephemeral=True)
                    return
            except (discord.NotFound, discord.HTTPException):
                pass
            try:
                await interaction.followup.send(embed=embed, ephemeral=True)
                return
            except (discord.NotFound, discord.HTTPException):
                pass
            # Last resort: DM the user so the error isn't completely silent
            try:
                await interaction.user.send(embed=embed)
            except Exception:
                pass

        if isinstance(error, discord.app_commands.CheckFailure):
            embed = discord.Embed(
                title="🚫 Permission Denied",
                description=(
                    "You don't have the required role to use this command.\n\n"
                    "Use `/help` to see which commands are available to you.\n"
                    "*If you think this is a mistake, reach out to an administrator.*"
                ),
                color=0xED4245, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
            embed.set_footer(text="MoonNodes · Use /help to see your available commands")
            await _safe_respond(embed)

        elif isinstance(error, discord.app_commands.CommandInvokeError):
            original = error.original
            # Silently swallow expired-token errors — they're Discord's timeout, not a bug
            if isinstance(original, discord.NotFound) and getattr(original, 'code', 0) == 10062:
                logger.debug(f"Interaction token expired (10062) for /{getattr(interaction.command, 'name', '?')} — suppressed")
                return
            msg = str(original)[:3900]
            logger.error(f"Command invoke error: {msg}")
            embed = discord.Embed(
                title="⚠️ Command Error",
                description=(
                    "Something went wrong while running that command.\n"
                    f"```\n{msg[:1800]}\n```"
                ),
                color=Theme.ERROR, timestamp=datetime.now(),
            )
            embed.set_footer(text="If this keeps happening, please contact an admin · MoonNodes")
            await _safe_respond(embed)

        else:
            msg = str(error)[:3900]
            logger.error(f"App command error: {msg}")
            embed = discord.Embed(title="❌ Error", description=msg[:2000], color=Theme.ERROR)
            await _safe_respond(embed)

    async def on_command_error(self, ctx, error):
        if isinstance(error, commands.CommandNotFound):
            return

    async def on_message(self, message: discord.Message):
        """Award +1 MoonCoin for chatting in the main channel (5-min cooldown)."""
        if message.author.bot or not message.guild:
            return
        try:
            from core.database import get_db, add_coins
            chat_ch = cfg.MAIN_CHAT_ID
            if chat_ch and message.channel.id == chat_ch:
                uid  = str(message.author.id)
                conn = get_db(); cur = conn.cursor()
                cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (uid,))
                cur.execute("SELECT last_chat_coin FROM users WHERE user_id=?", (uid,))
                row   = cur.fetchone()
                last  = row["last_chat_coin"] if row and row["last_chat_coin"] else None
                now   = datetime.now()
                ready = True
                if last:
                    try:
                        diff = (now - datetime.fromisoformat(last)).total_seconds()
                        if diff < 300:  # 5-min cooldown
                            ready = False
                    except Exception:
                        pass
                if ready:
                    # Apply multipliers from VIP/Boost roles
                    mult  = 1.0
                    member = message.guild.get_member(message.author.id)
                    if member:
                        roles = [r.name.lower() for r in member.roles]
                        if "vip" in roles:    mult += 0.01
                        if "server booster" in roles: mult += 0.02
                    coins = max(1, round(1 * mult))
                    add_coins(uid, coins)
                    cur.execute("UPDATE users SET last_chat_coin=? WHERE user_id=?",
                                (now.isoformat(), uid))
                    conn.commit()
        except Exception as e:
            logger.debug(f"on_message coin error: {e}")
        # ── DM block ──────────────────────────────────────────────────────
        if not message.guild:
            try:
                from core.ext import dm_commands_enabled
                if not message.author.bot:
                    # Get configured prefix (default: !)
                    from core.database import get_db as _gdb2
                    try:
                        _conn2 = _gdb2(); _cur2 = _conn2.cursor()
                        _cur2.execute("SELECT value FROM dm_settings WHERE key='dm_prefix'")
                        _prow = _cur2.fetchone()
                        _pfx  = _prow["value"] if _prow else "!"
                    except Exception:
                        _pfx = "!"

                    # Only intercept prefix commands (slash commands use interactions, not on_message)
                    if message.content.startswith(_pfx):
                        if not dm_commands_enabled():
                            dm_embed = discord.Embed(
                                title="💬 DM Commands Unavailable",
                                description=(
                                    "This bot doesn't accept commands in Direct Messages.\n\n"
                                    "Please head to the **server** and use commands in the appropriate channel.\n"
                                    "Type `/help` there to see what's available!"
                                ),
                                color=0xED4245,
                                timestamp=datetime.now(),
                            )
                            dm_embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                            dm_embed.set_footer(text="MoonNodes · Server commands only")
                            await message.channel.send(embed=dm_embed)
                            return
            except Exception:
                pass
        await self.process_commands(message)

    async def on_member_join(self, member: discord.Member):
        """Track invites, award coins to inviter, record join date."""
        try:
            from core.database import get_db, add_coins
            # Record join date
            conn = get_db(); cur = conn.cursor()
            cur.execute("INSERT OR IGNORE INTO users (user_id, joined_at) VALUES (?,?)",
                        (str(member.id), datetime.now().isoformat()))
            cur.execute("UPDATE users SET joined_at=? WHERE user_id=? AND joined_at IS NULL",
                        (datetime.now().isoformat(), str(member.id)))
            conn.commit()

            # Try to identify which invite was used (requires Manage Server permission)
            try:
                invites_after = await member.guild.invites()
                cached_inv    = getattr(self, "_invite_cache", {}).get(member.guild.id, [])
                used_inv      = None
                for inv in invites_after:
                    for c in cached_inv:
                        if c.code == inv.code and c.uses < inv.uses:
                            used_inv = inv; break
                    if used_inv: break

                if used_inv and used_inv.inviter:
                    inviter_id = str(used_inv.inviter.id)
                    cur2 = conn.cursor()
                    cur2.execute(
                        "INSERT OR IGNORE INTO invite_tracking (inviter_id,invitee_id,joined_at,valid) VALUES (?,?,?,1)",
                        (inviter_id, str(member.id), datetime.now().isoformat())
                    )
                    conn.commit()
                    # Award invite coins immediately (may be invalidated at 7 days if they leave)
                    add_coins(inviter_id, 5)
                    logger.info(f"[Invite] {member} invited by {inviter_id} — +5 coins")
            except Exception as e:
                logger.debug(f"[Invite] Tracking failed: {e}")

            # Refresh invite cache
            try:
                self._invite_cache = getattr(self, "_invite_cache", {})
                self._invite_cache[member.guild.id] = await member.guild.invites()
            except Exception: pass

        except Exception as e:
            logger.debug(f"on_member_join error: {e}")

    async def on_member_remove(self, member: discord.Member):
        """
        When a member leaves:
        1. If they were in VPS_USERS → auto-delete their VPS
        2. If they leave within 7 days → invalidate invite, deduct coins from inviter
        """
        mid = str(member.id)
        try:
            from core.database import get_db, add_coins

            # ── Invite invalidation (7-day anti-fake rule) ───────────────────
            conn = get_db(); cur = conn.cursor()
            cur.execute("SELECT * FROM invite_tracking WHERE invitee_id=? AND valid=1", (mid,))
            inv_row = cur.fetchone()
            if inv_row:
                joined_at  = inv_row["joined_at"]
                inviter_id = inv_row["inviter_id"]
                try:
                    jdt = datetime.fromisoformat(joined_at)
                    days_stayed = (datetime.now() - jdt).days
                    if days_stayed < 7:
                        # Invalidate invite + claw back coins
                        cur.execute("UPDATE invite_tracking SET valid=0, left_at=? WHERE invitee_id=?",
                                    (datetime.now().isoformat(), mid))
                        conn.commit()
                        add_coins(inviter_id, -5)  # deduct
                        logger.info(f"[Invite] {mid} left after {days_stayed}d — invalidated, -5 coins from {inviter_id}")
                    else:
                        cur.execute("UPDATE invite_tracking SET left_at=? WHERE invitee_id=?",
                                    (datetime.now().isoformat(), mid))
                        conn.commit()
                except Exception: pass

            # ── Auto-delete VPS on leave ─────────────────────────────────────
            async with data_lock:
                user_vps = list(vps_data.get(mid, []))

            if not user_vps:
                return

            logger.info(f"[Leave] {member} left — auto-deleting {len(user_vps)} VPS")

            for vps in user_vps:
                name   = vps.get("container_name")
                node   = vps.get("node", "local")
                prefix = f"{node}:" if node != "local" else ""
                if not name: continue
                try:
                    await execute_lxc(f"lxc delete {prefix}{name} --force")
                    logger.info(f"[Leave] Deleted {name}")
                except Exception as e:
                    logger.warning(f"[Leave] Could not delete {name}: {e}")

            async with data_lock:
                if mid in vps_data:
                    del vps_data[mid]
            await async_save_vps_data()

            # Log to admin channel
            embed = discord.Embed(
                title="🚪 Member Left — VPS Cleaned Up",
                description=(
                    f"**{member}** (`{mid}`) has left the server.\n"
                    f"**{len(user_vps)}** VPS container(s) were automatically removed."
                ),
                color=0xED4245, timestamp=datetime.now(),
            )
            embed.set_footer(text="MoonNodes — Automatic Cleanup on Leave")
            await _send_log(embed)

            # Refresh invite cache
            try:
                self._invite_cache = getattr(self, "_invite_cache", {})
                self._invite_cache[member.guild.id] = await member.guild.invites()
            except Exception: pass

        except Exception as e:
            logger.debug(f"on_member_remove error: {e}")


# ── Helpers ───────────────────────────────────────────────────────────────────

def _load_extension_states():
    EXT_ATTRS = [
        "MULTI_NODE", "SOSB", "ISTS", "AES", "RR", "A2FA", "MSTC",
        "UBL_ENABLED", "MARKETPLACE", "ACCOUNT", "VPS_RENEWAL",
        "VPS_MONITORING", "VPS_TEMPLATES", "MULTILANG",
    ]
    for attr in EXT_ATTRS:
        val_str = get_setting(f"ext_{attr}")
        if val_str is not None:
            new_val = (val_str.lower() == "true")
            setattr(cfg, attr, new_val)
            logger.debug(f"  ext {attr} = {new_val} (from DB)")


async def _send_log(embed: discord.Embed):
    log_ch_id = get_setting("log_channel")
    if log_ch_id and log_ch_id != "0":
        try:
            ch = bot.get_channel(int(log_ch_id))
            if ch:
                await ch.send(embed=embed)
        except Exception as e:
            logger.debug(f"Log send failed: {e}")


async def _dm_user(user_id: str, embed: discord.Embed):
    try:
        user = await bot.fetch_user(int(user_id))
        await user.send(embed=embed)
    except discord.Forbidden:
        logger.debug(f"DM to {user_id} blocked (Forbidden)")
    except Exception as e:
        logger.debug(f"DM to {user_id} failed: {e}")


# ── Background tasks ──────────────────────────────────────────────────────────

bot = MoonNodesBot()


@tasks.loop(seconds=60)
async def update_status_task():
    try:
        if getattr(cfg, "MAINTENANCE_MODE", False):
            await bot.change_presence(
                status=discord.Status.dnd,
                activity=discord.Activity(type=discord.ActivityType.watching, name="🚧 Maintenance"),
            )
            return
        total   = sum(len(v) for v in vps_data.values())
        running = sum(1 for lst in vps_data.values() for v in lst if v.get("status") == "running")
        picks   = [
            f"🌙 {total} VPS Online",
            f"🟢 {running} containers running",
            "Type /help for commands",
            "MoonNodes VPS Manager",
        ]
        await bot.change_presence(
            activity=discord.Activity(type=discord.ActivityType.watching, name=random.choice(picks))
        )
    except Exception as e:
        logger.debug(f"update_status_task error: {e}")


@tasks.loop(hours=1)
async def scheduled_backup_task():
    try:
        if not cfg.SOSB:
            return
        time_str = get_setting("scheduled_backups_time") or "02:00AM"
        try:
            run_at = datetime.strptime(time_str.upper(), "%I:%M%p").replace(
                year=datetime.now().year, month=datetime.now().month, day=datetime.now().day
            )
            now = datetime.now()
            if abs((now - run_at).total_seconds()) > 3600:
                return
        except Exception:
            pass

        logger.info("[SOSB] Running scheduled backups…")
        today = datetime.now().strftime("%Y%m%d")
        async with data_lock:
            snapshot = {uid: list(lst) for uid, lst in vps_data.items()}

        backed_up = 0
        for uid, vps_list in snapshot.items():
            for vps in vps_list:
                if vps.get("status") != "running":
                    continue
                name      = vps["container_name"]
                node      = vps.get("node", "local")
                prefix    = f"{node}:" if node != "local" else ""
                snap_name = f"auto-{today}"

                if cfg.UBL_ENABLED:
                    try:
                        limit = int(get_setting("backup_limits_value") or cfg.UBL_LIMIT or 1)
                        info  = await execute_lxc(f"lxc info {prefix}{name}")
                        auto_snaps = [l for l in str(info).splitlines() if "auto-" in l]
                        while len(auto_snaps) >= limit:
                            oldest = sorted(auto_snaps)[0].strip().split()[0]
                            try:
                                await execute_lxc(f"lxc delete {prefix}{name}/{oldest}")
                            except Exception:
                                pass
                            auto_snaps.pop(0)
                    except Exception:
                        pass

                try:
                    await execute_lxc(f"lxc snapshot {prefix}{name} {snap_name}")
                    backed_up += 1
                    logger.info(f"[SOSB] ✅ {name}/{snap_name}")
                except Exception as e:
                    logger.warning(f"[SOSB] ⚠️ {name}: {e}")

        if backed_up > 0:
            await _send_log(create_success_embed(
                "📦  Scheduled Backup Complete",
                f"Auto-backed up **{backed_up}** VPS container(s) at `{today}`."
            ))
    except Exception as e:
        logger.error(f"scheduled_backup_task unhandled error: {e}")


@tasks.loop(hours=6)
@tasks.loop(hours=1)
async def expiration_task():
    """
    Enterprise-grade VPS lifecycle manager.

    Timeline (configurable via .env):
      T-14d  → First reminder DM
      T-7d   → Second reminder DM
      T-3d   → Third reminder DM
      T-1d   → Final warning DM
      T-0    → Grace period starts (VPS keeps running, GRACE_HOURS hours)
      T+GRACE→ VPS suspended + DM
      T+GRACE+DELETE_DAYS → VPS permanently deleted + DM
    """
    try:
        if not cfg.AES and not cfg.RR:
            return

        GRACE_HOURS  = int(getattr(cfg, "GRACE_HOURS",  24))   # hours after expiry before suspend
        DELETE_DAYS  = int(getattr(cfg, "DELETE_DAYS",  7))    # days after suspend before delete
        REMIND_DAYS  = [14, 7, 3, 1]                           # days before expiry to send reminders

        logger.info("[Expiry] Running lifecycle checks…")
        now = datetime.now()

        async with data_lock:
            snapshot = {uid: list(lst) for uid, lst in vps_data.items()}

        for uid, vps_list in snapshot.items():
            lang = "en"
            try:
                from core.lang import get_user_lang
                lang = get_user_lang(uid)
            except Exception:
                pass

            for vps in vps_list:
                exp_str = vps.get("expiry") or vps.get("expires_at")
                name    = vps.get("container_name", "?")
                node    = vps.get("node", "local")
                prefix  = f"{node}:" if node != "local" else ""

                try:
                    # ── CASE 1: No expiry set → skip ─────────────────────────
                    if not exp_str:
                        continue

                    exp_date  = datetime.fromisoformat(exp_str)
                    hours_left = (exp_date - now).total_seconds() / 3600
                    days_left  = hours_left / 24

                    # ── CASE 2: Not yet expired → send reminders ──────────────
                    if hours_left > 0 and cfg.RR:
                        for remind_day in REMIND_DAYS:
                            # Window: within this hour of the remind-day mark
                            target = remind_day * 24
                            if target - 1 <= hours_left < target:
                                _sent_key = f"reminded_{name}_{remind_day}d"
                                # Avoid duplicate reminders within same hour
                                if vps.get(_sent_key) == now.strftime("%Y-%m-%dT%H"):
                                    break

                                from core.lang import t as _t
                                if remind_day == 1:
                                    title = _t("expire_final_title", lang=lang)
                                    body  = _t("expire_final_body", lang=lang,
                                               name=name, ts=int(exp_date.timestamp()))
                                    color = Theme.ERROR
                                else:
                                    emoji = "🟡" if remind_day >= 7 else "🟠"
                                    s     = "s" if remind_day > 1 else ""
                                    title = _t("expire_warning_title", lang=lang,
                                               emoji=emoji, days=remind_day, s=s)
                                    body  = _t("expire_reminder_body", lang=lang,
                                               name=name, ts=int(exp_date.timestamp()))
                                    color = Theme.WARNING

                                embed = discord.Embed(
                                    title=title, description=body,
                                    color=color, timestamp=now
                                )
                                embed.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)
                                embed.set_footer(text="MoonNodes · Renewal Reminder")
                                await _dm_user(uid, embed)

                                # Mark sent
                                async with data_lock:
                                    vps[_sent_key] = now.strftime("%Y-%m-%dT%H")
                                await async_save_vps_data()
                                logger.info(f"[Expiry] Reminder ({remind_day}d) → {uid} for {name}")
                                break

                    # ── CASE 3: Expired, within grace period → DM once ────────
                    elif -GRACE_HOURS <= hours_left <= 0 and not vps.get("suspended"):
                        if cfg.AES:
                            _grace_key = f"grace_dm_{name}"
                            if not vps.get(_grace_key):
                                from core.lang import t as _t
                                hours_remaining = GRACE_HOURS + hours_left  # hours_left is negative
                                body  = _t("expire_grace_body", lang=lang,
                                           name=name, ts=int(exp_date.timestamp()),
                                           grace=int(max(1, hours_remaining)))
                                embed = discord.Embed(
                                    title=_t("expire_grace_title", lang=lang),
                                    description=body,
                                    color=0xFFA500, timestamp=now,
                                )
                                embed.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)
                                embed.set_footer(text=f"MoonNodes · {int(max(1, hours_remaining))}h grace period remaining")
                                await _dm_user(uid, embed)
                                async with data_lock:
                                    vps[_grace_key] = True
                                await async_save_vps_data()
                                logger.info(f"[Expiry] Grace period DM → {uid} for {name}")

                    # ── CASE 4: Grace expired → suspend ───────────────────────
                    elif hours_left < -GRACE_HOURS and not vps.get("suspended") and cfg.AES:
                        try:
                            await execute_lxc(f"lxc stop {prefix}{name}", timeout=30)
                        except Exception:
                            pass
                        async with data_lock:
                            vps["suspended"]  = True
                            vps["status"]     = "stopped"
                            vps["suspended_at"] = now.isoformat()
                            vps.setdefault("suspension_history", []).append({
                                "time": now.isoformat(), "reason": "Subscription expired", "by": "System",
                            })
                        await async_save_vps_data()

                        from core.lang import t as _t
                        s    = "s" if DELETE_DAYS > 1 else ""
                        body = _t("expire_suspended_body", lang=lang,
                                  name=name, ts=int(exp_date.timestamp()),
                                  delete_days=DELETE_DAYS, s=s)
                        embed = discord.Embed(
                            title=_t("expire_title", lang=lang),
                            description=body,
                            color=Theme.ERROR, timestamp=now,
                        )
                        embed.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)
                        embed.set_footer(text="MoonNodes · Automated Expiry System")
                        await _dm_user(uid, embed)

                        # Log to audit
                        try:
                            from core.audit import audit_bg
                            await audit_bg(bot_ref, "VPS Auto-Suspended",
                                           by_id="System", target=name,
                                           details=f"Grace period expired. Owner: {uid}")
                        except Exception:
                            pass
                        logger.info(f"[Expiry] Auto-suspended {name} (owner {uid})")

                    # ── CASE 5: Suspended + DELETE_DAYS passed → delete ───────
                    elif vps.get("suspended") and cfg.AES:
                        suspended_at_str = vps.get("suspended_at")
                        if not suspended_at_str:
                            # Legacy: fall back to expiry date + grace
                            suspended_at_str = (exp_date + __import__("datetime").timedelta(hours=GRACE_HOURS)).isoformat()

                        suspended_at  = datetime.fromisoformat(suspended_at_str)
                        days_suspended = (now - suspended_at).days

                        if days_suspended >= DELETE_DAYS:
                            # Destroy container
                            try:
                                await execute_lxc(f"lxc delete {prefix}{name} --force", timeout=60)
                            except Exception as del_err:
                                logger.warning(f"[Expiry] Delete failed for {name}: {del_err}")
                                continue

                            # Remove from memory
                            async with data_lock:
                                user_list = vps_data.get(uid, [])
                                vps_data[uid] = [v for v in user_list if v.get("container_name") != name]
                            await async_save_vps_data()

                            # DM the user
                            from core.lang import t as _t
                            body = _t("expire_deleted_body", lang=lang,
                                      name=name,
                                      sus_ts=int(suspended_at.timestamp()),
                                      delete_days=DELETE_DAYS)
                            embed = discord.Embed(
                                title=_t("expire_deleted_title", lang=lang),
                                description=body,
                                color=0x36393F, timestamp=now,
                            )
                            embed.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)
                            embed.set_footer(text="MoonNodes · Automated Expiry System")
                            await _dm_user(uid, embed)

                            try:
                                from core.audit import audit_bg
                                await audit_bg(bot_ref, "VPS Auto-Deleted",
                                               by_id="System", target=name,
                                               details=f"Suspended {days_suspended}d ago. Owner: {uid}")
                            except Exception:
                                pass
                            logger.info(f"[Expiry] Auto-deleted {name} (suspended {days_suspended}d ago)")

                except Exception as e:
                    logger.warning(f"[Expiry] Error for {name}: {e}")

    except Exception as e:
        logger.error(f"expiration_task unhandled error: {e}")


@tasks.loop(minutes=5)
async def usage_sampling_task():
    """
    Sample CPU / RAM / disk for every running VPS every 5 minutes.
    Stores results in usage_history table.
    Prunes data older than 30 days automatically.
    """
    try:
        from core.lxc import get_container_cpu_pct, get_container_memory, get_container_disk
        from core.database import save_snapshot  # reuse DB connection

        now = datetime.now()
        async with data_lock:
            snapshot = {uid: list(lst) for uid, lst in vps_data.items()}

        rows_to_insert = []
        for uid, vps_list in snapshot.items():
            for vps in vps_list:
                if vps.get("status") != "running" or vps.get("suspended"):
                    continue
                cname = vps.get("container_name", "")
                node  = vps.get("node", "local")
                if not cname:
                    continue
                try:
                    cpu_pct  = await get_container_cpu_pct(cname, node) or 0.0
                    mem_str  = await get_container_memory(cname, node) or ""
                    dsk_str  = await get_container_disk(cname, node) or ""

                    import re as _re
                    ram_pct = 0.0
                    dsk_pct = 0.0
                    m = _re.search(r"\((\d+\.?\d*)%\)", mem_str)
                    if m: ram_pct = float(m.group(1))
                    m = _re.search(r"\((\d+\.?\d*)%\)", dsk_str)
                    if m: dsk_pct = float(m.group(1))

                    rows_to_insert.append((cname, uid, node, cpu_pct, ram_pct, dsk_pct, now.isoformat()))
                except Exception:
                    pass

        if rows_to_insert:
            conn = get_db()
            conn.executemany(
                "INSERT INTO usage_history (container_name,user_id,node,cpu_pct,ram_pct,disk_pct,sampled_at) "
                "VALUES (?,?,?,?,?,?,?)",
                rows_to_insert,
            )
            # Prune data older than 30 days
            cutoff = (now - __import__("datetime").timedelta(days=30)).isoformat()
            conn.execute("DELETE FROM usage_history WHERE sampled_at < ?", (cutoff,))
            conn.commit()
            logger.debug(f"[UsageSampling] Recorded {len(rows_to_insert)} samples")
    except ImportError:
        pass  # lxc module not available
    except Exception as e:
        logger.error(f"usage_sampling_task error: {e}")


@tasks.loop(minutes=10)
async def vps_monitoring_task():
    try:
        if not cfg.VPS_MONITORING:
            return
        from core.lxc import get_container_cpu_pct, get_container_memory
        async with data_lock:
            snapshot = {uid: list(lst) for uid, lst in vps_data.items()}

        alerted = set()
        for uid, vps_list in snapshot.items():
            for vps in vps_list:
                if vps.get("status") != "running" or vps.get("suspended"):
                    continue
                name = vps["container_name"]
                node = vps.get("node", "local")
                try:
                    cpu_pct = await get_container_cpu_pct(name, node)
                    mem_str = await get_container_memory(name, node)
                    ram_pct = 0.0
                    m = re.search(r"\((\d+\.?\d*)%\)", mem_str)
                    if m:
                        ram_pct = float(m.group(1))

                    alert_key = f"{uid}:{name}"
                    if (cpu_pct >= cfg.CPU_THRESHOLD or ram_pct >= cfg.RAM_THRESHOLD) and alert_key not in alerted:
                        alerted.add(alert_key)
                        embed = discord.Embed(
                            title="🚨 High Resource Usage Detected",
                            description=(
                                f"Your VPS **`{name}`** is consuming unusually high resources!\n\n"
                                f"💠 **CPU Usage:** `{cpu_pct:.1f}%` {'⚠️ Above threshold' if cpu_pct >= cfg.CPU_THRESHOLD else '✅ Normal'}\n"
                                f"🧬 **RAM Usage:** `{ram_pct:.1f}%` {'⚠️ Above threshold' if ram_pct >= cfg.RAM_THRESHOLD else '✅ Normal'}\n\n"
                                "**Action required:** Check your running processes to prevent automatic suspension.\n"
                                "*Use `/manage` to access your VPS console.*"
                            ),
                            color=Theme.ERROR,
                            timestamp=datetime.now(),
                        )
                        embed.set_author(name="MoonNodes Monitoring", icon_url=Theme.ICON_URL)
                        embed.set_footer(text="MoonNodes · Resource Monitor — Use /manage to investigate")
                        await _dm_user(uid, embed)
                        logger.info(f"[VPS_MONITORING] Alert → {uid} for {name} (CPU:{cpu_pct:.1f}% RAM:{ram_pct:.1f}%)")
                except Exception:
                    pass
    except Exception as e:
        logger.error(f"vps_monitoring_task unhandled error: {e}")


@tasks.loop(hours=24)
async def mstc_health_task():
    try:
        if not cfg.MSTC:
            return
        for guild in bot.guilds:
            ch_id = get_setting(f"ticket_channel_{guild.id}") or get_setting("ticket_channel")
            if ch_id and guild.get_channel(int(ch_id)) is None:
                logger.warning(f"[MSTC] Ticket channel {ch_id} missing in guild {guild.id}")
    except Exception as e:
        logger.error(f"mstc_health_task unhandled error: {e}")


@tasks.loop(hours=12)
async def ubl_cleanup_task():
    try:
        if not cfg.UBL_ENABLED:
            return
        limit_str = get_setting("backup_limits_value") or str(getattr(cfg, "UBL_LIMIT", 1))
        try:
            limit = max(1, int(limit_str))
        except ValueError:
            return

        logger.info(f"[UBL] Enforcing backup limit of {limit} per VPS…")
        async with data_lock:
            snapshot = {uid: list(lst) for uid, lst in vps_data.items()}

        for uid, vps_list in snapshot.items():
            for vps in vps_list:
                name   = vps["container_name"]
                node   = vps.get("node", "local")
                prefix = f"{node}:" if node != "local" else ""
                try:
                    info  = await execute_lxc(f"lxc info {prefix}{name}")
                    snaps = [l.strip().split()[0] for l in str(info).splitlines() if l.strip().startswith("auto-")]
                    while len(snaps) > limit:
                        oldest = sorted(snaps)[0]
                        await execute_lxc(f"lxc delete {prefix}{name}/{oldest}")
                        snaps.remove(oldest)
                        logger.info(f"[UBL] Deleted old snapshot {name}/{oldest}")
                except Exception:
                    pass
    except Exception as e:
        logger.error(f"ubl_cleanup_task unhandled error: {e}")


# ── A2FA helper ───────────────────────────────────────────────────────────────

async def verify_a2fa(interaction: discord.Interaction) -> bool:
    if not cfg.A2FA:
        return True
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("SELECT pin FROM admins WHERE user_id=?", (str(interaction.user.id),))
    row  = cur.fetchone()
    pin  = row["pin"] if row else "0000"
    if pin == "0000":
        return True

    class PinModal(discord.ui.Modal, title="🔐 Admin 2FA Verification"):
        pin_input = discord.ui.TextInput(label="Enter your 4-digit PIN", max_length=4, min_length=4)
        async def on_submit(self_m, inter: discord.Interaction):
            self_m.success = (self_m.pin_input.value == pin)
            await inter.response.defer()
        success = False

    modal = PinModal()
    await interaction.response.send_modal(modal)
    await modal.wait()
    if not modal.success:
        await interaction.followup.send(
            embed=create_error_embed("🔐 2FA Failed", "Incorrect PIN. Access denied."),
            ephemeral=True
        )
    return modal.success


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    init_db()
    if not DISCORD_TOKEN:
        logger.error(
            "DISCORD_TOKEN is not set.\n"
            "  • Open your .env file in the bot folder\n"
            "  • Add:  DISCORD_TOKEN=your_token_here\n"
            "  • Save the file and restart the bot.\n"
            "  • Get your token from https://discord.com/developers/applications"
        )
        sys.exit(1)
    try:
        bot.run(DISCORD_TOKEN, log_handler=None)
    except KeyboardInterrupt:
        logger.info("Bot stopped.")
