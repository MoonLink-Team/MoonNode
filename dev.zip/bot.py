"""
MoonNodes VPS Manager — bot.py
Entry point: loads all cogs and starts background tasks.
"""

import asyncio
import logging
import random
import sys
import os
from datetime import datetime, timedelta

import discord
from discord.ext import commands, tasks

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import core
from core.config import DISCORD_TOKEN, MAIN_ADMIN_ID, CPU_THRESHOLD, RAM_THRESHOLD
from core.database import init_db, load_vps_data, load_admin_data, vps_data, data_lock, save_vps_data, get_setting, admin_data, get_db
from core.lxc import execute_lxc, RUNTIME
from core.monitoring import start_resource_monitor
from core.theme import Theme, add_field, create_embed, create_error_embed, create_info_embed, create_loading_embed, create_success_embed, create_warning_embed
import core.config as cfg

logger = logging.getLogger("moonnodes_vps_bot")


# ── Bot class ────────────────────────────────────────────────────────────────

class MoonNodesBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members         = True
        intents.invites         = True
        super().__init__(command_prefix="!", intents=intents, help_command=None)

    async def setup_hook(self):
        cogs = [
            # Owner
            "commands.Owner.admin",
            "commands.Owner.create",
            "commands.Owner.delete",
            "commands.Owner.giveaway",
            "commands.Owner.nodes",
            "commands.Owner.system",
            # Admin
            "commands.Admin.set_cmd",
            # Dev
            "commands.Dev.dev_tools",
            # Mod
            "commands.Mod.mod_tools",
            # Staff
            "commands.Staff.staff_tools",
            # User
            "commands.User.list_cmd",
            "commands.User.manage",
            "commands.User.plans",
            "commands.User.claim",
            "commands.User.backup",
            "commands.User.support",
            "commands.User.status",
            "commands.User.upgrade",
            "commands.User.help",
            "commands.User.marketplace",
            "commands.User.account",
        ]
        for cog in cogs:
            try:
                await self.load_extension(cog)
                logger.info(f"✅ Loaded: {cog}")
            except Exception as e:
                logger.error(f"❌ Failed to load {cog}: {e}")

        # ── Sync slash commands ──────────────────────────────────────────────
        from core.config import GUILD_ID
        try:
            if GUILD_ID:
                guild_obj = discord.Object(id=GUILD_ID)
                # Clear global commands to prevent duplicates in Discord command list
                self.tree.clear_commands(guild=None)
                await self.tree.sync()                         # push empty global
                # Sync all commands to the specific guild (appears instantly)
                self.tree.copy_global_to(guild=guild_obj)
                synced = await self.tree.sync(guild=guild_obj)
                logger.info(f"🔗 Synced {len(synced)} command(s) to guild {GUILD_ID} (instant, no duplicates)")
            else:
                # Global sync — clear guild-specific commands first
                for guild in self.guilds:
                    self.tree.clear_commands(guild=guild)
                    await self.tree.sync(guild=guild)
                synced = await self.tree.sync()
                logger.info(f"🔗 Synced {len(synced)} command(s) globally")
        except Exception as e:
            logger.error(f"Failed to sync commands: {e}")

    async def on_ready(self):
        logger.info(f"🌙 Bot ready — {self.user} ({self.user.id}) | Runtime: {RUNTIME}")

        load_vps_data()
        load_admin_data()

        # Load admin roles from DB into memory
        try:
            conn = get_db()
            cur  = conn.cursor()
            cur.execute("SELECT user_id, role FROM admins")
            for row in cur.fetchall():
                admin_data[row["user_id"]] = row["role"]
            conn.close()
        except Exception as e:
            logger.error(f"Admin load error: {e}")

        # Load extension states from DB (overrides .env at runtime)
        _load_extension_states()

        # Start background tasks
        update_status_task.start()
        scheduled_backup_task.start()
        expiration_task.start()
        vps_monitoring_task.start()
        mstc_health_task.start()
        ubl_cleanup_task.start()

        # Start sync resource monitor thread
        start_resource_monitor(
            bot_loop      = self.loop,
            cpu_threshold = CPU_THRESHOLD,
            ram_threshold = RAM_THRESHOLD,
            vps_data_ref  = vps_data,
            data_lock_ref = data_lock,
            save_fn       = save_vps_data,
            send_log_fn   = _send_log,
        )

        # Sync VPS states from actual incus/lxd state (fixes status after restarts/crashes)
        await self._sync_vps_states()

        # Log VPS inventory after sync
        total   = sum(len(v) for v in vps_data.values())
        running = sum(1 for lst in vps_data.values() for v in lst if v.get("status") == "running")
        logger.info(f"🟢 All systems online — {total} VPS in database ({running} running)")

        # Post startup notice to log channel
        await _send_log(create_info_embed(
            "Bot Online",
            "MoonNodes is online. Runtime: " + RUNTIME + " | VPS: " + str(total) + " | Running: " + str(running)
        ))

    async def _sync_vps_states(self):
        """
        Full VPS sync:
        1. Update status of known containers from actual incus/lxd state
        2. Import orphaned containers (exist in incus/lxd but not in vps_data)
           This recovers VPS after a vps_data.json loss or first run.
        """
        from core.lxc import execute_lxc
        from core.database import vps_data, data_lock, save_vps_data
        from core.config import VPS_PREFIX
        logger.info("🔄 Syncing VPS states from container runtime...")
        synced  = 0
        adopted = 0
        try:
            raw = await execute_lxc("lxc list --format=csv")
            if not raw or raw is True:
                logger.info("✅ VPS state sync — no containers found")
                return

            # Parse: container_name -> {status, ipv4}
            actual = {}
            for line in str(raw).strip().splitlines():
                parts = line.split(",")
                if len(parts) >= 2:
                    name   = parts[0].strip()
                    status = parts[1].strip().lower()
                    ipv4   = parts[2].strip() if len(parts) > 2 else ""
                    if name:
                        actual[name] = {"status": status, "ipv4": ipv4}

            # Build set of already-known containers
            with data_lock:
                known = {
                    v.get("container_name")
                    for lst in vps_data.values()
                    for v in lst
                }

            # Step 1: Update known containers
            with data_lock:
                for uid, vps_list in vps_data.items():
                    for vps in vps_list:
                        cname = vps.get("container_name", "")
                        if cname in actual:
                            real = actual[cname]["status"]
                            if vps.get("status") != real:
                                logger.info(f"  Sync {cname}: {vps.get('status')} → {real}")
                                vps["status"] = real
                                if real == "running" and vps.get("suspended"):
                                    vps["suspended"] = False
                                synced += 1

            # Step 2: Adopt orphaned containers that match our prefix
            for cname, info in actual.items():
                if cname in known:
                    continue
                # Only adopt containers that match our naming pattern
                if not cname.startswith(VPS_PREFIX + "-"):
                    continue

                # Try to extract user from container name: vps-username-N
                parts = cname.split("-")
                # Format: {prefix}-{username}-{num}
                # parts[0] = prefix, parts[-1] = num, parts[1:-1] = username
                if len(parts) < 3:
                    continue

                # Get info about the container
                try:
                    info_out = await execute_lxc(f"lxc config show {cname}")
                    info_text = str(info_out) if info_out and info_out is not True else ""
                except Exception:
                    info_text = ""

                # Extract limits from config
                import re as _re
                ram_mb  = 0
                cpu_cnt = "1"
                m = _re.search(r"limits\.memory:\s*(\d+)MB", info_text)
                if m: ram_mb = int(m.group(1))
                m = _re.search(r"limits\.cpu:\s*(\d+)", info_text)
                if m: cpu_cnt = m.group(1)

                ram_gb = (ram_mb // 1024) if ram_mb else 1
                orphan = {
                    "container_name": cname,
                    "ram":    f"{ram_gb}GB",
                    "cpu":    cpu_cnt,
                    "storage": "10GB",
                    "config":  f"{ram_gb}GB RAM / {cpu_cnt} CPU / 10GB Disk",
                    "os_version": "ubuntu:22.04",
                    "status":     info["status"],
                    "suspended":  False,
                    "whitelisted": False,
                    "node":       "local",
                    "created_at": datetime.now().isoformat(),
                    "expiry":     None,
                    "shared_with": [],
                    "suspension_history": [],
                    "id": None,
                }

                # We can't know the owner, so put it under the bot owner
                owner_uid = str(MAIN_ADMIN_ID)
                with data_lock:
                    vps_data.setdefault(owner_uid, []).append(orphan)
                adopted += 1
                logger.warning(
                    f"  Adopted orphaned container `{cname}` under owner {owner_uid}. "
                    f"Use /account admin_action:VPS to reassign if needed."
                )

            if synced or adopted:
                save_vps_data()

            logger.info(f"✅ VPS sync complete — updated {synced}, adopted {adopted} orphaned container(s)")
        except Exception as e:
            logger.warning(f"VPS state sync failed (non-fatal): {e}")

    async def on_app_command_error(self, interaction: discord.Interaction, error):
        msg = ""
        if isinstance(error, discord.app_commands.CheckFailure):
            msg = str(error) or "You don't have permission to use this command."
            embed = create_error_embed("Access Denied", msg)
        elif isinstance(error, discord.app_commands.CommandInvokeError):
            msg = str(error.original)[:3900]
            logger.error(f"Command invoke error: {msg}")
            embed = create_error_embed("Something Went Wrong", f"```{msg}```")
        else:
            msg = str(error)[:3900]
            logger.error(f"App command error: {msg}")
            embed = create_error_embed("Error", msg)

        try:
            if interaction.response.is_done():
                await interaction.followup.send(embed=embed, ephemeral=True)
            else:
                await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception:
            pass

    async def on_command_error(self, ctx, error):
        if isinstance(error, commands.CommandNotFound):
            return


# ── Helpers ───────────────────────────────────────────────────────────────────

def _load_extension_states():
    """
    Load extension on/off states from DB, overriding .env values.
    Called on startup and whenever /system changes a flag.
    This ensures bot restarts preserve the last toggle state.
    """
    EXT_ATTRS = [
        "MULTI_NODE","SOSB","ISTS","AES","RR","A2FA","MSTC",
        "UBL_ENABLED","MARKETPLACE","ACCOUNT","VPS_RENEWAL",
        "VPS_MONITORING","VPS_TEMPLATES","MULTILANG",
    ]
    for attr in EXT_ATTRS:
        val_str = get_setting(f"ext_{attr}")
        if val_str is not None:
            new_val = (val_str.lower() == "true")
            setattr(cfg, attr, new_val)
            logger.debug(f"  ext {attr} = {new_val} (from DB)")

async def _send_log(embed: discord.Embed):
    log_ch_id = get_setting("log_channel")
    if log_ch_id and log_ch_id != "0":
        try:
            ch = bot.get_channel(int(log_ch_id))
            if ch:
                await ch.send(embed=embed)
        except Exception as e:
            logger.error(f"Log send failed: {e}")

async def _dm_user(user_id: str, embed: discord.Embed):
    try:
        user = await bot.fetch_user(int(user_id))
        await user.send(embed=embed)
    except Exception:
        pass


# ── Background tasks ──────────────────────────────────────────────────────────

bot = MoonNodesBot()


@tasks.loop(seconds=60)
async def update_status_task():
    try:
        if getattr(cfg, "MAINTENANCE_MODE", False):
            await bot.change_presence(
                status=discord.Status.dnd,
                activity=discord.Activity(type=discord.ActivityType.watching, name="🚧 Maintenance"),
            )
            return
        total   = sum(len(v) for v in vps_data.values())
        running = sum(1 for lst in vps_data.values() for v in lst if v.get("status") == "running")
        picks   = [
            f"🌙 {total} VPS Online",
            f"🟢 {running} containers running",
            "Type /help for commands",
            "MoonNodes VPS Manager",
        ]
        await bot.change_presence(
            activity=discord.Activity(type=discord.ActivityType.watching, name=random.choice(picks))
        )
    except Exception:
        pass


# ── SOSB — Scheduled Backups ──────────────────────────────────────────────────

@tasks.loop(hours=1)
async def scheduled_backup_task():
    if not cfg.SOSB:
        return

    # Check if now matches the configured run time
    time_str = get_setting("scheduled_backups_time") or "02:00AM"
    try:
        run_at   = datetime.strptime(time_str.upper(), "%I:%M%p").replace(
            year=datetime.now().year, month=datetime.now().month, day=datetime.now().day
        )
        now      = datetime.now()
        if abs((now - run_at).total_seconds()) > 3600:  # Not within this hour
            return
    except Exception:
        pass  # Run every 24h if parsing fails

    logger.info("[SOSB] Running scheduled backups…")
    today = datetime.now().strftime("%Y%m%d")
    with data_lock:
        snapshot = {uid: list(lst) for uid, lst in vps_data.items()}

    backed_up = 0
    for uid, vps_list in snapshot.items():
        for vps in vps_list:
            if vps.get("status") != "running":
                continue
            name      = vps["container_name"]
            node      = vps.get("node", "local")
            prefix    = f"{node}:" if node != "local" else ""
            snap_name = f"auto-{today}"

            # Enforce backup limit if UBL enabled
            if cfg.UBL_ENABLED:
                try:
                    limit = int(get_setting("backup_limits_value") or cfg.UBL_LIMIT or 1)
                    info  = await execute_lxc(f"lxc info {prefix}{name}")
                    auto_snaps = [l for l in str(info).splitlines() if "auto-" in l]
                    # Delete oldest if over limit
                    while len(auto_snaps) >= limit:
                        oldest = sorted(auto_snaps)[0].strip().split()[0]
                        try:
                            await execute_lxc(f"lxc delete {prefix}{name}/{oldest}")
                        except Exception:
                            pass
                        auto_snaps.pop(0)
                except Exception:
                    pass

            try:
                await execute_lxc(f"lxc snapshot {prefix}{name} {snap_name}")
                backed_up += 1
                logger.info(f"[SOSB] ✅ {name}/{snap_name}")
            except Exception as e:
                logger.warning(f"[SOSB] ⚠️ {name}: {e}")

    if backed_up > 0:
        await _send_log(create_success_embed(
            "Scheduled Backup Complete",
            f"Auto-backed up **{backed_up}** VPS container(s) at `{today}`."
        ))


# ── AES + RR — Expiration & Renewal Reminders ─────────────────────────────────

@tasks.loop(hours=6)
async def expiration_task():
    if not cfg.AES and not cfg.RR:
        return
    logger.info("[AES/RR] Running expiration checks…")
    now = datetime.now()
    with data_lock:
        snapshot = {uid: list(lst) for uid, lst in vps_data.items()}

    for uid, vps_list in snapshot.items():
        for vps in vps_list:
            exp_str = vps.get("expiry") or vps.get("expires_at")
            if not exp_str:
                continue
            try:
                exp_date  = datetime.fromisoformat(exp_str)
                days_left = (exp_date - now).days
                name      = vps["container_name"]
                node      = vps.get("node", "local")
                prefix    = f"{node}:" if node != "local" else ""

                # Auto Expire & Suspend
                if cfg.AES and days_left <= 0 and not vps.get("suspended"):
                    try:
                        await execute_lxc(f"lxc stop {prefix}{name}", timeout=30)
                    except Exception:
                        pass
                    with data_lock:
                        vps["suspended"] = True
                        vps["status"]    = "stopped"
                        vps.setdefault("suspension_history", []).append({
                            "time": now.isoformat(), "reason": "VPS expired", "by": "System",
                        })
                    save_vps_data()
                    embed = discord.Embed(
                        title="⏰  VPS Expired & Suspended",
                        description=(
                            f"Your VPS **`{name}`** has reached its expiry date and has been suspended.\n\n"
                            "To reactivate it, please renew your plan or open a support ticket."
                        ),
                        color=Theme.ERROR, timestamp=now,
                    )
                    embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                    await _dm_user(uid, embed)
                    logger.info(f"[AES] Suspended expired VPS: {name}")

                # Renewal reminders — 7 days, 3 days, 1 day
                elif cfg.RR and days_left in (7, 3, 1):
                    urgency = "🔴" if days_left == 1 else "🟡" if days_left == 3 else "🟠"
                    embed   = discord.Embed(
                        title=f"{urgency}  VPS Expiry Reminder",
                        description=(
                            f"Your VPS **`{name}`** expires in **{days_left} day{'s' if days_left > 1 else ''}**!\n\n"
                            f"**Expiry:** <t:{int(exp_date.timestamp())}:F>\n\n"
                            "Renew now to avoid losing access to your server."
                        ),
                        color=Theme.WARNING if days_left > 1 else Theme.ERROR,
                        timestamp=now,
                    )
                    embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                    embed.set_footer(text="Use /upgrade or open a ticket to renew")
                    await _dm_user(uid, embed)

            except Exception as e:
                logger.warning(f"[AES/RR] Error processing {vps.get('container_name','?')}: {e}")


# ── VPS Monitoring Alerts ─────────────────────────────────────────────────────

@tasks.loop(minutes=10)
async def vps_monitoring_task():
    if not cfg.VPS_MONITORING:
        return
    from core.lxc import get_container_cpu_pct, get_container_memory
    with data_lock:
        snapshot = {uid: list(lst) for uid, lst in vps_data.items()}

    alerted = set()
    for uid, vps_list in snapshot.items():
        for vps in vps_list:
            if vps.get("status") != "running" or vps.get("suspended"):
                continue
            name   = vps["container_name"]
            node   = vps.get("node", "local")

            try:
                cpu_pct = await get_container_cpu_pct(name, node)
                mem_str = await get_container_memory(name, node)

                # Parse RAM % from "used/total MB (pct%)"
                ram_pct = 0.0
                import re
                m = re.search(r"\((\d+\.?\d*)%\)", mem_str)
                if m:
                    ram_pct = float(m.group(1))

                alert_key = f"{uid}:{name}"
                if (cpu_pct >= cfg.CPU_THRESHOLD or ram_pct >= cfg.RAM_THRESHOLD) and alert_key not in alerted:
                    alerted.add(alert_key)
                    embed = discord.Embed(
                        title="🚨  VPS High Resource Alert",
                        description=(
                            f"Your VPS **`{name}`** is using excessive resources!\n\n"
                            f"💠 **CPU:** `{cpu_pct:.1f}%` {'⚠️' if cpu_pct >= cfg.CPU_THRESHOLD else '✅'}\n"
                            f"🧬 **RAM:** `{ram_pct:.1f}%` {'⚠️' if ram_pct >= cfg.RAM_THRESHOLD else '✅'}\n\n"
                            "Please check your running processes to prevent automatic suspension."
                        ),
                        color=Theme.ERROR,
                        timestamp=datetime.now(),
                    )
                    embed.set_author(name="MoonNodes Monitoring", icon_url="https://imgur.com/6yfYDTP.png")
                    embed.set_footer(text="Use /manage to access your VPS console")
                    await _dm_user(uid, embed)
                    logger.info(f"[VPS_MONITORING] Alert sent to {uid} for {name} (CPU:{cpu_pct:.1f}% RAM:{ram_pct:.1f}%)")
            except Exception:
                pass


# ── MSTC — Multi-Server Ticket Channel Health Check ──────────────────────────

@tasks.loop(hours=24)
async def mstc_health_task():
    if not cfg.MSTC:
        return
    # Verify configured ticket channels still exist in all guilds
    for guild in bot.guilds:
        ch_id = get_setting(f"ticket_channel_{guild.id}") or get_setting("ticket_channel")
        if ch_id and guild.get_channel(int(ch_id)) is None:
            logger.warning(f"[MSTC] Ticket channel {ch_id} missing in guild {guild.id}")


# ── UBL — Backup Limit Cleanup ────────────────────────────────────────────────

@tasks.loop(hours=12)
async def ubl_cleanup_task():
    if not cfg.UBL_ENABLED:
        return
    limit_str = get_setting("backup_limits_value") or str(getattr(cfg, "UBL_LIMIT", 1))
    try:
        limit = max(1, int(limit_str))
    except ValueError:
        return

    logger.info(f"[UBL] Enforcing backup limit of {limit} per VPS…")
    with data_lock:
        snapshot = {uid: list(lst) for uid, lst in vps_data.items()}

    for uid, vps_list in snapshot.items():
        for vps in vps_list:
            name   = vps["container_name"]
            node   = vps.get("node", "local")
            prefix = f"{node}:" if node != "local" else ""
            try:
                info = await execute_lxc(f"lxc info {prefix}{name}")
                snaps = [l.strip().split()[0] for l in str(info).splitlines() if l.strip().startswith("auto-")]
                while len(snaps) > limit:
                    oldest = sorted(snaps)[0]
                    await execute_lxc(f"lxc delete {prefix}{name}/{oldest}")
                    snaps.remove(oldest)
                    logger.info(f"[UBL] Deleted old snapshot {name}/{oldest}")
            except Exception:
                pass


# ── A2FA verification helper ──────────────────────────────────────────────────

async def verify_a2fa(interaction: discord.Interaction) -> bool:
    """Returns True if A2FA passes (or is disabled). Sends error embed if fails."""
    if not cfg.A2FA:
        return True
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("SELECT pin FROM admins WHERE user_id=?", (str(interaction.user.id),))
    row  = cur.fetchone()
    conn.close()
    pin  = row["pin"] if row else "0000"
    if pin == "0000":
        return True  # Not configured

    class PinModal(discord.ui.Modal, title="🔐 Admin 2FA Verification"):
        pin_input = discord.ui.TextInput(label="Enter your 4-digit PIN", max_length=4, min_length=4)
        async def on_submit(self_m, inter: discord.Interaction):
            if self_m.pin_input.value == pin:
                self_m.success = True
            else:
                self_m.success = False
            await inter.response.defer()
        success = False

    modal = PinModal()
    await interaction.response.send_modal(modal)
    await modal.wait()
    if not modal.success:
        await interaction.followup.send(
            embed=create_error_embed("2FA Failed", "Incorrect PIN. Access denied."),
            ephemeral=True
        )
    return modal.success


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    init_db()
    if not DISCORD_TOKEN:
        logger.error("DISCORD_TOKEN not set in .env — exiting.")
        sys.exit(1)
    try:
        bot.run(DISCORD_TOKEN, log_handler=None)
    except KeyboardInterrupt:
        logger.info("Bot stopped.")