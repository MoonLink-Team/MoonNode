"""
MoonNodes VPS Manager — bot.py  (v2)

Changes from v1:
  ✅ All missing cogs now loaded (Admin/vps, User/affiliate, share, transfer)
  ✅ on_ready guard: background tasks only start once (no stacking on reconnect)
  ✅ asyncio.Lock used everywhere (threading.Lock removed)
  ✅ async_await async_save_vps_data() used in all async contexts
  ✅ MAIN_ADMIN_ID compared as int throughout
  ✅ Rate limiter on /create and other heavy commands
  ✅ import re moved to module level
  ✅ Background tasks all wrapped in try/except (one crash won't kill the loop)
  ✅ DB reconnect handled in get_db()
"""

import asyncio
import logging
import random
import re
import sys
import os
from datetime import datetime, timedelta
from collections import defaultdict

import discord
from discord import app_commands
from discord.ext import commands, tasks

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import core
from core.config import DISCORD_TOKEN, MAIN_ADMIN_ID, CPU_THRESHOLD, RAM_THRESHOLD
from core.database import (
    init_db, load_vps_data, load_admin_data, vps_data, data_lock,
    async_save_vps_data, save_vps_data, get_setting, admin_data, get_db
)
from core.lxc import execute_lxc, RUNTIME
from core.monitoring import start_resource_monitor
from core.theme import (
    Theme, add_field, create_embed, create_error_embed,
    create_info_embed, create_loading_embed, create_success_embed, create_warning_embed
)
import core.config as cfg

logger = logging.getLogger("moonnodes_vps_bot")

# ── Rate limiter ──────────────────────────────────────────────────────────────
# Maps command_name → {user_id: last_used_timestamp}
_rate_limits: dict[str, dict[int, float]] = defaultdict(dict)

RATE_LIMIT_SECONDS: dict[str, int] = {
    "create":      30,   # /create  — heavy LXC deploy
    "claim":       20,   # /claim   — also deploys
    "giveaway":    10,
    "marketplace": 5,
    "backup":      15,
    "upgrade":     10,
}


def _check_rate_limit(cmd: str, user_id: int) -> float:
    """Return 0 if allowed, else seconds remaining."""
    limit = RATE_LIMIT_SECONDS.get(cmd, 0)
    if limit == 0:
        return 0
    last = _rate_limits[cmd].get(user_id, 0)
    elapsed = asyncio.get_event_loop().time() - last
    if elapsed < limit:
        return limit - elapsed
    _rate_limits[cmd][user_id] = asyncio.get_event_loop().time()
    return 0


# ── Bot class ─────────────────────────────────────────────────────────────────

class MoonNodesBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members         = True
        intents.invites         = True
        super().__init__(command_prefix="!", intents=intents, help_command=None)
        self._ready_fired      = False   # guard: only run on_ready logic once
        self._owner_confirmed  = False   # guard: commands locked until owner clicks first-boot button

    async def setup_hook(self):
        # Global interaction check — blocklist and mute
        async def _global_check(interaction: discord.Interaction) -> bool:
            if interaction.user.bot:
                return True
            uid = str(interaction.user.id)
            # ── Command lock until owner completes first-boot setup ───────────
            # ── Command lock — ALL users blocked until first-boot is done ───────
            if not self._owner_confirmed:
                import os as _osck
                _flag = _osck.path.join(_osck.path.dirname(_osck.path.abspath(__file__)), ".first_boot_done")
                if not _osck.path.exists(_flag):
                    try:
                        _lock_embed = discord.Embed(
                            title="⏳ First-Boot Setup Required",
                            description=(
                                "**The bot has not been configured yet.**\n\n"
                                "The bot owner needs to complete **First-Boot Setup** "
                                "before any commands can be used.\n\n"
                                "Check your DMs from the bot to get started."
                            ),
                            color=0xFEE75C,
                        )
                        _lock_embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                        _lock_embed.set_footer(text="All commands are locked until setup is complete.")
                        if not interaction.response.is_done():
                            await interaction.response.send_message(embed=_lock_embed, ephemeral=True)
                        else:
                            await interaction.followup.send(embed=_lock_embed, ephemeral=True)
                    except Exception:
                        pass
                    return False
            from core.database import get_db as _gdb
            try:
                conn = _gdb(); cur = conn.cursor()
                cur.execute("SELECT 1 FROM blocklist WHERE user_id=?", (uid,))
                if cur.fetchone():
                    embed = discord.Embed(
                        title="🚫 Blocklisted",
                        description="You are **blocklisted** and cannot use any bot commands.\nContact a staff member if you believe this is a mistake.",
                        color=0xED4245, timestamp=datetime.now(),
                    )
                    embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                    try:
                        if not interaction.response.is_done():
                            await interaction.response.send_message(embed=embed, ephemeral=True)
                        else:
                            await interaction.followup.send(embed=embed, ephemeral=True)
                    except Exception: pass
                    return False
            except Exception: pass
            return True
        self.tree.interaction_check = _global_check

        # Wire tree error handler — ensures CheckFailure and other app_command errors
        # reach on_app_command_error instead of being "Ignored" by discord.py default
        async def _tree_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
            self.dispatch("app_command_error", interaction, error)
        self.tree.on_error = _tree_error

        cogs = [
            # Owner
            "commands.Owner.admin",
            "commands.Owner.create",
            "commands.Owner.delete",
            "commands.Owner.giveaway",
            "commands.Owner.nodes",
            "commands.Owner.system",
            "commands.Owner.af2f_cmd",
            # Admin
            "commands.Admin.set_cmd",
            # Dev
            "commands.Dev.dev_tools",
            # Mod
            "commands.Mod.mod_tools",
            # Staff
            "commands.Staff.staff_tools",
            # User
            "commands.User.list_cmd",
            "commands.User.manage",
            "commands.User.plans",
            "commands.User.claim",
            "commands.User.support",
            "commands.User.status",
            "commands.User.help",
            "commands.User.marketplace",
            "commands.User.account",
        ]
        for cog in cogs:
            try:
                await self.load_extension(cog)
                logger.info(f"✅ Loaded: {cog}")
            except Exception as e:
                logger.error(f"❌ Failed to load {cog}: {e}")

        # ── Sync slash commands ──────────────────────────────────────────────
        from core.config import GUILD_ID
        try:
            if GUILD_ID:
                guild_obj = discord.Object(id=GUILD_ID)
                self.tree.copy_global_to(guild=guild_obj)
                # Guild sync is instant (no Discord propagation delay)
                synced = await self.tree.sync(guild=guild_obj)
                # Also copy commands to guild for instant availability
                self.tree.copy_global_to(guild=guild_obj)
                logger.info(f"🔗 Synced {len(synced)} command(s) to guild {GUILD_ID} (instant)")

            else:
                synced = await self.tree.sync()
                logger.info(f"🔗 Synced {len(synced)} command(s) globally")
        except Exception as e:
            logger.error(f"Failed to sync commands: {e}")

    async def _send_first_boot_dm(self):
        """
        Send owner a DM on first boot with 10 setup options.
        All commands are locked for non-owners until the owner clicks a button.
        """
        import os as _os, shutil as _sh, urllib.request as _ur
        BOT_DIR = _os.path.dirname(_os.path.abspath(__file__))
        flag    = _os.path.join(BOT_DIR, ".first_boot_done")
        if _os.path.exists(flag):
            self._owner_confirmed = True
            return
        try:
            owner = await self.fetch_user(MAIN_ADMIN_ID)
        except Exception as e:
            logger.warning(f"First-boot DM failed to fetch owner: {e}")
            self._owner_confirmed = True  # fail-open so bot still works
            return

        bot_ref = self

        def _mark_done():
            open(flag, "w").write("done")
            bot_ref._owner_confirmed = True
            logger.info("First-boot complete — commands unlocked for all users.")

        async def _restore_db(inter, db_path_src):
            """Helper: reload DB after restore and return summary string."""
            from core.database import init_db, load_vps_data, load_admin_data
            init_db(); load_vps_data(); load_admin_data()
            vps_count  = sum(len(v) for v in vps_data.values())
            user_count = len(vps_data)
            recreated = 0; failed_list = []
            from core.lxc import deploy_container, execute_lxc
            from core import ACTIVE_STORAGE_POOL
            for uid2, vlist in list(vps_data.items()):
                for v in vlist:
                    cname = v.get("container_name", "")
                    if not cname: continue
                    try:
                        node   = (v.get("node") or "local").strip().rstrip(":") or "local"
                        prefix = f"{node}:" if node != "local" else ""
                        chk    = await execute_lxc(f"lxc list {prefix}{cname} --format=csv")
                        if chk and cname in str(chk): continue
                    except Exception: pass
                    try:
                        ram  = int(str(v.get("ram","1GB")).replace("GB","").strip()) if v.get("ram") else 1
                        cpu  = int(str(v.get("cpu","1")).strip()) if v.get("cpu") else 1
                        disk = int(str(v.get("storage","10GB")).replace("GB","").strip()) if v.get("storage") else 10
                        os_v = v.get("os_version","ubuntu:22.04") or "ubuntu:22.04"
                        await deploy_container(user_id=uid2, username=f"user{uid2[:6]}",
                            ram=ram, cpu=cpu, disk=disk, os_version=os_v,
                            validity_days=None, target_node=node, storage_pool=ACTIVE_STORAGE_POOL)
                        recreated += 1
                    except Exception as ce:
                        failed_list.append(cname)
            fail_str = f"\nFailed: {', '.join(failed_list[:5])}" if failed_list else ""
            return (
                f"📊 **{user_count}** users · **{vps_count}** VPS records loaded\n"
                f"🚀 **{recreated}** containers recreated on host"
                + (f" · {len(failed_list)} failed{fail_str}" if failed_list else "")
            )

        # ── Quick Setup Channel Wizard ─────────────────────────────────────────
        SETUP_CHANNELS = [
            ("log_channel",     "📋 Log Channel",       "Where bot activity is logged"),
            ("main_chat_id",    "💬 Main Chat Channel", "For MoonCoin chat rewards"),
            ("payment_channel", "💳 Payment Channel",   "Where payment proofs are posted"),
            ("ticket_channel",  "🎫 Ticket Category",   "Discord category for support tickets"),
            ("update_channel",  "📢 Update Channel",    "Maintenance/update announcements"),
            ("af2f_channel_id", "🔐 AF2F Channel",      "Where admin 2FA codes are posted"),
            ("claim_channel",   "🎟️ Claim Channel",     "Where users claim free VPS"),
        ]

        async def _run_quick_setup(inter: discord.Interaction):
            """Walk the owner through each channel one by one via DM."""
            set_count = 0
            for key, label, desc_ch in SETUP_CHANNELS:
                ask_embed = discord.Embed(
                    title=f"⚙️ Quick Setup — {label}",
                    description=(
                        f"**{label}**\n*{desc_ch}*\n\n"
                        "📋 **Send the channel ID in this DM.**\n"
                        "Right-click the channel → **Copy ID** → paste it here.\n\n"
                        "Type `skip` to skip this channel.\n"
                        "⏳ *2-minute window per channel.*"
                    ),
                    color=0x5865F2,
                    timestamp=datetime.now(),
                )
                ask_embed.set_author(name="MoonNodes — Quick Setup", icon_url="https://imgur.com/6yfYDTP.png")
                ask_embed.set_footer(text=f"Channel {set_count + 1} of {len(SETUP_CHANNELS)}")
                await inter.channel.send(embed=ask_embed)

                def _ch_check(m):
                    return (
                        m.author.id == MAIN_ADMIN_ID
                        and isinstance(m.channel, discord.DMChannel)
                    )
                try:
                    msg = await bot_ref.wait_for("message", check=_ch_check, timeout=120)
                    val = msg.content.strip()
                    if val.lower() != "skip" and val.isdigit():
                        from core.database import set_setting as _ss
                        _ss(key, val)
                        set_count += 1
                        await inter.channel.send(
                            embed=discord.Embed(
                                description=f"✅ **{label}** set to <#{val}>",
                                color=0x57F287,
                            )
                        )
                    else:
                        await inter.channel.send(
                            embed=discord.Embed(description=f"⏭️ Skipped **{label}**", color=0xFEE75C)
                        )
                except asyncio.TimeoutError:
                    await inter.channel.send(
                        embed=discord.Embed(description=f"⏰ Timed out — skipped **{label}**", color=0xED4245)
                    )

            done_embed = discord.Embed(
                title="✅ Quick Setup Complete!",
                description=(
                    f"**{set_count}/{len(SETUP_CHANNELS)}** channels configured.\n\n"
                    "The bot is now **fully operational**! 🎉\n\n"
                    "Use `/set setting:Channel` anytime to update channels.\n"
                    "Use `/help` to explore all commands."
                ),
                color=0x57F287,
                timestamp=datetime.now(),
            )
            done_embed.set_author(name="MoonNodes — Setup Complete", icon_url="https://imgur.com/6yfYDTP.png")
            await inter.channel.send(embed=done_embed)
            _mark_done()

        # ── Start Fresh Sub-View ──────────────────────────────────────────────
        class StartFreshView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=300)

            @discord.ui.button(label="🚀 Start Now", style=discord.ButtonStyle.success, row=0)
            async def start_now_btn(self, inter: discord.Interaction, btn: discord.ui.Button):
                for item in self.children: item.disabled = True
                emb = discord.Embed(
                    title="🚀 Bot Started!",
                    description=(
                        "The bot is now **live** with a clean database.\n\n"
                        "Use `/set` to configure channels.\n"
                        "Use `/help` to explore all commands.\n\n"
                        "✅ All commands are now unlocked."
                    ),
                    color=0x57F287,
                    timestamp=datetime.now(),
                )
                emb.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                emb.set_footer(text="MoonNodes · Setup Complete")
                await inter.response.edit_message(embed=emb, view=self)
                _mark_done()

            @discord.ui.button(label="⚙️ Quick Setup", style=discord.ButtonStyle.primary, row=0)
            async def quick_setup_btn(self, inter: discord.Interaction, btn: discord.ui.Button):
                for item in self.children: item.disabled = True
                emb = discord.Embed(
                    title="⚙️ Quick Setup Starting…",
                    description=(
                        "I'll walk you through each channel **one by one**.\n\n"
                        "Send each **channel ID** as a message here in DM.\n"
                        "Type `skip` to skip any channel.\n\n"
                        "⏳ Starting now…"
                    ),
                    color=0x5865F2,
                    timestamp=datetime.now(),
                )
                emb.set_author(name="MoonNodes — Quick Setup", icon_url="https://imgur.com/6yfYDTP.png")
                await inter.response.edit_message(embed=emb, view=self)
                await _run_quick_setup(inter)

            @discord.ui.button(label="← Back", style=discord.ButtonStyle.secondary, row=0)
            async def back_btn(self, inter: discord.Interaction, btn: discord.ui.Button):
                emb = discord.Embed(
                    title="👋 Welcome to MoonNodes — First Boot Setup",
                    description=(
                        "🌙 **MoonNodes VPS Manager** is online!\n\n"
                        "Choose how to start:\n\n"
                        "› **📤 Restore system.db** — Restore an existing database\n"
                        "› **🆕 Start Fresh** — Set up a brand new bot\n\n"
                        "⚠️ **All commands are locked until you choose.**"
                    ),
                    color=0xFFD700,
                    timestamp=datetime.now(),
                )
                emb.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                emb.set_footer(text="MoonNodes · First Boot Setup")
                await inter.response.edit_message(embed=emb, view=FirstBootView())

        # ── Main First Boot View (2 buttons only) ─────────────────────────────
        class FirstBootView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=600)

            # ── Option 1: Restore system.db ───────────────────────────────────
            @discord.ui.button(label="📤 Restore system.db", style=discord.ButtonStyle.primary, emoji="💾", row=0)
            async def upload_btn(self, inter: discord.Interaction, btn: discord.ui.Button):
                for item in self.children: item.disabled = True
                await inter.response.edit_message(
                    embed=discord.Embed(
                        title="📤 Upload Your system.db",
                        description=(
                            "**Attach `system.db` to your next message here in DM.**\n\n"
                            "🔄 The current database (if any) will be backed up first.\n\n"
                            "⏳ *You have 10 minutes to send the file.*"
                        ),
                        color=0x5865F2,
                        timestamp=datetime.now(),
                    ).set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png"),
                    view=self,
                )

                def check(m):
                    return (
                        m.author.id == MAIN_ADMIN_ID
                        and isinstance(m.channel, discord.DMChannel)
                        and m.attachments
                        and m.attachments[0].filename == "system.db"
                    )
                try:
                    msg = await bot_ref.wait_for("message", check=check, timeout=600)
                    db_path = _os.path.join(BOT_DIR, "system.db")
                    if _os.path.exists(db_path):
                        _sh.copy2(db_path, db_path + ".pre_restore.bak")
                    _ur.urlretrieve(msg.attachments[0].url, db_path)
                    summary = await _restore_db(inter, db_path)
                    done_emb = discord.Embed(
                        title="✅ Database Restored!",
                        description=(
                            summary + "\n\n"
                            "✅ **Bot is fully operational!**\n"
                            "All your data has been restored."
                        ),
                        color=0x57F287,
                        timestamp=datetime.now(),
                    )
                    done_emb.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                    await msg.reply(embed=done_emb)
                    _mark_done()
                except asyncio.TimeoutError:
                    await inter.channel.send(embed=discord.Embed(
                        title="⏰ Upload Timed Out",
                        description="No file received in 10 minutes.\nRestart the bot to try again.",
                        color=0xED4245,
                    ))
                    _mark_done()
                except Exception as e:
                    await inter.channel.send(embed=discord.Embed(
                        title="❌ Restore Failed",
                        description=f"`{str(e)[:400]}`\n\nRestart the bot to try again.",
                        color=0xED4245,
                    ))
                    _mark_done()

            # ── Option 2: Start Fresh → sub-menu ─────────────────────────────
            @discord.ui.button(label="🆕 Start Fresh", style=discord.ButtonStyle.success, emoji="✨", row=0)
            async def fresh_btn(self, inter: discord.Interaction, btn: discord.ui.Button):
                emb = discord.Embed(
                    title="🆕 Start Fresh",
                    description=(
                        "Starting with a **clean database**.\n\n"
                        "**How do you want to begin?**\n\n"
                        "› **🚀 Start Now** — Launch immediately with defaults\n"
                        "› **⚙️ Quick Setup** — Configure channels one by one\n"
                        "› **← Back** — Return to the main menu"
                    ),
                    color=0x57F287,
                    timestamp=datetime.now(),
                )
                emb.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                emb.set_footer(text="MoonNodes · Start Fresh")
                await inter.response.edit_message(embed=emb, view=StartFreshView())

        # ── Build and send the first-boot embed ───────────────────────────────
        embed = discord.Embed(
            title="👋 Welcome to MoonNodes — First Boot Setup",
            description=(
                "🌙 **MoonNodes VPS Manager** is now online!\n\n"
                "Choose how you want to start the bot:\n\n"
                "› **📤 Restore system.db** — Upload your existing database\n"
                "  All VPS data, users, and settings will be restored.\n\n"
                "› **🆕 Start Fresh** — Begin with a clean database\n"
                "  Optionally run Quick Setup to configure channels.\n\n"
                "⚠️ **All commands are locked until you choose.**\n"
                "⏳ *You have 10 minutes to decide.*"
            ),
            color=0xFFD700,
            timestamp=datetime.now(),
        )
        embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
        embed.set_footer(text="MoonNodes · First Boot Setup")
        try:
            await owner.send(embed=embed, view=FirstBootView())
            logger.info("First-boot DM sent to owner — ALL commands locked until setup complete.")
        except Exception as e:
            logger.warning(f"First-boot DM failed: {e}")
            self._owner_confirmed = True  # fail-open

    async def on_ready(self):
        # Guard: on_ready can fire multiple times on reconnect
        if self._ready_fired:
            return
        self._ready_fired = True

        logger.info(f"🌙 Bot ready — {self.user} ({self.user.id}) | Runtime: {RUNTIME}")

        load_vps_data()
        load_admin_data()

        # Load admin roles from DB
        try:
            conn = get_db()
            cur  = conn.cursor()
            cur.execute("SELECT user_id, role FROM admins")
            for row in cur.fetchall():
                admin_data[row["user_id"]] = row["role"]
        except Exception as e:
            logger.error(f"Admin load error: {e}")

        _load_extension_states()

        # ── First-boot DM ─────────────────────────────────────────────────────
        await self._send_first_boot_dm()

        # Start background tasks (only once)
        update_status_task.start()
        scheduled_backup_task.start()
        expiration_task.start()
        vps_monitoring_task.start()
        mstc_health_task.start()
        ubl_cleanup_task.start()

        start_resource_monitor(
            bot_loop      = self.loop,
            cpu_threshold = CPU_THRESHOLD,
            ram_threshold = RAM_THRESHOLD,
            vps_data_ref  = vps_data,
            data_lock_ref = data_lock,
            save_fn       = save_vps_data,
            send_log_fn   = _send_log,
        )

        await self._sync_vps_states()

        total   = sum(len(v) for v in vps_data.values())
        running = sum(1 for lst in vps_data.values() for v in lst if v.get("status") == "running")
        logger.info(f"🟢 All systems online — {total} VPS ({running} running)")

        await _send_log(create_info_embed(
            "🌙 Bot Online",
            f"MoonNodes is **online**.\n\n"
            f"**Runtime:** `{RUNTIME}`\n"
            f"**VPS:** `{total}` total · `{running}` running\n"
            f"**Cogs loaded:** `{len(self.cogs)}`"
        ))

    async def _sync_vps_states(self):
        logger.info("🔄 Syncing VPS states from container runtime...")
        synced = adopted = 0
        try:
            raw = await execute_lxc("lxc list --format=csv")
            if not raw or raw is True:
                logger.info("✅ VPS state sync — no containers found")
                return

            actual = {}
            for line in str(raw).strip().splitlines():
                parts = line.split(",")
                if len(parts) >= 2:
                    name   = parts[0].strip()
                    status = parts[1].strip().lower()
                    ipv4   = parts[2].strip() if len(parts) > 2 else ""
                    if name:
                        actual[name] = {"status": status, "ipv4": ipv4}

            async with data_lock:
                known = {
                    v.get("container_name")
                    for lst in vps_data.values()
                    for v in lst
                }

            async with data_lock:
                for uid, vps_list in vps_data.items():
                    for vps in vps_list:
                        cname = vps.get("container_name", "")
                        if cname in actual:
                            real = actual[cname]["status"]
                            if vps.get("status") != real:
                                logger.info(f"  Sync {cname}: {vps.get('status')} → {real}")
                                vps["status"] = real
                                if real == "running" and vps.get("suspended"):
                                    vps["suspended"] = False
                                synced += 1

            for cname, info in actual.items():
                if cname in known:
                    continue
                if not cname.startswith(cfg.VPS_PREFIX + "-"):
                    continue
                parts = cname.split("-")
                if len(parts) < 3:
                    continue
                try:
                    info_out  = await execute_lxc(f"lxc config show {cname}")
                    info_text = str(info_out) if info_out and info_out is not True else ""
                except Exception:
                    info_text = ""

                ram_mb  = 0
                cpu_cnt = "1"
                m = re.search(r"limits\.memory:\s*(\d+)MB", info_text)
                if m: ram_mb = int(m.group(1))
                m = re.search(r"limits\.cpu:\s*(\d+)", info_text)
                if m: cpu_cnt = m.group(1)
                ram_gb = (ram_mb // 1024) if ram_mb else 1

                orphan = {
                    "container_name":    cname,
                    "ram":               f"{ram_gb}GB",
                    "cpu":               cpu_cnt,
                    "storage":           "10GB",
                    "config":            f"{ram_gb}GB RAM / {cpu_cnt} CPU / 10GB Disk",
                    "os_version":        "ubuntu:22.04",
                    "status":            info["status"],
                    "suspended":         False,
                    "whitelisted":       False,
                    "node":              "local",
                    "created_at":        datetime.now().isoformat(),
                    "expiry":            None,
                    "shared_with":       [],
                    "suspension_history": [],
                    "id":                None,
                }
                owner_uid = str(MAIN_ADMIN_ID)
                async with data_lock:
                    vps_data.setdefault(owner_uid, []).append(orphan)
                adopted += 1
                logger.warning(f"  Adopted orphaned container `{cname}` under owner {owner_uid}.")

            if synced or adopted:
                await async_save_vps_data()

            logger.info(f"✅ VPS sync — updated {synced}, adopted {adopted} orphan(s)")
        except Exception as e:
            logger.warning(f"VPS state sync failed (non-fatal): {e}")

    async def on_app_command_error(self, interaction: discord.Interaction, error):
        if isinstance(error, discord.app_commands.CheckFailure):
            embed = discord.Embed(
                title="🚫  No Permission",
                description=(
                    "You **don't have permission** to use this command.\n\n"
                    "Use `/help` to see the commands available to your role.\n"
                    "If you think this is a mistake, contact an admin."
                ),
                color=0xED4245, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
            embed.set_footer(text="MoonNodes · Use /help for your commands")
            # CheckFailure fires before any defer — must use response, not followup
            try:
                if not interaction.response.is_done():
                    return await interaction.response.send_message(embed=embed, ephemeral=True)
                else:
                    return await interaction.followup.send(embed=embed, ephemeral=True)
            except Exception:
                return
        elif isinstance(error, discord.app_commands.CommandInvokeError):
            msg = str(error.original)[:3900]
            logger.error(f"Command invoke error: {msg}")
            embed = discord.Embed(
                title="⚠️  Something Went Wrong",
                description=f"An unexpected error occurred.\n```\n{msg[:1800]}\n```",
                color=Theme.ERROR, timestamp=datetime.now(),
            )
            embed.set_footer(text="If this keeps happening, contact an admin · MoonNodes")
            try:
                if interaction.response.is_done():
                    await interaction.followup.send(embed=embed, ephemeral=True)
                else:
                    await interaction.response.send_message(embed=embed, ephemeral=True)
            except Exception:
                pass
        else:
            msg = str(error)[:3900]
            logger.error(f"App command error: {msg}")
            embed = discord.Embed(title="❌  Error", description=msg, color=Theme.ERROR)
            try:
                if interaction.response.is_done():
                    await interaction.followup.send(embed=embed, ephemeral=True)
                else:
                    await interaction.response.send_message(embed=embed, ephemeral=True)
            except Exception:
                pass

    async def on_command_error(self, ctx, error):
        if isinstance(error, commands.CommandNotFound):
            return

    async def on_message(self, message: discord.Message):
        """Award +1 MoonCoin for chatting in the main channel (5-min cooldown)."""
        if message.author.bot or not message.guild:
            return
        try:
            from core.database import get_db, add_coins
            chat_ch = cfg.MAIN_CHAT_ID
            if chat_ch and message.channel.id == chat_ch:
                uid  = str(message.author.id)
                conn = get_db(); cur = conn.cursor()
                cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (uid,))
                cur.execute("SELECT last_chat_coin FROM users WHERE user_id=?", (uid,))
                row   = cur.fetchone()
                last  = row["last_chat_coin"] if row and row["last_chat_coin"] else None
                now   = datetime.now()
                ready = True
                if last:
                    try:
                        diff = (now - datetime.fromisoformat(last)).total_seconds()
                        if diff < 300:  # 5-min cooldown
                            ready = False
                    except Exception:
                        pass
                if ready:
                    # Apply multipliers from VIP/Boost roles
                    mult  = 1.0
                    member = message.guild.get_member(message.author.id)
                    if member:
                        roles = [r.name.lower() for r in member.roles]
                        if "vip" in roles:    mult += 0.01
                        if "server booster" in roles: mult += 0.02
                    coins = max(1, round(1 * mult))
                    add_coins(uid, coins)
                    cur.execute("UPDATE users SET last_chat_coin=? WHERE user_id=?",
                                (now.isoformat(), uid))
                    conn.commit()
        except Exception as e:
            logger.debug(f"on_message coin error: {e}")
        # ── DM block ──────────────────────────────────────────────────────
        if not message.guild:
            try:
                from core.ext import dm_commands_enabled
                if not message.author.bot:
                    from core.database import get_db as _gdb2
                    try:
                        _conn2 = _gdb2(); _cur2 = _conn2.cursor()
                        _cur2.execute("SELECT value FROM dm_settings WHERE key='dm_prefix'")
                        _prow = _cur2.fetchone()
                        _pfx  = _prow["value"] if _prow else "!"
                    except Exception: _pfx = "!"
                    if not dm_commands_enabled():
                        # DM commands off entirely
                        if message.content.startswith("/"):
                            dm_embed = discord.Embed(
                            title="❌ DM Commands Disabled",
                            description=(
                                "Bot commands are **not allowed in DMs**.\n\n"
                                "Please use commands in the **server channel** only.\n"
                                "👉 Head to the server and use commands there!"
                            ),
                            color=0xED4245, timestamp=datetime.now(),
                        )
                        dm_embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                        dm_embed.set_footer(text="MoonNodes · Commands work in the server only")
                        await message.channel.send(embed=dm_embed)
                        return
            except Exception: pass
        await self.process_commands(message)

    async def on_member_join(self, member: discord.Member):
        """Track invites, award coins to inviter, record join date."""
        try:
            from core.database import get_db, add_coins, get_setting
            # Record join date
            conn = get_db(); cur = conn.cursor()
            cur.execute("INSERT OR IGNORE INTO users (user_id, joined_at) VALUES (?,?)",
                        (str(member.id), datetime.now().isoformat()))
            cur.execute("UPDATE users SET joined_at=? WHERE user_id=? AND joined_at IS NULL",
                        (datetime.now().isoformat(), str(member.id)))
            conn.commit()

            # Try to identify which invite was used (requires Manage Server permission)
            try:
                invites_after = await member.guild.invites()
                cached_inv    = getattr(self, "_invite_cache", {}).get(member.guild.id, [])
                used_inv      = None
                for inv in invites_after:
                    for c in cached_inv:
                        if c.code == inv.code and c.uses < inv.uses:
                            used_inv = inv; break
                    if used_inv: break

                if used_inv and used_inv.inviter:
                    inviter_id = str(used_inv.inviter.id)
                    cur2 = conn.cursor()
                    cur2.execute(
                        "INSERT OR IGNORE INTO invite_tracking (inviter_id,invitee_id,joined_at,valid) VALUES (?,?,?,1)",
                        (inviter_id, str(member.id), datetime.now().isoformat())
                    )
                    conn.commit()
                    # Award invite coins immediately (may be invalidated at 7 days if they leave)
                    add_coins(inviter_id, 5)
                    logger.info(f"[Invite] {member} invited by {inviter_id} — +5 coins")
            except Exception as e:
                logger.debug(f"[Invite] Tracking failed: {e}")

            # Refresh invite cache
            try:
                self._invite_cache = getattr(self, "_invite_cache", {})
                self._invite_cache[member.guild.id] = await member.guild.invites()
            except Exception: pass

        except Exception as e:
            logger.debug(f"on_member_join error: {e}")

    async def on_member_remove(self, member: discord.Member):
        """
        When a member leaves:
        1. If they were in VPS_USERS → auto-delete their VPS
        2. If they leave within 7 days → invalidate invite, deduct coins from inviter
        """
        mid = str(member.id)
        try:
            from core.database import get_db, add_coins

            # ── Invite invalidation (7-day anti-fake rule) ───────────────────
            conn = get_db(); cur = conn.cursor()
            cur.execute("SELECT * FROM invite_tracking WHERE invitee_id=? AND valid=1", (mid,))
            inv_row = cur.fetchone()
            if inv_row:
                joined_at  = inv_row["joined_at"]
                inviter_id = inv_row["inviter_id"]
                try:
                    jdt = datetime.fromisoformat(joined_at)
                    days_stayed = (datetime.now() - jdt).days
                    if days_stayed < 7:
                        # Invalidate invite + claw back coins
                        cur.execute("UPDATE invite_tracking SET valid=0, left_at=? WHERE invitee_id=?",
                                    (datetime.now().isoformat(), mid))
                        conn.commit()
                        add_coins(inviter_id, -5)  # deduct
                        logger.info(f"[Invite] {mid} left after {days_stayed}d — invalidated, -5 coins from {inviter_id}")
                    else:
                        cur.execute("UPDATE invite_tracking SET left_at=? WHERE invitee_id=?",
                                    (datetime.now().isoformat(), mid))
                        conn.commit()
                except Exception: pass

            # ── Auto-delete VPS on leave ─────────────────────────────────────
            async with data_lock:
                user_vps = list(vps_data.get(mid, []))

            if not user_vps:
                return

            logger.info(f"[Leave] {member} left — auto-deleting {len(user_vps)} VPS")

            for vps in user_vps:
                name   = vps.get("container_name")
                node   = vps.get("node", "local")
                prefix = f"{node}:" if node != "local" else ""
                if not name: continue
                try:
                    await execute_lxc(f"lxc delete {prefix}{name} --force")
                    logger.info(f"[Leave] Deleted {name}")
                except Exception as e:
                    logger.warning(f"[Leave] Could not delete {name}: {e}")

            async with data_lock:
                if mid in vps_data:
                    del vps_data[mid]
            await async_save_vps_data()

            # Log to admin channel
            embed = discord.Embed(
                title="🚪 Member Left — VPS Auto-Deleted",
                description=(
                    f"**{member}** (`{mid}`) left the server.\n"
                    f"**{len(user_vps)}** VPS container(s) were automatically removed."
                ),
                color=0xED4245, timestamp=datetime.now(),
            )
            embed.set_footer(text="MoonNodes — Auto Cleanup")
            await _send_log(embed)

            # Refresh invite cache
            try:
                self._invite_cache = getattr(self, "_invite_cache", {})
                self._invite_cache[member.guild.id] = await member.guild.invites()
            except Exception: pass

        except Exception as e:
            logger.debug(f"on_member_remove error: {e}")


# ── Helpers ───────────────────────────────────────────────────────────────────

def _load_extension_states():
    EXT_ATTRS = [
        "MULTI_NODE", "SOSB", "ISTS", "AES", "RR", "A2FA", "MSTC",
        "UBL_ENABLED", "MARKETPLACE", "ACCOUNT", "VPS_RENEWAL",
        "VPS_MONITORING", "VPS_TEMPLATES", "MULTILANG",
    ]
    for attr in EXT_ATTRS:
        val_str = get_setting(f"ext_{attr}")
        if val_str is not None:
            new_val = (val_str.lower() == "true")
            setattr(cfg, attr, new_val)
            logger.debug(f"  ext {attr} = {new_val} (from DB)")


async def _send_log(embed: discord.Embed):
    log_ch_id = get_setting("log_channel")
    if log_ch_id and log_ch_id != "0":
        try:
            ch = bot.get_channel(int(log_ch_id))
            if ch:
                await ch.send(embed=embed)
        except Exception as e:
            logger.debug(f"Log send failed: {e}")


async def _dm_user(user_id: str, embed: discord.Embed):
    try:
        user = await bot.fetch_user(int(user_id))
        await user.send(embed=embed)
    except discord.Forbidden:
        logger.debug(f"DM to {user_id} blocked (Forbidden)")
    except Exception as e:
        logger.debug(f"DM to {user_id} failed: {e}")


# ── Background tasks ──────────────────────────────────────────────────────────

bot = MoonNodesBot()


@tasks.loop(seconds=60)
async def update_status_task():
    try:
        if getattr(cfg, "MAINTENANCE_MODE", False):
            await bot.change_presence(
                status=discord.Status.dnd,
                activity=discord.Activity(type=discord.ActivityType.watching, name="🚧 Maintenance"),
            )
            return
        total   = sum(len(v) for v in vps_data.values())
        running = sum(1 for lst in vps_data.values() for v in lst if v.get("status") == "running")
        picks   = [
            f"🌙 {total} VPS Online",
            f"🟢 {running} containers running",
            "Type /help for commands",
            "MoonNodes VPS Manager",
        ]
        await bot.change_presence(
            activity=discord.Activity(type=discord.ActivityType.watching, name=random.choice(picks))
        )
    except Exception as e:
        logger.debug(f"update_status_task error: {e}")


@tasks.loop(hours=1)
async def scheduled_backup_task():
    try:
        if not cfg.SOSB:
            return
        time_str = get_setting("scheduled_backups_time") or "02:00AM"
        try:
            run_at = datetime.strptime(time_str.upper(), "%I:%M%p").replace(
                year=datetime.now().year, month=datetime.now().month, day=datetime.now().day
            )
            now = datetime.now()
            if abs((now - run_at).total_seconds()) > 3600:
                return
        except Exception:
            pass

        logger.info("[SOSB] Running scheduled backups…")
        today = datetime.now().strftime("%Y%m%d")
        async with data_lock:
            snapshot = {uid: list(lst) for uid, lst in vps_data.items()}

        backed_up = 0
        for uid, vps_list in snapshot.items():
            for vps in vps_list:
                if vps.get("status") != "running":
                    continue
                name      = vps["container_name"]
                node      = vps.get("node", "local")
                prefix    = f"{node}:" if node != "local" else ""
                snap_name = f"auto-{today}"

                if cfg.UBL_ENABLED:
                    try:
                        limit = int(get_setting("backup_limits_value") or cfg.UBL_LIMIT or 1)
                        info  = await execute_lxc(f"lxc info {prefix}{name}")
                        auto_snaps = [l for l in str(info).splitlines() if "auto-" in l]
                        while len(auto_snaps) >= limit:
                            oldest = sorted(auto_snaps)[0].strip().split()[0]
                            try:
                                await execute_lxc(f"lxc delete {prefix}{name}/{oldest}")
                            except Exception:
                                pass
                            auto_snaps.pop(0)
                    except Exception:
                        pass

                try:
                    await execute_lxc(f"lxc snapshot {prefix}{name} {snap_name}")
                    backed_up += 1
                    logger.info(f"[SOSB] ✅ {name}/{snap_name}")
                except Exception as e:
                    logger.warning(f"[SOSB] ⚠️ {name}: {e}")

        if backed_up > 0:
            await _send_log(create_success_embed(
                "📦  Scheduled Backup Complete",
                f"Auto-backed up **{backed_up}** VPS container(s) at `{today}`."
            ))
    except Exception as e:
        logger.error(f"scheduled_backup_task unhandled error: {e}")


@tasks.loop(hours=6)
async def expiration_task():
    try:
        if not cfg.AES and not cfg.RR:
            return
        logger.info("[AES/RR] Running expiration checks…")
        now = datetime.now()
        async with data_lock:
            snapshot = {uid: list(lst) for uid, lst in vps_data.items()}

        for uid, vps_list in snapshot.items():
            for vps in vps_list:
                exp_str = vps.get("expiry") or vps.get("expires_at")
                if not exp_str:
                    continue
                try:
                    exp_date  = datetime.fromisoformat(exp_str)
                    days_left = (exp_date - now).days
                    name      = vps["container_name"]
                    node      = vps.get("node", "local")
                    prefix    = f"{node}:" if node != "local" else ""

                    if cfg.AES and days_left <= 0 and not vps.get("suspended"):
                        try:
                            await execute_lxc(f"lxc stop {prefix}{name}", timeout=30)
                        except Exception:
                            pass
                        async with data_lock:
                            vps["suspended"] = True
                            vps["status"]    = "stopped"
                            vps.setdefault("suspension_history", []).append({
                                "time": now.isoformat(), "reason": "VPS expired", "by": "System",
                            })
                        await async_save_vps_data()
                        embed = discord.Embed(
                            title="⏰  VPS Expired & Suspended",
                            description=(
                                f"Your VPS **`{name}`** has reached its expiry date and has been suspended.\n\n"
                                "To reactivate it, please renew your plan or open a support ticket with `/support`."
                            ),
                            color=Theme.ERROR, timestamp=now,
                        )
                        embed.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)
                        embed.set_footer(text="MoonNodes · Automated Expiry System")
                        await _dm_user(uid, embed)
                        logger.info(f"[AES] Suspended expired VPS: {name}")

                    elif cfg.RR and days_left in (7, 3, 1):
                        urgency = "🔴" if days_left == 1 else "🟡" if days_left == 3 else "🟠"
                        embed   = discord.Embed(
                            title=f"{urgency}  VPS Expiry Reminder",
                            description=(
                                f"Your VPS **`{name}`** expires in **{days_left} day{'s' if days_left > 1 else ''}**!\n\n"
                                f"**Expiry:** <t:{int(exp_date.timestamp())}:F>\n\n"
                                "Renew now to avoid losing access to your server."
                            ),
                            color=Theme.WARNING if days_left > 1 else Theme.ERROR,
                            timestamp=now,
                        )
                        embed.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)
                        embed.set_footer(text="Use /upgrade or open a ticket to renew")
                        await _dm_user(uid, embed)

                except Exception as e:
                    logger.warning(f"[AES/RR] Error for {vps.get('container_name','?')}: {e}")
    except Exception as e:
        logger.error(f"expiration_task unhandled error: {e}")


@tasks.loop(minutes=10)
async def vps_monitoring_task():
    try:
        if not cfg.VPS_MONITORING:
            return
        from core.lxc import get_container_cpu_pct, get_container_memory
        async with data_lock:
            snapshot = {uid: list(lst) for uid, lst in vps_data.items()}

        alerted = set()
        for uid, vps_list in snapshot.items():
            for vps in vps_list:
                if vps.get("status") != "running" or vps.get("suspended"):
                    continue
                name = vps["container_name"]
                node = vps.get("node", "local")
                try:
                    cpu_pct = await get_container_cpu_pct(name, node)
                    mem_str = await get_container_memory(name, node)
                    ram_pct = 0.0
                    m = re.search(r"\((\d+\.?\d*)%\)", mem_str)
                    if m:
                        ram_pct = float(m.group(1))

                    alert_key = f"{uid}:{name}"
                    if (cpu_pct >= cfg.CPU_THRESHOLD or ram_pct >= cfg.RAM_THRESHOLD) and alert_key not in alerted:
                        alerted.add(alert_key)
                        embed = discord.Embed(
                            title="🚨  VPS High Resource Alert",
                            description=(
                                f"Your VPS **`{name}`** is using excessive resources!\n\n"
                                f"💠 **CPU:** `{cpu_pct:.1f}%` {'⚠️' if cpu_pct >= cfg.CPU_THRESHOLD else '✅'}\n"
                                f"🧬 **RAM:** `{ram_pct:.1f}%` {'⚠️' if ram_pct >= cfg.RAM_THRESHOLD else '✅'}\n\n"
                                "Please check your running processes to prevent automatic suspension."
                            ),
                            color=Theme.ERROR,
                            timestamp=datetime.now(),
                        )
                        embed.set_author(name="MoonNodes Monitoring", icon_url=Theme.ICON_URL)
                        embed.set_footer(text="Use /manage to access your VPS console")
                        await _dm_user(uid, embed)
                        logger.info(f"[VPS_MONITORING] Alert → {uid} for {name} (CPU:{cpu_pct:.1f}% RAM:{ram_pct:.1f}%)")
                except Exception:
                    pass
    except Exception as e:
        logger.error(f"vps_monitoring_task unhandled error: {e}")


@tasks.loop(hours=24)
async def mstc_health_task():
    try:
        if not cfg.MSTC:
            return
        for guild in bot.guilds:
            ch_id = get_setting(f"ticket_channel_{guild.id}") or get_setting("ticket_channel")
            if ch_id and guild.get_channel(int(ch_id)) is None:
                logger.warning(f"[MSTC] Ticket channel {ch_id} missing in guild {guild.id}")
    except Exception as e:
        logger.error(f"mstc_health_task unhandled error: {e}")


@tasks.loop(hours=12)
async def ubl_cleanup_task():
    try:
        if not cfg.UBL_ENABLED:
            return
        limit_str = get_setting("backup_limits_value") or str(getattr(cfg, "UBL_LIMIT", 1))
        try:
            limit = max(1, int(limit_str))
        except ValueError:
            return

        logger.info(f"[UBL] Enforcing backup limit of {limit} per VPS…")
        async with data_lock:
            snapshot = {uid: list(lst) for uid, lst in vps_data.items()}

        for uid, vps_list in snapshot.items():
            for vps in vps_list:
                name   = vps["container_name"]
                node   = vps.get("node", "local")
                prefix = f"{node}:" if node != "local" else ""
                try:
                    info  = await execute_lxc(f"lxc info {prefix}{name}")
                    snaps = [l.strip().split()[0] for l in str(info).splitlines() if l.strip().startswith("auto-")]
                    while len(snaps) > limit:
                        oldest = sorted(snaps)[0]
                        await execute_lxc(f"lxc delete {prefix}{name}/{oldest}")
                        snaps.remove(oldest)
                        logger.info(f"[UBL] Deleted old snapshot {name}/{oldest}")
                except Exception:
                    pass
    except Exception as e:
        logger.error(f"ubl_cleanup_task unhandled error: {e}")


# ── A2FA helper ───────────────────────────────────────────────────────────────

async def verify_a2fa(interaction: discord.Interaction) -> bool:
    if not cfg.A2FA:
        return True
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("SELECT pin FROM admins WHERE user_id=?", (str(interaction.user.id),))
    row  = cur.fetchone()
    pin  = row["pin"] if row else "0000"
    if pin == "0000":
        return True

    class PinModal(discord.ui.Modal, title="🔐 Admin 2FA Verification"):
        pin_input = discord.ui.TextInput(label="Enter your 4-digit PIN", max_length=4, min_length=4)
        async def on_submit(self_m, inter: discord.Interaction):
            self_m.success = (self_m.pin_input.value == pin)
            await inter.response.defer()
        success = False

    modal = PinModal()
    await interaction.response.send_modal(modal)
    await modal.wait()
    if not modal.success:
        await interaction.followup.send(
            embed=create_error_embed("🔐 2FA Failed", "Incorrect PIN. Access denied."),
            ephemeral=True
        )
    return modal.success


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    init_db()
    if not DISCORD_TOKEN:
        logger.error("DISCORD_TOKEN not set in .env — exiting.")
        sys.exit(1)
    try:
        bot.run(DISCORD_TOKEN, log_handler=None)
    except KeyboardInterrupt:
        logger.info("Bot stopped.")
