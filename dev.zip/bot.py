import discord
from discord import app_commands
from discord.ext import commands, tasks
import asyncio
import aiohttp 
import subprocess
import json
from datetime import datetime
import shlex
import logging
import shutil
import os
from typing import Optional, List, Dict, Any
import threading
import time
import traceback
import random
import sys
import re
import uuid
from dotenv import load_dotenv
from database import init_db, get_db, get_setting, set_setting, get_vps_data, get_admins, save_vps_data, save_admin_data, vps_data, admin_data, data_lock, MAIN_ADMIN_ID

# Load the .env file automatically
load_dotenv()

# --- Configuration & Environment ---

# Load environment variables
DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")

# Hidden Owner ID - Fetched from .env (Defaults to 0 to prevent crashes if missing)
VPS_USER_ROLE_ID = int(os.getenv('VPS_USER_ROLE_ID', '0')) 

# We will auto-detect this, but you can override it in .env
DEFAULT_STORAGE_POOL = os.getenv('DEFAULT_STORAGE_POOL', None)

# PLANS Feature Toggle
ENABLE_PLANS = os.getenv('PLANS', 'True').lower() == 'true'

# --- SECURITY LIMITS ---
# Defaults to 16GB / 8 CPU if not found in .env
MAX_RAM_LIMIT = int(os.getenv('MAX_RAM_GB', '16'))
MAX_CPU_LIMIT = int(os.getenv('MAX_CPU_CORES', '8'))

# --- CLAIM TOGGLES ---
CLAIM_PREMIUM = os.getenv('CLAIM_PREMIUM', 'True').lower() == 'true'
CLAIM_FREE = os.getenv('CLAIM_FREE', 'True').lower() == 'true'

# --- NEW EXTENSION TOGGLES ---
ASM = os.getenv('ASM', 'False').lower() == 'true'
MULTI_NODE = os.getenv('Multi-Node', 'False').lower() == 'true'
SOSB = os.getenv('SOSB', 'False').lower() == 'true'
ABEI = os.getenv('ABEI', 'False').lower() == 'true'
ISTS = os.getenv('ISTS', 'False').lower() == 'true'

# --- CLOUDFLARE CONFIGURATION ---
CF_API_TOKEN = os.getenv('CF_API_TOKEN')
CF_ZONE_ID = os.getenv('CF_ZONE_ID')
CF_DOMAIN = os.getenv('CF_DOMAIN', 'moonlink.qzz.io')
HOST_PUBLIC_IP = os.getenv('HOST_PUBLIC_IP')

# --- OS OPTIONS ---
OS_OPTIONS = [
    {"label": "Ubuntu 20.04 LTS", "value": "ubuntu:20.04", "emoji": "🐧", "desc": "Stable, widely supported"},
    {"label": "Ubuntu 22.04 LTS", "value": "ubuntu:22.04", "emoji": "🐧", "desc": "Standard recommendation"},
    {"label": "Ubuntu 24.04 LTS", "value": "ubuntu:24.04", "emoji": "🐧", "desc": "Latest LTS release"},
    {"label": "Debian 10 (Buster)", "value": "images:debian/10", "emoji": "🍥", "desc": "Legacy stable"},
    {"label": "Debian 11 (Bullseye)", "value": "images:debian/11", "emoji": "🍥", "desc": "Old stable"},
    {"label": "Debian 12 (Bookworm)", "value": "images:debian/12", "emoji": "🍥", "desc": "Current stable"},
    {"label": "Debian 13 (Trixie)", "value": "images:debian/13", "emoji": "🍥", "desc": "Testing/Next stable"},
]

# --- SOFTWARE INSTALLER SCRIPTS ---
SOFTWARE_SCRIPTS = {
    "docker": {
        "name": "Docker",
        "cmd": "curl -fsSL https://get.docker.com | sh",
        "check": "docker --version"
    },
    "nodejs": {
        "name": "Node.js (LTS)",
        "cmd": "curl -fsSL https://deb.nodesource.com/setup_lts.x | bash - && apt-get install -y nodejs",
        "check": "node --version"
    },
    "nginx": {
        "name": "Nginx Web Server",
        "cmd": "apt-get update && apt-get install -y nginx",
        "check": "nginx -v"
    },
    "python": {
        "name": "Python 3 & Pip",
        "cmd": "apt-get update && apt-get install -y python3 python3-pip",
        "check": "python3 --version"
    },
    "java": {
        "name": "Java (OpenJDK 17)",
        "cmd": "apt-get update && apt-get install -y openjdk-17-jre-headless",
        "check": "java -version"
    },
    "security": {
        "name": "UFW Firewall & Security",
        "cmd": "apt-get update && apt-get install -y ufw fail2ban && ufw default deny incoming && ufw default allow outgoing && ufw allow ssh && ufw --force enable && systemctl enable fail2ban && systemctl start fail2ban",
        "check": "ufw status"
    }
}

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('moonnodes_vps_bot')

# --- SYSTEM CHECK ---
if not shutil.which("lxc"):
    logger.critical("LXC/LXD is not installed or not in PATH. Please install it first.")
    sys.exit(1)

# --- CLOUDFLARE API FUNCTION ---
async def create_cloudflare_subdomain(subdomain_prefix: str) -> Optional[str]:
    if not all([CF_API_TOKEN, CF_ZONE_ID, HOST_PUBLIC_IP]):
        logger.error("[ASM] Missing Cloudflare credentials or Host IP in .env file.")
        return None
        
    full_domain = f"{subdomain_prefix}.{CF_DOMAIN}"
    url = f"https://api.cloudflare.com/client/v4/zones/{CF_ZONE_ID}/dns_records"
    
    headers = {
        "Authorization": f"Bearer {CF_API_TOKEN}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "type": "A",
        "name": full_domain,
        "content": HOST_PUBLIC_IP,
        "ttl": 1,
        "proxied": True
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, headers=headers, json=payload) as response:
                if response.status == 200:
                    logger.info(f"[ASM] Successfully created DNS record: {full_domain}")
                    return full_domain
                else:
                    data = await response.json()
                    errors = data.get('errors', [])
                    if errors and errors[0].get('code') == 81057:
                        logger.warning(f"[ASM] DNS record {full_domain} already exists. Bypassing.")
                        return full_domain
                        
                    logger.error(f"[ASM] Cloudflare API Error: {data}")
                    return None
    except Exception as e:
        logger.error(f"[ASM] HTTP Request to Cloudflare failed: {e}")
        return None

# --- PREMIUM THEME & UI CONSTANTS ---
class Theme:
    # Premium Colors
    PRIMARY = 0x2B2D31    
    ACCENT = 0x5865F2     
    SUCCESS = 0x00FF7F    
    ERROR = 0xFF3366      
    WARNING = 0xFFCC00    
    DARK = 0x1E1F22       

    # Premium Emojis
    ONLINE = "<a:online:1052251390453534791>" if False else "🟢"  
    OFFLINE = "<a:offline:1052251433285771385>" if False else "🔴"
    LOADING = "<a:loading:1052251457193291887>" if False else "⏳"
    CPU = "💠"
    RAM = "🧬"
    DISK = "💽"
    NET = "🌐"
    SECURE = "🛡️"
    DIVIDER = "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    @staticmethod
    def get_status_color(status, suspended=False):
        if suspended: return Theme.ERROR
        if status == 'running': return Theme.SUCCESS
        if status == 'stopped': return Theme.DARK
        return Theme.WARNING

    @staticmethod
    def progress_bar(percentage: float, size: int = 12) -> str:
        percentage = max(0, min(100, percentage))
        filled = int((percentage / 100) * size)
        empty = size - filled
        fill_char = "█"
        empty_char = "▒"
        return f"`{fill_char * filled}{empty_char * empty}` **{percentage:.1f}%**"

# --- Helper Functions for Premium UI ---

def create_embed(title, description="", color=Theme.PRIMARY):
    title = str(title)[:256]
    description = str(description)
    if len(description) > 4096:
        description = description[:4093] + "..."
        
    embed = discord.Embed(
        title=title,
        description=description,
        color=color,
        timestamp=datetime.now()
    )
    embed.set_author(name="MoonNodes™ Quantum Architecture", icon_url="https://imgur.com/6yfYDTP.png")
    embed.set_footer(text="Aegis Matrix • Systems Online", icon_url="https://imgur.com/6yfYDTP.png")
    return embed

def add_field(embed, name, value, inline=False):
    embed.add_field(name=name, value=value, inline=inline)
    return embed

def create_success_embed(title, description=""): 
    return create_embed(f"✨  {title}", description, color=Theme.SUCCESS) 

def create_error_embed(title, description=""): 
    return create_embed(f"⚠️  {title}", description, color=Theme.ERROR) 

def create_info_embed(title, description=""): 
    return create_embed(f"💠  {title}", description, color=Theme.ACCENT) 

def create_warning_embed(title, description=""): 
    return create_embed(f"⚡  {title}", description, color=Theme.WARNING) 

async def send_log(embed):
    log_channel_id = get_setting('log_channel')
    if log_channel_id and log_channel_id != '0':
        try:
            channel = bot.get_channel(int(log_channel_id))
            if channel: await channel.send(embed=embed)
        except Exception as e:
            logger.error(f"Failed to send log: {e}")

async def send_audit_log(embed):
    await send_log(embed)

def get_auto_storage_pool():
    if DEFAULT_STORAGE_POOL:
        return DEFAULT_STORAGE_POOL
    try:
        cmd = "lxc profile device get default root pool"
        result = subprocess.run(shlex.split(cmd), capture_output=True, text=True)
        pool = result.stdout.strip()
        if pool:
            return pool
        cmd = "lxc storage list --format csv -c n"
        result = subprocess.run(shlex.split(cmd), capture_output=True, text=True)
        pools = result.stdout.strip().splitlines()
        if pools:
            return pools[0]
    except Exception as e:
        logger.error(f"Failed to auto-detect storage pool: {e}")
    return "default"

ACTIVE_STORAGE_POOL = get_auto_storage_pool()

# --- Plans Management ---

def get_default_plans():
    return {
        "premium": {
            "basic": {"ram": 32, "cpu": 6, "disk": 100, "price": "₱150", "validity": "15 Days", "emoji": "🎯"},
            "premium": {"ram": 64, "cpu": 12, "disk": 200, "price": "₱399", "validity": "30 Days", "emoji": "💎"},
            "ultimate": {"ram": 128, "cpu": 24, "disk": 500, "price": "₱599", "validity": "60 Days", "emoji": "🚀"}
        },
        "free": {
            "basic": {"ram": 2, "cpu": 1, "disk": 10, "price": "invite 4", "emoji": "🎯"},
            "standard": {"ram": 4, "cpu": 2, "disk": 25, "price": "invite 10", "emoji": "💎"},
            "pro": {"ram": 8, "cpu": 4, "disk": 50, "price": "invite 15", "emoji": "🚀"}
        }
    }

def load_plans():
    if not ENABLE_PLANS:
        return {"premium": {}, "free": {}}
    try:
        with open('plans.json', 'r') as f:
            data = json.load(f)
            if "premium" not in data and "free" not in data:
                defaults = get_default_plans()
                return {"premium": defaults["premium"], "free": data}
            return data
    except FileNotFoundError:
        return get_default_plans()
    except json.JSONDecodeError:
        return get_default_plans()

PLANS = load_plans()

def save_plans():
    if not ENABLE_PLANS:
        return
    try:
        with open('plans.json', 'w') as f:
            json.dump(PLANS, f, indent=4)
    except Exception as e:
        logger.error(f"Failed to save plans.json: {e}")

# Global settings
CPU_THRESHOLD = int(get_setting('cpu_threshold', 90))
RAM_THRESHOLD = int(get_setting('ram_threshold', 90))
MAINTENANCE_MODE = get_setting('maintenance_mode', 'false') == 'true'

# Global Active Giveaways Tracker
active_giveaways = {}

# --- Bot Class ---

class MoonNodesBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        intents.reactions = True  
        intents.invites = True # Required for checking free plan invites
        super().__init__(command_prefix="!", intents=intents) 

    async def setup_hook(self):
        self.tree.on_error = self.on_tree_error
        
        cogs = [
            'command.owner.owner', 'command.admin.admin',
            'command.mod.mod', 'command.dev.dev', 'command.user.user'
        ]
        for cog in cogs:
            try: await self.load_extension(cog)
            except Exception as e: logger.error(f"Failed to load {cog}: {e}")
            
        try:
            synced = await self.tree.sync()
            logger.info(f"Synced {len(synced)} slash commands globally")
        except Exception as e:
            logger.error(f"Failed to sync slash commands: {e}")
        self.update_status_task.start()
        
        if SOSB:
            automated_backups.start()

    async def on_tree_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        if isinstance(error, app_commands.CommandOnCooldown):
            embed = create_warning_embed("System Cooldown", f"Command rate-limited. Try again in {error.retry_after:.2f}s.")
            try:
                if interaction.response.is_done(): await interaction.followup.send(embed=embed, ephemeral=True)
                else: await interaction.response.send_message(embed=embed, ephemeral=True)
            except Exception: pass
            return
            
        if isinstance(error, app_commands.CheckFailure):
            embed = create_error_embed("Access Denied", str(error))
            try:
                if interaction.response.is_done(): await interaction.followup.send(embed=embed, ephemeral=True)
                else: await interaction.response.send_message(embed=embed, ephemeral=True)
            except Exception: pass
            return

        error_message = str(error.original) if isinstance(error, app_commands.CommandInvokeError) else str(error)
        logger.error(f"Command Error: {error_message}")
        traceback.print_exc()

        try:
            embed = create_error_embed("System Fault", f"An anomaly occurred within the Matrix: {error_message[:4000]}")
            if interaction.response.is_done(): await interaction.followup.send(embed=embed, ephemeral=True)
            else: await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception: pass

    @tasks.loop(seconds=60)
    async def update_status_task(self):
        try:
            if MAINTENANCE_MODE:
                 await self.change_presence(status=discord.Status.dnd, activity=discord.Activity(type=discord.ActivityType.watching, name="Maintenance Lockdown"))
                 return

            total_vps = sum(len(v) for v in vps_data.values())
            statuses = [
                f"Aegis Status: Nominal",
                f"Routing {total_vps} Active Cores",
                f"Nexus Architecture V3",
                f"Awaiting /help Input"
            ]
            await self.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name=random.choice(statuses)))
        except: pass

bot = MoonNodesBot()
resource_monitor_active = True

# --- Scheduled & Off-Site Backups (Feature 6) ---
@tasks.loop(hours=24)
async def automated_backups():
    if not SOSB: return
    logger.info("[SOSB] Running scheduled automated backups...")
    with data_lock:
        current_data = vps_data.copy()
    for uid, vps_list in current_data.items():
        for vps in vps_list:
            cname = vps['container_name']
            snap_name = f"auto-backup-{datetime.now().strftime('%Y%m%d')}"
            try:
                await execute_lxc(f"lxc snapshot {cname} {snap_name}")
                logger.info(f"[SOSB] Automated backup created for {cname}")
            except Exception as e:
                logger.error(f"[SOSB] Failed auto-backup for {cname}: {e}")

# --- Checks & Permissions ---

def is_admin_check(user_id):
    role = admin_data.get(str(user_id))
    return role in ['Owner', 'Admin', 'Dev'] or str(user_id) == str(MAIN_ADMIN_ID)

def check_maintenance():
    async def predicate(interaction: discord.Interaction):
        if MAINTENANCE_MODE:
            if is_admin_check(interaction.user.id):
                return True
            raise app_commands.CheckFailure("⚠️ System is currently under maintenance lockout. Please stand by.")
        return True
    return app_commands.check(predicate)

def has_role(*allowed_roles):
    async def predicate(interaction: discord.Interaction):
        user_id = str(interaction.user.id)
        if user_id == str(MAIN_ADMIN_ID):
            return True
        role = admin_data.get(user_id)
        if role == 'Owner' or role in allowed_roles:
            return True
        raise app_commands.CheckFailure(f"You lack the requisite security clearance: {', '.join(allowed_roles)} or Root")
    return app_commands.check(predicate)

# --- LXC Execution & Deployment Logic ---

async def execute_lxc(command, timeout=120):
    logger.info(f"Executing LXC: {command}")
    try:
        cmd = shlex.split(command)
        proc = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            raise asyncio.TimeoutError(f"Command timed out after {timeout} seconds")
        
        if proc.returncode != 0:
            error = stderr.decode().strip() if stderr else "Command failed with no error output"
            if "not found" in error.lower() or "doesn't exist" in error.lower(): pass
            else: logger.error(f"LXC Failed: {error}")
            raise Exception(error)
        
        return stdout.decode().strip() if stdout else True
    except Exception as e:
        if "not found" not in str(e).lower(): logger.error(f"LXC Error in execution: {command} - {str(e)}")
        raise

async def apply_advanced_permissions(container_name):
    try:
        await execute_lxc(f"lxc config set {container_name} security.nesting true")
        try:
            await execute_lxc(f"lxc config device add {container_name} fuse unix-char path=/dev/fuse")
        except: pass
        try:
             await execute_lxc(f"lxc config device set {container_name} root limits.read 50MB") 
             await execute_lxc(f"lxc config device set {container_name} root limits.write 50MB")
        except: pass
    except Exception as e:
        logger.warning(f"Failed to apply full permissions to {container_name}: {e}")

async def get_or_create_vps_role(guild):
    global VPS_USER_ROLE_ID
    if VPS_USER_ROLE_ID and VPS_USER_ROLE_ID != 0:
        role = guild.get_role(VPS_USER_ROLE_ID)
        if role: return role
    role = discord.utils.get(guild.roles, name="MoonNodes Quantum User")
    if role:
        VPS_USER_ROLE_ID = role.id
        return role
    try:
        role = await guild.create_role(
            name="MoonNodes Quantum User",
            color=discord.Color.brand_green(),
            reason="MoonNodes Matrix Access Role",
            permissions=discord.Permissions.none()
        )
        VPS_USER_ROLE_ID = role.id
        return role
    except Exception as e: return None

async def auto_deploy_vps(user: discord.Member, ram: int, cpu: int, disk: int, os_version: str = "ubuntu:22.04"):
    """Automated backend deployment function utilized for giveaways and automated systems."""
    user_id = str(user.id)
    with data_lock:
        if user_id not in vps_data: vps_data[user_id] = []
        vps_count = 1
        
        safe_username = re.sub(r'[^a-z0-9]', '', user.name.lower())
        if not safe_username: safe_username = "user" 
        
        existing_names = {v['container_name'] for lst in vps_data.values() for v in lst}
        while f"moonode-{safe_username}-{vps_count}" in existing_names:
            vps_count += 1
        container_name = f"moonode-{safe_username}-{vps_count}"
    
    try:
        await execute_lxc(f"lxc init {os_version} {container_name} -s {ACTIVE_STORAGE_POOL}") 
        await execute_lxc(f"lxc config set {container_name} limits.memory {ram}GB")
        await execute_lxc(f"lxc config set {container_name} limits.cpu {cpu}")
        try:
            await execute_lxc(f"lxc config device set {container_name} root size={disk}GB")
        except:
            await execute_lxc(f"lxc config device add {container_name} root disk pool={ACTIVE_STORAGE_POOL} path=/ size={disk}GB")
        
        await apply_advanced_permissions(container_name)
        await execute_lxc(f"lxc start {container_name}")
        
        config_str = f"{ram}GB RAM / {cpu} CPU / {disk}GB Disk"
        vps_info = {
            "container_name": container_name, "ram": f"{ram}GB", "cpu": str(cpu),
            "storage": f"{disk}GB", "config": config_str, "os_version": os_version,
            "status": "running", "suspended": False, "whitelisted": False,
            "suspension_history": [], "created_at": datetime.now().isoformat(), "shared_with": [], "id": None
        }
        
        with data_lock:
            vps_data[user_id].append(vps_info)
        save_vps_data()
        
        subdomain_url = "None"
        if ASM:
            clean_name = re.sub(r'[^a-zA-Z0-9-]', '', container_name).lower()
            result = await create_cloudflare_subdomain(clean_name)
            if result:
                subdomain_url = result
                logger.info(f"[ASM] Creating Subdomain for giveaway winner: {subdomain_url}")
        
        try:
            dm_embed = create_success_embed("🎉 Quantum Node Synchronized!", f"Your newly deployed premium architecture `{container_name}` is online and ready for incoming connections.")
            add_field(dm_embed, "Allocated Specs", f"```yaml\nRAM: {ram}GB\nCPU: {cpu} Cores\nDisk: {disk}GB\n```")
            add_field(dm_embed, "🌐 Routing Matrix", f"http://{subdomain_url}" if subdomain_url != "None" else "Manual Setup Required", False)
            await user.send(embed=dm_embed)
        except: pass
    except Exception as e:
        logger.error(f"Auto Deploy Failed for {user.name}: {e}")

# --- Monitoring Functions ---

def get_cpu_usage_sync():
    try:
        if shutil.which("mpstat"):
            result = subprocess.run(['mpstat', '1', '1'], capture_output=True, text=True)
            for line in result.stdout.split('\n'):
                if 'all' in line and '%' in line: return 100.0 - float(line.split()[-1])
        else:
            result = subprocess.run(['top', '-bn1'], capture_output=True, text=True)
            for line in result.stdout.split('\n'):
                if '%Cpu(s):' in line:
                    return 100.0 - float(line.split()[7])
        return 0.0
    except: return 0.0

def get_ram_usage_sync():
    try:
        result = subprocess.run(['free', '-m'], capture_output=True, text=True)
        lines = result.stdout.splitlines()
        if len(lines) > 1:
            mem = lines[1].split()
            return (int(mem[2]) / int(mem[1]) * 100) if int(mem[1]) > 0 else 0.0
        return 0.0
    except: return 0.0

async def get_cpu_usage_async():
    return await asyncio.to_thread(get_cpu_usage_sync)

async def get_ram_usage_async():
    return await asyncio.to_thread(get_ram_usage_sync)

async def get_uptime_async():
    try: 
        proc = await asyncio.create_subprocess_exec('uptime', '-p', stdout=asyncio.subprocess.PIPE)
        stdout, _ = await proc.communicate()
        return stdout.decode().strip() if stdout else "Unknown"
    except: return "Unknown"

def resource_monitor():
    global resource_monitor_active
    while resource_monitor_active:
        try:
            if get_cpu_usage_sync() > CPU_THRESHOLD or get_ram_usage_sync() > RAM_THRESHOLD:
                logger.warning("Resource usage exceeded thresholds. Stopping all VPS.")
                subprocess.run(['lxc', 'stop', '--all', '--force'], check=True)
                with data_lock:
                    for user_id, vps_list in list(vps_data.items()):
                        for vps in vps_list:
                            if vps.get('status') == 'running': 
                                vps['status'] = 'stopped'
                save_vps_data()
                asyncio.run_coroutine_threadsafe(send_log(create_error_embed("Critical System Haltdown", "All Quantum Nodes halted due to host resource exhaustion.")), bot.loop)
            time.sleep(60)
        except Exception: time.sleep(60)

monitor_thread = threading.Thread(target=resource_monitor, daemon=True)

async def get_container_cpu_raw(container_name):
    try:
        proc = await asyncio.create_subprocess_exec("lxc", "exec", container_name, "--", "top", "-bn1", stdout=asyncio.subprocess.PIPE)
        stdout, _ = await proc.communicate()
        for line in stdout.decode().splitlines():
            if '%Cpu(s):' in line:
                parts = line.split()
                return sum(float(parts[i]) for i in [1,3,5,9,11,13,15])
        return 0.0
    except: return 0.0

async def get_container_memory_raw(container_name):
    try:
        proc = await asyncio.create_subprocess_exec("lxc", "exec", container_name, "--", "free", "-m", stdout=asyncio.subprocess.PIPE)
        stdout, _ = await proc.communicate()
        lines = stdout.decode().splitlines()
        if len(lines) > 1:
            parts = lines[1].split()
            used = int(parts[2])
            total = int(parts[1])
            percent = (used / total) * 100 if total > 0 else 0
            return f"{used}/{total} MB", percent
        return "Unknown", 0.0
    except: return "Unknown", 0.0

async def get_container_disk(container_name):
    try:
        proc = await asyncio.create_subprocess_exec("lxc", "exec", container_name, "--", "df", "-h", "/", stdout=asyncio.subprocess.PIPE)
        stdout, _ = await proc.communicate()
        for line in stdout.decode().splitlines():
            if '/dev/' in line and ' /' in line:
                parts = line.split()
                return f"{parts[2]}/{parts[1]} ({parts[4]})"
        return "Unknown"
    except: return "Unknown"

# --- Events ---

async def handle_tmate_ssh(interaction: discord.Interaction, container_name: str):
    await interaction.response.defer(ephemeral=True)
    msg = await interaction.followup.send(embed=create_info_embed(f"{Theme.LOADING} Handshaking Secure Subnet", "Generating advanced RSA pairs and opening relay tunnel..."), ephemeral=True)
    try:
        try: await execute_lxc(f"lxc exec {container_name} -- ping -c 1 -W 3 8.8.8.8", timeout=5)
        except Exception: return await msg.edit(embed=create_error_embed("Bridge Unreachable", "This node is disconnected from the global network. Ping an Administrator to check host routing bridges."))

        is_installed = False
        try:
            await execute_lxc(f"lxc exec {container_name} -- which tmate")
            is_installed = True
        except: pass

        if not is_installed:
            await msg.edit(embed=create_info_embed(f"{Theme.LOADING} Sourcing Dependencies", "Downloading binary packets required for secure SSH routing..."))
            try:
                await execute_lxc(f"lxc exec {container_name} -- apt-get update -y", timeout=300)
                await execute_lxc(f"lxc exec {container_name} -- apt-get install tmate openssh-client -y", timeout=300)
            except:
                try:
                    await execute_lxc(f"lxc exec {container_name} -- apt-get install software-properties-common -y", timeout=300)
                    await execute_lxc(f"lxc exec {container_name} -- add-apt-repository universe -y", timeout=120)
                    await execute_lxc(f"lxc exec {container_name} -- apt-get update -y", timeout=300)
                    await execute_lxc(f"lxc exec {container_name} -- apt-get install tmate openssh-client -y", timeout=300)
                except:
                    await msg.edit(embed=create_warning_embed("APT Overload", "Compiling native binaries from external CDN fallback..."))
                    await execute_lxc(f"lxc exec {container_name} -- apt-get install curl xz-utils openssh-client -y", timeout=300)
                    dl_cmd = "curl -sS -L --connect-timeout 15 https://github.com/tmate-io/tmate/releases/download/2.4.0/tmate-2.4.0-static-linux-amd64.tar.xz -o /tmp/tmate.tar.xz"
                    await execute_lxc(f"lxc exec {container_name} -- {dl_cmd}", timeout=300)
                    await execute_lxc(f"lxc exec {container_name} -- tar -xJf /tmp/tmate.tar.xz -C /tmp")
                    await execute_lxc(f"lxc exec {container_name} -- mv /tmp/tmate-2.4.0-static-linux-amd64/tmate /usr/bin/tmate")
                    await execute_lxc(f"lxc exec {container_name} -- chmod +x /usr/bin/tmate")

        try: await execute_lxc(f"lxc exec {container_name} -- ssh-keygen -A")
        except: pass

        sess = f"moonnodes-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        await execute_lxc(f"lxc exec {container_name} -- tmate -S /tmp/{sess}.sock new-session -d")
        try: await execute_lxc(f"lxc exec {container_name} -- tmate -S /tmp/{sess}.sock wait tmate-ready", timeout=30)
        except: pass
        url = await execute_lxc(f"lxc exec {container_name} -- tmate -S /tmp/{sess}.sock display -p '#{{tmate_ssh}}'")
        
        if url and "ssh" in url.lower():
            try:
                embed = create_success_embed("🔑 Secure Shell Cleared")
                add_field(embed, "Connection String (Terminal)", f"```bash\n{url}\n```", False)
                add_field(embed, "Session Token", f"`{sess}`", True)
                add_field(embed, "Clearance Warning", "⚠️ This grants absolute Root Authority over the container. Do not leak it.", False)
                await interaction.user.send(embed=embed)
                await msg.edit(embed=create_success_embed("Token Transmitted", "The SSH connection string has been dropped securely into your Direct Messages."))
            except: await msg.edit(embed=create_error_embed("Delivery Blocked", "Matrix transmission failed. Ensure Direct Messages are open."))
        else: await msg.edit(embed=create_error_embed("Tunnel Failure", "Failed to retrieve SSH credentials from the relay. The endpoint may be unstable."))
    except Exception as e: await msg.edit(embed=create_error_embed("Protocol Fault", str(e)[:4000]))

async def handle_tailscale_ssh(interaction: discord.Interaction, container_name: str):
    await interaction.response.defer(ephemeral=True)
    msg = await interaction.followup.send(embed=create_info_embed(f"{Theme.LOADING} Installing Tailscale", "Injecting Tailscale routing protocol..."), ephemeral=True)
    try:
        await execute_lxc(f"lxc exec {container_name} -- curl -fsSL https://tailscale.com/install.sh | sh", timeout=300)
        await execute_lxc(f"lxc exec {container_name} -- sh -c 'tailscale up > /tmp/ts.log 2>&1 &'", timeout=10)
        await asyncio.sleep(3)
        logs = await execute_lxc(f"lxc exec {container_name} -- cat /tmp/ts.log")
        url_match = re.search(r'https://login.tailscale.com/a/\w+', logs)
        if url_match:
            await msg.edit(embed=create_success_embed("Tailscale Matrix", f"Authenticate via the following secure link:\n{url_match.group(0)}"))
        else:
            await msg.edit(embed=create_success_embed("Tailscale Active", "Service deployed. If it requires auth, check the node's terminal."))
    except Exception as e:
        await msg.edit(embed=create_error_embed("Tailscale Error", str(e)[:4000]))

class SSHChoiceView(discord.ui.View):
    def __init__(self, user_id, container_name):
        super().__init__(timeout=180)
        self.user_id = user_id
        self.container_name = container_name

    @discord.ui.button(label="Tmate SSH", style=discord.ButtonStyle.primary, emoji="🔑")
    async def tmate_ssh(self, interaction: discord.Interaction, button: discord.ui.Button):
        if str(interaction.user.id) != self.user_id:
            return await interaction.response.send_message("Clearance Denied.", ephemeral=True)
        await handle_tmate_ssh(interaction, self.container_name)

    @discord.ui.button(label="Tailscale", style=discord.ButtonStyle.success, emoji="🌐")
    async def tailscale_ssh(self, interaction: discord.Interaction, button: discord.ui.Button):
        if str(interaction.user.id) != self.user_id:
            return await interaction.response.send_message("Clearance Denied.", ephemeral=True)
        await handle_tailscale_ssh(interaction, self.container_name)

@bot.event
async def on_ready():
    logger.info(f'{bot.user} has connected to the Matrix!')
    logger.info(f"Storage Backbone: {ACTIVE_STORAGE_POOL}")
    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name="MoonNodes Premium Architecture"))
    logger.info("Aegis Systems Online.")

# --- Views & Modals ---

class ResizeModal(discord.ui.Modal, title="Recalibrate Quantum Allocation"):
    def __init__(self, container_name, current_ram, current_cpu, current_disk):
        super().__init__()
        self.container_name = container_name
        
        self.ram = discord.ui.TextInput(label="RAM Matrix (GB)", default=str(current_ram).replace("GB","").strip(), placeholder="e.g. 4", min_length=1, max_length=3)
        self.cpu = discord.ui.TextInput(label="Compute Cores", default=str(current_cpu), placeholder="e.g. 2", min_length=1, max_length=2)
        self.disk = discord.ui.TextInput(label="Storage Block (GB)", default=str(current_disk).replace("GB","").strip(), placeholder="e.g. 20", min_length=1, max_length=4)
        
        self.add_item(self.ram)
        self.add_item(self.cpu)
        self.add_item(self.disk)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        
        try:
            ram_val = int(self.ram.value)
            cpu_val = int(self.cpu.value)
            disk_val = int(self.disk.value)
        except ValueError:
            return await interaction.followup.send(embed=create_error_embed("Syntax Error", "Hardware integers must be pure numeric values."), ephemeral=True)

        if ram_val > MAX_RAM_LIMIT or cpu_val > MAX_CPU_LIMIT:
             return await interaction.followup.send(embed=create_error_embed("Safety Lockout Exceeded", f"Max RAM Ceil: {MAX_RAM_LIMIT}GB\nMax CPU Ceil: {MAX_CPU_LIMIT} Core"), ephemeral=True)

        try:
            await execute_lxc(f"lxc config set {self.container_name} limits.memory {ram_val}GB")
            await execute_lxc(f"lxc config set {self.container_name} limits.cpu {cpu_val}")
            try: await execute_lxc(f"lxc config device set {self.container_name} root size={disk_val}GB")
            except: pass 

            with data_lock:
                for uid, vps_list in vps_data.items():
                    for vps in vps_list:
                        if vps['container_name'] == self.container_name:
                            vps['ram'] = f"{ram_val}GB"
                            vps['cpu'] = cpu_val
                            vps['storage'] = f"{disk_val}GB"
                            vps['config'] = f"{ram_val}GB RAM / {cpu_val} CPU / {disk_val}GB Disk"
            save_vps_data()
            
            embed = create_success_embed("Recalibration Complete", f"Successfully rewrote blocks for **{self.container_name}**")
            add_field(embed, "New Hardware Arrays", f"```yaml\nRAM: {ram_val}GB\nCPU: {cpu_val} Cores\nDisk: {disk_val}GB\n```")
            await interaction.followup.send(embed=embed, ephemeral=True)
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Recalibration Failed", str(e)), ephemeral=True)

class SoftwareView(discord.ui.View):
    def __init__(self, user_id, container_name):
        super().__init__(timeout=180)
        self.user_id = user_id
        self.container_name = container_name
        self.add_buttons()

    def add_buttons(self):
        for key, script in SOFTWARE_SCRIPTS.items():
            btn = discord.ui.Button(label=script['name'], style=discord.ButtonStyle.secondary, custom_id=key, row=0 if len(self.children) < 3 else 1)
            btn.callback = self.make_callback(key)
            self.add_item(btn)

    def make_callback(self, key):
        async def callback(interaction: discord.Interaction):
            if str(interaction.user.id) != self.user_id: return await interaction.response.send_message("Security Clearance Denied.", ephemeral=True)
            script_data = SOFTWARE_SCRIPTS[key]
            
            try:
                await execute_lxc(f"lxc exec {self.container_name} -- ping -c 1 -W 3 8.8.8.8", timeout=5)
            except Exception:
                return await interaction.response.send_message(embed=create_error_embed("Network Unreachable", "This node lacks an external internet bridge. Please ask a Level 3 Administrator to fix the host LXD routing protocol."), ephemeral=True)

            await interaction.response.send_message(embed=create_info_embed(f"Injecting {script_data['name']} Matrix", "Fetching enterprise dependencies. Stand by..."), ephemeral=True)
            try:
                cmd = script_data['cmd']
                await execute_lxc(f"lxc exec {self.container_name} -- sh -c '{cmd}'", timeout=600)
                await interaction.followup.send(embed=create_success_embed("Injection Confirmed", f"**{script_data['name']}** framework has been written to `{self.container_name}`."), ephemeral=True)
            except Exception as e:
                await interaction.followup.send(embed=create_error_embed("Injection Failed", str(e)[:4000]), ephemeral=True)
        return callback

class ConfirmView(discord.ui.View):
    def __init__(self, user_id):
        super().__init__(timeout=30)
        self.user_id = user_id
        self.value = None

    @discord.ui.button(label="Authorize Overwrite", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        if str(interaction.user.id) != self.user_id: return await interaction.response.send_message("Unauthorized.", ephemeral=True)
        self.value = True
        self.stop()
        await interaction.response.defer()

    @discord.ui.button(label="Abort", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        if str(interaction.user.id) != self.user_id: return await interaction.response.send_message("Unauthorized.", ephemeral=True)
        self.value = False
        self.stop()
        await interaction.response.defer()

class AdminVPSView(discord.ui.View):
    def __init__(self, user_id, vps_dict, owner_id):
        super().__init__(timeout=300)
        self.user_id = user_id
        self.vps = vps_dict
        self.owner_id = owner_id
        self.container_name = vps_dict['container_name']
        self.is_suspended = self.vps.get('suspended', False)
        self.update_buttons()

    def update_buttons(self):
        self.clear_items()
        if self.is_suspended: label, style, emoji = "Unsuspend", discord.ButtonStyle.success, "▶️"
        else: label, style, emoji = "Suspend", discord.ButtonStyle.danger, "⛔"

        suspend_btn = discord.ui.Button(label=label, style=style, emoji=emoji, row=0)
        suspend_btn.callback = self.toggle_suspend
        self.add_item(suspend_btn)

        resize_btn = discord.ui.Button(label="Recalibrate", style=discord.ButtonStyle.primary, emoji="📏", row=0)
        resize_btn.callback = self.resize_vps
        self.add_item(resize_btn)

        refresh_btn = discord.ui.Button(label="Sync Telemetry", style=discord.ButtonStyle.secondary, emoji="🔄", row=0)
        refresh_btn.callback = self.refresh_view
        self.add_item(refresh_btn)

        owner_btn = discord.ui.Button(label="Transfer Rights", style=discord.ButtonStyle.secondary, emoji="👤", row=1)
        owner_btn.callback = self.change_owner
        self.add_item(owner_btn)

        delete_btn = discord.ui.Button(label="Purge Asset", style=discord.ButtonStyle.danger, emoji="🗑️", row=1)
        delete_btn.callback = self.delete_vps_btn
        self.add_item(delete_btn)

    async def refresh_view(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.user_id: return
        await interaction.response.defer(ephemeral=True)
        target_vps = None
        with data_lock:
            if self.owner_id in vps_data:
                for v in vps_data[self.owner_id]:
                    if v['container_name'] == self.container_name:
                        target_vps = v
                        break
        if target_vps:
            self.vps = target_vps
            self.is_suspended = target_vps.get('suspended', False)
            self.update_buttons()
            status_text = "⛔ Suspended Lockout" if self.is_suspended else "🟢 Routing Nominal"
            embed = create_warning_embed(f"🛡️ Admin Override: {self.container_name}", f"**Network Status:** {status_text}\n*Telemetry sync complete.*")
            await interaction.edit_original_response(embed=embed, view=self)
        else:
            await interaction.followup.send(embed=create_error_embed("Null Reference", "Asset no longer mapped to the hypervisor pool."), ephemeral=True)

    async def toggle_suspend(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.user_id: return
        await interaction.response.defer(ephemeral=True)
        try:
            if self.is_suspended:
                await execute_lxc(f"lxc start {self.container_name}")
                with data_lock:
                    self.vps['suspended'] = False
                    self.vps['status'] = 'running'
                self.is_suspended = False
                msg = "Restored"
            else:
                await execute_lxc(f"lxc stop {self.container_name}")
                with data_lock:
                    self.vps['suspended'] = True
                    self.vps['status'] = 'stopped'
                    self.vps['suspension_history'].append({'time': datetime.now().isoformat(), 'reason': 'Root Administrative Lockout', 'by': interaction.user.name})
                self.is_suspended = True
                msg = "Frozen"
            
            save_vps_data()
            self.update_buttons()
            status_text = "⛔ Suspended" if self.is_suspended else "🟢 Running"
            embed = create_warning_embed(f"🛡️ Security Control: {self.container_name}", f"**Network Status:** {status_text}\nCommand Sequence: **{msg}** successfully executed.")
            await interaction.edit_original_response(embed=embed, view=self)
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Execution Error", str(e)[:4000]), ephemeral=True)

    async def resize_vps(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.user_id: return
        await interaction.response.send_modal(ResizeModal(self.container_name, self.vps.get('ram', '1GB'), self.vps.get('cpu', '1'), self.vps.get('storage', '10GB')))

    async def change_owner(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.user_id: return
        await interaction.response.send_message(embed=create_info_embed("Transfer Access Keys", "Ping the designated identity in the terminal (e.g. @User)."), ephemeral=True)
        def check(m): return m.author.id == interaction.user.id and m.channel.id == interaction.channel.id and len(m.mentions) > 0
        try:
            msg = await bot.wait_for('message', check=check, timeout=30.0)
            new_owner = msg.mentions[0]
            new_id = str(new_owner.id)
            if new_id == self.owner_id: return await interaction.followup.send(embed=create_error_embed("Transfer Fault", "Target identity already holds primary keys."), ephemeral=True)

            with data_lock:
                if self.owner_id in vps_data:
                    idx = next((i for i, v in enumerate(vps_data[self.owner_id]) if v['container_name'] == self.container_name), -1)
                    if idx != -1:
                        vps_obj = vps_data[self.owner_id].pop(idx)
                        if new_id not in vps_data: vps_data[new_id] = []
                        vps_data[new_id].append(vps_obj)
                        if not vps_data[self.owner_id]: del vps_data[self.owner_id]
                        save_vps_data()
                        await interaction.followup.send(embed=create_success_embed("Key Transfer Complete", f"Asset ownership successfully bound to {new_owner.mention}."), ephemeral=True)
        except asyncio.TimeoutError:
            await interaction.followup.send(embed=create_warning_embed("Timeout Reached", "Handshake procedure aborted."), ephemeral=True)

    async def delete_vps_btn(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.user_id: return
        view = ConfirmView(self.user_id)
        await interaction.response.send_message(embed=create_warning_embed("Critical Purge Authorization", f"Authorize immediate destruction of `{self.container_name}`? All sectors will be permanently wiped."), view=view, ephemeral=True)
        await view.wait()
        if view.value:
            await interaction.edit_original_response(embed=create_info_embed("Termination Sequence", "Wiping blocks and clearing matrices..."), view=None)
            try:
                await execute_lxc(f"lxc delete {self.container_name} --force")
                with data_lock:
                    if self.owner_id in vps_data:
                        vps_data[self.owner_id] = [v for v in vps_data[self.owner_id] if v['container_name'] != self.container_name]
                        if not vps_data[self.owner_id]: del vps_data[self.owner_id]
                save_vps_data()
                await interaction.followup.send(embed=create_success_embed("Purge Complete", "Volume irrecoverably wiped from the primary cluster."), ephemeral=True)
            except Exception as e:
                await interaction.followup.send(embed=create_error_embed("Matrix Error", str(e)[:4000]), ephemeral=True)

class ManageView(discord.ui.View):
    def __init__(self, user_id, vps_list, is_shared=False, owner_id=None, is_admin=False, actual_index: Optional[int] = None):
        super().__init__(timeout=None)
        self.user_id = user_id
        self.vps_list_initial = vps_list 
        self.selected_index = None
        self.is_shared = is_shared
        self.owner_id = owner_id or user_id
        self.is_admin = is_admin
        self.actual_index = actual_index
        self.indices = list(range(len(vps_list)))
        self.cooldowns = {}
        
        if self.is_shared and self.actual_index is None: raise ValueError("actual_index required")
        
        if len(vps_list) > 1 and self.actual_index is None:
            options = [discord.SelectOption(label=f"Node {i+1} ({v.get('config', 'Custom')})", value=str(i), emoji="🖥️") for i, v in enumerate(vps_list)]
            self.select = discord.ui.Select(placeholder="▼ Interface with Quantum Node", options=options)
            self.select.callback = self.select_vps
            self.add_item(self.select)
            self.initial_embed = create_embed("🎛️ Aegis Control Matrix", "Designate a target Node from the dropdown to access routing controls.")
        else:
            self.selected_index = 0
            self.initial_embed = None
            self.add_action_buttons()

    def check_cooldown(self, user_id, command_name):
        key = f"{user_id}:{command_name}"
        if key in self.cooldowns:
            if time.time() - self.cooldowns[key] < 5: return False
        self.cooldowns[key] = time.time()
        return True

    async def get_initial_embed(self):
        if self.initial_embed: return self.initial_embed
        return await self.create_vps_embed(self.selected_index)

    def get_vps_data_safe(self, index):
        try:
            actual_idx = self.actual_index if (self.is_shared or self.actual_index is not None) else self.indices[index]
            with data_lock:
                if self.owner_id in vps_data and len(vps_data[self.owner_id]) > actual_idx:
                    return vps_data[self.owner_id][actual_idx], actual_idx
        except: pass
        return None, None

    async def create_vps_embed(self, index):
        vps, _ = self.get_vps_data_safe(index)
        if not vps: return create_error_embed("Data Fault", "Could not query Quantum array parameters.")
        
        container_name = vps['container_name']
        status = vps.get('status', 'stopped')
        suspended = vps.get('suspended', False)

        color = Theme.get_status_color(status, suspended)
        if status == 'running' and not suspended:
            status_text = f"ROUTING TRAFFIC"
            status_indicator = Theme.ONLINE
            cpu_val = await get_container_cpu_raw(container_name)
            mem_str, mem_val = await get_container_memory_raw(container_name)
            disk_usage = await get_container_disk(container_name)
        else:
            status_text = f"NETWORK LOCKOUT" if suspended else f"POWERED DOWN"
            status_indicator = Theme.OFFLINE
            cpu_val, mem_val, mem_str, disk_usage = 0, 0, "0/0 MB", "Sector Offline"

        embed = create_embed(f"🎛️ Enterprise Node: {container_name}", "", color)
        
        embed.add_field(name="📍 System Link", value=f"> {status_indicator} **{status_text}**", inline=True)
        embed.add_field(name="⚙️ Hardware Blueprint", value=f"> **{vps.get('config', 'Custom')}**", inline=True)
        embed.add_field(name="\u200b", value=Theme.DIVIDER, inline=False)
        
        embed.add_field(name=f"{Theme.CPU} Processor Load", value=Theme.progress_bar(cpu_val), inline=False)
        embed.add_field(name=f"{Theme.RAM} Memory Threads", value=f"{Theme.progress_bar(mem_val)}\n`{mem_str}`", inline=True)
        embed.add_field(name=f"{Theme.DISK} Root Volume", value=f"```\n{disk_usage}\n```", inline=True)
        
        return embed

    def make_action_callback(self, action: str):
        async def callback(interaction: discord.Interaction):
            await self.action_callback(interaction, action)
        return callback

    def add_action_buttons(self):
        if not self.is_shared:
            reinstall = discord.ui.Button(label="Re-Flash", style=discord.ButtonStyle.danger, emoji="🔄", row=0)
            reinstall.callback = self.make_action_callback('reinstall')
            self.add_item(reinstall)

        start = discord.ui.Button(label="Ignite", style=discord.ButtonStyle.success, emoji="▶️", row=0)
        start.callback = self.make_action_callback('start')
        self.add_item(start)

        stop = discord.ui.Button(label="Halt", style=discord.ButtonStyle.secondary, emoji="⏸️", row=0)
        stop.callback = self.make_action_callback('stop')
        self.add_item(stop)

        ssh = discord.ui.Button(label="SSH & Tailscale", style=discord.ButtonStyle.primary, emoji="🔑", row=0)
        ssh.callback = self.make_action_callback('ssh_tailscale')
        self.add_item(ssh)

        stats = discord.ui.Button(label="Telemetry", style=discord.ButtonStyle.secondary, emoji="🔄", row=0)
        stats.callback = self.make_action_callback('stats')
        self.add_item(stats)
        
        console = discord.ui.Button(label="Terminal Feed", style=discord.ButtonStyle.secondary, emoji="💻", row=1)
        console.callback = self.make_action_callback('console')
        self.add_item(console)
        
        soft = discord.ui.Button(label="Software Hub", style=discord.ButtonStyle.secondary, emoji="💿", row=1)
        soft.callback = self.make_action_callback('software')
        self.add_item(soft)

        if self.is_admin:
            admin_btn = discord.ui.Button(label="Root Admin", style=discord.ButtonStyle.danger, emoji="🛡️", row=1)
            admin_btn.callback = self.open_admin_panel
            self.add_item(admin_btn)

    async def select_vps(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.user_id and not self.is_admin:
            return await interaction.response.send_message("Clearance Denied.", ephemeral=True)
        await interaction.response.defer()
        self.selected_index = int(self.select.values[0])
        self.clear_items()
        self.add_action_buttons()
        embed = await self.create_vps_embed(self.selected_index)
        await interaction.edit_original_response(embed=embed, view=self)

    async def open_admin_panel(self, interaction: discord.Interaction):
        target_vps, _ = self.get_vps_data_safe(self.selected_index or 0)
        if not target_vps: return
        admin_view = AdminVPSView(str(interaction.user.id), target_vps, self.owner_id)
        await interaction.response.send_message(embed=create_warning_embed(f"🛡️ Admin Override: {target_vps['container_name']}", "Extreme caution advised. You are operating outside standard Matrix parameters."), view=admin_view, ephemeral=True)

    async def action_callback(self, interaction: discord.Interaction, action: str):
        if str(interaction.user.id) != self.user_id and not self.is_admin:
            return await interaction.response.send_message("Clearance Denied.", ephemeral=True)
            
        target_vps, _ = self.get_vps_data_safe(self.selected_index or 0)
        if not target_vps: return
        container_name = target_vps["container_name"]
        
        if action == 'software':
            view = SoftwareView(str(interaction.user.id), container_name)
            await interaction.response.send_message(embed=create_info_embed("Software Nexus", "Push high-level 1-click packages directly into your node."), view=view, ephemeral=True)

        elif action == 'reinstall':
            view = ConfirmView(str(interaction.user.id))
            await interaction.response.send_message(embed=create_warning_embed("Confirm Flash Overwrite?", "WARNING: All sectors on the primary volume will be permanently eradicated."), view=view, ephemeral=True)
            await view.wait()
            if not view.value: return
            await interaction.edit_original_response(embed=create_info_embed(f"{Theme.LOADING} Reconstructing Quantum Architecture...", f"Writing new OS blocks to `{container_name}`."), view=None)
            try:
                await execute_lxc(f"lxc delete {container_name} --force")
                await execute_lxc(f"lxc init {target_vps['os_version']} {container_name} -s {ACTIVE_STORAGE_POOL}")
                await execute_lxc(f"lxc config set {container_name} limits.memory {target_vps['ram']}")
                await execute_lxc(f"lxc config set {container_name} limits.cpu {target_vps['cpu']}")
                try: await execute_lxc(f"lxc config device set {container_name} root size={target_vps['storage']}")
                except: await execute_lxc(f"lxc config device add {container_name} root disk pool={ACTIVE_STORAGE_POOL} path=/ size={target_vps['storage']}")
                await apply_advanced_permissions(container_name)
                await execute_lxc(f"lxc start {container_name}")
                with data_lock:
                    target_vps["status"] = "running"
                    target_vps["suspended"] = False
                save_vps_data()
                await interaction.followup.send(embed=create_success_embed("Flash Protocol Successful", "System core has been rewritten."), ephemeral=True)
            except Exception as e: await interaction.followup.send(embed=create_error_embed("Flash Failed", str(e)[:4000]), ephemeral=True)

        elif action == 'start':
            if not self.check_cooldown(interaction.user.id, "start"): return await interaction.response.send_message("Action rate limited. Let the cluster cool down...", ephemeral=True)
            await interaction.response.defer(ephemeral=True)
            try:
                await execute_lxc(f"lxc start {container_name}")
                with data_lock: target_vps["status"] = "running"
                save_vps_data()
                await interaction.followup.send(embed=create_success_embed("Core Ignited", f"Energy state for `{container_name}` mapped to ONLINE."), ephemeral=True)
                await send_audit_log(create_info_embed("Nexus Boot", f"Identity {interaction.user} ignited {container_name}"))
            except Exception as e: await interaction.followup.send(embed=create_error_embed("Ignition Failed", str(e)[:4000]), ephemeral=True)

        elif action == 'stop':
            if not self.check_cooldown(interaction.user.id, "stop"): return await interaction.response.send_message("Action rate limited. Let the cluster cool down...", ephemeral=True)
            await interaction.response.defer(ephemeral=True)
            try:
                await execute_lxc(f"lxc stop {container_name}")
                with data_lock: target_vps["status"] = "stopped"
                save_vps_data()
                await interaction.followup.send(embed=create_success_embed("Core Halted", f"Graceful energy cut for `{container_name}` complete."), ephemeral=True)
                await send_audit_log(create_warning_embed("Nexus Shutdown", f"Identity {interaction.user} halted {container_name}"))
            except Exception as e: await interaction.followup.send(embed=create_error_embed("Halt Failed", str(e)[:4000]), ephemeral=True)

        elif action == 'stats':
            await interaction.response.defer(ephemeral=True)
            await interaction.followup.send(embed=create_info_embed("Telemetry Bridge Synced", "System statistics have been pulled from the hypervisor."), ephemeral=True)
        
        elif action == 'console':
            await interaction.response.defer(ephemeral=True)
            try:
                logs = await execute_lxc(f"lxc info {container_name} --show-log")
                lines = logs.splitlines()[-15:]
                log_text = "\n".join(lines)
                if not log_text: log_text = "No trace available in kernel history."
                await interaction.followup.send(embed=create_info_embed("Kernel Readout Array", f"```bash\n{log_text}\n```"), ephemeral=True)
            except Exception as e: await interaction.followup.send(embed=create_error_embed("Read Error", str(e)[:4000]), ephemeral=True)

        elif action == 'ssh_tailscale':
            view = SSHChoiceView(str(interaction.user.id), container_name)
            await interaction.response.send_message(embed=create_info_embed("Routing Link", "Select your SSH connection protocol:"), view=view, ephemeral=True)

        try:
             new_embed = await self.create_vps_embed(self.selected_index or 0)
             await interaction.message.edit(embed=new_embed, view=self)
        except: pass

# --- General System Commands ---

@bot.tree.command(name="ping", description="Ping Global Quantum Hubs")
@check_maintenance()
async def ping(interaction: discord.Interaction):
    latency = round(bot.latency * 1000)
    await interaction.response.send_message(embed=create_success_embed("Gateway Online", f"Hypervisor Backbone Latency: `{latency}ms`"))

@bot.tree.command(name="status", description="Pull architecture health readouts")
@check_maintenance()
async def status(interaction: discord.Interaction):
    await interaction.response.defer()
    cpu = await get_cpu_usage_async()
    ram = await get_ram_usage_async()
    uptime = await get_uptime_async()
    embed = create_embed("🌐 Aegis Global Matrix Telemetry")
    add_field(embed, f"{Theme.NET} API Heartbeat", f"`{round(bot.latency * 1000)}ms`", True)
    add_field(embed, "⏱️ Cluster Uptime", f"`{uptime}`", True)
    add_field(embed, Theme.DIVIDER, "", False)
    add_field(embed, f"{Theme.CPU} Aggregated CPU Pool", Theme.progress_bar(cpu), False)
    add_field(embed, f"{Theme.RAM} Memory Sector Allocation", Theme.progress_bar(ram), False)
    await interaction.followup.send(embed=embed)

@bot.tree.command(name="maintenance", description="[ADMIN] Trigger emergency cluster freeze")
@has_role('Owner', 'Admin')
@app_commands.choices(state=[app_commands.Choice(name="Lockdown", value="on"), app_commands.Choice(name="Nominal", value="off")])
async def maintenance(interaction: discord.Interaction, state: str):
    global MAINTENANCE_MODE
    MAINTENANCE_MODE = (state == 'on')
    set_setting('maintenance_mode', 'true' if MAINTENANCE_MODE else 'false')
    if MAINTENANCE_MODE:
        await bot.change_presence(status=discord.Status.dnd, activity=discord.Activity(type=discord.ActivityType.watching, name="Maintenance Lockdown"))
        await interaction.response.send_message(embed=create_warning_embed("Lockdown Active", "Systems halted. Non-Root identities are currently blocked from the API."))
    else:
        await bot.change_presence(status=discord.Status.online, activity=discord.Activity(type=discord.ActivityType.watching, name="MoonNodes Premium Architecture"))
        await interaction.response.send_message(embed=create_success_embed("Lockdown Lifted", "System Nominal. Matrix access restored."))

# --- NEW CONSOLIDATED /SET SYSTEM ---
@bot.tree.command(name="set", description="[ADMIN] Configure Global Aegis Parameters")
@has_role('Owner', 'Admin')
@app_commands.choices(setting_type=[
    app_commands.Choice(name="Log Channel Target", value="log_channel"),
    app_commands.Choice(name="Payment/Claims Target", value="payment_channel"),
    app_commands.Choice(name="Bot Status RPC", value="status"),
    app_commands.Choice(name="Hardware Thresholds (CPU/RAM)", value="thresholds")
])
@app_commands.describe(setting_type="Setting to alter", channel="Select if mapping a channel", status_name="String for RPC status", cpu="Max CPU%", ram="Max RAM%")
async def set_config(interaction: discord.Interaction, setting_type: str, channel: discord.TextChannel = None, status_name: str = None, cpu: int = None, ram: int = None):
    await interaction.response.defer(ephemeral=True)
    
    if setting_type == "log_channel":
        if not channel: return await interaction.followup.send(embed=create_error_embed("Syntax", "A channel parameter is required."), ephemeral=True)
        set_setting('log_channel', str(channel.id))
        await interaction.followup.send(embed=create_success_embed("Matrix Updated", f"Audit logs securely routing to: {channel.mention}"))
        
    elif setting_type == "payment_channel":
        if not channel: return await interaction.followup.send(embed=create_error_embed("Syntax", "A channel parameter is required."), ephemeral=True)
        set_setting('payment_channel', str(channel.id))
        await interaction.followup.send(embed=create_success_embed("Matrix Updated", f"Premium acquisition tickets will now drop in: {channel.mention}"))
        
    elif setting_type == "status":
        if not status_name: return await interaction.followup.send(embed=create_error_embed("Syntax", "A status_name parameter is required."), ephemeral=True)
        await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name=status_name))
        await interaction.followup.send(embed=create_success_embed("RPC Altered", f"Nodes are now projecting: `{status_name}`"))
        
    elif setting_type == "thresholds":
        if not cpu or not ram: return await interaction.followup.send(embed=create_error_embed("Syntax", "Both cpu and ram parameters are required."), ephemeral=True)
        global CPU_THRESHOLD, RAM_THRESHOLD
        CPU_THRESHOLD, RAM_THRESHOLD = cpu, ram
        set_setting('cpu_threshold', str(cpu))
        set_setting('ram_threshold', str(ram))
        await interaction.followup.send(embed=create_success_embed("Safeties Calibrated", f"Hardware Haltdown Limits -> CPU: `{cpu}%` | RAM: `{ram}%`"))


@bot.tree.command(name="list", description="Access your allocated network assets")
@check_maintenance()
async def list_vps(interaction: discord.Interaction):
    await interaction.response.defer(ephemeral=True)
    user_id = str(interaction.user.id)
    with data_lock:
        vps_list = vps_data.get(user_id, [])
    
    if not vps_list:
        return await interaction.followup.send(embed=create_error_embed("Registry Empty", "You do not hold any verified Quantum Nodes within the cluster."))

    embed = create_embed(f"📦 Architect Repository - {interaction.user.name}")
    for i, vps in enumerate(vps_list):
        status_raw = vps.get('status', 'unknown')
        is_suspended = vps.get('suspended', False)
        is_whitelisted = vps.get('whitelisted', False)
        status_icon = Theme.OFFLINE
        status_text = "Dormant"
        if status_raw == 'running' and not is_suspended:
            status_icon, status_text = Theme.ONLINE, "Routing"
        elif is_suspended:
            status_icon, status_text = Theme.OFFLINE, "LOCKED"
        tags = " `🛡️ Quantum Bypass`" if is_whitelisted else ""
        details = f"> 🆔 **Node Key:** `{vps['container_name']}`\n> 📊 **Telemetry:** {status_icon} `{status_text}`{tags}\n> ⚙️ **Matrix:** `{vps.get('config', 'Custom')}`"
        add_field(embed, f"Asset [{i+1}]", details, False)

    add_field(embed, Theme.DIVIDER, "🔽 **Select an asset ID from the dashboard below to manage.**", False)
    view = ManageView(user_id, vps_list)
    await interaction.followup.send(embed=embed, view=view)

@bot.tree.command(name="list-all", description="[ADMIN] Intercept entire cluster ledger")
@has_role('Owner', 'Admin', 'Dev')
async def list_all_vps(interaction: discord.Interaction):
    await interaction.response.defer()
    with data_lock:
        total_users = len(vps_data)
        total_vps = sum(len(vps_list) for vps_list in vps_data.values())
        running = sum(1 for vps_list in vps_data.values() for vps in vps_list if vps.get('status') == 'running' and not vps.get('suspended', False))
    
    embed = create_embed("📂 Aegis Global Ledger", "Deep-scan overview of all hypervisor elements.")
    stats_text = f"```yaml\nTotal Architect IDs: {total_users}\nTotal Node Volumes:  {total_vps}\nActive Transmitting: {running}\n```"
    add_field(embed, "Cluster Wide Metrics", stats_text, False)
    await interaction.followup.send(embed=embed)
    
    vps_info = []
    with data_lock: current_data = vps_data.copy()
    for user_id, vps_list in current_data.items():
        try: user = await bot.fetch_user(int(user_id)); name = user.name
        except: name = f"ID: {user_id}"
        for i, vps in enumerate(vps_list):
            status_emoji = Theme.ONLINE if vps.get('status') == 'running' and not vps.get('suspended', False) else Theme.OFFLINE
            vps_info.append(f"`{vps['container_name']}` • {status_emoji} • **{name}**")
    
    if vps_info:
        vps_text = "\n".join(vps_info)
        for i in range(0, len(vps_text), 1024):
            chunk = vps_text[i:i+1024]
            embed = create_embed(f"📑 Ledger Block Fragment {i//1024 + 1}")
            add_field(embed, "Network Output", chunk, False)
            await interaction.followup.send(embed=embed)


@bot.tree.command(name="plans", description="Browse commercial hosting architectures")
@app_commands.choices(
    plan_type=[
        app_commands.Choice(name="Premium", value="premium"),
        app_commands.Choice(name="Free", value="free")
    ],
    action=[
        app_commands.Choice(name="list", value="list"),
        app_commands.Choice(name="add", value="add"),
        app_commands.Choice(name="edit", value="edit"),
        app_commands.Choice(name="remove", value="remove")
    ]
)
async def manage_plans(interaction: discord.Interaction, plan_type: str, action: str, plan_name: str = None, price: str = None, validity: str = None, ram: int = None, cpu: int = None, disk: int = None):
    if not ENABLE_PLANS:
        return await interaction.response.send_message(embed=create_error_embed("Module Disabled", "The marketplace sub-system is deactivated."), ephemeral=True)
    
    if plan_type == "premium" and not ABEI:
        return await interaction.response.send_message(embed=create_error_embed("Billing Offline", "Premium nodes are locked (ABEI False)."), ephemeral=True)

    if action == "list":
        embed = create_info_embed(f"💳 Corporate {plan_type.capitalize()} Hardware Catalog")
        desc = ""
        
        target_dict = PLANS.get(plan_type, {})
        if not target_dict:
            desc = f"No {plan_type} configurations found in matrix."
        else:
            for name, data in target_dict.items():
                emoji = data.get('emoji', '📦')
                p_price = f" - {data.get('price', '')}" if data.get('price') else ""
                desc += f"**{emoji} {name.title()} Block{p_price}**\n"
                desc += f"• **{data.get('ram')}GB** DDR4/DDR5 Sector\n"
                desc += f"• **{data.get('cpu')}** Quantum Cores\n"
                desc += f"• **{data.get('disk')}GB** Ultra-NVMe Storage\n"
                if data.get('validity'):
                    desc += f"• Matrix License: {data.get('validity')}\n"
                desc += "\n"
        
        embed.description = desc
        
        if plan_type == "premium":
            footer_text = (
                "**1.** Identify desired hardware block\n"
                "**2.** Secure payment via available channels\n"
                "**3.** Snapshot the confirmation hash\n"
                "**4.** Execute `/claim Premium <Plan> [attach snapshot]`\n"
                "**5.** Node boots upon Admin Authorization."
            )
            embed.add_field(name="📞 Routing Protocol", value=footer_text, inline=False)
            embed.set_image(url="https://imgur.com/6yfYDTP.png")
            
        await interaction.response.send_message(embed=embed)
        
    elif action in ["add", "edit"]:
        if not is_admin_check(interaction.user.id): return await interaction.response.send_message(embed=create_error_embed("Unauthorized", "Level 4 Clearance required."), ephemeral=True)
        if not plan_name or ram is None or cpu is None or disk is None:
            return await interaction.response.send_message(embed=create_error_embed("Syntax Error", "Incomplete matrix parameters."), ephemeral=True)
        
        if action == "edit" and plan_name.lower() not in PLANS.get(plan_type, {}):
            return await interaction.response.send_message(embed=create_error_embed("Null Reference", f"Block **{plan_name}** missing from cluster."), ephemeral=True)

        if plan_type not in PLANS: PLANS[plan_type] = {}
        
        PLANS[plan_type][plan_name.lower()] = {
            "ram": ram,
            "cpu": cpu,
            "disk": disk,
            "price": price or ("Free" if plan_type == 'free' else "TBD"),
            "validity": validity,
            "emoji": "🚀"
        }
        save_plans()
        embed = create_success_embed(f"Catalog Updated", f"Hardware **{plan_name}** mapped into {plan_type} array.")
        add_field(embed, "Parameters", f"`RAM: {ram}GB` | `CPU: {cpu}` | `Disk: {disk}GB`")
        await interaction.response.send_message(embed=embed, ephemeral=True)
        
    elif action == "remove":
        if not is_admin_check(interaction.user.id): return await interaction.response.send_message(embed=create_error_embed("Unauthorized", "Level 4 Clearance required."), ephemeral=True)
        if not plan_name: return await interaction.response.send_message(embed=create_error_embed("Syntax", "Hardware block name required."), ephemeral=True)
        if plan_name.lower() in PLANS.get(plan_type, {}):
            del PLANS[plan_type][plan_name.lower()]
            save_plans()
            await interaction.response.send_message(embed=create_success_embed("Block Trashed", f"**{plan_name}** permanently wiped from {plan_type} arrays."), ephemeral=True)
        else: await interaction.response.send_message(embed=create_error_embed("Null Reference", "Hardware block not found."), ephemeral=True)

# --- REBUILT /CLAIM SYSTEM ---
@bot.tree.command(name="claim", description="Acquire a Node configuration from the Catalog")
@app_commands.choices(plan_type=[
    app_commands.Choice(name="Premium Hardware", value="premium"),
    app_commands.Choice(name="Free Tier", value="free")
])
@app_commands.describe(plan_type="Tier Selection", plan_name="Name from /plans", proof="Payment Hash/Receipt Image (Premium)")
async def claim_vps_cmd(interaction: discord.Interaction, plan_type: str, plan_name: str, proof: discord.Attachment = None):
    await interaction.response.defer(ephemeral=True)

    if plan_type == "premium" and not CLAIM_PREMIUM:
        return await interaction.followup.send(embed=create_error_embed("Allocation Offline", "Premium network allocations are currently disabled globally."), ephemeral=True)

    if plan_type == "free" and not CLAIM_FREE:
        return await interaction.followup.send(embed=create_error_embed("Allocation Offline", "Free tier matrix allocations are currently disabled globally."), ephemeral=True)
    
    if plan_type == "premium" and not ABEI:
        return await interaction.followup.send(embed=create_error_embed("Billing Offline", "Premium network purchases are temporarily blocked by system Admins."), ephemeral=True)
    
    if not ENABLE_PLANS or plan_name.lower() not in PLANS.get(plan_type, {}):
        return await interaction.followup.send(embed=create_error_embed("Invalid Blueprint", "Requested plan does not exist in active catalogs. Consult `/plans list`."), ephemeral=True)
        
    p = PLANS[plan_type][plan_name.lower()]
    
    if plan_type == "premium":
        payment_ch_id = get_setting('payment_channel')
        if not payment_ch_id or payment_ch_id == '0':
            return await interaction.followup.send(embed=create_error_embed("Routing Failure", "No financial relay channel set up by Root Administration."))
            
        target_channel = interaction.guild.get_channel(int(payment_ch_id))
        if not target_channel:
            return await interaction.followup.send(embed=create_error_embed("Routing Failure", "Financial relay channel no longer exists."))
            
        embed = create_info_embed("💳 New Node Acquisition Logged")
        embed.add_field(name="Target Architect", value=interaction.user.mention, inline=True)
        embed.add_field(name="Hardware Block", value=f"`{plan_name}`", inline=True)
        if proof:
            if not proof.content_type or not proof.content_type.startswith('image/'):
                return await interaction.followup.send(embed=create_error_embed("Format Error", "Proof must be a visual image file."))
            embed.set_image(url=proof.url)
            
        try:
            await target_channel.send(content=f"<@{MAIN_ADMIN_ID}> Acquisition Request", embed=embed)
            await interaction.followup.send(embed=create_success_embed("Transmission Secure", "Your acquisition request has been beamed to our financial network. Your node will boot upon admin authorization."))
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Packet Loss", f"Transmission failed: {e}"))
            
    elif plan_type == "free":
        # Check Invites
        req_invites = 0
        match = re.search(r'invite\s+(\d+)', p.get('price', '').lower())
        if match:
            req_invites = int(match.group(1))
            
        if req_invites > 0:
            try:
                invites = await interaction.guild.invites()
                user_invites = sum(i.uses for i in invites if i.inviter == interaction.user)
                
                if user_invites < req_invites:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Clearance Denied", 
                        f"This sector requires **{req_invites} successful network invites**.\nYour current tally: **{user_invites}**."
                    ))
            except discord.errors.Forbidden:
                return await interaction.followup.send(embed=create_error_embed("API Fault", "Aegis system requires `Manage Server` permissions to authenticate your invite signatures."))

        view = OSSelectView(p['ram'], p['cpu'], p['disk'], interaction.user, interaction, plan_name)
        await interaction.edit_original_response(embed=create_info_embed("Sector Approved", f"Clearance granted. Select the core OS for **{plan_name}** below:"), view=view)


class OSSelectView(discord.ui.View):
    def __init__(self, ram: int, cpu: int, disk: int, user: discord.Member, ctx, plan_name: str = "Custom"):
        super().__init__(timeout=300)
        self.ram = ram
        self.cpu = cpu
        self.disk = disk
        self.user = user
        self.ctx = ctx
        self.plan_name = plan_name
        self.select = discord.ui.Select(
            placeholder="Map Base OS Architecture",
            options=[discord.SelectOption(label=o["label"], value=o["value"], description=o.get("desc", ""), emoji=o.get("emoji", "💿")) for o in OS_OPTIONS]
        )
        self.select.callback = self.select_os
        self.add_item(self.select)

    async def select_os(self, interaction: discord.Interaction):
        if str(interaction.user.id) != str(self.ctx.user.id): return await interaction.response.send_message(embed=create_error_embed("Identity Fault", "Only the initiating architect may finalize this block."), ephemeral=True)
        os_version = self.select.values[0]
        self.select.disabled = True
        
        await interaction.response.edit_message(embed=create_info_embed(f"{Theme.LOADING} Synchronizing Node", "Connecting to deep cluster..."), view=self)
        user_id = str(self.user.id)
        
        with data_lock:
            if user_id not in vps_data: vps_data[user_id] = []
            vps_count = 1
            
            safe_username = re.sub(r'[^a-z0-9]', '', self.user.name.lower())
            if not safe_username: safe_username = "user"
            
            existing_names = {v['container_name'] for lst in vps_data.values() for v in lst}
            while f"moonode-{safe_username}-{vps_count}" in existing_names: vps_count += 1
            container_name = f"moonode-{safe_username}-{vps_count}"
        
        try:
            steps = [f"Pulling architecture: {os_version}", f"Formatting network volume: {container_name}", f"Applying sector limits (RAM: {self.ram}GB, CPU: {self.cpu})", f"Mounting block drive ({ACTIVE_STORAGE_POOL})", "Injecting firewall routing arrays"]
            
            async def run_creation():
                await execute_lxc(f"lxc init {os_version} {container_name} -s {ACTIVE_STORAGE_POOL}", timeout=900) 
                await execute_lxc(f"lxc config set {container_name} limits.memory {self.ram}GB")
                await execute_lxc(f"lxc config set {container_name} limits.cpu {self.cpu}")
                try: await execute_lxc(f"lxc config device set {container_name} root size={self.disk}GB")
                except: await execute_lxc(f"lxc config device add {container_name} root disk pool={ACTIVE_STORAGE_POOL} path=/ size={self.disk}GB")
                
                try:
                    await execute_lxc(f"lxc config device set {container_name} root limits.read 50MB") 
                    await execute_lxc(f"lxc config device set {container_name} root limits.write 50MB")
                except: pass

                await apply_advanced_permissions(container_name)
                await execute_lxc(f"lxc start {container_name}")

            task_creation = asyncio.create_task(run_creation())
            msg = await interaction.original_response()
            start_time = time.time()
            step_idx = 0
            
            while not task_creation.done():
                elapsed = int(time.time() - start_time)
                current_step = steps[step_idx % len(steps)]
                embed_load = create_info_embed(f"{Theme.LOADING} Constructing Node", f"Operation Time: `{elapsed}s`")
                add_field(embed_load, "Terminal Data", f"```yaml\n>>> {current_step}...\n```", False)
                await msg.edit(embed=embed_load)
                step_idx += 1
                await asyncio.sleep(1.5)
            
            await task_creation 
            
            config_str = f"{self.ram}GB RAM / {self.cpu} CPU / {self.disk}GB Disk"
            vps_info = {
                "container_name": container_name, "ram": f"{self.ram}GB", "cpu": str(self.cpu),
                "storage": f"{self.disk}GB", "config": config_str, "os_version": os_version,
                "status": "running", "suspended": False, "whitelisted": False,
                "suspension_history": [], "created_at": datetime.now().isoformat(), "shared_with": [], "id": None
            }
            
            with data_lock:
                vps_data[user_id].append(vps_info)
                new_vps_list = vps_data[user_id]
                new_vps_index = len(new_vps_list) - 1
            save_vps_data()
            
            if self.ctx.guild:
                role = await get_or_create_vps_role(self.ctx.guild)
                if role: 
                    try: await self.user.add_roles(role)
                    except: pass
                    
            subdomain_url = "None"
            if ASM:
                clean_name = re.sub(r'[^a-zA-Z0-9-]', '', container_name).lower()
                result = await create_cloudflare_subdomain(clean_name)
                if result:
                    subdomain_url = result
                    logger.info(f"[ASM] Creating Subdomain: {subdomain_url}")
                else:
                    logger.error("[ASM] Subdomain routing drop.")
            
            embed = create_success_embed("Quantum Node Ignited", "Your premium cloud asset is online.")
            add_field(embed, "Network Architect", self.user.mention, True)
            add_field(embed, "Unique ID", f"`{container_name}`", True)
            add_field(embed, "Block Configuration", f"```yaml\nRAM: {self.ram}GB\nCPU: {self.cpu}\nDisk: {self.disk}GB\n```", False)
            add_field(embed, "🌐 Tunnel Protocol", f"http://{subdomain_url}" if subdomain_url != "None" else "Manual Network Tunnel Required", False)
            
            view = ManageView(user_id, new_vps_list, actual_index=new_vps_index)
            await interaction.edit_original_response(embed=embed, view=view)
            await send_log(embed)
            
            try: await self.user.send(embed=create_success_embed("Boot Process Verified", f"System ID `{container_name}` loaded with {os_version} is actively receiving packets."))
            except: pass
        except Exception as e:
            logger.error(f"Creation Exception: {e}")
            await interaction.edit_original_response(embed=create_error_embed("Fatal Node Crash", f"Log Output: `{str(e)[:4000]}`"), view=None)
            await send_log(create_error_embed("Crash Alert", f"Architect: {self.user.name}\nDump: {str(e)[:4000]}"))

@bot.tree.command(name="create", description="[ADMIN] Force inject a node for an identity")
@has_role('Owner', 'Admin', 'Dev')
@app_commands.choices(plan_type=[
    app_commands.Choice(name="Premium", value="premium"),
    app_commands.Choice(name="Free", value="free")
])
@app_commands.describe(user="Architect", plan_type="Node Tier", plans_name="Plan Label (optional)", ram="Custom RAM (GB)", cpu="Custom Cores", disk="Custom Disk (GB)")
async def create_vps(interaction: discord.Interaction, user: discord.Member, plan_type: str = None, plans_name: str = None, ram: int = None, cpu: int = None, disk: int = None):
    final_ram, final_cpu, final_disk, p_name = 0, 0, 0, "Root Override Block"
    
    if plans_name:
        if not plan_type:
            return await interaction.response.send_message(embed=create_error_embed("Logic Flaw", "Supply Node Tier type."), ephemeral=True)
        if not ENABLE_PLANS: return await interaction.response.send_message(embed=create_error_embed("Offline", "Plan catalogs are offline."), ephemeral=True)
        
        target_dict = PLANS.get(plan_type, {})
        if plans_name.lower() in target_dict:
            p = target_dict[plans_name.lower()]
            final_ram, final_cpu, final_disk, p_name = p.get('ram', 0), p.get('cpu', 0), p.get('disk', 0), plans_name
        else: return await interaction.response.send_message(embed=create_error_embed("Not Found", "Hardware tag invalid."), ephemeral=True)
    else:
        if ram and cpu and disk: final_ram, final_cpu, final_disk = ram, cpu, disk
        else: return await interaction.response.send_message(embed=create_error_embed("Syntax", "Inject explicit hardware integers or use a tag."), ephemeral=True)

    if final_ram <= 0 or final_cpu <= 0 or final_disk <= 0: return await interaction.response.send_message(embed=create_error_embed("Fault", "Metrics must be absolute positive."), ephemeral=True)
    if final_ram > MAX_RAM_LIMIT or final_cpu > MAX_CPU_LIMIT:
        return await interaction.response.send_message(embed=create_error_embed("Safety Limit", f"Overload prevented: **{MAX_RAM_LIMIT}GB RAM** | **{MAX_CPU_LIMIT} Cores**."), ephemeral=True)

    embed = create_info_embed("Root Block Override", f"**Target Matrix:** {user.mention}\n**Tag:** {p_name}\n**Sector Allocation:** `{final_ram}GB RAM`, `{final_cpu} Cores`, `{final_disk}GB Storage`")
    view = OSSelectView(final_ram, final_cpu, final_disk, user, interaction, p_name)
    await interaction.response.send_message(embed=embed, view=view)

# --- REBUILT GIVEAWAY SYSTEM ---

class GiveawayView(discord.ui.View):
    def __init__(self, g_id: str):
        super().__init__(timeout=None)
        self.g_id = g_id
        self.entrants = set()

    @discord.ui.button(label="🧬 Secure Entry Ticket", style=discord.ButtonStyle.success, emoji="🎟️")
    async def enter(self, interaction: discord.Interaction, button: discord.ui.Button):
        if self.g_id not in active_giveaways:
            return await interaction.response.send_message(embed=create_error_embed("Closed", "The protocol has ended."), ephemeral=True)
        if interaction.user.id in self.entrants:
            return await interaction.response.send_message(embed=create_warning_embed("Duplicate Ignored", "Your matrix key is already in the database."), ephemeral=True)
        
        self.entrants.add(interaction.user.id)
        await interaction.response.send_message(embed=create_success_embed("Access Verified", "You are injected into the distribution pool."), ephemeral=True)

async def giveaway_task(g_id: str, duration_sec: int, winners_count: int, ram: int, cpu: int, disk: int, message: discord.Message, view: GiveawayView):
    await asyncio.sleep(duration_sec)
    
    if g_id not in active_giveaways: return 
    
    del active_giveaways[g_id]
    
    if not view.entrants:
        end_embed = create_error_embed("Distribution Concluded", "Zero internal entries located. Hardware blocks rescinded.")
        try: await message.reply(embed=end_embed)
        except: pass
        return
        
    winner_pool = list(view.entrants)
    actual_winners = min(winners_count, len(winner_pool))
    drawn = random.sample(winner_pool, actual_winners)
    
    winner_tags = [f"<@{uid}>" for uid in drawn]
    
    congrats = create_success_embed("🎉 Quantum Distribution Complete", f"Identities verified: {', '.join(winner_tags)}!\n\nYour dedicated sectors are currently generating. SSH payloads will drop into Direct Messages.")
    try: await message.reply(content=f"{', '.join(winner_tags)}", embed=congrats)
    except: pass
    
    for uid in drawn:
        user = message.guild.get_member(uid)
        if user:
            asyncio.create_task(auto_deploy_vps(user, ram, cpu, disk))


@bot.tree.command(name="giveaway", description="[ADMIN] High-Level Node Distribution System")
@has_role('Owner', 'Admin')
@app_commands.choices(action=[
    app_commands.Choice(name="Create Protocol", value="create"),
    app_commands.Choice(name="Delete Protocol", value="delete"),
    app_commands.Choice(name="List Active Protocols", value="list")
])
@app_commands.describe(duration_minutes="Time (Mins)", ram="RAM(GB)", cpu="Cores", disk="Disk(GB)", winners="Count", description="Text", channel="Location", target_id="ID (For Deletion)")
async def giveaway_cmd(interaction: discord.Interaction, action: str, duration_minutes: int = None, ram: int = None, cpu: int = None, disk: int = None, winners: int = None, description: str = None, channel: discord.TextChannel = None, target_id: str = None):
    
    if action == "create":
        if not all([duration_minutes, ram, cpu, disk, winners]):
            return await interaction.response.send_message(embed=create_error_embed("Syntax", "Creation requires duration, ram, cpu, disk, and winners."), ephemeral=True)
            
        g_id = uuid.uuid4().hex[:6].upper()
        target_ch = channel or interaction.channel
        end_time = int(time.time() + (duration_minutes * 60))
        
        embed = create_embed(f"🎁 Aegis Architecture Giveaway `[{g_id}]`", description or "Network hardware distribution initialized.")
        add_field(embed, "Sector Allocation", f"```yaml\nRAM: {ram}GB\nCPU: {cpu} Cores\nDisk: {disk}GB\n```", False)
        add_field(embed, "Distribution Rules", f"**Targets Drawn:** {winners}\n**Locks In:** <t:{end_time}:R> (<t:{end_time}:F>)", False)
        
        view = GiveawayView(g_id)
        
        await interaction.response.send_message(embed=create_success_embed("Protocol Loaded", f"Deploying logic script `[{g_id}]` to {target_ch.mention}"), ephemeral=True)
        msg = await target_ch.send(embed=embed, view=view)
        
        task = asyncio.create_task(giveaway_task(g_id, duration_minutes * 60, winners, ram, cpu, disk, msg, view))
        
        active_giveaways[g_id] = {
            'task': task,
            'end': end_time,
            'msg': msg.jump_url,
            'desc': description or "Standard Distribution"
        }
        
    elif action == "delete":
        if not target_id or target_id not in active_giveaways:
            return await interaction.response.send_message(embed=create_error_embed("404", "Active ID not found in matrix."), ephemeral=True)
            
        active_giveaways[target_id]['task'].cancel()
        del active_giveaways[target_id]
        await interaction.response.send_message(embed=create_success_embed("Killed", f"Protocol `[{target_id}]` forcibly detached from operations."), ephemeral=True)
        
    elif action == "list":
        if not active_giveaways:
            return await interaction.response.send_message(embed=create_info_embed("Silent Network", "No distribution protocols are running."), ephemeral=True)
            
        embed = create_embed("⏳ Matrix Distribution Readout")
        for gid, data in active_giveaways.items():
            add_field(embed, f"ID: `{gid}`", f"Ends: <t:{data['end']}:R>\nLink: [View Sector]({data['msg']})", False)
            
        await interaction.response.send_message(embed=embed, ephemeral=True)

# --- Multi-Node Architecture Command (Feature 5) ---
@bot.tree.command(name="nodes", description="[ADMIN] Interface with Hypervisor Cluster Hub")
@has_role('Owner', 'Admin')
async def nodes_cmd(interaction: discord.Interaction):
    if not MULTI_NODE:
        return await interaction.response.send_message(embed=create_error_embed("Cluster Offline", "Advanced multi-node syncing disabled in configs."), ephemeral=True)
    
    embed = create_info_embed("🌐 Global Endpoint Cluster", "Routing directly to central network.\n\n*(Remote API listeners standing by...)*")
    await interaction.response.send_message(embed=embed)

# --- Integrated Support Ticket System (Feature 10) ---
@bot.tree.command(name="support", description="Pipe an emergency ticket to engineering")
async def support_cmd(interaction: discord.Interaction, issue: str):
    if not ISTS:
        return await interaction.response.send_message(embed=create_error_embed("Offline", "Internal ticketing matrix is decoupled."), ephemeral=True)
    
    await interaction.response.defer(ephemeral=True)
    
    if not isinstance(interaction.channel, discord.TextChannel):
        return await interaction.followup.send(embed=create_error_embed("Location Fault", "Execute within an open matrix channel."))
    
    try:
        thread = await interaction.channel.create_thread(name=f"ticket-{interaction.user.name}", type=discord.ChannelType.private_thread)
        await thread.add_user(interaction.user)
        
        vps_info_str = "No arrays detected."
        with data_lock:
            if str(interaction.user.id) in vps_data:
                vps_list = vps_data[str(interaction.user.id)]
                if vps_list:
                    vps_info_str = "\n".join([f"• `{v['container_name']}` (Firmware: {v.get('os_version', 'Unknown')}, Load: {v.get('config', 'Unknown')})" for v in vps_list])

        embed = create_info_embed(f"🎫 Priority Transmission: {interaction.user.name}", f"**Payload String:**\n{issue}\n\n**Tethered Hardware:**\n{vps_info_str}")
        await thread.send(f"<@{MAIN_ADMIN_ID}> Level 1 Alert from {interaction.user.mention}", embed=embed)
        
        await interaction.followup.send(embed=create_success_embed("Tunnel Linked", f"Secure thread opened: {thread.mention}"), ephemeral=True)
    except Exception as e:
        await interaction.followup.send(embed=create_error_embed("Fault", str(e)[:4000]), ephemeral=True)

@bot.tree.command(name="backup", description="Archive deep sector data")
@check_maintenance()
async def backup(interaction: discord.Interaction, action: str, vps_index: int):
    await interaction.response.defer()
    uid = str(interaction.user.id)
    with data_lock:
        if uid not in vps_data or vps_index < 1 or vps_index > len(vps_data[uid]):
            return await interaction.followup.send(embed=create_error_embed("Index Error", "Pointer detached from matrix."))
        vps = vps_data[uid][vps_index-1]
        name = vps['container_name']

    try:
        if action == "create":
            snap_name = f"backup-{int(time.time())}"
            await execute_lxc(f"lxc snapshot {name} {snap_name}")
            await interaction.followup.send(embed=create_success_embed("Snapshot Isolated", f"Deep freeze `{snap_name}` logged to main disk."))
        elif action == "list":
            out = await execute_lxc(f"lxc info {name}")
            snaps = [line for line in out.splitlines() if "backup-" in line]
            desc = "\n".join(snaps) if snaps else "No historical blocks found."
            await interaction.followup.send(embed=create_info_embed(f"Data Archive: {name}", f"```\n{desc}\n```"))
        elif action == "restore":
            await execute_lxc(f"lxc restore {name} $(lxc info {name} | grep backup- | tail -1 | awk '{{print $1}}')")
            await interaction.followup.send(embed=create_success_embed("Rollback Executed", "Asset state successfully restored from memory."))
        else: await interaction.followup.send(embed=create_error_embed("Syntax", "Valid operations: create, restore, list."))
    except Exception as e: await interaction.followup.send(embed=create_error_embed("IO Break", str(e)[:4000]))

@bot.tree.command(name="delete", description="[ADMIN] Permanently glass an asset")
@has_role('Owner', 'Admin', 'Mod', 'Dev')
@app_commands.describe(user="Target ID", vps_number="Index", reason="Audit String")
async def delete_vps(interaction: discord.Interaction, user: discord.Member, vps_number: int, reason: str = "TOS Enforcement"):
    user_id = str(user.id)
    with data_lock:
        if user_id not in vps_data or vps_number < 1 or vps_number > len(vps_data[user_id]):
            return await interaction.response.send_message(embed=create_error_embed("Pointer Error", "Array out of bounds."), ephemeral=True)
        vps = vps_data[user_id][vps_number - 1]
        container_name = vps["container_name"]
    
    view = ConfirmView(str(interaction.user.id))
    await interaction.response.send_message(embed=create_warning_embed("Critical Glassing Request", f"Authorize nuclear wipe of `{container_name}`?"), view=view)
    await view.wait()
    
    if not view.value: return await interaction.edit_original_response(embed=create_info_embed("Wipe Cancelled", "Safety systems re-engaged."), view=None)

    embed_del = create_info_embed("Glassing Matrix", f"Scrubbing `{container_name}`...")
    await interaction.edit_original_response(embed=embed_del, view=None)
    
    try:
        await execute_lxc(f"lxc delete {container_name} --force")
        with data_lock:
            if user_id in vps_data and len(vps_data[user_id]) >= vps_number:
                del vps_data[user_id][vps_number - 1]
                if not vps_data[user_id]:
                    del vps_data[user_id]
                    if interaction.guild:
                        role = await get_or_create_vps_role(interaction.guild)
                        if role: 
                            try: await user.remove_roles(role)
                            except: pass
        save_vps_data()
        
        embed = create_success_embed("Sector Glassed")
        add_field(embed, "Network Core", f"`{container_name}`", True)
        add_field(embed, "Justification", reason, False)
        await interaction.edit_original_response(embed=embed)
        await send_log(embed)
    except Exception as e: await interaction.edit_original_response(embed=create_error_embed("Wipe Failed", f"Core Fault: `{str(e)[:4000]}`"))

@bot.tree.command(name="manage", description="Access your primary control deck")
@check_maintenance()
@app_commands.describe(user="Architect (Admin Bypass)")
async def manage_vps(interaction: discord.Interaction, user: discord.Member = None):
    await interaction.response.defer()
    if user:
        if not is_admin_check(interaction.user.id):
            return await interaction.followup.send(embed=create_error_embed("Locked", "Insufficient clearance."), ephemeral=True)
        user_id = str(user.id)
        with data_lock: vps_list = vps_data.get(user_id, [])
        if not vps_list: return await interaction.followup.send(embed=create_error_embed("Empty Return", "Target lacks infrastructure."), ephemeral=True)
        view = ManageView(str(interaction.user.id), vps_list, is_admin=True, owner_id=user_id)
        await interaction.followup.send(embed=await view.get_initial_embed(), view=view)
    else:
        user_id = str(interaction.user.id)
        with data_lock: vps_list = vps_data.get(user_id, [])
        if not vps_list: return await interaction.followup.send(embed=create_error_embed("Empty Return", "You have zero dedicated blocks."), ephemeral=True)
        view = ManageView(user_id, vps_list)
        await interaction.followup.send(embed=await view.get_initial_embed(), view=view)

@bot.tree.command(name="manage-shared", description="Interface with linked network hardware")
@check_maintenance()
async def manage_shared_vps(interaction: discord.Interaction, owner: discord.Member, vps_number: int):
    await interaction.response.defer()
    owner_id = str(owner.id)
    with data_lock:
        if owner_id not in vps_data or vps_number < 1 or vps_number > len(vps_data[owner_id]):
            return await interaction.followup.send(embed=create_error_embed("Fault", "Target is ghosted."), ephemeral=True)
        vps = vps_data[owner_id][vps_number - 1]
    
    if str(interaction.user.id) not in vps.get("shared_with", []):
        return await interaction.followup.send(embed=create_error_embed("Firewall Blocked", "You do not hold decryption keys for this architecture."), ephemeral=True)
    view = ManageView(str(interaction.user.id), [vps], is_shared=True, owner_id=owner_id, actual_index=vps_number-1)
    await interaction.followup.send(embed=await view.get_initial_embed(), view=view)

@bot.tree.command(name="share-user", description="Embed keys for a subnet identity")
@check_maintenance()
async def share_user(interaction: discord.Interaction, shared_user: discord.Member, vps_number: int):
    await interaction.response.defer()
    user_id = str(interaction.user.id)
    with data_lock:
        if user_id not in vps_data or vps_number < 1: return await interaction.followup.send(embed=create_error_embed("Index Fault", "Hardware disconnected."), ephemeral=True)
        vps = vps_data[user_id][vps_number - 1]
        if "shared_with" not in vps: vps["shared_with"] = []
        if str(shared_user.id) not in vps["shared_with"]: vps["shared_with"].append(str(shared_user.id))
    save_vps_data()
    await interaction.followup.send(embed=create_success_embed("Access Matrix Woven", f"I/O keys distributed to {shared_user.mention}"))

@bot.tree.command(name="share-ruser", description="Revoke subnet identity keys")
@check_maintenance()
async def revoke_share(interaction: discord.Interaction, shared_user: discord.Member, vps_number: int):
    await interaction.response.defer()
    user_id = str(interaction.user.id)
    with data_lock:
        if user_id not in vps_data: return await interaction.followup.send(embed=create_error_embed("Index Fault", "Hardware disconnected."), ephemeral=True)
        vps = vps_data[user_id][vps_number - 1]
        if str(shared_user.id) in vps.get("shared_with", []): vps["shared_with"].remove(str(shared_user.id))
    save_vps_data()
    await interaction.followup.send(embed=create_success_embed("Network Sealed", f"Keys successfully stripped from {shared_user.mention}"))

@bot.tree.command(name="admin", description="Root Access Control Framework")
@app_commands.choices(action=[
    app_commands.Choice(name="Elevate", value="add"), 
    app_commands.Choice(name="Demote", value="remove"), 
    app_commands.Choice(name="Scan Registry", value="list"),
    app_commands.Choice(name="Review Logic", value="permissions")
])
@app_commands.choices(permission=[
    app_commands.Choice(name="Level 4 (Owner)", value="Owner"),
    app_commands.Choice(name="Level 3 (Admin)", value="Admin"),
    app_commands.Choice(name="Level 2 (Mod)", value="Mod"),
    app_commands.Choice(name="Level X (Dev)", value="Dev")
])
async def admin_action(interaction: discord.Interaction, action: str, user: discord.Member = None, permission: str = "Admin"):
    uid = str(interaction.user.id)
    role = admin_data.get(uid)
    is_owner = role == 'Owner' or uid == str(MAIN_ADMIN_ID)
    
    if action in ["add", "remove"] and not is_owner:
        return await interaction.response.send_message(embed=create_error_embed("Firewall Blocked", "Root keys required."), ephemeral=True)

    await interaction.response.defer()
    
    if action == "permissions":
        embed = create_info_embed("🛡️ Identity Access Nodes")
        embed.add_field(name="👑 Level 4 (Owner)", value="Absolute control over matrices and user roles.", inline=False)
        embed.add_field(name="⭐ Level 3 (Admin)", value="Hardware limits and system modifications.", inline=False)
        embed.add_field(name="🔨 Level 2 (Mod)", value="User infrastructure overrides (Pause/Wipe).", inline=False)
        embed.add_field(name="💻 Level X (Dev)", value="API bypass for core script testing.", inline=False)
        return await interaction.followup.send(embed=embed)
        
    elif action == "list":
        embed = create_embed("🛡️ Clearance Registry", "Currently verified administrative endpoints.")
        embed.add_field(name="👑 Prime Root", value=f"<@{MAIN_ADMIN_ID}>\n*Hardware Hardcode*", inline=False)
        
        main_admins = [f"<@{uid}>" for uid, r in admin_data.items() if r == 'Owner' and str(uid) != str(MAIN_ADMIN_ID)]
        if main_admins:
            embed.add_field(name="⭐ Level 4 Links", value="\n".join(main_admins) + "\n*Global Root*", inline=False)
            
        other_admins = {}
        for auid, arole in admin_data.items():
            if arole != 'Owner':
                if arole not in other_admins: other_admins[arole] = []
                other_admins[arole].append(f"<@{auid}>")
                
        for role_name, users in other_admins.items():
            embed.add_field(name=f"🛠️ {role_name} Division", value="\n".join(users) + "\n*Dynamic Sector*", inline=False)
            
        return await interaction.followup.send(embed=embed)

    if not user: return await interaction.followup.send(embed=create_error_embed("Logic Flaw", "Supply user identity."), ephemeral=True)
    
    target_id = str(user.id)
    if action == "add":
        admin_data[target_id] = permission
        save_admin_data()
        try:
            dm_embed = create_success_embed("Access Matrix Expanded", f"You hold `{permission}` keys mapped by {interaction.user.mention}")
            await user.send(embed=dm_embed)
        except: pass
        await interaction.followup.send(embed=create_success_embed("Permissions Elevated", f"{user.mention} shifted to **{permission}**."))
        
    elif action == "remove":
        if target_id in admin_data:
            del admin_data[target_id]
            save_admin_data()
            await interaction.followup.send(embed=create_success_embed("Keys Stripped", f"{user.mention} demoted to zero-trust tier."))
        else: await interaction.followup.send(embed=create_error_embed("Fault", "Identity not verified in Root registries."), ephemeral=True)

@bot.tree.command(name="system-admin", description="[ADMIN] Trigger Core Protocols")
@has_role('Owner', 'Admin')
@app_commands.choices(tool=[
    app_commands.Choice(name="Sync Database", value="sync"),
    app_commands.Choice(name="Clear Memory Orphans", value="orphans")
])
async def admin_tools(interaction: discord.Interaction, tool: str):
    await interaction.response.defer()
    if tool == "sync":
        removed = 0
        with data_lock:
            for uid in list(vps_data.keys()):
                new_list = []
                for vps in vps_data[uid]:
                    try:
                        await execute_lxc(f"lxc info {vps['container_name']}")
                        new_list.append(vps)
                    except: removed += 1
                vps_data[uid] = new_list
            save_vps_data()
        await interaction.followup.send(embed=create_success_embed("Deep Clean Executed", f"Purged {removed} dead links from ledger."))

@bot.tree.command(name="vps", description="[ADMIN] Intercept active hardware")
@has_role('Owner', 'Admin', 'Dev')
@app_commands.choices(action=[
    app_commands.Choice(name="Lock Sector", value="suspend"),
    app_commands.Choice(name="Unlock Sector", value="unsuspend"),
    app_commands.Choice(name="Read Traces", value="logs")
])
@app_commands.describe(action="Execution type", container_name="Target Core ID", reason="Log string")
async def vps_action(interaction: discord.Interaction, action: str, container_name: str = None, reason: str = "Security Fault"):
    await interaction.response.defer()
    
    if action in ['suspend', 'unsuspend'] and not container_name:
        return await interaction.followup.send(embed=create_error_embed("Logic", "Missing `container_name` vector."), ephemeral=True)
        
    if action == "suspend":
        target_vps = None
        with data_lock:
            for uid, lst in vps_data.items():
                for vps in lst:
                    if vps['container_name'] == container_name: target_vps = vps; break
                if target_vps: break

        if target_vps:
            try:
                await execute_lxc(f"lxc stop {container_name}")
                with data_lock:
                    target_vps['status'] = 'stopped'
                    target_vps['suspended'] = True
                    target_vps['suspension_history'].append({'time': datetime.now().isoformat(), 'reason': reason, 'by': interaction.user.name})
                save_vps_data()
                embed = create_warning_embed("Sector Locked", f"Power forcibly stripped from `{container_name}`.")
                add_field(embed, "Audit Log", reason)
                await interaction.followup.send(embed=embed)
                await send_log(embed)
            except Exception as e: await interaction.followup.send(embed=create_error_embed("Lock Failed", str(e)[:4000]), ephemeral=True)
        else: await interaction.followup.send(embed=create_error_embed("Null Ref", "Core not mapped."), ephemeral=True)
        
    elif action == "unsuspend":
        target_vps = None
        with data_lock:
            for uid, lst in vps_data.items():
                for vps in lst:
                    if vps['container_name'] == container_name: target_vps = vps; break
                if target_vps: break

        if target_vps:
            try:
                await execute_lxc(f"lxc start {container_name}")
                with data_lock:
                    target_vps['suspended'] = False
                    target_vps['status'] = 'running'
                save_vps_data()
                embed = create_success_embed("Energy Restored", f"Lockout lifted for `{container_name}`.")
                await interaction.followup.send(embed=embed)
                await send_log(embed)
            except Exception as e: await interaction.followup.send(embed=create_error_embed("Boot Issue", str(e)[:4000]), ephemeral=True)
        else: await interaction.followup.send(embed=create_error_embed("Null Ref", "Core not mapped."), ephemeral=True)
        
    elif action == "logs":
        if container_name:
            found_logs = None
            with data_lock:
                for lst in vps_data.values():
                    for vps in lst:
                        if vps['container_name'] == container_name: found_logs = vps.get('suspension_history', []); break
                    if found_logs is not None: break
            
            if found_logs is not None:
                logs_text = "\n".join([f"• **{h['time']}**: {h['reason']} (Auth: {h['by']})" for h in found_logs])
                await interaction.followup.send(embed=create_info_embed(f"📜 Network Audit: {container_name}", logs_text or "Ledger is spotless."))
            else: await interaction.followup.send(embed=create_error_embed("Null Ref", "Core not mapped."), ephemeral=True)
        else: 
            await interaction.followup.send(embed=create_info_embed("Vector Error", "Awaiting target core parameter."))

@bot.tree.command(name="whitelist-vps", description="[ADMIN] Toggle priority QOS filtering")
@has_role('Owner', 'Admin')
@app_commands.choices(action=[app_commands.Choice(name="Inject", value="add"), app_commands.Choice(name="Evict", value="remove")])
async def whitelist_vps(interaction: discord.Interaction, container_name: str, action: str):
    await interaction.response.defer()
    found = False
    with data_lock:
        for lst in vps_data.values():
            for vps in lst:
                if vps['container_name'] == container_name:
                    vps['whitelisted'] = (action == 'add')
                    found = True; break
            if found: break
    
    if found:
        save_vps_data()
        await interaction.followup.send(embed=create_success_embed("QOS Bypassed", f"Filter rules for `{container_name}` changed to: **{action.upper()}**"))
    else: await interaction.followup.send(embed=create_error_embed("Null Ref", "Core not mapped."), ephemeral=True)

@bot.tree.command(name="apply-permissions", description="[ADMIN] Inject deep-nesting virtualization layers")
@has_role('Owner', 'Admin')
async def apply_permissions(interaction: discord.Interaction, container_name: str):
    await interaction.response.defer()
    await apply_advanced_permissions(container_name)
    await execute_lxc(f"lxc restart {container_name}")
    await interaction.followup.send(embed=create_success_embed("Vectors Pushed", f"Docker-layer profiles forced onto `{container_name}`."))

@bot.tree.command(name="help", description="Access the Aegis Network Manual")
async def show_help(interaction: discord.Interaction):
    await interaction.response.defer()
    user_desc = (
        "> 🖥️ `/list` - Ping active nodes\n"
        "> 🎛️ `/manage` - Control infrastructure\n"
        "> 💾 `/backup` - Encrypt storage volumes\n"
        "> 🤝 `/share-user` - Map access keys\n"
        "> 💳 `/plans` - Query corporate hardware\n"
        "> 🎫 `/support` - Open admin uplink\n"
        "> 🚀 `/claim` - Lock-in your allocations\n"
        "> 🌐 `/status` - Hypervisor health readout"
    )
    embed = create_embed("📚 Enterprise Aegis Matrix", "Command line interfaces approved for your identity.")
    add_field(embed, "Network Terminals", user_desc, False)
    
    if is_admin_check(interaction.user.id):
        admin_desc = (
            "> 🛡️ `/admin` - Re-write identity bounds\n"
            "> ⚙️ `/set` - Alter global operations\n"
            "> 🔨 `/create` - Root deploy\n"
            "> 🗑️ `/delete` - Permanently glass nodes\n"
            "> 🎉 `/giveaway` - Mass distribution\n"
            "> 📡 `/nodes` - Cross-cluster matrix\n"
            "> 🔒 `/maintenance` - Sever API bridges\n"
            "> ⚙️ `/system-admin` - Deep kernel flush\n"
            "> 📂 `/list-all` - Dump registry vectors\n"
            "> ⚖️ `/vps` - Freeze system cycles"
        )
        add_field(embed, "Root Level Functions", admin_desc, False)
    await interaction.followup.send(embed=embed)

if __name__ == "__main__":
    if DISCORD_TOKEN: 
        try: bot.run(DISCORD_TOKEN)
        except KeyboardInterrupt: logger.info("Process halted by Root.")
    else: logger.error("No token detected in hypervisor config.")