import sqlite3
import json
import threading
from typing import Dict, List, Any
import os
from dotenv import load_dotenv

load_dotenv()
MAIN_ADMIN_ID = int(os.getenv('BOT_OWNER_ID', '0'))

data_lock = threading.Lock()

def get_db():
    conn = sqlite3.connect("vps.db", timeout=30, check_same_thread=False)
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cur = conn.cursor()
    cur.execute('''CREATE TABLE IF NOT EXISTS admins (user_id TEXT PRIMARY KEY, role TEXT DEFAULT 'Admin')''')
    cur.execute('PRAGMA table_info(admins)')
    if 'role' not in [col[1] for col in cur.fetchall()]:
        cur.execute("ALTER TABLE admins ADD COLUMN role TEXT DEFAULT 'Admin'")
    cur.execute('INSERT OR IGNORE INTO admins (user_id, role) VALUES (?, ?)', (str(MAIN_ADMIN_ID), 'Owner'))

    cur.execute('''CREATE TABLE IF NOT EXISTS vps (
        id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL, container_name TEXT UNIQUE NOT NULL,
        ram TEXT NOT NULL, cpu TEXT NOT NULL, storage TEXT NOT NULL, config TEXT NOT NULL,
        os_version TEXT DEFAULT 'ubuntu:22.04', status TEXT DEFAULT 'stopped', suspended INTEGER DEFAULT 0,
        whitelisted INTEGER DEFAULT 0, created_at TEXT NOT NULL, shared_with TEXT DEFAULT '[]', suspension_history TEXT DEFAULT '[]'
    )''')
    cur.execute('PRAGMA table_info(vps)')
    if 'os_version' not in [col[1] for col in cur.fetchall()]:
        cur.execute("ALTER TABLE vps ADD COLUMN os_version TEXT DEFAULT 'ubuntu:22.04'")

    cur.execute('''CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)''')
    for k, v in [('cpu_threshold', '90'), ('ram_threshold', '90'), ('log_channel', '0'), ('payment_channel', '0'), ('maintenance_mode', 'false')]:
        cur.execute('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)', (k, v))
    conn.commit()
    conn.close()

def get_setting(key: str, default: Any = None):
    conn = get_db()
    cur = conn.cursor()
    cur.execute('SELECT value FROM settings WHERE key = ?', (key,))
    row = cur.fetchone()
    conn.close()
    return row[0] if row else default

def set_setting(key: str, value: str):
    conn = get_db()
    cur = conn.cursor()
    cur.execute('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', (key, value))
    conn.commit()
    conn.close()

def get_vps_data() -> Dict[str, List[Dict[str, Any]]]:
    conn = get_db()
    cur = conn.cursor()
    cur.execute('SELECT * FROM vps')
    data = {}
    for row in cur.fetchall():
        uid = row['user_id']
        if uid not in data: data[uid] = []
        v = dict(row)
        v['shared_with'], v['suspension_history'] = json.loads(v['shared_with']), json.loads(v['suspension_history'])
        v['suspended'], v['whitelisted'] = bool(v['suspended']), bool(v['whitelisted'])
        data[uid].append(v)
    conn.close()
    return data

def get_admins() -> Dict[str, str]:
    conn = get_db()
    cur = conn.cursor()
    cur.execute('SELECT user_id, role FROM admins')
    res = {row['user_id']: row['role'] for row in cur.fetchall()}
    conn.close()
    return res

def save_vps_data():
    with data_lock:
        conn = get_db()
        cur = conn.cursor()
        for uid, vps_list in vps_data.items():
            for vps in vps_list:
                sj, hj = json.dumps(vps.get('shared_with', [])), json.dumps(vps.get('suspension_history', []))
                susp, wht = 1 if vps.get('suspended', False) else 0, 1 if vps.get('whitelisted', False) else 0
                if 'id' not in vps or vps['id'] is None:
                    cur.execute('''INSERT INTO vps (user_id, container_name, ram, cpu, storage, config, os_version, status, suspended, whitelisted, created_at, shared_with, suspension_history) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''', (uid, vps['container_name'], vps['ram'], vps['cpu'], vps['storage'], vps['config'], vps.get('os_version', 'ubuntu:22.04'), vps.get('status', 'stopped'), susp, wht, vps['created_at'], sj, hj))
                    vps['id'] = cur.lastrowid
                else:
                    cur.execute('''UPDATE vps SET user_id=?, ram=?, cpu=?, storage=?, config=?, os_version=?, status=?, suspended=?, whitelisted=?, shared_with=?, suspension_history=? WHERE id=?''', (uid, vps['ram'], vps['cpu'], vps['storage'], vps['config'], vps.get('os_version', 'ubuntu:22.04'), vps.get('status', 'stopped'), susp, wht, sj, hj, vps['id']))
        conn.commit()
        conn.close()

def save_admin_data():
    conn = get_db()
    cur = conn.cursor()
    cur.execute('DELETE FROM admins')
    for uid, role in admin_data.items(): cur.execute('INSERT INTO admins (user_id, role) VALUES (?, ?)', (uid, role))
    conn.commit()
    conn.close()

init_db()
vps_data = get_vps_data()
admin_data = get_admins()