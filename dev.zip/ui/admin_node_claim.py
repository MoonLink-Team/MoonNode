"""
ui/admin_node_claim.py — Admin Node Picker for free /claim deployments.

Flow:
  1. User claims free VPS (coin/invite)
  2. Bot posts to claim_channel with an admin node-select dropdown
  3. Admin picks node → OS select DM is sent to user
  4. User picks OS → VPS deployed → user gets DM
"""
import discord
from datetime import datetime

from core.lxc import list_lxd_remotes, get_node_stats, deploy_container
from core.database import get_setting
from core.theme import Theme, add_field, create_info_embed, create_success_embed, create_error_embed


class AdminClaimOSSelectView(discord.ui.View):
    """Sent via DM to the user after admin picks a node."""
    def __init__(self, user_id: int, ram: int, cpu: int, disk: int,
                 target_node: str, storage_pool: str, plan_name: str,
                 validity_days, claim_msg: discord.Message = None):
        super().__init__(timeout=600)
        self.user_id      = user_id
        self.ram          = ram
        self.cpu          = cpu
        self.disk         = disk
        self.target_node  = target_node
        self.storage_pool = storage_pool
        self.plan_name    = plan_name
        self.validity_days = validity_days
        self.claim_msg    = claim_msg

        from core.config import OS_OPTIONS
        select = discord.ui.Select(
            placeholder="▼  Choose your Operating System",
            options=[
                discord.SelectOption(
                    label=o["label"], value=o["value"],
                    description=o.get("desc",""), emoji=o.get("emoji","💿")
                ) for o in OS_OPTIONS
            ]
        )
        select.callback = self._on_select
        self.add_item(select)

    async def _on_select(self, interaction: discord.Interaction):
        if interaction.user.id != self.user_id:
            return await interaction.response.send_message("This is not your OS selector.", ephemeral=True)

        os_version = interaction.data["values"][0]
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(
            embed=discord.Embed(
                title="⏳ Setting Up Your VPS…",
                description=(
                    "Your VPS is being deployed right now!\n\n"
                    "This usually takes **30–60 seconds**. Please wait…"
                ),
                color=0x5865F2, timestamp=datetime.now(),
            ),
            view=self,
        )
        try:
            user = await interaction.client.fetch_user(self.user_id)
            entry = await deploy_container(
                user_id      = str(self.user_id),
                username     = user.name,
                ram          = self.ram,
                cpu          = self.cpu,
                disk         = self.disk,
                os_version   = os_version,
                validity_days= self.validity_days,
                target_node  = self.target_node,
                storage_pool = self.storage_pool,
            )
            name = entry["container_name"]
            ready_embed = discord.Embed(
                title="🎉 Your Free VPS is Ready!",
                description=(
                    f"Your VPS has been **deployed and is now online**!\n\n"
                    f"**Container:** `{name}`\n"
                    f"**Plan:** `{self.plan_name.title()}`\n"
                    f"**Specs:** `{self.ram}GB RAM · {self.cpu} CPU · {self.disk}GB Disk`\n"
                    f"**OS:** `{os_version}`\n"
                    f"**Node:** `{self.target_node or 'local'}`\n\n"
                    "Use `/manage` in the server to start, stop, or get SSH access."
                ),
                color=0x57F287, timestamp=datetime.now(),
            )
            ready_embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
            ready_embed.set_footer(text="MoonNodes · Enjoy your free VPS!")
            await interaction.edit_original_message(embed=ready_embed, view=None)

            # Update claim channel message
            if self.claim_msg:
                try:
                    done = discord.Embed(
                        title="✅ Claim Deployed",
                        description=(
                            f"**Container:** `{name}`\n"
                            f"**Node:** `{self.target_node or 'local'}`\n"
                            f"**OS:** `{os_version}`"
                        ),
                        color=0x57F287, timestamp=datetime.now(),
                    )
                    done.set_footer(text="MoonNodes · VPS deployed successfully")
                    await self.claim_msg.edit(embed=done, view=None)
                except Exception: pass

        except Exception as e:
            await interaction.edit_original_message(
                embed=create_error_embed("Deployment Failed", str(e)[:2000]), view=None)


class AdminNodeClaimView(discord.ui.View):
    """
    Posted in claim_channel. Admin picks a node → user gets OS select DM.
    Local node is shown as 'Admin Only' and is always available.
    """
    def __init__(self, user_id: int, user_name: str, ram: int, cpu: int,
                 disk: int, storage_pool: str, plan_name: str, validity_days,
                 paid_str: str = ""):
        super().__init__(timeout=None)  # persistent until admin acts
        self.user_id      = user_id
        self.user_name    = user_name
        self.ram          = ram
        self.cpu          = cpu
        self.disk         = disk
        self.storage_pool = storage_pool
        self.plan_name    = plan_name
        self.validity_days = validity_days
        self.paid_str     = paid_str

    @classmethod
    async def build(cls, user_id, user_name, ram, cpu, disk, storage_pool,
                    plan_name, validity_days, paid_str=""):
        self = cls(user_id, user_name, ram, cpu, disk, storage_pool,
                   plan_name, validity_days, paid_str)

        # Build node options
        from core.database import get_setting as _gs
        raw    = _gs("registered_nodes") or ""
        extras = [n.strip() for n in raw.split(",") if n.strip()]
        nodes  = ["local"] + extras

        options = []
        for node in nodes:
            try:
                s    = await get_node_stats(node)
                r_u  = s["used_ram_mb"]; r_t = s["total_ram_mb"]
                r_p  = s["ram_pct"];     c_p = s["cpu_pct"]
                v_r  = s["vps_running"]; v_c = s["vps_count"]

                label = "🔒 Local — Admin Only" if node == "local" else f"🌐 {node}"

                ping_str = ""
                if node != "local":
                    try:
                        import subprocess as _sp, re as _re
                        pr = _sp.run(["ping","-c","1","-W","2", node.split(":")[0]],
                            capture_output=True, text=True, timeout=4)
                        m = _re.search(r"time=([\d.]+)", pr.stdout)
                        if m: ping_str = f" · 📶 {float(m.group(1)):.0f}ms"
                    except Exception: pass

                desc = f"RAM {r_u}MB/{r_t}MB ({r_p}%) · VPS {v_r}/{v_c}{ping_str}" if r_t > 0 \
                       else f"VPS {v_r}/{v_c} running{ping_str}"

                options.append(discord.SelectOption(
                    label=label[:100], value=node,
                    description=desc[:100], emoji="🖥️"
                ))
            except Exception:
                options.append(discord.SelectOption(
                    label="🔒 Local — Admin Only" if node == "local" else f"🌐 {node}",
                    value=node, description="Stats unavailable", emoji="🖥️"
                ))

        if not options:
            options = [discord.SelectOption(label="🔒 Local — Admin Only", value="local", emoji="🏠")]

        sel = discord.ui.Select(
            placeholder="▼ Select deployment node for this claim",
            options=options, min_values=1, max_values=1
        )
        sel.callback = self._on_node_select
        self.add_item(sel)

        # Cancel button
        cancel_btn = discord.ui.Button(label="❌ Cancel Claim", style=discord.ButtonStyle.danger)
        cancel_btn.callback = self._on_cancel
        self.add_item(cancel_btn)

        return self

    async def _on_node_select(self, interaction: discord.Interaction):
        from core.config import MAIN_ADMIN_ID
        from core.database import admin_data
        uid  = str(interaction.user.id)
        role = admin_data.get(uid, "")
        is_admin = int(uid) == int(MAIN_ADMIN_ID) or role in (
            "Owner","Hard Admin","Admin","Manager","Hard Mod","Mod","Hard Staff","Staff")
        if not is_admin:
            return await interaction.response.send_message(
                "Only staff can pick nodes for claims.", ephemeral=True)

        chosen = interaction.data["values"][0]
        node_label = "Local" if chosen == "local" else chosen

        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(
            embed=discord.Embed(
                title="✅ Node Selected — Sending OS select to user…",
                description=(
                    f"**Node:** `{node_label}`\n"
                    f"**Assigned by:** {interaction.user.mention}\n\n"
                    "Sending OS selection to the user via DM…"
                ),
                color=0x57F287, timestamp=datetime.now(),
            ),
            view=self,
        )

        # DM user with OS select
        try:
            user = await interaction.client.fetch_user(self.user_id)
            os_view = AdminClaimOSSelectView(
                user_id      = self.user_id,
                ram          = self.ram,
                cpu          = self.cpu,
                disk         = self.disk,
                target_node  = chosen,
                storage_pool = self.storage_pool,
                plan_name    = self.plan_name,
                validity_days= self.validity_days,
                claim_msg    = interaction.message,
            )
            dm_embed = discord.Embed(
                title="🌙 Your Free VPS Node Has Been Assigned!",
                description=(
                    f"**Great news!** A staff member has reviewed your **{self.plan_name.title()}** "
                    f"VPS claim and assigned you a node.\n\n"
                    f"**Plan:** `{self.plan_name.title()}`\n"
                    f"**Specs:** `{self.ram}GB RAM · {self.cpu} CPU · {self.disk}GB Disk`\n"
                    f"**Node:** `{node_label}`\n\n"
                    "**Choose your operating system below to complete your claim:**"
                ),
                color=0xFFD700, timestamp=datetime.now(),
            )
            dm_embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
            dm_embed.set_footer(text="You have 10 minutes to pick your OS · MoonNodes")
            await user.send(embed=dm_embed, view=os_view)
            await interaction.followup.send(
                embed=create_info_embed("OS Select Sent", f"DM sent to <@{self.user_id}>. Waiting for OS choice."),
                ephemeral=True)
        except discord.Forbidden:
            await interaction.followup.send(
                embed=create_error_embed("DM Failed",
                    f"<@{self.user_id}> has DMs closed. Ask them to open DMs and retry."),
                ephemeral=True)
        except Exception as e:
            await interaction.followup.send(
                embed=create_error_embed("Error", str(e)[:1000]), ephemeral=True)

    async def _on_cancel(self, interaction: discord.Interaction):
        from core.config import MAIN_ADMIN_ID
        from core.database import admin_data
        uid  = str(interaction.user.id)
        role = admin_data.get(uid, "")
        is_admin = int(uid) == int(MAIN_ADMIN_ID) or role in (
            "Owner","Hard Admin","Admin","Manager","Hard Mod","Mod","Hard Staff","Staff")
        if not is_admin:
            return await interaction.response.send_message("Staff only.", ephemeral=True)
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(
            embed=discord.Embed(
                title="❌ Claim Cancelled",
                description=f"Cancelled by {interaction.user.mention}.",
                color=0xED4245, timestamp=datetime.now(),
            ),
            view=self,
        )
        try:
            user = await interaction.client.fetch_user(self.user_id)
            dm = discord.Embed(
                title="❌ Your VPS Claim Was Cancelled",
                description=(
                    "Your free VPS claim has been **cancelled** by a staff member.\n\n"
                    "If you believe this is a mistake, please open a ticket with `/support`."
                ),
                color=0xED4245, timestamp=datetime.now(),
            )
            dm.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
            await user.send(embed=dm)
        except Exception: pass
