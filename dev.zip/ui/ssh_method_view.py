import discord
import asyncio
import subprocess
import re

from core.theme import (
    create_embed, create_success_embed, create_error_embed,
    create_info_embed, Theme,
)
from core.lxc import execute_lxc, RUNTIME_BIN
from core import incus as _incus


_ANSI_RE = re.compile(r"\x1b\[[0-9;]*[mGKHF]")

def _strip_ansi(text: str) -> str:
    """Remove ANSI escape codes from a string."""
    return _ANSI_RE.sub("", text)


def _loading_embed(title: str, detail: str, step: int = 1, total: int = 4):
    bar   = "".join(["#" if j < step else "-" for j in range(total)])
    embed = discord.Embed(
        title="Loading: " + title,
        description=detail + f"\n\n`[{bar}]` Step {step}/{total}",
        color=0x5865F2,
    )
    embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
    embed.set_footer(text="Please wait…")
    return embed


class SSHMethodView(discord.ui.View):
    def __init__(self, user_id: str, vps: dict, parent_view, parent_embed_coro):
        super().__init__(timeout=120)
        self.user_id           = user_id
        self.vps               = vps
        self.parent_view       = parent_view
        self.parent_embed_coro = parent_embed_coro

    @staticmethod
    def picker_embed():
        embed = create_embed(
            "🔑 SSH Access — Choose Method",
            (
                "Select how you want to connect to your VPS:\n\n"
                "**🖥️ Tmate**\n"
                "> Starts a real tmate session inside your VPS.\n"
                "> Gives you a one-time `ssh` command — no port forwarding needed.\n\n"
                "**🔒 Tailscale**\n"
                "> Connects your VPS to your private Tailscale network.\n"
                "> Shows the auth link right here in Discord so you can approve it instantly.\n\n"
                "Use **← Back** to return to the VPS control panel."
            ),
            color=0x5865F2,
        )
        embed.set_footer(text="MoonNodes VPS Manager • SSH Setup")
        return embed

    async def _guard(self, interaction: discord.Interaction) -> bool:
        if str(interaction.user.id) != self.user_id:
            await interaction.response.send_message("Permission denied.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="← Back", style=discord.ButtonStyle.secondary, emoji="↩️", row=1)
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self._guard(interaction):
            return
        await interaction.response.defer()
        embed = await self.parent_embed_coro()
        await interaction.edit_original_response(embed=embed, view=self.parent_view)

    @discord.ui.button(label="Tmate (Quick SSH)", style=discord.ButtonStyle.primary, emoji="🖥️", row=0)
    async def tmate_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self._guard(interaction):
            return
        await interaction.response.defer()
        await self._run_tmate(interaction)

    @discord.ui.button(label="Tailscale (Private VPN)", style=discord.ButtonStyle.success, emoji="🔒", row=0)
    async def tailscale_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self._guard(interaction):
            return
        await interaction.response.defer()
        await self._run_tailscale(interaction)

    # ─────────────────────────────────────────────────────────────────────────
    # Tmate — real tmate session; SSH link posted directly to Discord
    # ─────────────────────────────────────────────────────────────────────────

    async def _run_tmate(self, interaction: discord.Interaction):
        vps    = self.vps
        name   = vps["container_name"]
        node   = vps.get("node", "local")
        prefix = f"{node}:" if node != "local" else ""
        full   = f"{prefix}{name}"

        await interaction.edit_original_response(
            embed=_loading_embed("Tmate SSH", "Checking network…", step=1, total=4),
            view=None,
        )

        try:
            if not await self._check_network(interaction, full, name):
                return

            # Install tmate (3-strategy fallback in core/incus.py)
            await interaction.edit_original_response(
                embed=_loading_embed(
                    "Tmate SSH",
                    "Installing tmate…\n*(apt → universe repo → static binary)*",
                    step=2, total=4,
                ),
                view=None,
            )
            try:
                await _incus.install_tmate(full)
            except Exception as _ie:
                return await self._show_error(interaction, "tmate Install Failed", str(_ie)[:800])

            # Start tmate session
            await interaction.edit_original_response(
                embed=_loading_embed("Tmate SSH", "Starting tmate session…", step=3, total=4),
                view=None,
            )

            SOCK = "/tmp/tmate-moonnodes.sock"
            LOG  = "/tmp/tmate-moonnodes.log"

            # Kill any stale session and wipe old log
            subprocess.run(
                [RUNTIME_BIN, "exec", full, "--", "bash", "-c",
                 f"tmate -S {SOCK} kill-server 2>/dev/null; rm -f {SOCK} {LOG}"],
                capture_output=True, text=True, timeout=10,
            )

            # Start tmate in foreground (-F) so it prints the SSH/web URLs to stdout
            # Redirect to log file; process runs in background via shell &
            # Use setsid so it survives the incus exec session ending
            subprocess.run(
                [RUNTIME_BIN, "exec", full, "--", "bash", "-c",
                 f"setsid tmate -S {SOCK} -F > {LOG} 2>&1 < /dev/null &"],
                capture_output=True, text=True, timeout=10,
            )

            # Wait for tmate.io connection and URL output
            await interaction.edit_original_response(
                embed=_loading_embed("Tmate SSH", "Waiting for tmate.io to assign session…", step=4, total=4),
                view=None,
            )

            ssh_line = ""
            web_url  = ""
            # tmate outputs: "ssh SESSION@lon1.tmate.io" (no -p flag)
            # We match the writable session (not "read only" prefixed lines)
            _SSH_RE  = re.compile(r"(?<!read only: )ssh\s+([A-Za-z0-9_-]+@\S+tmate\.io(?:\s+-p\s+\d+)?)")
            _WEB_RE  = re.compile(r"https?://tmate\.io/t/(?!ro-)(\S+)")

            # Poll log file up to 60 s
            for _ in range(12):
                await asyncio.sleep(5)
                r = subprocess.run(
                    [RUNTIME_BIN, "exec", full, "--", "cat", LOG],
                    capture_output=True, text=True, timeout=10,
                )
                log_text = r.stdout + r.stderr

                if not ssh_line:
                    m = _SSH_RE.search(log_text)
                    if m:
                        ssh_line = ("ssh " + m.group(1)).strip()

                if not web_url:
                    m2 = _WEB_RE.search(log_text)
                    if m2:
                        web_url = ("https://tmate.io/t/" + m2.group(1)).strip()

                if ssh_line:
                    break

            back_view = _BackOnlyView(self.user_id, self.parent_view, self.parent_embed_coro)

            if not ssh_line:
                # Show raw log so we can debug
                r_log = subprocess.run(
                    [RUNTIME_BIN, "exec", full, "--", "cat", LOG],
                    capture_output=True, text=True, timeout=10,
                )
                raw_out = (r_log.stdout + r_log.stderr).strip() or "(no output — tmate may have failed to start)"
                embed = create_error_embed(
                    "tmate — Could Not Get SSH Link",
                    f"tmate started but no SSH URL appeared within 60 s.\n\n"
                    f"**tmate log:**\n```\n{raw_out[:800]}\n```\n\n"
                    f"Try running manually inside the VPS:\n```\ntmate -F\n```",
                )
                return await interaction.edit_original_response(embed=embed, view=back_view)

            embed = create_success_embed("🖥️ Tmate SSH Ready")
            embed.add_field(
                name="SSH Command",
                value=f"```\n{ssh_line}\n```",
                inline=False,
            )
            if web_url and web_url.startswith("http"):
                embed.add_field(
                    name="🌐 Web Browser Access",
                    value=(
                        f"`{web_url}`\n"
                        "👆 Copy the URL above, or click **Open Web Terminal** button below."
                    ),
                    inline=False,
                )
            embed.add_field(
                name="ℹ️ Notes",
                value=(
                    "• This is a **live tmate session** — anyone with this link can connect.\n"
                    "• The session expires when the VPS stops or tmate is killed.\n"
                    "• To kill it: `tmate -S /tmp/tmate-moonnodes.sock kill-server`"
                ),
                inline=False,
            )
            # Build final view: link button + back button
            final_view = discord.ui.View(timeout=300)
            if web_url and web_url.startswith("http"):
                final_view.add_item(discord.ui.Button(
                    label="🌐 Open Web Terminal",
                    style=discord.ButtonStyle.link,
                    url=web_url,
                ))
            for item in back_view.children:
                final_view.add_item(item)
            await interaction.edit_original_response(embed=embed, view=final_view)

        except Exception as e:
            await self._show_error(interaction, "Tmate Error", str(e)[:4000])

    # ─────────────────────────────────────────────────────────────────────────
    # Tailscale — auto-capture auth URL and post it to Discord
    # ─────────────────────────────────────────────────────────────────────────

    async def _run_tailscale(self, interaction: discord.Interaction):
        vps    = self.vps
        name   = vps["container_name"]
        node   = vps.get("node", "local")
        prefix = f"{node}:" if node != "local" else ""
        full   = f"{prefix}{name}"

        await interaction.edit_original_response(
            embed=_loading_embed("Tailscale Setup", "Setting root password…", step=1, total=4),
            view=None,
        )

        try:
            import random as _r, string as _s

            # ── Step 1: Install openssh-server first, THEN configure it ─────────
            root_pw = "".join(_r.choices(_s.ascii_letters + _s.digits, k=20))
            try:
                # Install openssh-server FIRST so sshd_config exists before sed
                await execute_lxc(
                    f"lxc exec {full} -- apt-get install -y openssh-server",
                    timeout=180,
                )
                # Now sshd_config exists — safe to edit it
                await execute_lxc(
                    f'lxc exec {full} -- bash -c "[ -f /etc/ssh/sshd_config ] && '
                    f'sed -i \'s/^#*PermitRootLogin.*/PermitRootLogin yes/\' /etc/ssh/sshd_config '
                    f'|| echo \'sshd_config not found, skipping\'"',
                    timeout=10,
                )
                subprocess.run(
                    [RUNTIME_BIN, "exec", full, "--", "chpasswd"],
                    input=f"root:{root_pw}\n",
                    capture_output=True, text=True, timeout=10,
                )
                await execute_lxc(
                    f"lxc exec {full} -- systemctl enable --now ssh",
                    timeout=15,
                )
            except Exception as _pe:
                return await self._show_error(
                    interaction, "Root Password Setup Failed",
                    f"Could not set root password: {str(_pe)[:500]}",
                )

            # ── Check if Tailscale is already installed and connected ─────────────
            ts_check = subprocess.run(
                [RUNTIME_BIN, "exec", full, "--", "tailscale", "status", "--json"],
                capture_output=True, text=True, timeout=10,
            )
            ts_already_up = False
            if ts_check.returncode == 0:
                try:
                    import json as _json
                    ts_status = _json.loads(ts_check.stdout)
                    # BackendState is "Running" when already authenticated
                    if ts_status.get("BackendState") == "Running":
                        ts_already_up = True
                except Exception:
                    pass

            if ts_already_up:
                # ── Already connected — just show new password, skip re-auth ──────
                auth_url = ""  # no new URL needed
            else:
                # ── Step 2: Install Tailscale if not present ──────────────────────
                await interaction.edit_original_response(
                    embed=_loading_embed("Tailscale Setup", "Installing Tailscale inside VPS…", step=2, total=4),
                    view=None,
                )
                # Check if tailscale binary exists already
                ts_bin = subprocess.run(
                    [RUNTIME_BIN, "exec", full, "--", "which", "tailscale"],
                    capture_output=True, text=True, timeout=10,
                )
                if ts_bin.returncode != 0:
                    try:
                        await execute_lxc(
                            f'lxc exec {full} -- bash -c "curl -fsSL https://tailscale.com/install.sh | sh"',
                            timeout=300,
                        )
                    except Exception as _ie:
                        return await self._show_error(
                            interaction, "Tailscale Install Failed",
                            f"Could not install Tailscale: {str(_ie)[:500]}\n\nMake sure the VPS has internet access.",
                        )

                # ── Step 3: Start tailscaled daemon ──────────────────────────────
                await interaction.edit_original_response(
                    embed=_loading_embed("Tailscale Setup", "Starting Tailscale daemon…", step=3, total=4),
                    view=None,
                )
                subprocess.run(
                    [RUNTIME_BIN, "exec", full, "--", "bash", "-c",
                     "systemctl enable --now tailscaled 2>/dev/null || "
                     "tailscaled --state=/var/lib/tailscale/tailscaled.state "
                     "--tun=userspace-networking &"],
                    capture_output=True, text=True, timeout=20,
                )
                await asyncio.sleep(3)

                # ── Step 4: Run tailscale up and capture auth URL ─────────────────
                await interaction.edit_original_response(
                    embed=_loading_embed(
                        "Tailscale Setup",
                        "Running `tailscale up`…\n*(waiting for auth URL, up to 45 s)*",
                        step=4, total=4,
                    ),
                    view=None,
                )
                auth_url = await self._capture_tailscale_url(full)
            back_view = _BackOnlyView(self.user_id, self.parent_view, self.parent_embed_coro)

            if ts_already_up:
                # ── Already connected — show SSH command block + notes ────────────
                embed = create_success_embed("✅ 🔒 Tailscale Already Connected")
                embed.add_field(
                    name="SSH Command",
                    value=(
                        "```\nssh root@<tailscale-ip>\n```"
                    ),
                    inline=False,
                )
                embed.add_field(
                    name="🔑 Root Password",
                    value=f"```\n{root_pw}\n```",
                    inline=False,
                )
                embed.add_field(
                    name="🌐 Tailscale Admin Panel",
                    value=(
                        f"https://login.tailscale.com/admin/machines\n"
                        "👆 Copy the URL above, or click **Open Admin Panel** button below."
                    ),
                    inline=False,
                )
                embed.add_field(
                    name="ℹ️ Notes",
                    value=(
                        "• Your VPS is already joined to your Tailscale network.\n"
                        "• Replace `<tailscale-ip>` with the IP shown in the admin panel.\n"
                        "• The Tailscale IP stays the same across VPS restarts.\n"
                        "• Change your password after login: `passwd`"
                    ),
                    inline=False,
                )

            elif auth_url:
                # ── Fresh install — show auth URL + SSH instructions ──────────────
                embed = create_success_embed("✅ 🔒 Tailscale Ready — Authorize Your VPS")
                embed.add_field(
                    name="Authorization URL",
                    value=f"```\n{auth_url}\n```",
                    inline=False,
                )
                embed.add_field(
                    name="🌐 Browser Authorization",
                    value=(
                        f"`{auth_url}`\n"
                        "👆 Copy the URL above, or click **Authorize Tailscale** button below."
                    ),
                    inline=False,
                )
                embed.add_field(
                    name="🔑 Root Password",
                    value=f"```\n{root_pw}\n```",
                    inline=False,
                )
                embed.add_field(
                    name="ℹ️ Notes",
                    value=(
                        "• Open the URL above in your browser to authorize this VPS.\n"
                        "• After authorizing, find your VPS IP at "
                        "[login.tailscale.com/admin/machines](https://login.tailscale.com/admin/machines).\n"
                        "• Then SSH in: `ssh root@<tailscale-ip>`\n"
                        "• Tailscale must also be installed on **your** device."
                    ),
                    inline=False,
                )

            else:
                # ── URL not captured — show manual steps + password ───────────────
                embed = create_success_embed("✅ 🔒 Tailscale Installed — Action Needed")
                embed.add_field(
                    name="▶️ Run Inside Your VPS",
                    value="```\ntailscale up\n```",
                    inline=False,
                )
                embed.add_field(
                    name="🌐 Authorization",
                    value=(
                        "`https://login.tailscale.com/...`\n"
                        "👆 A URL like the one above will be printed — open it to authorize."
                    ),
                    inline=False,
                )
                embed.add_field(
                    name="🔑 Root Password",
                    value=f"```\n{root_pw}\n```",
                    inline=False,
                )
                embed.add_field(
                    name="ℹ️ Notes",
                    value=(
                        "• Run `tailscale up` inside the VPS to get your auth URL.\n"
                        "• After authorizing, find your VPS IP at "
                        "[login.tailscale.com/admin/machines](https://login.tailscale.com/admin/machines).\n"
                        "• Then SSH in: `ssh root@<tailscale-ip>`\n"
                        "• Change your password after login: `passwd`"
                    ),
                    inline=False,
                )

            # Build final view — link button + back button (mirrors Tmate layout)
            ts_final_view = discord.ui.View(timeout=300)
            if ts_already_up:
                ts_final_view.add_item(discord.ui.Button(
                    label="🌐 Open Admin Panel",
                    style=discord.ButtonStyle.link,
                    url="https://login.tailscale.com/admin/machines",
                ))
            elif auth_url and auth_url.startswith("http"):
                ts_final_view.add_item(discord.ui.Button(
                    label="🔒 Authorize Tailscale",
                    style=discord.ButtonStyle.link,
                    url=auth_url,
                ))
            for item in back_view.children:
                ts_final_view.add_item(item)
            await interaction.edit_original_response(embed=embed, view=ts_final_view)

        except Exception as e:
            await self._show_error(interaction, "Tailscale Error", str(e)[:4000])

    # ─────────────────────────────────────────────────────────────────────────
    # Shared helpers
    # ─────────────────────────────────────────────────────────────────────────

    async def _check_network(self, interaction: discord.Interaction, full: str, name: str) -> bool:
        try:
            await execute_lxc(f"lxc exec {full} -- ping -c 1 -W 3 8.8.8.8", timeout=8)
            return True
        except Exception:
            pass

        from core.lxc import IS_INCUS, RUNTIME_BIN as _rb
        net_cmd = "incusbr0" if IS_INCUS else "lxdbr0"

        await interaction.edit_original_response(
            embed=create_info_embed("🔧 Auto-fixing network…",
                "No internet detected — attempting automatic repair…"),
            view=None,
        )

        try:
            _nr = subprocess.run([_rb, "network", "show", net_cmd],
                capture_output=True, text=True, timeout=5)
            if _nr.returncode != 0:
                subprocess.run([_rb, "network", "create", net_cmd],
                    capture_output=True, text=True, timeout=20)
            subprocess.run([_rb, "config", "device", "remove", full, "eth0"],
                capture_output=True, text=True, timeout=10)
            subprocess.run([_rb, "config", "device", "add", full, "eth0",
                "nic", f"network={net_cmd}", "name=eth0"],
                capture_output=True, text=True, timeout=10)
            subprocess.run([_rb, "restart", full],
                capture_output=True, text=True, timeout=60)
            await asyncio.sleep(5)
            _netplan = "network:\n  version: 2\n  ethernets:\n    eth0:\n      dhcp4: true\n"
            subprocess.run(
                [_rb, "exec", full, "--", "bash", "-c",
                 f"printf '{_netplan}' > /etc/netplan/99-moonnodes-eth0.yaml "
                 f"&& chmod 600 /etc/netplan/99-moonnodes-eth0.yaml && netplan apply"],
                capture_output=True, text=True, timeout=20,
            )
            await asyncio.sleep(3)
            _ping = subprocess.run(
                [_rb, "exec", full, "--", "ping", "-c", "1", "-W", "3", "8.8.8.8"],
                capture_output=True, text=True, timeout=8,
            )
            if _ping.returncode == 0:
                return True
        except Exception:
            pass

        back_view = _BackOnlyView(self.user_id, self.parent_view, self.parent_embed_coro)
        await interaction.edit_original_response(
            embed=create_error_embed(
                "❌ Network repair failed",
                f"Could not restore internet access for `{name}`.\n"
                "Contact an admin and provide the container name.",
            ),
            view=back_view,
        )
        return False

    async def _capture_tailscale_url(self, full: str) -> str:
        """
        Use `tailscale login` (not `tailscale up`) — it prints the auth URL
        to stdout immediately and exits once the user authorizes.
        We run it synchronously with a generous timeout since incus exec
        keeps the process alive for the full duration.
        Falls back to `tailscale up` output parsing if login is unavailable.
        """
        _URL_RE = re.compile(r"https://login\.tailscale\.com/[A-Za-z0-9/_?=&%-]+")
        log_file = "/tmp/ts-auth-moonnodes.log"

        # Strategy 1: `tailscale login` — prints URL to stdout then waits
        # Run it in a short-timeout subprocess; we only need the URL line,
        # not to wait for the full auth flow.
        try:
            r = subprocess.run(
                [RUNTIME_BIN, "exec", full, "--",
                 "bash", "-c",
                 f"tailscale login --qr=false 2>&1 | tee {log_file}"],
                capture_output=True, text=True, timeout=30,
            )
            combined = r.stdout + r.stderr
            m = _URL_RE.search(combined)
            if m:
                return _strip_ansi(m.group(0)).rstrip(".,;)")
        except subprocess.TimeoutExpired:
            # Timeout is expected — the process is waiting for auth.
            # Check the log file for the URL that was already printed.
            pass
        except Exception:
            pass

        # Read the log file (written by tee above, even after timeout)
        try:
            r2 = subprocess.run(
                [RUNTIME_BIN, "exec", full, "--", "cat", log_file],
                capture_output=True, text=True, timeout=10,
            )
            m = _URL_RE.search(r2.stdout + r2.stderr)
            if m:
                return _strip_ansi(m.group(0)).rstrip(".,;)")
        except Exception:
            pass

        # Strategy 2: `tailscale up` — older versions print URL this way
        try:
            r3 = subprocess.run(
                [RUNTIME_BIN, "exec", full, "--",
                 "bash", "-c",
                 f"tailscale up --reset --qr=false 2>&1 | tee {log_file}"],
                capture_output=True, text=True, timeout=30,
            )
            combined3 = r3.stdout + r3.stderr
            m = _URL_RE.search(combined3)
            if m:
                return _strip_ansi(m.group(0)).rstrip(".,;)")
        except subprocess.TimeoutExpired:
            pass
        except Exception:
            pass

        # Final read of log file from strategy 2
        try:
            r4 = subprocess.run(
                [RUNTIME_BIN, "exec", full, "--", "cat", log_file],
                capture_output=True, text=True, timeout=10,
            )
            m = _URL_RE.search(r4.stdout + r4.stderr)
            if m:
                return _strip_ansi(m.group(0)).rstrip(".,;)")
        except Exception:
            pass

        return ""

    async def _show_error(self, interaction: discord.Interaction, title: str, detail: str):
        back_view = _BackOnlyView(self.user_id, self.parent_view, self.parent_embed_coro)
        try:
            await interaction.edit_original_response(
                embed=create_error_embed(title, detail),
                view=back_view,
            )
        except Exception:
            pass


class _BackOnlyView(discord.ui.View):
    def __init__(self, user_id: str, parent_view, parent_embed_coro):
        super().__init__(timeout=120)
        self.user_id           = user_id
        self.parent_view       = parent_view
        self.parent_embed_coro = parent_embed_coro

    @discord.ui.button(label="← Back to VPS Panel", style=discord.ButtonStyle.secondary, emoji="↩️")
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if str(interaction.user.id) != self.user_id:
            return await interaction.response.send_message("Permission denied.", ephemeral=True)
        await interaction.response.defer()
        embed = await self.parent_embed_coro()
        await interaction.edit_original_response(embed=embed, view=self.parent_view)
