import discord
import asyncio
import random
import string
import subprocess

from core.theme import create_embed, create_success_embed, create_error_embed, create_info_embed, Theme
from core.lxc import execute_lxc, RUNTIME_BIN
from core import incus as _incus


def _loading_embed(title, detail, step=1, total=4):
    bar   = "".join(["#" if j < step else "-" for j in range(total)])
    embed = discord.Embed(
        title="Loading: " + title,
        description=detail + "\n\n`[" + bar + "]` Step " + str(step) + "/" + str(total),
        color=0x5865F2,
    )
    embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
    embed.set_footer(text="Please wait...")
    return embed


class SSHMethodView(discord.ui.View):
    """
    Shown when the user clicks the SSH button.
    Lets the user pick between Tmate (session-sharing SSH) or
    Tailscale (WireGuard-based private network SSH), or go Back.
    """

    def __init__(self, user_id: str, vps: dict, parent_view, parent_embed_coro):
        super().__init__(timeout=120)
        self.user_id          = user_id
        self.vps              = vps
        self.parent_view      = parent_view       # ManageView instance
        self.parent_embed_coro = parent_embed_coro  # coroutine that rebuilds main embed

    # ─── Static embed shown when the picker appears ──────────────────────────

    @staticmethod
    def picker_embed():
        embed = create_embed(
            "🔑 SSH Access — Choose Method",
            (
                "Select how you want to connect to your VPS:\n\n"
                "**🖥️ Tmate**\n"
                "> Creates a temporary, shareable SSH session.\n"
                "> Generates a one-time `ssh` command you can use right away.\n\n"
                "**🔒 Tailscale**\n"
                "> Connects your VPS to your private Tailscale network.\n"
                "> Gives you a stable private IP for repeated SSH access.\n\n"
                "Use **← Back** to return to the VPS control panel."
            ),
            color=0x5865F2,
        )
        embed.set_footer(text="MoonNodes VPS Manager • SSH Setup")
        return embed

    # ─── Guard helper ─────────────────────────────────────────────────────────

    async def _guard(self, interaction: discord.Interaction) -> bool:
        if str(interaction.user.id) != self.user_id:
            await interaction.response.send_message("Permission denied.", ephemeral=True)
            return False
        return True

    # ─── Back button ─────────────────────────────────────────────────────────

    @discord.ui.button(label="← Back", style=discord.ButtonStyle.secondary, emoji="↩️", row=1)
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self._guard(interaction):
            return
        await interaction.response.defer()
        embed = await self.parent_embed_coro()
        await interaction.edit_original_response(embed=embed, view=self.parent_view)

    # ─── Tmate button ────────────────────────────────────────────────────────

    @discord.ui.button(label="Tmate (Quick SSH)", style=discord.ButtonStyle.primary, emoji="🖥️", row=0)
    async def tmate_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self._guard(interaction):
            return
        await interaction.response.defer()
        await self._run_tmate(interaction)

    # ─── Tailscale button ────────────────────────────────────────────────────

    @discord.ui.button(label="Tailscale (Private VPN)", style=discord.ButtonStyle.success, emoji="🔒", row=0)
    async def tailscale_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self._guard(interaction):
            return
        await interaction.response.defer()
        await self._run_tailscale(interaction)

    # ═══════════════════════════════════════════════════════════════════════════
    # Tmate implementation  (kept from the original ManageView `tmate` action)
    # ═══════════════════════════════════════════════════════════════════════════

    async def _run_tmate(self, interaction: discord.Interaction):
        vps    = self.vps
        name   = vps["container_name"]
        node   = vps.get("node", "local")
        prefix = f"{node}:" if node != "local" else ""
        full   = f"{prefix}{name}"

        await interaction.edit_original_response(
            embed=_loading_embed("Setting up SSH (Tmate)", "Checking network…", step=1, total=4),
            view=None,
        )

        try:
            # ── Network check / auto-fix ──────────────────────────────────
            has_net = False
            try:
                await execute_lxc(f"lxc exec {full} -- ping -c 1 -W 3 8.8.8.8", timeout=6)
                has_net = True
            except Exception:
                pass

            if not has_net:
                from core.lxc import IS_INCUS, RUNTIME_BIN as _rb
                net_cmd = "incusbr0" if IS_INCUS else "lxdbr0"
                await interaction.edit_original_response(embed=create_info_embed(
                    "🔧 Auto-fixing network…",
                    "No internet detected — attempting automatic repair…"
                ), view=None)
                _fixed = False
                try:
                    _nr = subprocess.run([_rb, "network", "show", net_cmd],
                        capture_output=True, text=True, timeout=5)
                    if _nr.returncode != 0:
                        subprocess.run([_rb, "network", "create", net_cmd],
                            capture_output=True, text=True, timeout=20)
                    subprocess.run([_rb, "config", "device", "remove", full, "eth0"],
                        capture_output=True, text=True, timeout=10)
                    subprocess.run([_rb, "config", "device", "add", full, "eth0",
                        "nic", f"network={net_cmd}", "name=eth0"],
                        capture_output=True, text=True, timeout=10)
                    subprocess.run([_rb, "restart", full],
                        capture_output=True, text=True, timeout=60)
                    await asyncio.sleep(5)
                    _netplan = (
                        "network:\n"
                        "  version: 2\n"
                        "  ethernets:\n"
                        "    eth0:\n"
                        "      dhcp4: true\n"
                    )
                    subprocess.run(
                        [_rb, "exec", full, "--", "bash", "-c",
                         f'printf "{_netplan}" > /etc/netplan/99-moonnodes-eth0.yaml '
                         f'&& chmod 600 /etc/netplan/99-moonnodes-eth0.yaml '
                         f'&& netplan apply'],
                        capture_output=True, text=True, timeout=20
                    )
                    await asyncio.sleep(3)
                    _ping = subprocess.run(
                        [_rb, "exec", full, "--", "ping", "-c", "1", "-W", "3", "8.8.8.8"],
                        capture_output=True, text=True, timeout=8
                    )
                    _fixed = (_ping.returncode == 0)
                except Exception:
                    pass

                if _fixed:
                    has_net = True
                else:
                    back_view = _BackOnlyView(self.user_id, self.parent_view, self.parent_embed_coro)
                    await interaction.edit_original_response(embed=create_error_embed(
                        "❌ Network repair failed",
                        f"Could not restore internet access for `{name}`.\n"
                        f"Contact an admin and provide the container name."
                    ), view=back_view)
                    return

            from core.config import HOST_PUBLIC_IP

            # ── Install tmate via incus.install_tmate (3-strategy fallback) ──
            await interaction.edit_original_response(
                embed=_loading_embed("Setting up SSH (Tmate)",
                    "Installing tmate… (trying apt, universe repo, then static binary)",
                    step=2, total=4),
                view=None,
            )
            try:
                await _incus.install_tmate(full)
            except Exception as _ie:
                back_view = _BackOnlyView(self.user_id, self.parent_view, self.parent_embed_coro)
                return await interaction.edit_original_response(
                    embed=create_error_embed("tmate Install Failed", str(_ie)[:800]),
                    view=back_view,
                )

            # ── Start a tmate session and grab the SSH line ───────────────
            await interaction.edit_original_response(
                embed=_loading_embed("Setting up SSH (Tmate)",
                    "Starting tmate session…", step=3, total=4),
                view=None,
            )
            _pw = "".join(random.choices(string.ascii_letters + string.digits, k=20))
            try:
                await execute_lxc(
                    f'lxc exec {full} -- sed -i "s/^#*PermitRootLogin.*/PermitRootLogin yes/" /etc/ssh/sshd_config',
                    timeout=10
                )
                subprocess.run(
                    [RUNTIME_BIN, "exec", full, "--", "chpasswd"],
                    input=f"root:{_pw}\n",
                    capture_output=True, text=True, timeout=10
                )
                await execute_lxc(f"lxc exec {full} -- systemctl enable --now ssh", timeout=15)
            except Exception as _ce:
                back_view = _BackOnlyView(self.user_id, self.parent_view, self.parent_embed_coro)
                return await interaction.edit_original_response(
                    embed=create_error_embed("SSH Setup Failed", str(_ce)[:500]),
                    view=back_view,
                )

            # ── Random host port + proxy device ──────────────────────────
            subprocess.run([RUNTIME_BIN, "config", "device", "remove", full, "moonnode-ssh"],
                capture_output=True, text=True, timeout=10)
            _port  = random.randint(20000, 40000)
            _proxy = subprocess.run(
                [RUNTIME_BIN, "config", "device", "add", full, "moonnode-ssh", "proxy",
                 f"listen=tcp:0.0.0.0:{_port}", "connect=tcp:127.0.0.1:22"],
                capture_output=True, text=True, timeout=15
            )
            if _proxy.returncode != 0:
                back_view = _BackOnlyView(self.user_id, self.parent_view, self.parent_embed_coro)
                return await interaction.edit_original_response(
                    embed=create_error_embed(
                        "SSH Setup Failed",
                        f"Could not forward port: {_proxy.stderr.strip()[:400]}"
                    ),
                    view=back_view,
                )

            # ── Show credentials ──────────────────────────────────────────
            _host     = HOST_PUBLIC_IP or "YOUR_SERVER_IP"
            back_view = _BackOnlyView(self.user_id, self.parent_view, self.parent_embed_coro)
            embed     = create_success_embed("🔑 SSH Ready (Tmate / Direct SSH)")
            embed.add_field(
                name="SSH Command",
                value=f"```\nssh root@{_host} -p {_port}\n```",
                inline=False
            )
            embed.add_field(name="Password", value=f"```\n{_pw}\n```", inline=False)
            embed.add_field(
                name="⚠️ Security",
                value="Change your password after login with `passwd`. Do not share these credentials.",
                inline=False
            )
            await interaction.edit_original_response(embed=embed, view=back_view)

        except Exception as e:
            back_view = _BackOnlyView(self.user_id, self.parent_view, self.parent_embed_coro)
            try:
                await interaction.edit_original_response(
                    embed=create_error_embed("SSH Error", str(e)[:4000]),
                    view=back_view,
                )
            except Exception:
                pass

    # ═══════════════════════════════════════════════════════════════════════════
    # Tailscale implementation
    # ═══════════════════════════════════════════════════════════════════════════

    async def _run_tailscale(self, interaction: discord.Interaction):
        vps    = self.vps
        name   = vps["container_name"]
        node   = vps.get("node", "local")
        prefix = f"{node}:" if node != "local" else ""
        full   = f"{prefix}{name}"

        await interaction.edit_original_response(
            embed=_loading_embed("Setting up Tailscale", "Installing Tailscale inside VPS…", step=1, total=3),
            view=None,
        )

        try:
            # ── 1. Install Tailscale ──────────────────────────────────────
            install_cmd = (
                "curl -fsSL https://tailscale.com/install.sh | sh"
            )
            try:
                await execute_lxc(
                    f"lxc exec {full} -- bash -c \"{install_cmd}\"",
                    timeout=300,
                )
            except Exception as _ie:
                back_view = _BackOnlyView(self.user_id, self.parent_view, self.parent_embed_coro)
                return await interaction.edit_original_response(
                    embed=create_error_embed(
                        "Tailscale Install Failed",
                        f"Could not install Tailscale: {str(_ie)[:500]}\n\n"
                        "Make sure the VPS has internet access."
                    ),
                    view=back_view,
                )

            await interaction.edit_original_response(
                embed=_loading_embed("Setting up Tailscale", "Starting Tailscale daemon…", step=2, total=3),
                view=None,
            )

            # ── 2. Start tailscaled (allow userspace networking) ──────────
            try:
                await execute_lxc(
                    f"lxc exec {full} -- bash -c "
                    f"'systemctl enable --now tailscaled 2>/dev/null || "
                    f"tailscaled --state=/var/lib/tailscale/tailscaled.state &'",
                    timeout=20,
                )
                await asyncio.sleep(2)
            except Exception:
                pass  # daemon may already be running

            # ── 3. Run `tailscale up` and capture auth URL ────────────────
            await interaction.edit_original_response(
                embed=_loading_embed("Setting up Tailscale", "Generating auth link…", step=3, total=3),
                view=None,
            )

            result = ""
            try:
                raw = subprocess.run(
                    [RUNTIME_BIN, "exec", full, "--",
                     "tailscale", "up", "--auth-key=", "--qr=false", "--timeout=10s"],
                    capture_output=True, text=True, timeout=20,
                )
                result = (raw.stdout + raw.stderr).strip()
            except Exception:
                pass

            # Try to extract the https://login.tailscale.com URL from the output
            auth_url = ""
            for line in result.splitlines():
                if "https://" in line:
                    auth_url = line.strip()
                    break

            back_view = _BackOnlyView(self.user_id, self.parent_view, self.parent_embed_coro)

            if auth_url:
                embed = create_success_embed("🔒 Tailscale — Authorize Your VPS")
                embed.add_field(
                    name="Step 1 — Open the auth link",
                    value=f"[Click here to authorize your VPS]({auth_url})\n`{auth_url}`",
                    inline=False,
                )
                embed.add_field(
                    name="Step 2 — SSH via Tailscale IP",
                    value=(
                        "After authorizing, find your VPS IP in the Tailscale admin panel:\n"
                        "```\nssh root@<tailscale-ip>\n```"
                    ),
                    inline=False,
                )
                embed.add_field(
                    name="ℹ️ Note",
                    value=(
                        "You must also have Tailscale running on the device you're connecting **from**.\n"
                        "The Tailscale IP stays stable as long as the VPS is in your network."
                    ),
                    inline=False,
                )
            else:
                embed = create_info_embed(
                    "🔒 Tailscale Installed",
                    (
                        f"Tailscale was installed on `{name}`, but no auth URL was captured automatically.\n\n"
                        "**To finish setup, run inside the VPS:**\n"
                        "```\ntailscale up\n```\n"
                        "Then open the printed URL in your browser to authorize the device.\n\n"
                        "After that, SSH using the Tailscale IP shown in your Tailscale admin panel:\n"
                        "```\nssh root@<tailscale-ip>\n```"
                    ),
                )

            await interaction.edit_original_response(embed=embed, view=back_view)

        except Exception as e:
            back_view = _BackOnlyView(self.user_id, self.parent_view, self.parent_embed_coro)
            try:
                await interaction.edit_original_response(
                    embed=create_error_embed("Tailscale Error", str(e)[:4000]),
                    view=back_view,
                )
            except Exception:
                pass


# ─── Minimal "← Back" only view (shown after SSH result) ─────────────────────

class _BackOnlyView(discord.ui.View):
    """Single back-button shown on the result screen so the user can return."""

    def __init__(self, user_id: str, parent_view, parent_embed_coro):
        super().__init__(timeout=120)
        self.user_id           = user_id
        self.parent_view       = parent_view
        self.parent_embed_coro = parent_embed_coro

    @discord.ui.button(label="← Back to VPS Panel", style=discord.ButtonStyle.secondary, emoji="↩️")
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if str(interaction.user.id) != self.user_id:
            return await interaction.response.send_message("Permission denied.", ephemeral=True)
        await interaction.response.defer()
        embed = await self.parent_embed_coro()
        await interaction.edit_original_response(embed=embed, view=self.parent_view)
