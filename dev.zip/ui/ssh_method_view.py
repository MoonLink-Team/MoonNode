import discord
import asyncio
import subprocess
import re

from core.theme import (
    create_embed, create_success_embed, create_error_embed,
    create_info_embed, Theme,
)
from core.lxc import execute_lxc, RUNTIME_BIN
from core import incus as _incus


def _loading_embed(title: str, detail: str, step: int = 1, total: int = 4):
    bar   = "".join(["#" if j < step else "-" for j in range(total)])
    embed = discord.Embed(
        title="Loading: " + title,
        description=detail + f"\n\n`[{bar}]` Step {step}/{total}",
        color=0x5865F2,
    )
    embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
    embed.set_footer(text="Please wait…")
    return embed


class SSHMethodView(discord.ui.View):
    def __init__(self, user_id: str, vps: dict, parent_view, parent_embed_coro):
        super().__init__(timeout=120)
        self.user_id           = user_id
        self.vps               = vps
        self.parent_view       = parent_view
        self.parent_embed_coro = parent_embed_coro

    @staticmethod
    def picker_embed():
        embed = create_embed(
            "🔑 SSH Access — Choose Method",
            (
                "Select how you want to connect to your VPS:\n\n"
                "**🖥️ Tmate**\n"
                "> Starts a real tmate session inside your VPS.\n"
                "> Gives you a one-time `ssh` command — no port forwarding needed.\n\n"
                "**🔒 Tailscale**\n"
                "> Connects your VPS to your private Tailscale network.\n"
                "> Shows the auth link right here in Discord so you can approve it instantly.\n\n"
                "Use **← Back** to return to the VPS control panel."
            ),
            color=0x5865F2,
        )
        embed.set_footer(text="MoonNodes VPS Manager • SSH Setup")
        return embed

    async def _guard(self, interaction: discord.Interaction) -> bool:
        if str(interaction.user.id) != self.user_id:
            await interaction.response.send_message("Permission denied.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="← Back", style=discord.ButtonStyle.secondary, emoji="↩️", row=1)
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self._guard(interaction):
            return
        await interaction.response.defer()
        embed = await self.parent_embed_coro()
        await interaction.edit_original_response(embed=embed, view=self.parent_view)

    @discord.ui.button(label="Tmate (Quick SSH)", style=discord.ButtonStyle.primary, emoji="🖥️", row=0)
    async def tmate_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self._guard(interaction):
            return
        await interaction.response.defer()
        await self._run_tmate(interaction)

    @discord.ui.button(label="Tailscale (Private VPN)", style=discord.ButtonStyle.success, emoji="🔒", row=0)
    async def tailscale_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await self._guard(interaction):
            return
        await interaction.response.defer()
        await self._run_tailscale(interaction)

    # ─────────────────────────────────────────────────────────────────────────
    # Tmate — real tmate session; SSH link posted directly to Discord
    # ─────────────────────────────────────────────────────────────────────────

    async def _run_tmate(self, interaction: discord.Interaction):
        vps    = self.vps
        name   = vps["container_name"]
        node   = vps.get("node", "local")
        prefix = f"{node}:" if node != "local" else ""
        full   = f"{prefix}{name}"

        await interaction.edit_original_response(
            embed=_loading_embed("Tmate SSH", "Checking network…", step=1, total=4),
            view=None,
        )

        try:
            if not await self._check_network(interaction, full, name):
                return

            # Install tmate (3-strategy fallback in core/incus.py)
            await interaction.edit_original_response(
                embed=_loading_embed(
                    "Tmate SSH",
                    "Installing tmate…\n*(apt → universe repo → static binary)*",
                    step=2, total=4,
                ),
                view=None,
            )
            try:
                await _incus.install_tmate(full)
            except Exception as _ie:
                return await self._show_error(interaction, "tmate Install Failed", str(_ie)[:800])

            # Start tmate session
            await interaction.edit_original_response(
                embed=_loading_embed("Tmate SSH", "Starting tmate session…", step=3, total=4),
                view=None,
            )

            SOCK = "/tmp/tmate-moonnodes.sock"

            # Kill any stale session, then start a fresh detached one
            subprocess.run(
                [RUNTIME_BIN, "exec", full, "--", "bash", "-c",
                 f"tmate -S {SOCK} kill-server 2>/dev/null; rm -f {SOCK}"],
                capture_output=True, text=True, timeout=10,
            )
            subprocess.run(
                [RUNTIME_BIN, "exec", full, "--", "bash", "-c",
                 f"tmate -S {SOCK} new-session -d -s moonnodes 2>/dev/null"],
                capture_output=True, text=True, timeout=15,
            )

            # Wait for tmate.io to assign the session link
            await asyncio.sleep(5)

            # Fetch the SSH link
            await interaction.edit_original_response(
                embed=_loading_embed("Tmate SSH", "Fetching SSH link from tmate.io…", step=4, total=4),
                view=None,
            )

            ssh_line = ""
            web_url  = ""

            for _ in range(6):   # poll up to 30 s
                r = subprocess.run(
                    [RUNTIME_BIN, "exec", full, "--", "bash", "-c",
                     f"tmate -S {SOCK} display -p '#{{tmate_ssh}}' 2>/dev/null"],
                    capture_output=True, text=True, timeout=10,
                )
                candidate = r.stdout.strip()
                if candidate.startswith("ssh "):
                    ssh_line = candidate
                    break
                await asyncio.sleep(5)

            r2 = subprocess.run(
                [RUNTIME_BIN, "exec", full, "--", "bash", "-c",
                 f"tmate -S {SOCK} display -p '#{{tmate_web}}' 2>/dev/null"],
                capture_output=True, text=True, timeout=10,
            )
            web_url = r2.stdout.strip()

            back_view = _BackOnlyView(self.user_id, self.parent_view, self.parent_embed_coro)

            if not ssh_line:
                r3 = subprocess.run(
                    [RUNTIME_BIN, "exec", full, "--", "bash", "-c",
                     f"tmate -S {SOCK} display -p '#{{tmate_ssh}} #{{tmate_web}}' 2>&1 | head -5"],
                    capture_output=True, text=True, timeout=10,
                )
                raw_out = r3.stdout.strip() or "(no output)"
                embed = create_error_embed(
                    "tmate — Could Not Get SSH Link",
                    f"tmate started but the session URL was not returned in time.\n\n"
                    f"**Raw output:**\n```\n{raw_out[:600]}\n```\n\n"
                    f"You can try running tmate manually inside the VPS:\n```\ntmate\n```",
                )
                return await interaction.edit_original_response(embed=embed, view=back_view)

            embed = create_success_embed("🖥️ Tmate SSH Ready")
            embed.add_field(
                name="SSH Command",
                value=f"```\n{ssh_line}\n```",
                inline=False,
            )
            if web_url and web_url.startswith("http"):
                embed.add_field(
                    name="🌐 Web Browser Access",
                    value=f"[Open terminal in browser]({web_url})\n`{web_url}`",
                    inline=False,
                )
            embed.add_field(
                name="ℹ️ Notes",
                value=(
                    "• This is a **live tmate session** — anyone with this link can connect.\n"
                    "• The session expires when the VPS stops or tmate is killed.\n"
                    "• To kill it: `tmate -S /tmp/tmate-moonnodes.sock kill-server`"
                ),
                inline=False,
            )
            await interaction.edit_original_response(embed=embed, view=back_view)

        except Exception as e:
            await self._show_error(interaction, "Tmate Error", str(e)[:4000])

    # ─────────────────────────────────────────────────────────────────────────
    # Tailscale — auto-capture auth URL and post it to Discord
    # ─────────────────────────────────────────────────────────────────────────

    async def _run_tailscale(self, interaction: discord.Interaction):
        vps    = self.vps
        name   = vps["container_name"]
        node   = vps.get("node", "local")
        prefix = f"{node}:" if node != "local" else ""
        full   = f"{prefix}{name}"

        await interaction.edit_original_response(
            embed=_loading_embed("Tailscale Setup", "Installing Tailscale inside VPS…", step=1, total=3),
            view=None,
        )

        try:
            try:
                await execute_lxc(
                    f'lxc exec {full} -- bash -c "curl -fsSL https://tailscale.com/install.sh | sh"',
                    timeout=300,
                )
            except Exception as _ie:
                return await self._show_error(
                    interaction, "Tailscale Install Failed",
                    f"Could not install Tailscale: {str(_ie)[:500]}\n\nMake sure the VPS has internet access.",
                )

            await interaction.edit_original_response(
                embed=_loading_embed("Tailscale Setup", "Starting Tailscale daemon…", step=2, total=3),
                view=None,
            )
            subprocess.run(
                [RUNTIME_BIN, "exec", full, "--", "bash", "-c",
                 "systemctl enable --now tailscaled 2>/dev/null || "
                 "tailscaled --state=/var/lib/tailscale/tailscaled.state "
                 "--tun=userspace-networking &"],
                capture_output=True, text=True, timeout=20,
            )
            await asyncio.sleep(3)

            await interaction.edit_original_response(
                embed=_loading_embed(
                    "Tailscale Setup",
                    "Running `tailscale up`…\n*(waiting for auth URL, up to 45 s)*",
                    step=3, total=3,
                ),
                view=None,
            )

            auth_url = await self._capture_tailscale_url(full)
            back_view = _BackOnlyView(self.user_id, self.parent_view, self.parent_embed_coro)

            if auth_url:
                embed = create_success_embed("🔒 Tailscale — Authorize Your VPS")
                embed.add_field(
                    name="Step 1 — Click to authorize",
                    value=(
                        f"[**🔗 Open Tailscale Auth Page**]({auth_url})\n"
                        f"```\n{auth_url}\n```"
                    ),
                    inline=False,
                )
                embed.add_field(
                    name="Step 2 — SSH via Tailscale IP",
                    value=(
                        "After authorizing, your VPS appears in the "
                        "[Tailscale admin panel](https://login.tailscale.com/admin/machines).\n"
                        "Then connect with:\n```\nssh root@<tailscale-ip>\n```"
                    ),
                    inline=False,
                )
                embed.add_field(
                    name="ℹ️ Requirements",
                    value=(
                        "• Tailscale must be running on **your** device too.\n"
                        "• The Tailscale IP stays stable across VPS restarts."
                    ),
                    inline=False,
                )
            else:
                embed = create_info_embed(
                    "🔒 Tailscale Installed — Manual Auth Needed",
                    (
                        f"Tailscale was installed on `{name}`, but the auth URL "
                        f"couldn't be captured automatically.\n\n"
                        f"**Inside your VPS, run:**\n```\ntailscale up\n```\n"
                        f"Copy the `https://login.tailscale.com/...` URL it prints "
                        f"and open it in your browser to authorize.\n\n"
                        f"Then SSH using the IP from the "
                        f"[admin panel](https://login.tailscale.com/admin/machines):\n"
                        f"```\nssh root@<tailscale-ip>\n```"
                    ),
                )

            await interaction.edit_original_response(embed=embed, view=back_view)

        except Exception as e:
            await self._show_error(interaction, "Tailscale Error", str(e)[:4000])

    # ─────────────────────────────────────────────────────────────────────────
    # Shared helpers
    # ─────────────────────────────────────────────────────────────────────────

    async def _check_network(self, interaction: discord.Interaction, full: str, name: str) -> bool:
        try:
            await execute_lxc(f"lxc exec {full} -- ping -c 1 -W 3 8.8.8.8", timeout=8)
            return True
        except Exception:
            pass

        from core.lxc import IS_INCUS, RUNTIME_BIN as _rb
        net_cmd = "incusbr0" if IS_INCUS else "lxdbr0"

        await interaction.edit_original_response(
            embed=create_info_embed("🔧 Auto-fixing network…",
                "No internet detected — attempting automatic repair…"),
            view=None,
        )

        try:
            _nr = subprocess.run([_rb, "network", "show", net_cmd],
                capture_output=True, text=True, timeout=5)
            if _nr.returncode != 0:
                subprocess.run([_rb, "network", "create", net_cmd],
                    capture_output=True, text=True, timeout=20)
            subprocess.run([_rb, "config", "device", "remove", full, "eth0"],
                capture_output=True, text=True, timeout=10)
            subprocess.run([_rb, "config", "device", "add", full, "eth0",
                "nic", f"network={net_cmd}", "name=eth0"],
                capture_output=True, text=True, timeout=10)
            subprocess.run([_rb, "restart", full],
                capture_output=True, text=True, timeout=60)
            await asyncio.sleep(5)
            _netplan = "network:\n  version: 2\n  ethernets:\n    eth0:\n      dhcp4: true\n"
            subprocess.run(
                [_rb, "exec", full, "--", "bash", "-c",
                 f"printf '{_netplan}' > /etc/netplan/99-moonnodes-eth0.yaml "
                 f"&& chmod 600 /etc/netplan/99-moonnodes-eth0.yaml && netplan apply"],
                capture_output=True, text=True, timeout=20,
            )
            await asyncio.sleep(3)
            _ping = subprocess.run(
                [_rb, "exec", full, "--", "ping", "-c", "1", "-W", "3", "8.8.8.8"],
                capture_output=True, text=True, timeout=8,
            )
            if _ping.returncode == 0:
                return True
        except Exception:
            pass

        back_view = _BackOnlyView(self.user_id, self.parent_view, self.parent_embed_coro)
        await interaction.edit_original_response(
            embed=create_error_embed(
                "❌ Network repair failed",
                f"Could not restore internet access for `{name}`.\n"
                "Contact an admin and provide the container name.",
            ),
            view=back_view,
        )
        return False

    async def _capture_tailscale_url(self, full: str) -> str:
        """
        Capture the Tailscale auth URL by:
          1. Writing a wrapper script into the container that runs
             `tailscale up` and saves all output to a log file.
          2. Running it with nohup so it survives the exec session.
          3. Polling the log file every 5 s for up to 60 s.
        Handles both old-style plain URL output and new-style
        JSON / ANSI-coloured output from tailscale >= 1.44.
        """
        _URL_RE = re.compile(r"https://login\.tailscale\.com/[A-Za-z0-9/_-]+")
        log_file = "/tmp/ts-auth-moonnodes.log"
        script   = "/tmp/ts-auth-moonnodes.sh"

        # Write the launcher script into the container
        script_body = (
            "#!/bin/bash\n"
            f"rm -f {log_file}\n"
            # tailscale up prints the URL to stderr; redirect both streams
            f"tailscale up --reset --accept-routes --qr=false >> {log_file} 2>&1\n"
        )
        subprocess.run(
            [RUNTIME_BIN, "exec", full, "--", "bash", "-c",
             f"printf '{script_body}' > {script} && chmod +x {script}"],
            capture_output=True, text=True, timeout=10,
        )

        # Launch with nohup so it keeps running after exec exits
        subprocess.run(
            [RUNTIME_BIN, "exec", full, "--", "bash", "-c",
             f"nohup {script} >/dev/null 2>&1 &"],
            capture_output=True, text=True, timeout=10,
        )

        # Poll the log file for the URL (up to 60 s)
        for _ in range(12):   # 12 × 5 s = 60 s
            await asyncio.sleep(5)
            r = subprocess.run(
                [RUNTIME_BIN, "exec", full, "--", "cat", log_file],
                capture_output=True, text=True, timeout=10,
            )
            combined = r.stdout + r.stderr
            m = _URL_RE.search(combined)
            if m:
                # Strip any trailing ANSI codes or punctuation
                url = re.sub(r"[\x1b\x1B]\[[0-9;]*m", "", m.group(0)).rstrip(".,;)")
                return url

        return ""

    async def _show_error(self, interaction: discord.Interaction, title: str, detail: str):
        back_view = _BackOnlyView(self.user_id, self.parent_view, self.parent_embed_coro)
        try:
            await interaction.edit_original_response(
                embed=create_error_embed(title, detail),
                view=back_view,
            )
        except Exception:
            pass


class _BackOnlyView(discord.ui.View):
    def __init__(self, user_id: str, parent_view, parent_embed_coro):
        super().__init__(timeout=120)
        self.user_id           = user_id
        self.parent_view       = parent_view
        self.parent_embed_coro = parent_embed_coro

    @discord.ui.button(label="← Back to VPS Panel", style=discord.ButtonStyle.secondary, emoji="↩️")
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if str(interaction.user.id) != self.user_id:
            return await interaction.response.send_message("Permission denied.", ephemeral=True)
        await interaction.response.defer()
        embed = await self.parent_embed_coro()
        await interaction.edit_original_response(embed=embed, view=self.parent_view)
