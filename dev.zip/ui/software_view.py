import discord
from core.config import SOFTWARE_SCRIPTS
from core.lxc import execute_lxc
from core.theme import create_info_embed, create_success_embed, create_error_embed, Theme


class SoftwareView(discord.ui.View):
    def __init__(self, user_id: str, container_name: str, node: str = "local"):
        super().__init__(timeout=300)
        self.user_id        = user_id
        self.container_name = container_name
        self.node           = node
        self.node_prefix    = f"{node}:" if node != "local" else ""

        options = [
            discord.SelectOption(
                label=v["name"],
                value=k,
                emoji="⚙️",
            )
            for k, v in SOFTWARE_SCRIPTS.items()
        ]
        select = discord.ui.Select(placeholder="▼ Choose software to install", options=options)
        select.callback = self._install
        self.add_item(select)

    async def _install(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.user_id:
            return await interaction.response.send_message("Not your action.", ephemeral=True)

        key    = interaction.data["values"][0]
        script = SOFTWARE_SCRIPTS[key]
        full   = f"{self.node_prefix}{self.container_name}"

        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(
            embed=create_info_embed(f"{Theme.LOADING} Installing {script['name']}", "This may take a few minutes…"),
            view=self,
        )

        try:
            cmd = f"bash -c '{script['cmd']}'"
            await execute_lxc(f"lxc exec {full} -- {cmd}", timeout=600)
            ver = await execute_lxc(f"lxc exec {full} -- {script['check']}", timeout=15)
            await interaction.edit_original_response(
                embed=create_success_embed(
                    f"{script['name']} Installed",
                    f"```\n{str(ver)[:1000]}\n```",
                ),
                view=None,
            )
        except Exception as e:
            await interaction.edit_original_response(
                embed=create_error_embed("Install Failed", str(e)[:4000]),
                view=None,
            )
