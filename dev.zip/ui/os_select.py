"""
OSSelectView  –  Step 2 of /create (and still used by /claim free)
Picks OS then deploys the container or KVM/QEMU VM.
"""

import discord
import logging
import re
import asyncio
from typing import Optional

from core.config import OS_OPTIONS, ASM, VPS_PREFIX
from core.lxc import deploy_container
from core.cloudflare import create_cloudflare_subdomain
from core.database import get_db, save_vps_data
from core.theme import create_info_embed, create_success_embed, create_error_embed, add_field, Theme
from animation import animate_embed
from datetime import datetime

logger = logging.getLogger("moonnodes_vps_bot")

# ── Extra OS options for VMs (KVM supports broader range) ────────────────────
VM_EXTRA_OPTIONS = [
    {"label": "Windows Server 2022",    "value": "images:windows/2022",    "emoji": "🪟", "desc": "Full Windows Server (KVM only)"},
    {"label": "FreeBSD 14",             "value": "images:freebsd/14",      "emoji": "😈", "desc": "FreeBSD 14 (KVM only)"},
    {"label": "Alpine Linux (VM)",      "value": "images:alpine/edge",     "emoji": "🏔️", "desc": "Alpine Linux edge (KVM)"},
]


class OSSelectView(discord.ui.View):
    def __init__(
        self,
        ram: int,
        cpu: int,
        disk: int,
        user: discord.Member,
        invoker,
        plan_name: str = "Custom",
        validity_days: Optional[int] = None,
        target_node: str = "",
        storage_pool: str = "default",
        dm_user_on_deploy: bool = False,
        vm_mode: bool = False,
    ):
        super().__init__(timeout=300)
        self.ram               = ram
        self.cpu               = cpu
        self.disk              = disk
        self.user              = user
        self.invoker           = invoker
        self.plan_name         = plan_name
        self.validity_days     = validity_days
        self.target_node       = target_node
        self.storage_pool      = storage_pool
        self.dm_user_on_deploy = dm_user_on_deploy
        self.vm_mode           = vm_mode

        # Build OS options — add VM-only extras when vm_mode
        base_options = list(OS_OPTIONS)
        if vm_mode:
            base_options = base_options + VM_EXTRA_OPTIONS

        select = discord.ui.Select(
            placeholder=f"▼  Step {'3' if not vm_mode else '3'} – Select an Operating System",
            options=[
                discord.SelectOption(
                    label=o["label"],
                    value=o["value"],
                    description=o.get("desc", ""),
                    emoji=o.get("emoji", "💿"),
                )
                for o in base_options
            ],
        )
        select.callback = self._on_select
        self.add_item(select)

    async def _on_select(self, interaction: discord.Interaction):
        if str(interaction.user.id) != str(self.invoker.user.id):
            return await interaction.response.send_message(
                embed=create_error_embed("Error", "You cannot select the OS for someone else's VPS."),
                ephemeral=True,
            )

        os_version = interaction.data["values"][0]
        for item in self.children:
            item.disabled = True

        mode_label = "🖥️ KVM/QEMU VM" if self.vm_mode else "📦 LXC Container"
        await interaction.response.edit_message(
            embed=create_info_embed(
                f"{Theme.LOADING} Deploying {mode_label}",
                "🌙 Initialising your server…\n\nThis may take up to 2 minutes for VMs.",
            ),
            view=self,
        )

        # ── Animated deploy steps ─────────────────────────────────────────────
        anim_name = "deploy"
        frames = [
            "🔧 Initialising container…",
            "💾 Allocating disk…",
            "🌐 Attaching network…",
            f"{'🖥️ Booting KVM/QEMU VM' if self.vm_mode else '🚀 Starting container'}…",
            "✅ Almost ready…",
        ]
        async def _run_anim():
            for frame in frames:
                try:
                    await interaction.edit_original_response(
                        embed=create_info_embed(f"{Theme.LOADING} Deploying {mode_label}", frame),
                    )
                    await asyncio.sleep(0.8 if not self.vm_mode else 1.5)
                except Exception:
                    break

        # Run animation concurrently with deploy
        anim_task   = asyncio.create_task(_run_anim())

        try:
            vps_info = await deploy_container(
                user_id      = str(self.user.id),
                username     = self.user.name,
                ram          = self.ram,
                cpu          = self.cpu,
                disk         = self.disk,
                os_version   = os_version,
                validity_days= self.validity_days,
                target_node  = self.target_node,
                storage_pool = self.storage_pool,
                vm_mode      = self.vm_mode,
            )
        except Exception as e:
            anim_task.cancel()
            logger.error(f"[deploy] VPS creation failed for {self.user.id}: {e}", exc_info=True)
            try:
                await interaction.edit_original_response(
                    embed=create_error_embed(
                        "Deployment Failed",
                        "```\n" + str(e)[:3000] + "\n```\n\nCheck bot logs for full traceback."
                    ),
                    view=None,
                )
            except Exception as edit_err:
                logger.error(f"[deploy] Could not edit interaction after failure: {edit_err}")
            return

        anim_task.cancel()
        container_name = vps_info["container_name"]

        # Assign VPS User role
        if interaction.guild:
            try:
                role = discord.utils.get(interaction.guild.roles, name="VPS User")
                if role:
                    await self.user.add_roles(role)
            except Exception:
                pass

        # Cloudflare ASM
        subdomain_url = "None"
        if ASM:
            clean = re.sub(r"[^a-zA-Z0-9-]", "", container_name).lower()
            result = await create_cloudflare_subdomain(clean)
            if result:
                subdomain_url = result

        # DB record
        try:
            conn = get_db()
            cur  = conn.cursor()
            cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (str(self.user.id),))
            conn.commit()
            conn.close()
        except Exception:
            pass

        # Success embed
        node_label  = self.target_node.rstrip(":") or "local"
        type_badge  = "🖥️ KVM/QEMU VM" if self.vm_mode else "📦 LXC Container"
        embed = create_success_embed(
            "🚀 VPS Deployed!",
            f"Your VPS `{container_name}` is online on node **{node_label}**.",
        )
        add_field(embed, "📦 Specs",
                  f"```yaml\nRAM:  {self.ram}GB\nCPU:  {self.cpu} Cores\nDisk: {self.disk}GB\nOS:   {os_version}\nType: {type_badge}\n```")
        add_field(embed, "🖥️ Node", f"`{node_label}`", True)
        if subdomain_url != "None":
            add_field(embed, "🌐 Domain", f"http://{subdomain_url}", True)
        if vps_info.get("expires_at") or vps_info.get("expiry"):
            exp_raw = vps_info.get("expires_at") or vps_info.get("expiry")
            try:
                ts = int(datetime.fromisoformat(exp_raw).timestamp())
                add_field(embed, "⏳ Expires", f"<t:{ts}:R>", True)
            except Exception:
                pass

        await interaction.edit_original_response(embed=embed, view=None)

        # ── DM owner — animated notification ─────────────────────────────────
        try:
            exp_str = ""
            if vps_info.get("expires_at") or vps_info.get("expiry"):
                exp_raw = vps_info.get("expires_at") or vps_info.get("expiry")
                try:
                    ts = int(datetime.fromisoformat(exp_raw).timestamp())
                    exp_str = f"\n**Expires:** <t:{ts}:R>"
                except Exception:
                    pass

            dm = discord.Embed(
                title="🚀  Your VPS is Ready!",
                description=(
                    f"Your **{type_badge}** has been deployed and is now **online**!\n\n"
                    f"**Container:** `{container_name}`\n"
                    f"**Node:** `{node_label}`"
                    + (f"\n**Domain:** `http://{subdomain_url}`" if subdomain_url != "None" else "")
                    + exp_str
                ),
                color=0x57F287,
                timestamp=datetime.now(),
            )
            dm.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
            dm.add_field(
                name="⚙️  Specifications",
                value=(
                    f"```yaml\n"
                    f"RAM:  {self.ram} GB\n"
                    f"CPU:  {self.cpu} Cores\n"
                    f"Disk: {self.disk} GB\n"
                    f"OS:   {os_version}\n"
                    f"Type: {'KVM/QEMU VM' if self.vm_mode else 'LXC Container'}\n"
                    f"```"
                ),
                inline=False,
            )
            dm.add_field(
                name="🎮  Quick Start",
                value=(
                    "`/manage` → **My VPS** → **🔑 SSH** to get console access\n"
                    "`/backup` to create your first snapshot\n"
                    "`/support` if you need any help"
                ),
                inline=False,
            )
            dm.set_footer(text="Welcome to MoonNodes! Enjoy your server.")
            await self.user.send(embed=dm)
        except Exception:
            pass
