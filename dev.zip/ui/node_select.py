"""
NodeSelectView  –  Step 1 of /create
Shows available LXD nodes (local + remotes).
On selection it hands off to OSSelectView (Step 2).
"""

import discord
from core.lxc import list_lxd_remotes, get_node_stats
from core.theme import create_info_embed, create_error_embed, Theme


class NodeSelectView(discord.ui.View):
    def __init__(
        self,
        invoker_id: str,
        ram: int,
        cpu: int,
        disk: int,
        target_user: discord.Member,
        plan_name: str,
        validity_days,
        storage_pool: str,
    ):
        super().__init__(timeout=120)
        self.invoker_id   = invoker_id
        self.ram          = ram
        self.cpu          = cpu
        self.disk         = disk
        self.target_user  = target_user
        self.plan_name    = plan_name
        self.validity_days = validity_days
        self.storage_pool = storage_pool

    # ── We build the dropdown dynamically in a classmethod ──────────────────

    @classmethod
    async def create(cls, invoker_id, ram, cpu, disk, target_user,
                     plan_name, validity_days, storage_pool):
        self = cls(invoker_id, ram, cpu, disk, target_user,
                   plan_name, validity_days, storage_pool)

        remotes = await list_lxd_remotes()
        nodes   = ["local"] + remotes

        options = []
        for node in nodes:
            stats = await get_node_stats(node)
            ram_used  = stats["used_ram_mb"]
            ram_total = stats["total_ram_mb"]
            ram_pct   = stats["ram_pct"]
            cpu_pct   = stats["cpu_pct"]
            vps_c     = stats["vps_count"]
            vps_r     = stats["vps_running"]

            if ram_total > 0:
                ram_desc = f"RAM {ram_used}MB/{ram_total}MB ({ram_pct}%) | CPU {cpu_pct}% | VPS {vps_r}/{vps_c}"
            else:
                ram_desc = f"VPS {vps_r}/{vps_c} running"

            label = f"{'🏠 Local' if node == 'local' else f'🌐 {node}'}"
            options.append(
                discord.SelectOption(
                    label=label[:100],
                    value=node,
                    description=ram_desc[:100],
                    emoji="🖥️",
                )
            )

        if not options:
            options = [discord.SelectOption(label="local", value="local", emoji="🏠")]

        select = discord.ui.Select(
            placeholder="▼  Step 1 – Select a Node",
            options=options,
            min_values=1,
            max_values=1,
        )
        select.callback = self._on_select
        self.add_item(select)
        return self

    async def _on_select(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.invoker_id:
            return await interaction.response.send_message("Not your action.", ephemeral=True)

        chosen_node = interaction.data["values"][0]
        node_prefix = "" if chosen_node == "local" else f"{chosen_node}:"

        from ui.os_select import OSSelectView
        view = OSSelectView(
            ram=self.ram,
            cpu=self.cpu,
            disk=self.disk,
            user=self.target_user,
            invoker=interaction,
            plan_name=self.plan_name,
            validity_days=self.validity_days,
            target_node=node_prefix,
            storage_pool=self.storage_pool,
        )

        await interaction.response.edit_message(
            embed=create_info_embed(
                f"Step 2 – Select OS",
                f"Node: **{chosen_node}** | Plan: **{self.plan_name}**"
            ),
            view=view,
        )
