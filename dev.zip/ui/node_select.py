"""
ui/node_select.py — Step 1 of /create and /claim

Shows registered nodes with live RAM/CPU/Disk stats.
Nodes are filtered by their `section` setting:
  - free    → shown only to Free-plan (MoonCoin/Invite/Giveaway) deployments
  - premium → shown only to Premium deployments
  - all     → always shown

On selection → hands off to OSSelectView (Step 2).
"""
import discord
from datetime import datetime

from core.lxc import list_lxd_remotes, get_node_stats
from core.database import get_setting
from core.theme import Theme, create_info_embed, create_error_embed


def _all_nodes() -> list:
    raw    = get_setting("registered_nodes") or ""
    extras = [n.strip() for n in raw.split(",") if n.strip()]
    return ["local"] + extras


def _node_section(node: str) -> str:
    if node == "local": return "admin"  # local is always admin-only
    return (get_setting(f"node_section_{node}") or "all").lower()


def _plan_type_to_section(plan_type: str) -> str:
    """
    Map a plan type string → which nodes to show:
      free / coin / inv / giveaway → 'free' + 'all'
      premium                      → 'premium' + 'all'
      None / admin                 → all nodes
    """
    pt = (plan_type or "all").lower()
    if pt in ("free", "coin", "inv", "invite", "giveaway"):
        return "free"
    if pt == "premium":
        return "premium"
    return "all"


class NodeSelectView(discord.ui.View):
    def __init__(
        self,
        invoker_id:    str,
        ram:           int,
        cpu:           int,
        disk:          int,
        target_user:   discord.User,
        plan_name:     str,
        validity_days,
        storage_pool:  str,
        plan_type:     str = None,
        dm_user_on_deploy: bool = False,
        vm_mode:       bool = False,
    ):
        super().__init__(timeout=180)
        self.invoker_id        = invoker_id
        self.ram               = ram
        self.cpu               = cpu
        self.disk              = disk
        self.target_user       = target_user
        self.plan_name         = plan_name
        self.validity_days     = validity_days
        self.storage_pool      = storage_pool
        self.plan_type         = plan_type
        self.dm_user_on_deploy = dm_user_on_deploy
        self.vm_mode           = vm_mode

    @classmethod
    async def create(
        cls,
        invoker_id:    str,
        ram:           int,
        cpu:           int,
        disk:          int,
        target_user:   discord.User,
        plan_name:     str,
        validity_days,
        storage_pool:  str,
        plan_type:     str = None,
        dm_user_on_deploy: bool = False,
        vm_mode:       bool = False,
    ):
        self = cls(
            invoker_id        = invoker_id,
            ram               = ram,
            cpu               = cpu,
            disk              = disk,
            target_user       = target_user,
            plan_name         = plan_name,
            validity_days     = validity_days,
            storage_pool      = storage_pool,
            plan_type         = plan_type,
            dm_user_on_deploy = dm_user_on_deploy,
            vm_mode           = vm_mode,
        )
        await self._build_select()
        return self

    async def _build_select(self):
        """Build the node dropdown with live stats, filtered by section."""
        self.clear_items()

        required_section = _plan_type_to_section(self.plan_type)
        nodes            = _all_nodes()

        # Filter: node must be "all" OR match the required section
        # "admin" nodes only show when required_section is "all" (admin deploying)
        visible = []
        for node in nodes:
            sec = _node_section(node)
            if sec == "admin" and required_section != "all":
                continue  # hide admin-only nodes from user-facing claims
            if required_section == "all" or sec == "all" or sec == required_section:
                visible.append(node)

        if not visible:
            visible = ["local"]

        options = []
        for node in visible:
            try:
                s    = await get_node_stats(node)
                r_u  = s["used_ram_mb"]
                r_t  = s["total_ram_mb"]
                r_p  = s["ram_pct"]
                c_p  = s["cpu_pct"]
                v_r  = s["vps_running"]
                v_c  = s["vps_count"]
                c_a  = s["cpu_cores"]
                sec  = _node_section(node)
                sec_icons = {"free": "🌙", "premium": "💎", "all": "🌐"}
                sec_icon  = sec_icons.get(sec, "🌐")

                if node == "local":
                    label = "🔒  Local — Admin Only"
                else:
                    label = f"🌐  {node}"

                # Measure ping to node
                ping_ms = "?"
                if node != "local":
                    try:
                        import subprocess as _sp
                        pr = _sp.run(["ping","-c","1","-W","2", node.split(":")[0]],
                            capture_output=True, text=True, timeout=4)
                        m = __import__("re").search(r"time=([\d.]+)", pr.stdout)
                        if m: ping_ms = f"{float(m.group(1)):.0f}ms"
                    except Exception: pass

                ping_str = f" · 📶 {ping_ms}" if node != "local" else ""

                if r_t > 0:
                    desc = f"{sec_icon} RAM {r_u}MB/{r_t}MB ({r_p}%) · CPU {c_p}% ({c_a}c) · VPS {v_r}/{v_c}{ping_str}"
                else:
                    desc = f"{sec_icon} VPS {v_r}/{v_c} running{ping_str}"

                options.append(discord.SelectOption(
                    label       = label[:100],
                    value       = node,
                    description = desc[:100],
                    emoji       = "🖥️",
                ))
            except Exception:
                options.append(discord.SelectOption(
                    label="🖥️  " + (node.title() if node != "local" else "Local — Main Host"),
                    value=node,
                    description="Stats unavailable",
                    emoji="🖥️",
                ))

        select = discord.ui.Select(
            placeholder = "▼  Step 1 — Select a Node",
            options     = options,
            min_values  = 1,
            max_values  = 1,
        )
        select.callback = self._on_select
        self.add_item(select)

    async def _on_select(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.invoker_id:
            return await interaction.response.send_message(
                "This node selector belongs to someone else.", ephemeral=True)

        chosen_node = interaction.data["values"][0]

        from ui.os_select import OSSelectView

        os_view = OSSelectView(
            ram               = self.ram,
            cpu               = self.cpu,
            disk              = self.disk,
            user              = self.target_user,
            invoker           = interaction,
            plan_name         = self.plan_name,
            validity_days     = self.validity_days,
            target_node       = chosen_node,
            storage_pool      = self.storage_pool,
            dm_user_on_deploy = self.dm_user_on_deploy,
            vm_mode           = self.vm_mode,
        )

        node_label = "Local" if chosen_node == "local" else chosen_node
        type_label = "🖥️ KVM/QEMU VM" if self.vm_mode else "📦 LXC Container"
        await interaction.response.edit_message(
            embed=create_info_embed(
                "Step 2 — Select Operating System",
                (
                    f"**Node:** `{node_label}` ✅\n"
                    f"**Plan:** `{self.plan_name}`\n"
                    f"**Type:** {type_label}\n"
                    f"**Specs:** `{self.ram}GB RAM · {self.cpu} CPU · {self.disk}GB Disk`\n\n"
                    "Now choose the operating system for this VPS:"
                ),
            ),
            view=os_view,
        )
