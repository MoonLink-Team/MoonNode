import discord
from core.database import get_db
from core.config import A2FA


class ConfirmView(discord.ui.View):
    def __init__(self, user_id: str, requires_2fa: bool = False):
        super().__init__(timeout=60)
        self.user_id     = user_id
        self.requires_2fa = requires_2fa
        self.value        = False

    @discord.ui.button(label="Confirm", style=discord.ButtonStyle.danger, emoji="✅")
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        if str(interaction.user.id) != self.user_id:
            return await interaction.response.send_message("Not your action.", ephemeral=True)

        if self.requires_2fa and A2FA:
            conn = get_db()
            cur  = conn.cursor()
            cur.execute("SELECT pin FROM admins WHERE user_id=?", (self.user_id,))
            row = cur.fetchone()
            stored_pin = row["pin"] if row else "0000"
            if stored_pin and stored_pin != "0000":
                await interaction.response.send_message(
                    "🔐 Enter your 4-digit A2FA PIN:", ephemeral=True
                )
                def check(m):
                    return m.author.id == interaction.user.id and m.channel == interaction.channel

                try:
                    msg = await interaction.client.wait_for("message", check=check, timeout=30)
                    await msg.delete()
                    if msg.content != stored_pin:
                        self.value = False
                        self.stop()
                        return await interaction.followup.send("❌ Wrong PIN. Action cancelled.", ephemeral=True)
                except Exception:
                    self.value = False
                    self.stop()
                    return

        self.value = True
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(view=self)
        self.stop()

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary, emoji="❌")
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        if str(interaction.user.id) != self.user_id:
            return await interaction.response.send_message("Not your action.", ephemeral=True)
        self.value = False
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(view=self)
        self.stop()
