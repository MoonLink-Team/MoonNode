import discord
from core.theme import create_info_embed


# ── Plans payment picker ─────────────────────────────────────────────────────

class PaymentSelect(discord.ui.Select):
    def __init__(self, payments: list):
        options = [discord.SelectOption(label=p["name"], value=p["name"], emoji="💳") for p in payments]
        super().__init__(placeholder="▼ Select a Payment Method", options=options)
        self.payments = {p["name"]: p["image_url"] for p in payments}

    async def callback(self, interaction: discord.Interaction):
        selected  = self.values[0]
        image_url = self.payments[selected]
        embed = create_info_embed(
            f"Payment Method: {selected}",
            "Scan the QR code or use the details below to complete your payment.",
        )
        embed.set_image(url=image_url)
        try:
            await interaction.user.send(embed=embed)
            await interaction.response.send_message(
                f"✅ **{selected}** payment details sent to your DMs!", ephemeral=True
            )
        except discord.Forbidden:
            await interaction.response.send_message(
                "❌ Couldn't DM you. Check your privacy settings.", ephemeral=True
            )


class PlansView(discord.ui.View):
    def __init__(self, payments: list):
        super().__init__(timeout=None)
        if payments:
            self.add_item(PaymentSelect(payments))


# ── Giveaway view ────────────────────────────────────────────────────────────

class GiveawayView(discord.ui.View):
    def __init__(self, g_id: str):
        super().__init__(timeout=None)
        self.g_id     = g_id
        self.entrants: set = set()

    @discord.ui.button(label="Enter Giveaway", style=discord.ButtonStyle.success, emoji="🎉")
    async def enter(self, interaction: discord.Interaction, button: discord.ui.Button):
        from core.database import active_giveaways
        from core.theme import create_error_embed, create_warning_embed, create_success_embed
        if self.g_id not in active_giveaways:
            return await interaction.response.send_message(
                embed=create_error_embed("Giveaway Ended", "This giveaway is over."), ephemeral=True
            )
        if interaction.user.id in self.entrants:
            return await interaction.response.send_message(
                embed=create_warning_embed("Already Entered", "You are already in this giveaway."), ephemeral=True
            )
        self.entrants.add(interaction.user.id)
        await interaction.response.send_message(
            embed=create_success_embed("Joined!", "You have entered the giveaway!"), ephemeral=True
        )
