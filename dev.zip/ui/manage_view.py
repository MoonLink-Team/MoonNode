import discord
import asyncio
import time
from typing import Optional
from datetime import datetime

from core.database import vps_data, data_lock, async_save_vps_data
from core.lxc import execute_lxc, get_container_cpu_raw, get_container_memory_raw, get_container_disk, apply_advanced_permissions, RUNTIME
from core.theme import create_embed, create_success_embed, create_error_embed, create_info_embed, create_warning_embed, add_field, Theme
from core.ext import a2fa_enabled
from ui.confirm_view import ConfirmView

try:
    from core.config import ACTIVE_STORAGE_POOL_REF as _pool_ref
except (ImportError, AttributeError):
    _pool_ref = "default"


def _loading_embed(title, detail, step=1, total=4):
    bar   = "".join(["#" if j < step else "-" for j in range(total)])
    embed = discord.Embed(
        title="Loading: " + title,
        description=detail + "\n\n`[" + bar + "]` Step " + str(step) + "/" + str(total),
        color=0x5865F2,
    )
    embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
    embed.set_footer(text="Please wait...")
    return embed


class AdminVPSView(discord.ui.View):
    def __init__(self, user_id: str, vps: dict, owner_id: str):
        super().__init__(timeout=120)
        self.user_id  = user_id
        self.vps      = vps
        self.owner_id = owner_id

    @discord.ui.button(label="Whitelist Toggle", style=discord.ButtonStyle.secondary, emoji="🛡️")
    async def toggle_whitelist(self, interaction: discord.Interaction, button: discord.ui.Button):
        async with data_lock:
            self.vps["whitelisted"] = not self.vps.get("whitelisted", False)
        await async_save_vps_data()
        state = "ON" if self.vps["whitelisted"] else "OFF"
        await interaction.response.send_message(
            embed=create_success_embed("Whitelist", f"Anti-shutoff whitelist is now **{state}**."),
            ephemeral=True,
        )

    @discord.ui.button(label="Force Restart", style=discord.ButtonStyle.danger, emoji="🔁")
    async def force_restart(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        node   = self.vps.get("node", "local")
        prefix = f"{node}:" if node != "local" else ""
        full   = f"{prefix}{self.vps['container_name']}"
        try:
            await execute_lxc(f"lxc restart {full}")
            await interaction.followup.send(embed=create_success_embed("Restarted", f"`{full}` restarted."), ephemeral=True)
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Failed", str(e)[:2000]), ephemeral=True)


class ManageView(discord.ui.View):
    def __init__(self, user_id: str, vps_list: list, is_shared: bool = False,
                 owner_id: str = None, is_admin: bool = False, actual_index: Optional[int] = None):
        super().__init__(timeout=None)
        self.user_id        = user_id
        self.vps_list_init  = vps_list
        self.selected_index = None
        self.is_shared      = is_shared
        self.owner_id       = owner_id or user_id
        self.is_admin       = is_admin
        self.actual_index   = actual_index
        self.indices        = list(range(len(vps_list)))
        self.cooldowns: dict = {}

        if self.is_shared and self.actual_index is None:
            raise ValueError("actual_index required for shared VPS")

        if len(vps_list) > 1 and self.actual_index is None:
            options = [
                discord.SelectOption(label=f"VPS {i+1} ({v.get('config','Custom')})", value=str(i), emoji="🖥️")
                for i, v in enumerate(vps_list)
            ]
            sel = discord.ui.Select(placeholder="▼ Select a VPS to manage", options=options)
            sel.callback = self._select_vps
            self.add_item(sel)
            self.initial_embed = create_embed("🎛️ VPS Control Panel", "Select a VPS from the dropdown.")
        else:
            self.selected_index = 0
            self.initial_embed  = None
            self._add_action_buttons()

    def _check_cooldown(self, uid, action: str) -> bool:
        key = f"{uid}:{action}"
        if key in self.cooldowns and time.time() - self.cooldowns[key] < 5:
            return False
        self.cooldowns[key] = time.time()
        return True

    async def get_initial_embed(self):
        if self.initial_embed:
            return self.initial_embed
        return await self._build_embed(self.selected_index)

    def _get_vps(self, index: int):
        try:
            actual = self.actual_index if (self.is_shared or self.actual_index is not None) else self.indices[index]
            if self.owner_id in vps_data and len(vps_data[self.owner_id]) > actual:
                return vps_data[self.owner_id][actual], actual
        except Exception:
            pass
        return None, None

    async def _build_embed(self, index: int):
        vps, _ = self._get_vps(index)
        if not vps:
            return create_error_embed("Error", "Could not fetch VPS details.")

        name      = vps["container_name"]
        node      = vps.get("node", "local")
        status    = vps.get("status", "stopped")
        suspended = vps.get("suspended", False)

        color = Theme.get_status_color(status, suspended)
        if status == "running" and not suspended:
            status_text              = "RUNNING"
            indicator                = Theme.ONLINE
            cpu_val                  = await get_container_cpu_raw(name, node)
            mem_str, mem_val         = await get_container_memory_raw(name, node)
            disk_usage               = await get_container_disk(name, node)
        else:
            status_text = "SUSPENDED" if suspended else "STOPPED"
            indicator   = Theme.OFFLINE
            cpu_val, mem_val, mem_str, disk_usage = 0, 0, "0/0 MB", "Offline"

        embed = create_embed(f"🖥️ VPS: {name}", "", color)
        embed.add_field(name="📍 Status",  value=f"> {indicator} **{status_text}**",    inline=True)
        embed.add_field(name="⚙️ Specs",   value=f"> **{vps.get('config','Custom')}**", inline=True)
        embed.add_field(name="🌐 Node",    value=f"> **{node}**",                        inline=True)

        if vps.get("expires_at") or vps.get("expiry"):
            exp = vps.get("expiry") or vps.get("expires_at")
            try:
                ts = int(datetime.fromisoformat(exp).timestamp())
                embed.add_field(name="⏳ Expires", value=f"> <t:{ts}:R>", inline=True)
            except Exception:
                pass

        embed.add_field(name="\u200b", value=Theme.DIVIDER, inline=False)
        embed.add_field(name=f"{Theme.CPU} CPU",   value=Theme.progress_bar(cpu_val), inline=False)
        embed.add_field(name=f"{Theme.RAM} RAM",   value=f"{Theme.progress_bar(mem_val)}\n`{mem_str}`", inline=True)
        embed.add_field(name=f"{Theme.DISK} Disk", value=f"```\n{disk_usage}\n```", inline=True)
        return embed

    def _make_cb(self, action: str):
        async def cb(interaction: discord.Interaction):
            await self._action(interaction, action)
        return cb

    def _add_action_buttons(self):
        # Row 0
        if not self.is_shared:
            b = discord.ui.Button(label="Reinstall OS", style=discord.ButtonStyle.danger, emoji="🔄", row=0)
            b.callback = self._make_cb("reinstall")
            self.add_item(b)

        for label, action, style, emoji, row in [
            ("Start",         "start",   discord.ButtonStyle.success,   "▶️", 0),
            ("Stop",          "stop",    discord.ButtonStyle.secondary,  "⏸️", 0),
            ("SSH",           "tmate",   discord.ButtonStyle.primary,    "🔑", 0),
            ("Refresh Stats", "stats",   discord.ButtonStyle.secondary,  "🔄", 0),
            ("Console Logs",  "console", discord.ButtonStyle.secondary,  "💻", 1),
            # "Install Software" button REMOVED
        ]:
            b = discord.ui.Button(label=label, style=style, emoji=emoji, row=row)
            b.callback = self._make_cb(action)
            self.add_item(b)

        if self.is_admin:
            b = discord.ui.Button(label="Admin Panel", style=discord.ButtonStyle.danger, emoji="🛡️", row=1)
            b.callback = self._open_admin_panel
            self.add_item(b)

    async def _select_vps(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.user_id and not self.is_admin:
            return await interaction.response.send_message("Permission denied.", ephemeral=True)
        await interaction.response.defer()
        self.selected_index = int(interaction.data["values"][0])
        self.clear_items()
        self._add_action_buttons()
        embed = await self._build_embed(self.selected_index)
        await interaction.edit_original_response(embed=embed, view=self)

    async def _open_admin_panel(self, interaction: discord.Interaction):
        vps, _ = self._get_vps(self.selected_index or 0)
        if not vps:
            return
        view = AdminVPSView(str(interaction.user.id), vps, self.owner_id)
        await interaction.response.send_message(
            embed=create_warning_embed(f"🛡️ Admin Panel: {vps['container_name']}", "Use these controls carefully."),
            view=view, ephemeral=True,
        )

    async def _action(self, interaction: discord.Interaction, action: str):
        if str(interaction.user.id) != self.user_id and not self.is_admin:
            return await interaction.response.send_message("Permission denied.", ephemeral=True)

        vps, _ = self._get_vps(self.selected_index or 0)
        if not vps:
            return
        name   = vps["container_name"]
        node   = vps.get("node", "local")
        prefix = f"{node}:" if node != "local" else ""
        full   = f"{prefix}{name}"
        pool   = _pool_ref

        # ── Reinstall ────────────────────────────────────────────────────────
        if action == "reinstall":
            view = ConfirmView(self.user_id)
            await interaction.response.send_message(
                embed=create_warning_embed("Reinstall OS?", "⚠️ All files will be deleted permanently."),
                view=view, ephemeral=True,
            )
            await view.wait()
            if not view.value:
                return
            await interaction.edit_original_response(
                embed=create_info_embed(f"{Theme.LOADING} Reinstalling…", "Please wait…"), view=None
            )
            try:
                await execute_lxc(f"lxc delete {full} --force")
                if RUNTIME == "incus":
                    await execute_lxc(
                        f"lxc init {vps['os_version']} {full} -s {pool}"
                        f" --config security.privileged=true --config security.nesting=true"
                    )
                else:
                    await execute_lxc(f"lxc init {vps['os_version']} {full} -s {pool}")

                await execute_lxc(f"lxc config set {full} limits.memory {vps['ram']}")
                await execute_lxc(f"lxc config set {full} limits.cpu {vps['cpu']}")
                try:
                    await execute_lxc(
                        f"lxc config device add {full} root disk path=/ pool={pool} size={vps['storage']}"
                    )
                except Exception:
                    pass
                await apply_advanced_permissions(full)
                await execute_lxc(f"lxc start {full}")
                async with data_lock:
                    vps["status"]    = "running"
                    vps["suspended"] = False
                await async_save_vps_data()
                await interaction.followup.send(embed=create_success_embed("Reinstall Complete", "VPS reinstalled successfully."), ephemeral=True)
            except Exception as e:
                await interaction.followup.send(embed=create_error_embed("Reinstall Failed", str(e)[:4000]), ephemeral=True)

        # ── Start ─────────────────────────────────────────────────────────────
        elif action == "start":
            if not self._check_cooldown(interaction.user.id, "start"):
                return await interaction.response.send_message("Please wait a few seconds.", ephemeral=True)
            await interaction.response.defer(ephemeral=True)
            try:
                await execute_lxc(f"lxc start {full}")
                async with data_lock:
                    vps["status"] = "running"
                await async_save_vps_data()
                await interaction.followup.send(embed=create_success_embed("Started", f"`{name}` is running."), ephemeral=True)
            except Exception as e:
                await interaction.followup.send(embed=create_error_embed("Failed", str(e)[:4000]), ephemeral=True)

        # ── Stop ──────────────────────────────────────────────────────────────
        elif action == "stop":
            if not self._check_cooldown(interaction.user.id, "stop"):
                return await interaction.response.send_message("Please wait a few seconds.", ephemeral=True)
            await interaction.response.defer(ephemeral=True)
            try:
                await execute_lxc(f"lxc stop {full}")
                async with data_lock:
                    vps["status"] = "stopped"
                await async_save_vps_data()
                await interaction.followup.send(embed=create_success_embed("Stopped", f"`{name}` stopped."), ephemeral=True)
            except Exception as e:
                await interaction.followup.send(embed=create_error_embed("Failed", str(e)[:4000]), ephemeral=True)

        # ── Stats ─────────────────────────────────────────────────────────────
        elif action == "stats":
            await interaction.response.defer(ephemeral=True)
            embed = await self._build_embed(self.selected_index or 0)
            await interaction.edit_original_response(embed=embed, view=self)
            await interaction.followup.send(embed=create_info_embed("Refreshed", "Stats updated."), ephemeral=True)

        # ── Console logs ──────────────────────────────────────────────────────
        elif action == "console":
            await interaction.response.defer(ephemeral=True)
            try:
                from core.lxc import IS_INCUS
                cmd  = f"incus info {full} --show-log" if IS_INCUS else f"lxc info {full} --show-log"
                logs = await execute_lxc(cmd)
                raw  = str(logs) if logs and logs is not True else ""

                # Filter out loopback/lo interface noise and kernel noise
                skip_prefixes = (
                    "lo:", "Type: loopback", "State: UP", "MTU:", "Bytes received:",
                    "Bytes sent:", "Packets received:", "Packets sent:", "IP addresses:",
                    "inet:  127.", "inet6: ::1/",
                    "lxc.cgroup2", "bpf_program", "Failed to load bpf",
                    "Operation not permitted",
                )
                lines = []
                for line in raw.splitlines():
                    stripped = line.strip()
                    if any(stripped.startswith(p) or p in stripped for p in skip_prefixes):
                        continue
                    lines.append(line)

                # Show last 25 meaningful lines
                lines = [l for l in lines if l.strip()][-25:]
                text  = "\n".join(lines) if lines else "No console output recorded."

                embed = create_info_embed(
                    "🖥️ Console Output",
                    f"```\n{text[:3800]}\n```"
                )
                embed.set_footer(text=f"{name} · Loopback and kernel noise filtered · MoonNodes")
                await interaction.followup.send(embed=embed, ephemeral=True)
            except Exception as e:
                await interaction.followup.send(embed=create_error_embed("Console Error", str(e)[:2000]), ephemeral=True)

        # ── SSH (tmate) ───────────────────────────────────────────────────────
        elif action == "tmate":
            await interaction.response.defer(ephemeral=True)
            msg = await interaction.followup.send(
                embed=_loading_embed("Setting up SSH", "Checking network…", step=1, total=4),
                ephemeral=True,
            )
            try:
                has_net = False
                try:
                    await execute_lxc(f"lxc exec {full} -- ping -c 1 -W 3 8.8.8.8", timeout=6)
                    has_net = True
                except Exception:
                    pass

                if not has_net:
                    import subprocess as _sp
                    from core.lxc import IS_INCUS, RUNTIME_BIN
                    net_cmd = "incusbr0" if IS_INCUS else "lxdbr0"
                    await msg.edit(embed=create_info_embed(
                        "🔧 Auto-fixing network…",
                        "No internet detected — attempting automatic repair…"
                    ))
                    _fixed = False
                    try:
                        # Step 1 — ensure incus-managed network exists (has dnsmasq/DHCP)
                        _nr = _sp.run([RUNTIME_BIN, "network", "show", net_cmd],
                            capture_output=True, text=True, timeout=5)
                        if _nr.returncode != 0:
                            _sp.run([RUNTIME_BIN, "network", "create", net_cmd],
                                capture_output=True, text=True, timeout=20)
                        # Step 2 — re-attach NIC using managed network (enables DHCP)
                        _sp.run([RUNTIME_BIN, "config", "device", "remove", full, "eth0"],
                            capture_output=True, text=True, timeout=10)
                        _sp.run([RUNTIME_BIN, "config", "device", "add", full, "eth0",
                            "nic", f"network={net_cmd}", "name=eth0"],
                            capture_output=True, text=True, timeout=10)
                        # Step 3 — restart container
                        _sp.run([RUNTIME_BIN, "restart", full],
                            capture_output=True, text=True, timeout=60)
                        await asyncio.sleep(5)
                        # Step 4 — inject netplan DHCP config so IP persists across reboots
                        _netplan = (
                            "network:\n"
                            "  version: 2\n"
                            "  ethernets:\n"
                            "    eth0:\n"
                            "      dhcp4: true\n"
                        )
                        _sp.run(
                            [RUNTIME_BIN, "exec", full, "--", "bash", "-c",
                             f'printf "{_netplan}" > /etc/netplan/99-moonnodes-eth0.yaml '
                             f'&& chmod 600 /etc/netplan/99-moonnodes-eth0.yaml '
                             f'&& netplan apply'],
                            capture_output=True, text=True, timeout=20
                        )
                        await asyncio.sleep(3)
                        # Step 5 — verify
                        _ping = _sp.run(
                            [RUNTIME_BIN, "exec", full, "--", "ping", "-c", "1", "-W", "3", "8.8.8.8"],
                            capture_output=True, text=True, timeout=8
                        )
                        _fixed = (_ping.returncode == 0)
                    except Exception as _fe:
                        pass
                    if _fixed:
                        has_net = True
                        await msg.edit(embed=create_info_embed(
                            "✅ Network restored", "Continuing SSH setup…"
                        ))
                    else:
                        await msg.edit(embed=create_error_embed(
                            "❌ Network repair failed",
                            f"Could not restore internet access for `{name}`.\n"
                            f"Contact an admin and provide the container name."
                        ))
                        return

                import subprocess as _sp, random as _rand, string as _str
                from core.config import HOST_PUBLIC_IP
                from core.lxc import RUNTIME_BIN

                await msg.edit(embed=create_info_embed(
                    f"{Theme.LOADING} Setting up SSH…", "Installing SSH server inside VPS…"
                ))

                # ── 1. Install openssh-server inside container ────────────────
                try:
                    await execute_lxc(f"lxc exec {full} -- apt-get install -y openssh-server", timeout=180)
                except Exception as _ie:
                    return await msg.edit(embed=create_error_embed("SSH Setup Failed", f"Could not install SSH server: {str(_ie)[:500]}"))

                # ── 2. Allow root login + set random password ─────────────────
                _pw = "".join(_rand.choices(_str.ascii_letters + _str.digits, k=20))
                try:
                    _sshcfg = (
                        "sed -i 's/^#*PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config"
                        f" && echo 'root:{_pw}' | chpasswd"
                        " && systemctl enable --now ssh"
                    )
                    await execute_lxc(
                        f"lxc exec {full} -- bash -c '{_sshcfg}'",
                        timeout=30
                    )
                except Exception as _ce:
                    return await msg.edit(embed=create_error_embed("SSH Setup Failed", str(_ce)[:500]))

                # ── 3. Pick random host port + add Incus proxy device ─────────
                # Remove any previous SSH proxy for this VPS (ignore errors)
                _sp.run([RUNTIME_BIN, "config", "device", "remove", full, "moonnode-ssh"],
                    capture_output=True, text=True, timeout=10)
                _port = _rand.randint(20000, 40000)
                _proxy = _sp.run(
                    [RUNTIME_BIN, "config", "device", "add", full, "moonnode-ssh", "proxy",
                     f"listen=tcp:0.0.0.0:{_port}", "connect=tcp:127.0.0.1:22", "nat=true"],
                    capture_output=True, text=True, timeout=15
                )
                if _proxy.returncode != 0:
                    return await msg.edit(embed=create_error_embed(
                        "SSH Setup Failed",
                        f"Could not forward port: {_proxy.stderr.strip()[:400]}"
                    ))

                # ── 4. Show credentials ───────────────────────────────────────
                _host = HOST_PUBLIC_IP or "YOUR_SERVER_IP"
                embed = create_success_embed("🔑 SSH Ready")
                embed.add_field(
                    name="SSH Command",
                    value=f"```\nssh root@{_host} -p {_port}\n```",
                    inline=False
                )
                embed.add_field(name="Password", value=f"```\n{_pw}\n```", inline=False)
                embed.add_field(
                    name="⚠️ Security",
                    value="Change your password after login with `passwd`. Do not share these credentials.",
                    inline=False
                )
                await msg.edit(embed=embed)
            except Exception as e:
                try:
                    await msg.edit(embed=create_error_embed("SSH Error", str(e)[:4000]))
                except Exception:
                    pass
