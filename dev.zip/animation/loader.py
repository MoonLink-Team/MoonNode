"""
animation/loader.py — Named animation frame sets.

Rules:
  - Add new files as  animation/{name}.py  (each defines FRAMES list)
  - MoonCoin TRANSFER animation is intentionally absent (transfers not animated)
  - All other MoonCoin animations (earn, spend, view) are fine
"""

import importlib
import logging
from typing import Optional
import discord

logger = logging.getLogger("moonnodes_vps_bot")

# ── Built-in frame sets ───────────────────────────────────────────────────────

FRAMES: dict[str, list[str]] = {
    # Generic loading
    "loading": ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"],
    # VPS deploy
    "deploy": [
        "🔧 Initialising container…",
        "💾 Allocating disk…",
        "🌐 Attaching network…",
        "🚀 Starting container…",
        "✅ Almost ready…",
    ],
    # Bot startup
    "startup": [
        "🌙 MoonNodes waking up…",
        "🔌 Connecting to Discord…",
        "🗄️ Loading database…",
        "⚙️ Registering commands…",
        "✅ Ready!",
    ],
    # MoonCoin earn
    "mooncoin_earn": ["🌕", "🌖", "🌗", "🌘", "🌑", "🌒", "🌓", "🌔"],
    # MoonCoin spend
    "mooncoin_spend": ["💸", "🌙", "✨", "💫"],
    # MoonCoin view (balance)
    "mooncoin_view": ["🌙", "💰", "📊"],
    # Suspend
    "suspend": ["🔴 Suspending…", "🔒 Locking VPS…", "✅ Suspended."],
    # AF2F prompt
    "af2f": ["🔐", "🛡️", "🔑", "✅"],
    # First boot
    "first_boot": [
        "🌙 First boot detected…",
        "📦 Loading MoonNodes…",
        "🛡️ Preparing setup…",
        "✅ Ready for configuration!",
    ],
}

# NOTE: "mooncoin_transfer" is intentionally NOT in FRAMES.
# MoonCoin transfers are not animated by design.


def get_frames(name: str) -> list[str]:
    """
    Return frames for animation `name`.
    First checks animation/{name}.py for a custom FRAMES list,
    then falls back to built-in FRAMES dict.
    """
    # Try custom animation file
    try:
        mod = importlib.import_module(f"animation.{name}")
        if hasattr(mod, "FRAMES") and isinstance(mod.FRAMES, list):
            return mod.FRAMES
    except ModuleNotFoundError:
        pass
    except Exception as e:
        logger.warning(f"[animation] load {name}: {e}")

    # Built-in
    frames = FRAMES.get(name)
    if frames:
        return frames

    logger.debug(f"[animation] unknown set '{name}', using loading")
    return FRAMES["loading"]


async def animate_embed(
    interaction: discord.Interaction,
    name: str,
    title: str,
    color: int = 0x5865F2,
    delay: float = 0.6,
    final_embed: Optional[discord.Embed] = None,
):
    """
    Edit the interaction response through animation frames, then
    optionally swap to final_embed when done.

    Usage:
        await interaction.response.defer()
        await animate_embed(interaction, "deploy", "Deploying VPS…", final_embed=success_embed)
    """
    import asyncio
    frames = get_frames(name)
    for frame in frames:
        try:
            e = discord.Embed(title=title, description=frame, color=color)
            e.set_author(name="MoonNodes VPS Manager",
                         icon_url="https://imgur.com/6yfYDTP.png")
            await interaction.edit_original_response(embed=e)
            await asyncio.sleep(delay)
        except Exception:
            break
    if final_embed:
        try:
            await interaction.edit_original_response(embed=final_embed)
        except Exception:
            pass
