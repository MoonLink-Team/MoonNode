"""animation/ — Named animation frame sets for MoonNodes bot messages.

Add new animations:  animation/{name}.py  with a  FRAMES = [...]  list.
MoonCoin transfer animation is intentionally NOT supported.
"""
from .loader import get_frames, animate_embed

__all__ = ["get_frames", "animate_embed"]
