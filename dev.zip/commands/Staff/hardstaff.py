"""
/hardstaff — Commands exclusive to Hard Staff and above.
"""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock, get_db
from core.theme import Theme, add_field, create_error_embed, create_info_embed, create_success_embed

HARD_STAFF_ROLES = {"Owner", "Hard Admin", "Admin", "Manager", "Hard Mod", "Mod", "Hard Staff"}


def is_hard_staff(uid):
    if str(uid) == str(MAIN_ADMIN_ID): return True
    return admin_data.get(str(uid), "") in HARD_STAFF_ROLES


def has_hard_staff():
    async def predicate(interaction: discord.Interaction):
        if is_hard_staff(interaction.user.id): return True
        raise app_commands.CheckFailure("no_permission")
    return app_commands.check(predicate)


class DMModal(discord.ui.Modal, title="✉️ Send Staff DM"):
    message = discord.ui.TextInput(label="Message", style=discord.TextStyle.paragraph, max_length=1000)
    async def on_submit(self, interaction: discord.Interaction):
        self._val = self.message.value
        await interaction.response.defer()


class HardStaffCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="hardstaff", description="[HARD STAFF+] Extended staff tools")
    @app_commands.choices(action=[
        app_commands.Choice(name="🔍 User Info — Full profile: VPS, coins, warns",          value="user_info"),
        app_commands.Choice(name="🖥️ VPS Info — Details for a specific container",           value="vps_info"),
        app_commands.Choice(name="📋 List VPS — All VPS owned by a user",                   value="list_vps"),
        app_commands.Choice(name="📊 Server Stats — Global VPS counts and node usage",      value="server_stats"),
        app_commands.Choice(name="📋 Open Tickets — All open support threads",              value="open_tickets"),
        app_commands.Choice(name="📜 Suspension Logs — Recent VPS suspension history",      value="suspension_logs"),
        app_commands.Choice(name="✉️ DM User — Send a staff message to any user",           value="dm_user"),
        app_commands.Choice(name="⚠️ Warn User — Issue a formal warning",                   value="warn"),
        app_commands.Choice(name="📜 Warn Log — View a user's warning history",             value="warn_log"),
    ])
    @app_commands.describe(
        action          = "Action to perform",
        target_user     = "Target user (@mention)",
        container_name  = "Container name (VPS Info only)",
        message         = "Message text (DM / Warn)",
    )
    @has_hard_staff()
    async def hardstaff_cmd(
        self, interaction: discord.Interaction,
        action:         str,
        target_user:    discord.Member = None,
        container_name: str            = None,
        message:        str            = None,
    ):
        await interaction.response.defer(ephemeral=True)

        # ── User Info ─────────────────────────────────────────────────────────
        if action == "user_info":
            if not target_user:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `target_user`."))
            tid  = str(target_user.id)
            conn = get_db(); cur = conn.cursor()
            cur.execute("SELECT mooncoin, total_referrals, invites_used FROM users WHERE user_id=?", (tid,))
            row  = cur.fetchone()
            cur.execute("SELECT COUNT(*) as cnt FROM warnings WHERE user_id=?", (tid,))
            wrow = cur.fetchone()
            async with data_lock:
                vlist = vps_data.get(tid, [])
            role  = admin_data.get(tid, "User")
            coins = row["mooncoin"] if row else 0
            warns = wrow["cnt"] if wrow else 0
            embed = discord.Embed(title=f"🔍 User Profile — {target_user.display_name}",
                color=0x5865F2, timestamp=datetime.now())
            embed.set_author(name="MoonNodes Hard Staff", icon_url="https://imgur.com/6yfYDTP.png")
            embed.set_thumbnail(url=target_user.display_avatar.url)
            add_field(embed, "👤 User",      f"{target_user.mention}\n`{tid}`",         True)
            add_field(embed, "🎭 Role",      role,                                       True)
            add_field(embed, "🌙 Coins",     f"**{coins:,}** MoonCoins",                 True)
            add_field(embed, "🖥️ VPS Count", f"**{len(vlist)}** VPS",                    True)
            add_field(embed, "⚠️ Warnings",  f"**{warns}** on record",                   True)
            if vlist:
                vps_lines = "\n".join(f"› `{v['container_name']}` — {v.get('status','?').upper()}" for v in vlist[:5])
                add_field(embed, "📦 VPS List", vps_lines, False)
            await interaction.followup.send(embed=embed)

        # ── VPS Info ──────────────────────────────────────────────────────────
        elif action == "vps_info":
            if not container_name:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `container_name`."))
            found = None; owner_id = None
            async with data_lock:
                for uid2, lst in vps_data.items():
                    for v in lst:
                        if v.get("container_name") == container_name:
                            found = v; owner_id = uid2; break
            if not found:
                return await interaction.followup.send(embed=create_error_embed("Not Found", f"`{container_name}` not in database."))
            embed = discord.Embed(title=f"🖥️ VPS — {container_name}", color=0x5865F2, timestamp=datetime.now())
            embed.set_author(name="MoonNodes Hard Staff", icon_url="https://imgur.com/6yfYDTP.png")
            add_field(embed, "Owner",   f"<@{owner_id}> (`{owner_id}`)", True)
            add_field(embed, "Status",  found.get("status","?").upper(), True)
            add_field(embed, "Node",    found.get("node","local"),        True)
            add_field(embed, "Specs",   found.get("config","?"),          True)
            add_field(embed, "OS",      found.get("os_version","?"),      True)
            exp = found.get("expiry") or found.get("expires_at")
            if exp:
                try:
                    ts = int(datetime.fromisoformat(exp).timestamp())
                    add_field(embed, "Expires", f"<t:{ts}:R>", True)
                except Exception: pass
            await interaction.followup.send(embed=embed)

        # ── List VPS ──────────────────────────────────────────────────────────
        elif action == "list_vps":
            if not target_user:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `target_user`."))
            tid = str(target_user.id)
            async with data_lock:
                vlist = list(vps_data.get(tid, []))
            if not vlist:
                return await interaction.followup.send(embed=create_info_embed("No VPS", f"{target_user.mention} has no VPS."))
            embed = discord.Embed(title=f"📋 VPS List — {target_user.display_name}",
                description=f"**{len(vlist)}** VPS instance(s)", color=0x5865F2, timestamp=datetime.now())
            embed.set_author(name="MoonNodes Hard Staff", icon_url="https://imgur.com/6yfYDTP.png")
            for i, v in enumerate(vlist, 1):
                status = "🟢" if v.get("status") == "running" else ("🔴" if v.get("suspended") else "⚫")
                add_field(embed, f"{status} VPS #{i} — {v['container_name']}",
                    f"`{v.get('config','?')}` · Node: `{v.get('node','local')}`", False)
            await interaction.followup.send(embed=embed)

        # ── Server Stats ──────────────────────────────────────────────────────
        elif action == "server_stats":
            async with data_lock:
                total   = sum(len(v) for v in vps_data.values())
                running = sum(1 for lst in vps_data.values() for v in lst if v.get("status") == "running")
                suspended = sum(1 for lst in vps_data.values() for v in lst if v.get("suspended"))
                users   = len(vps_data)
            conn = get_db(); cur = conn.cursor()
            cur.execute("SELECT COUNT(*) as cnt FROM users"); urow = cur.fetchone()
            embed = discord.Embed(title="📊 Server Overview", color=0x5865F2, timestamp=datetime.now())
            embed.set_author(name="MoonNodes Hard Staff", icon_url="https://imgur.com/6yfYDTP.png")
            add_field(embed, "🖥️ Total VPS",   str(total),     True)
            add_field(embed, "🟢 Running",     str(running),   True)
            add_field(embed, "🔴 Suspended",   str(suspended), True)
            add_field(embed, "👥 VPS Owners",  str(users),     True)
            add_field(embed, "📋 DB Users",    str(urow["cnt"] if urow else 0), True)
            await interaction.followup.send(embed=embed)

        # ── Open Tickets ──────────────────────────────────────────────────────
        elif action == "open_tickets":
            from core.database import get_setting
            ch_id = get_setting("ticket_channel")
            if not ch_id or ch_id == "0":
                return await interaction.followup.send(embed=create_error_embed("Not Configured", "No ticket channel set."))
            ch = interaction.guild.get_channel(int(ch_id))
            if not ch:
                return await interaction.followup.send(embed=create_error_embed("Not Found", "Ticket channel not found."))
            threads = [t for t in ch.threads if not t.archived]
            if not threads:
                return await interaction.followup.send(embed=create_info_embed("No Open Tickets", "All tickets are closed."))
            embed = discord.Embed(title=f"🎫 Open Tickets ({len(threads)})", color=0xFFD700, timestamp=datetime.now())
            embed.set_author(name="MoonNodes Hard Staff", icon_url="https://imgur.com/6yfYDTP.png")
            for t in threads[:10]:
                add_field(embed, t.name[:50], t.mention, False)
            await interaction.followup.send(embed=embed)

        # ── Suspension Logs ───────────────────────────────────────────────────
        elif action == "suspension_logs":
            logs = []
            async with data_lock:
                for uid2, lst in vps_data.items():
                    for v in lst:
                        for s in v.get("suspension_history", [])[-3:]:
                            logs.append((v["container_name"], uid2, s))
            logs.sort(key=lambda x: x[2].get("time",""), reverse=True)
            embed = discord.Embed(title="📜 Recent Suspension Logs", color=0xED4245, timestamp=datetime.now())
            embed.set_author(name="MoonNodes Hard Staff", icon_url="https://imgur.com/6yfYDTP.png")
            for name, uid2, s in logs[:10]:
                add_field(embed, f"`{name}` — <@{uid2}>",
                    f"Reason: {s.get('reason','?')}\nBy: <@{s.get('by','?')}> · {s.get('time','?')[:10]}", False)
            if not logs:
                embed.description = "No suspensions on record."
            await interaction.followup.send(embed=embed)

        # ── DM User ───────────────────────────────────────────────────────────
        elif action == "dm_user":
            if not target_user:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `target_user`."))
            if message:
                msg_text = message
            else:
                modal = DMModal()
                await interaction.response.send_modal(modal)
                await modal.wait()
                msg_text = getattr(modal, "_val", None)
                if not msg_text: return
                await interaction.followup.send(embed=create_info_embed("Sending…", ""), ephemeral=True)
            try:
                dm = discord.Embed(title="📩 Message from MoonNodes Staff",
                    description=msg_text, color=0x5865F2, timestamp=datetime.now())
                dm.set_author(name=f"Staff: {interaction.user.display_name}", icon_url=interaction.user.display_avatar.url)
                dm.set_footer(text="MoonNodes — Reply with /support if you need help")
                await target_user.send(embed=dm)
                await interaction.followup.send(embed=create_success_embed("DM Sent", f"Message delivered to {target_user.mention}."))
            except Exception as e:
                await interaction.followup.send(embed=create_error_embed("Failed", str(e)[:500]))

        # ── Warn User ─────────────────────────────────────────────────────────
        elif action == "warn":
            if not target_user or not message:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `target_user` and `message`."))
            conn = get_db(); cur = conn.cursor()
            cur.execute("INSERT INTO warnings (user_id,reason,by_id,at) VALUES (?,?,?,?)",
                (str(target_user.id), message, str(interaction.user.id), datetime.now().isoformat()))
            conn.commit()
            await interaction.followup.send(embed=create_success_embed("Warning Issued ⚠️",
                f"Warning recorded for {target_user.mention}.\n**Reason:** {message}"))
            try:
                dm = discord.Embed(title="⚠️ You Received a Warning",
                    description=f"**Reason:** {message}\n\nPlease review our rules to avoid further action.",
                    color=0xFFAA00, timestamp=datetime.now())
                dm.set_author(name="MoonNodes Staff", icon_url="https://imgur.com/6yfYDTP.png")
                await target_user.send(embed=dm)
            except Exception: pass

        # ── Warn Log ──────────────────────────────────────────────────────────
        elif action == "warn_log":
            if not target_user:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `target_user`."))
            conn = get_db(); cur = conn.cursor()
            cur.execute("SELECT * FROM warnings WHERE user_id=? ORDER BY at DESC LIMIT 10", (str(target_user.id),))
            rows = cur.fetchall()
            embed = discord.Embed(title=f"⚠️ Warnings — {target_user.display_name}",
                color=0xFFAA00, timestamp=datetime.now())
            embed.set_author(name="MoonNodes Hard Staff", icon_url="https://imgur.com/6yfYDTP.png")
            if not rows:
                embed.description = "No warnings on record."
            for r in rows:
                add_field(embed, f"Warn #{r['id']} — {r['at'][:10]}",
                    f"**Reason:** {r['reason']}\nBy: <@{r['by_id']}>", False)
            await interaction.followup.send(embed=embed)


async def setup(bot):
    await bot.add_cog(HardStaffCog(bot))
