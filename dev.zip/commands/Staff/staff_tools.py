"""
/staff — Commands for all staff tiers.
Access is automatically scoped to the user's role.
"""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock, get_db, get_setting
from core.theme import Theme, add_field, create_embed, create_error_embed, create_info_embed, create_success_embed, create_warning_embed

from commands.Owner.admin import (
    ROLE_HIERARCHY, ROLE_ICONS, STAFF_ROLES, MOD_ROLES, ADMIN_ROLES
)


def _role(uid):
    if str(uid) == str(MAIN_ADMIN_ID): return "Owner"
    return admin_data.get(str(uid), "")


def _can(uid, required_set: set) -> bool:
    return _role(uid) in required_set


class StaffCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="staff", description="Staff tools — actions available depend on your role")
    @app_commands.choices(action=[
        # ── All Staff (Trial Staff and above) ────────────────────────────────
        app_commands.Choice(name="🎫 My Tickets — Your assigned support threads",         value="my_tickets"),
        app_commands.Choice(name="📋 All Tickets — All open support threads",             value="all_tickets"),
        app_commands.Choice(name="✅ Close Ticket — Archive a support thread",            value="close_ticket"),
        app_commands.Choice(name="🙋 Claim Ticket — Assign a ticket to yourself",        value="claim_ticket"),

        # ── Hard Staff and above ──────────────────────────────────────────────
        app_commands.Choice(name="📝 Add Note — Add a note to a user's file",            value="add_note"),
        app_commands.Choice(name="📂 View Notes — Read a user's staff notes",            value="view_notes"),
        app_commands.Choice(name="🔍 User Lookup — Quick profile and VPS summary",       value="user_lookup"),

        # ── Mod and above ─────────────────────────────────────────────────────
        app_commands.Choice(name="⚠️ Warn User — Issue a formal warning",                value="warn"),
        app_commands.Choice(name="📜 Warn Log — View a user's warning history",          value="warn_log"),
        app_commands.Choice(name="🗑️ Clear Warns — Remove all warnings for a user",     value="clear_warns"),
        app_commands.Choice(name="📊 Server Overview — VPS counts and global stats",     value="server_stats"),
        app_commands.Choice(name="📣 Staff Announce — Send a staff DM broadcast",       value="broadcast"),

        # ── Admin and above ───────────────────────────────────────────────────
        app_commands.Choice(name="🔒 Lock Channel — Temporarily lock a channel",        value="lock"),
        app_commands.Choice(name="🔓 Unlock Channel — Restore a locked channel",        value="unlock"),
        app_commands.Choice(name="🧹 Purge — Delete recent messages (max 100)",         value="purge"),
    ])
    @app_commands.describe(
        action       ="Staff action to perform",
        target_user  ="Target Discord member",
        message      ="Message or reason",
        container    ="Container name (for lookup)",
        amount       ="Number of messages to purge",
        channel      ="Channel to lock/unlock (default: current)",
        thread       ="Thread link or ID (for ticket actions)",
    )
    async def staff_cmd(
        self, interaction: discord.Interaction,
        action:      str,
        target_user: discord.Member = None,
        message:     str = None,
        container:   str = None,
        amount:      int = 10,
        channel:     discord.TextChannel = None,
        thread:      str = None,
    ):
        await interaction.response.defer(ephemeral=True)
        uid  = str(interaction.user.id)
        role = _role(uid)

        if not role:
            return await interaction.followup.send(embed=create_error_embed(
                "Access Denied",
                "This command is only available to MoonNodes staff members.\n"
                "If you believe this is a mistake, contact an Owner."
            ))

        # ── Helper to find support threads ────────────────────────────────────
        def _get_threads():
            ch_id = get_setting("ticket_channel")
            if not ch_id: return []
            ch = interaction.guild.get_channel(int(ch_id))
            if not ch: return []
            return [t for t in interaction.guild.threads if t.parent_id == int(ch_id) and not t.archived]

        # ══════════════════════════════════════════════════════════════════════
        # TRIAL STAFF + STAFF + HARD STAFF + everyone above
        # ══════════════════════════════════════════════════════════════════════

        if action == "my_tickets":
            threads = _get_threads()
            mine    = [t for t in threads if any(
                m.id == interaction.user.id for m in t.members
            )]
            if not mine:
                return await interaction.followup.send(embed=create_info_embed(
                    "No Tickets", "You have no active tickets assigned to you."
                ))
            embed = create_embed("🎫  Your Tickets", f"{len(mine)} active thread(s)")
            for t in mine[:10]:
                embed.add_field(name=t.name, value=f"{t.mention} · {t.member_count} member(s)", inline=False)
            return await interaction.followup.send(embed=embed)

        elif action == "all_tickets":
            if role not in STAFF_ROLES:
                return await interaction.followup.send(embed=create_error_embed("Denied", "Staff only."))
            threads = _get_threads()
            if not threads:
                return await interaction.followup.send(embed=create_info_embed("No Tickets", "No open support threads right now."))
            embed = create_embed("📋  Open Tickets", f"{len(threads)} active thread(s)")
            for t in threads[:15]:
                embed.add_field(name=t.name, value=f"{t.mention} · {t.member_count} member(s)", inline=True)
            return await interaction.followup.send(embed=embed)

        elif action == "close_ticket":
            if role not in STAFF_ROLES:
                return await interaction.followup.send(embed=create_error_embed("Denied", "Staff only."))
            ch = interaction.channel
            if not isinstance(ch, discord.Thread):
                return await interaction.followup.send(embed=create_error_embed("Wrong Channel", "Run this inside a support thread."))
            close_embed = create_success_embed("🔒  Ticket Closed", f"Closed by **{interaction.user.display_name}**. Thread archived.")
            await interaction.channel.send(embed=close_embed)
            await interaction.channel.edit(archived=True, locked=True)
            return await interaction.followup.send(embed=create_success_embed("Done", "Ticket archived."))

        elif action == "claim_ticket":
            if role not in STAFF_ROLES:
                return await interaction.followup.send(embed=create_error_embed("Denied", "Staff only."))
            ch = interaction.channel
            if not isinstance(ch, discord.Thread):
                return await interaction.followup.send(embed=create_error_embed("Wrong Channel", "Run this inside a support thread."))
            await interaction.channel.send(embed=create_success_embed(
                "Ticket Claimed",
                f"**{interaction.user.display_name}** is now handling this ticket."
            ))
            return await interaction.followup.send(embed=create_success_embed("Claimed", "You have claimed this ticket."))

        # ══════════════════════════════════════════════════════════════════════
        # HARD STAFF + everyone above
        # ══════════════════════════════════════════════════════════════════════

        HARD_STAFF_UP = {"Hard Staff", "Staff"} | MOD_ROLES

        if action in ("add_note", "view_notes", "user_lookup"):
            if role not in HARD_STAFF_UP and role != "Owner":
                return await interaction.followup.send(embed=create_error_embed("Denied", "Hard Staff or above required."))

            if action == "add_note":
                if not target_user or not message:
                    return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `target_user` and `message`."))
                conn = get_db(); cur = conn.cursor()
                cur.execute("CREATE TABLE IF NOT EXISTS staff_notes (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT, note TEXT, by TEXT, at TEXT)")
                cur.execute("INSERT INTO staff_notes (user_id, note, by, at) VALUES (?,?,?,?)",
                            (str(target_user.id), message, str(interaction.user.id), datetime.now().isoformat()))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed("Note Added", f"Staff note added for {target_user.mention}."))

            elif action == "view_notes":
                if not target_user:
                    return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `target_user`."))
                conn = get_db(); cur = conn.cursor()
                try:
                    cur.execute("SELECT note, by, at FROM staff_notes WHERE user_id=? ORDER BY at DESC LIMIT 10", (str(target_user.id),))
                    rows = cur.fetchall()
                except Exception: rows = []
                conn.close()
                if not rows:
                    return await interaction.followup.send(embed=create_info_embed("No Notes", f"No staff notes for {target_user.mention}."))
                embed = create_embed(f"📂  Notes for {target_user.display_name}", "")
                for r in rows:
                    ts  = datetime.fromisoformat(r["at"]).strftime("%b %d, %Y %H:%M")
                    by  = interaction.guild.get_member(int(r["by"]))
                    embed.add_field(name=ts, value=f"{r['note']}\n*— {by.display_name if by else r['by']}*", inline=False)
                return await interaction.followup.send(embed=embed)

            elif action == "user_lookup":
                if not target_user:
                    return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `target_user`."))
                t_uid = str(target_user.id)
                conn  = get_db(); cur = conn.cursor()
                cur.execute("SELECT mooncoin FROM users WHERE user_id=?", (t_uid,)); row = cur.fetchone(); conn.close()
                coins = row["mooncoin"] if row else 0
                with data_lock:
                    vpsc = len(vps_data.get(t_uid, []))
                staff_role = admin_data.get(t_uid, "User")
                embed = create_embed(f"👤  {target_user.display_name}", "")
                embed.set_thumbnail(url=target_user.display_avatar.url)
                embed.add_field(name="Discord ID",  value=f"`{t_uid}`", inline=True)
                embed.add_field(name="Staff Role",  value=f"{ROLE_ICONS.get(staff_role,'•')} {staff_role}", inline=True)
                embed.add_field(name="VPS Count",   value=str(vpsc), inline=True)
                embed.add_field(name="MoonCoins",   value=f"🌙 {coins:,}", inline=True)
                joined = f"<t:{int(target_user.joined_at.timestamp())}:R>" if target_user.joined_at else "?"
                embed.add_field(name="Joined",      value=joined, inline=True)
                return await interaction.followup.send(embed=embed)

        # ══════════════════════════════════════════════════════════════════════
        # MOD + everyone above
        # ══════════════════════════════════════════════════════════════════════

        if action in ("warn", "warn_log", "clear_warns", "server_stats", "broadcast"):
            if role not in MOD_ROLES:
                return await interaction.followup.send(embed=create_error_embed("Denied", "Mod or above required."))

            if action == "warn":
                if not target_user or not message:
                    return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `target_user` and `message` (reason)."))
                conn = get_db(); cur = conn.cursor()
                cur.execute("CREATE TABLE IF NOT EXISTS warnings (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT, reason TEXT, by_id TEXT, at TEXT)")
                cur.execute("INSERT INTO warnings (user_id, reason, by_id, at) VALUES (?,?,?,?)",
                            (str(target_user.id), message, str(interaction.user.id), datetime.now().isoformat()))
                conn.commit(); conn.close()
                try:
                    dm = discord.Embed(title="⚠️  Warning Issued", description=f"**Reason:** {message}", color=Theme.WARNING, timestamp=datetime.now())
                    dm.set_author(name="MoonNodes Moderation", icon_url=Theme.ICON_URL)
                    dm.set_footer(text=f"Issued by {interaction.user.display_name}")
                    await target_user.send(embed=dm)
                except Exception: pass
                return await interaction.followup.send(embed=create_success_embed("Warning Issued", f"{target_user.mention} warned: {message}"))

            elif action == "warn_log":
                if not target_user:
                    return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `target_user`."))
                conn = get_db(); cur = conn.cursor()
                try:
                    cur.execute("SELECT reason, at, by_id FROM warnings WHERE user_id=? ORDER BY at DESC LIMIT 10", (str(target_user.id),))
                    rows = cur.fetchall()
                except Exception: rows = []
                conn.close()
                if not rows:
                    return await interaction.followup.send(embed=create_info_embed("Clean Record", f"{target_user.mention} has no warnings."))
                embed = create_embed(f"📜  Warnings for {target_user.display_name}", f"{len(rows)} warning(s) on record")
                for r in rows:
                    ts  = datetime.fromisoformat(r["at"]).strftime("%b %d %H:%M")
                    by  = interaction.guild.get_member(int(r["by_id"]))
                    embed.add_field(name=ts, value=f"{r['reason']} *— {by.display_name if by else r['by_id']}*", inline=False)
                return await interaction.followup.send(embed=embed)

            elif action == "clear_warns":
                if not target_user:
                    return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `target_user`."))
                conn = get_db(); cur = conn.cursor()
                try:
                    cur.execute("DELETE FROM warnings WHERE user_id=?", (str(target_user.id),))
                    conn.commit()
                except Exception: pass
                conn.close()
                return await interaction.followup.send(embed=create_success_embed("Warnings Cleared", f"All warnings removed for {target_user.mention}."))

            elif action == "server_stats":
                with data_lock:
                    total   = sum(len(v) for v in vps_data.values())
                    running = sum(1 for lst in vps_data.values() for v in lst if v.get("status") == "running")
                    susp    = sum(1 for lst in vps_data.values() for v in lst if v.get("suspended"))
                    users   = len(vps_data)
                embed = create_embed("📊  Server Overview", "")
                embed.add_field(name="Users with VPS", value=str(users), inline=True)
                embed.add_field(name="Total VPS",      value=str(total), inline=True)
                embed.add_field(name="Running",        value=str(running), inline=True)
                embed.add_field(name="Suspended",      value=str(susp), inline=True)
                embed.add_field(name="Staff Members",  value=str(len(admin_data)), inline=True)
                return await interaction.followup.send(embed=embed)

            elif action == "broadcast":
                if not message:
                    return await interaction.followup.send(embed=create_error_embed("Missing", "Provide a `message` to broadcast."))
                sent = 0
                dm_embed = discord.Embed(title="📣  Staff Announcement", description=message, color=Theme.WARNING, timestamp=datetime.now())
                dm_embed.set_author(name="MoonNodes Staff", icon_url=Theme.ICON_URL)
                dm_embed.set_footer(text=f"Sent by {interaction.user.display_name}")
                for uid2, role2 in admin_data.items():
                    try:
                        member = interaction.guild.get_member(int(uid2))
                        if member:
                            await member.send(embed=dm_embed)
                            sent += 1
                    except Exception: pass
                return await interaction.followup.send(embed=create_success_embed("Broadcast Sent", f"Staff DM delivered to **{sent}** member(s)."))

        # ══════════════════════════════════════════════════════════════════════
        # ADMIN + OWNER only
        # ══════════════════════════════════════════════════════════════════════

        if action in ("lock", "unlock", "purge"):
            if role not in ADMIN_ROLES:
                return await interaction.followup.send(embed=create_error_embed("Denied", "Admin or above required."))

            target_ch = channel or interaction.channel

            if action == "lock":
                overwrite = target_ch.overwrites_for(interaction.guild.default_role)
                overwrite.send_messages = False
                await target_ch.set_permissions(interaction.guild.default_role, overwrite=overwrite)
                await target_ch.send(embed=create_warning_embed("🔒  Channel Locked", f"Locked by {interaction.user.mention}."))
                return await interaction.followup.send(embed=create_success_embed("Locked", f"{target_ch.mention} has been locked."))

            elif action == "unlock":
                overwrite = target_ch.overwrites_for(interaction.guild.default_role)
                overwrite.send_messages = None
                await target_ch.set_permissions(interaction.guild.default_role, overwrite=overwrite)
                await target_ch.send(embed=create_success_embed("🔓  Channel Unlocked", f"Unlocked by {interaction.user.mention}."))
                return await interaction.followup.send(embed=create_success_embed("Unlocked", f"{target_ch.mention} is back to normal."))

            elif action == "purge":
                amt = min(max(1, amount), 100)
                deleted = await target_ch.purge(limit=amt)
                return await interaction.followup.send(embed=create_success_embed("Purge Complete", f"Deleted **{len(deleted)}** messages from {target_ch.mention}."))


async def setup(bot):
    await bot.add_cog(StaffCog(bot))
