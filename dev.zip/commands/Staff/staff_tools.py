import logging
logger = logging.getLogger("moonnodes_vps_bot")
"""
/staff — Staff + Hard Staff tools in one command.
User picks role: Staff or Hard Staff → sees appropriate action set.
Hard Staff actions are gated — only Hard Staff+ can use them.
"""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock, get_db, get_setting
from core.theme import add_field, create_embed, create_success_embed, create_error_embed, create_info_embed

STAFF_ROLES     = {"Owner","Hard Admin","Admin","Manager","Hard Mod","Mod","Hard Staff","Staff","Trial Staff","Trial Mod"}
HARD_STAFF_ROLES= {"Owner","Hard Admin","Admin","Manager","Hard Mod","Mod","Hard Staff"}

def _role(uid): return "Owner" if str(uid)==str(MAIN_ADMIN_ID) else admin_data.get(str(uid),"")
def is_staff(uid): return _role(uid) in STAFF_ROLES
def is_hard_staff(uid): return _role(uid) in HARD_STAFF_ROLES


class DMModal(discord.ui.Modal, title="✉️ Send Staff DM"):
    message = discord.ui.TextInput(label="Message",style=discord.TextStyle.paragraph,max_length=1000)
    async def on_submit(self,inter): self._val=self.message.value; await inter.response.defer()


class StaffCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="staff", description="[STAFF/HARD STAFF] Staff tools")
    @app_commands.choices(role=[
        app_commands.Choice(name="🌟 Staff — Standard staff tools",          value="staff"),
        app_commands.Choice(name="⭐ Hard Staff — Senior staff tools",       value="hardstaff"),
    ])
    @app_commands.choices(action=[
        # Staff actions
        app_commands.Choice(name="🎫 My Tickets",        value="my_tickets"),
        app_commands.Choice(name="📋 All Tickets",       value="all_tickets"),
        app_commands.Choice(name="✅ Close Ticket",      value="close_ticket"),
        app_commands.Choice(name="🙋 Claim Ticket",      value="claim_ticket"),
        app_commands.Choice(name="📝 Add Note",          value="add_note"),
        app_commands.Choice(name="📂 View Notes",        value="view_notes"),
        app_commands.Choice(name="🔍 User Lookup",       value="user_lookup"),
        # Hard Staff only
        app_commands.Choice(name="👤 User Info [HS]",    value="user_info"),
        app_commands.Choice(name="🖥️ VPS Info [HS]",     value="vps_info"),
        app_commands.Choice(name="📋 List VPS [HS]",     value="list_vps"),
        app_commands.Choice(name="📊 Server Stats [HS]", value="server_stats"),
        app_commands.Choice(name="📜 Susp Logs [HS]",    value="susp_logs"),
        app_commands.Choice(name="🎫 Open Tickets [HS]", value="open_tickets"),
        app_commands.Choice(name="✉️ DM User [HS]",      value="dm_user"),
        app_commands.Choice(name="⚠️ Warn User [HS]",    value="warn"),
        app_commands.Choice(name="📜 Warn Log [HS]",     value="warn_log"),
    ])
    @app_commands.describe(
        role        = "Your role scope: Staff or Hard Staff",
        action      = "Action to perform",
        target_user = "Target user",
        message     = "Message or note text",
        container   = "Container name (VPS Info)",
        thread      = "Thread/channel ID (ticket actions)",
    )
    async def staff_cmd(
        self, interaction: discord.Interaction,
        role:        str,
        action:      str,
        target_user: discord.Member = None,
        message:     str = None,
        container:   str = None,
        thread:      str = None,
    ):
        await interaction.response.defer(ephemeral=True)
        uid = str(interaction.user.id)

        HARD_STAFF_ACTIONS = {"user_info","vps_info","list_vps","server_stats",
                               "susp_logs","open_tickets","dm_user","warn","warn_log"}
        if action in HARD_STAFF_ACTIONS:
            if not is_hard_staff(uid):
                return await interaction.followup.send(embed=create_error_embed(
                    "🚫 No Permission",
                    "This action requires **Hard Staff** or above.\nUse `/help` to see your available commands."))
        else:
            if not is_staff(uid):
                return await interaction.followup.send(embed=create_error_embed(
                    "🚫 No Permission",
                    "This action requires **Staff** or above.\nUse `/help` to see your available commands."))

        # ── STAFF ACTIONS ─────────────────────────────────────────────────────

        if action in ("my_tickets","all_tickets","open_tickets"):
            cat_id = get_setting("ticket_channel")
            if not cat_id or cat_id=="0":
                return await interaction.followup.send(embed=create_error_embed("Not Configured","No ticket category set."))
            cat = interaction.guild.get_channel(int(cat_id))
            if not cat:
                return await interaction.followup.send(embed=create_error_embed("Not Found","Category not found."))
            chans = [c for c in cat.channels if isinstance(c, discord.TextChannel)]
            if action == "my_tickets":
                chans = [c for c in chans if str(uid) in (c.topic or "")]
            if not chans:
                return await interaction.followup.send(embed=create_info_embed("No Tickets","No open ticket channels."))
            embed = create_embed(f"🎫 Tickets ({len(chans)})","")
            for c in chans[:10]: add_field(embed, c.name[:50], c.mention, False)
            return await interaction.followup.send(embed=embed)

        elif action == "close_ticket":
            ch = interaction.channel
            await interaction.followup.send(embed=create_success_embed("Ticket Closed","This ticket channel will be deleted in 5 seconds."))
            import asyncio; await asyncio.sleep(5)
            try: await ch.delete(reason=f"Ticket closed by {interaction.user}")
            except discord.Forbidden: pass
            except Exception as del_err: logger.warning(f"close_ticket delete failed: {del_err}")

        elif action == "claim_ticket":
            await interaction.followup.send(embed=create_success_embed("Ticket Claimed",
                f"🛡️ **{interaction.user.display_name}** is now handling this ticket."))

        elif action == "add_note":
            if not target_user or not message:
                return await interaction.followup.send(embed=create_error_embed("Missing","Specify `target_user` and `message`."))
            conn=get_db(); cur=conn.cursor()
            cur.execute("INSERT INTO staff_notes (user_id,note,by,at) VALUES (?,?,?,?)",
                (str(target_user.id),message,uid,datetime.now().isoformat()))
            conn.commit()
            return await interaction.followup.send(embed=create_success_embed("Note Added",
                f"Staff note saved for {target_user.mention}."))

        elif action == "view_notes":
            if not target_user:
                return await interaction.followup.send(embed=create_error_embed("Missing","Specify `target_user`."))
            conn=get_db(); cur=conn.cursor()
            cur.execute("SELECT * FROM staff_notes WHERE user_id=? ORDER BY at DESC LIMIT 10",(str(target_user.id),))
            rows=cur.fetchall()
            embed=create_embed(f"📂 Notes — {target_user.display_name}","")
            if not rows: embed.description="No staff notes."
            for r in rows:
                add_field(embed,f"Note #{r['id']} — {r['at'][:10]}",f"{r['note']}\nBy: <@{r['by']}>",False)
            return await interaction.followup.send(embed=embed)

        elif action == "user_lookup":
            if not target_user:
                return await interaction.followup.send(embed=create_error_embed("Missing","Specify `target_user`."))
            tid=str(target_user.id)
            async with data_lock:
                vlist=vps_data.get(tid,[])
            conn=get_db(); cur=conn.cursor()
            cur.execute("SELECT mooncoin FROM users WHERE user_id=?",(tid,)); row=cur.fetchone()
            embed=create_embed(f"🔍 {target_user.display_name}","")
            embed.set_thumbnail(url=target_user.display_avatar.url)
            add_field(embed,"User ID",tid,True)
            add_field(embed,"Role",admin_data.get(tid,"User"),True)
            add_field(embed,"VPS",str(len(vlist)),True)
            add_field(embed,"🌙 Coins",f"{(row['mooncoin'] if row else 0):,}",True)
            return await interaction.followup.send(embed=embed)

        # ── HARD STAFF ACTIONS ────────────────────────────────────────────────

        elif action == "user_info":
            if not target_user:
                return await interaction.followup.send(embed=create_error_embed("Missing","Specify `target_user`."))
            tid=str(target_user.id)
            conn=get_db(); cur=conn.cursor()
            cur.execute("SELECT mooncoin,total_referrals FROM users WHERE user_id=?",(tid,)); row=cur.fetchone()
            cur.execute("SELECT COUNT(*) as cnt FROM warnings WHERE user_id=?",(tid,)); wrow=cur.fetchone()
            async with data_lock: vlist=vps_data.get(tid,[])
            embed=create_embed(f"👤 {target_user.display_name}","")
            embed.set_thumbnail(url=target_user.display_avatar.url)
            add_field(embed,"User ID",f"{tid}",True)
            add_field(embed,"Role",admin_data.get(tid,"User"),True)
            add_field(embed,"VPS",str(len(vlist)),True)
            add_field(embed,"🌙 Coins",f"{(row['mooncoin'] if row else 0):,}",True)
            add_field(embed,"⚠️ Warns",str(wrow['cnt'] if wrow else 0),True)
            if vlist:
                add_field(embed,"VPS List","\n".join(f"› `{v['container_name']}` {v.get('status','?').upper()}" for v in vlist[:5]),False)
            return await interaction.followup.send(embed=embed)

        elif action == "vps_info":
            if not container:
                return await interaction.followup.send(embed=create_error_embed("Missing","Specify `container`."))
            found=owner=None
            async with data_lock:
                for uid2,lst in vps_data.items():
                    for v in lst:
                        if v["container_name"]==container: found=v; owner=uid2; break
            if not found: return await interaction.followup.send(embed=create_error_embed("Not Found",f"`{container}` not found."))
            embed=create_embed(f"🖥️ {container}","")
            add_field(embed,"Owner",f"<@{owner}>",True); add_field(embed,"Status",found.get("status","?").upper(),True)
            add_field(embed,"Node",found.get("node","local"),True); add_field(embed,"Specs",found.get("config","?"),True)
            return await interaction.followup.send(embed=embed)

        elif action == "list_vps":
            if not target_user: return await interaction.followup.send(embed=create_error_embed("Missing","Specify `target_user`."))
            async with data_lock: vlist=list(vps_data.get(str(target_user.id),[]))
            if not vlist: return await interaction.followup.send(embed=create_info_embed("No VPS",f"{target_user.mention} has no VPS."))
            embed=create_embed(f"📋 VPS — {target_user.display_name}",f"{len(vlist)} VPS instance(s)")
            for i,v in enumerate(vlist,1):
                st="🟢" if v.get("status")=="running" else ("🔴" if v.get("suspended") else "⚫")
                add_field(embed,f"{st} VPS #{i} — {v['container_name']}",f"`{v.get('config','?')}` · `{v.get('node','local')}`",False)
            return await interaction.followup.send(embed=embed)

        elif action == "server_stats":
            async with data_lock:
                total=sum(len(v) for v in vps_data.values())
                running=sum(1 for lst in vps_data.values() for v in lst if v.get("status")=="running")
                susp=sum(1 for lst in vps_data.values() for v in lst if v.get("suspended"))
            embed=create_embed("📊 Server Stats","")
            add_field(embed,"🖥️ Total",str(total),True); add_field(embed,"🟢 Running",str(running),True); add_field(embed,"🔴 Suspended",str(susp),True)
            return await interaction.followup.send(embed=embed)

        elif action == "susp_logs":
            logs=[]
            async with data_lock:
                for uid2,lst in vps_data.items():
                    for v in lst:
                        for s in v.get("suspension_history",[])[-2:]: logs.append((v["container_name"],uid2,s))
            logs.sort(key=lambda x:x[2].get("time",""),reverse=True)
            embed=create_embed("📝 Suspension Logs","")
            for n,uid2,s in logs[:10]: add_field(embed,f"`{n}` — <@{uid2}>",f"Reason: {s.get('reason','?')} · {s.get('time','?')[:10]}",False)
            if not logs: embed.description="No suspensions."
            return await interaction.followup.send(embed=embed)

        elif action == "dm_user":
            if not target_user: return await interaction.followup.send(embed=create_error_embed("Missing","Specify `target_user`."))
            if message: msg_text=message
            else:
                modal=DMModal(); await interaction.response.send_modal(modal); await modal.wait()
                msg_text=getattr(modal,"_val",None)
                if not msg_text: return
                await interaction.followup.send(embed=create_info_embed("Sending…",""),ephemeral=True)
            try:
                dm=discord.Embed(title="📩 Message from MoonNodes Staff",description=msg_text,color=0x5865F2,timestamp=datetime.now())
                dm.set_author(name=f"Staff: {interaction.user.display_name}",icon_url=interaction.user.display_avatar.url)
                await target_user.send(embed=dm)
                await interaction.followup.send(embed=create_success_embed("DM Sent",f"Message delivered to {target_user.mention}."))
            except Exception as e: await interaction.followup.send(embed=create_error_embed("Failed",str(e)[:500]))

        elif action == "warn":
            if not target_user or not message: return await interaction.followup.send(embed=create_error_embed("Missing","Specify `target_user` and `message`."))
            conn=get_db(); cur=conn.cursor()
            cur.execute("INSERT INTO warnings (user_id,reason,by_id,at) VALUES (?,?,?,?)",(str(target_user.id),message,uid,datetime.now().isoformat()))
            conn.commit()
            await interaction.followup.send(embed=create_success_embed("⚠️ Warning Issued",f"{target_user.mention}\n**Reason:** {message}"))
            try:
                dm=discord.Embed(title="⚠️ You Received a Warning",description=f"**Reason:** {message}",color=0xFFAA00,timestamp=datetime.now())
                dm.set_author(name="MoonNodes Staff",icon_url="https://imgur.com/6yfYDTP.png")
                await target_user.send(embed=dm)
            except Exception: pass

        elif action == "warn_log":
            if not target_user: return await interaction.followup.send(embed=create_error_embed("Missing","Specify `target_user`."))
            conn=get_db(); cur=conn.cursor()
            cur.execute("SELECT * FROM warnings WHERE user_id=? ORDER BY at DESC LIMIT 10",(str(target_user.id),))
            rows=cur.fetchall()
            embed=create_embed(f"📜 Warns — {target_user.display_name}","")
            if not rows: embed.description="No warnings."
            for r in rows: add_field(embed,f"Warn #{r['id']} — {r['at'][:10]}",f"**Reason:** {r['reason']}\nBy: <@{r['by_id']}>",False)
            return await interaction.followup.send(embed=embed)


async def setup(bot):
    await bot.add_cog(StaffCog(bot))
