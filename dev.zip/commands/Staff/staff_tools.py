import discord,asyncio
from discord import app_commands
from discord.ext import commands
from datetime import datetime
from core.config import MAIN_ADMIN_ID
from core.database import admin_data,vps_data,data_lock,get_db
from core.theme import create_embed,create_success_embed,create_error_embed,create_info_embed,create_warning_embed,create_loading_embed,add_field,Theme

HIERARCHY=["Owner","Hard Admin","Admin","Manager","Hard Mod","Mod","Hard Staff","Staff","Trial Staff","Trial Mod","Partner"]

def _role(uid):
    if str(uid)==str(MAIN_ADMIN_ID): return "Owner"
    return admin_data.get(str(uid),"")

def _tier(role):
    try: return HIERARCHY.index(role)
    except ValueError: return 99

def _has_min(uid,min_role):
    return _tier(_role(str(uid)))<=_tier(min_role)

is_trial_staff=lambda uid:_has_min(uid,"Trial Staff")
is_staff=      lambda uid:_has_min(uid,"Staff")
is_hard_staff= lambda uid:_has_min(uid,"Hard Staff")
is_mod=        lambda uid:_has_min(uid,"Mod")
is_hard_mod=   lambda uid:_has_min(uid,"Hard Mod")
is_admin_role= lambda uid:_has_min(uid,"Admin")

def _deny(role_name):
    return create_error_embed("Access Denied",f"**{role_name}** or higher is required to use this action.")

class StaffCog(commands.Cog):
    def __init__(self,bot): self.bot=bot

    @app_commands.command(name="staff",description="Staff command hub — available actions depend on your role")
    @app_commands.choices(action=[
        app_commands.Choice(name="🎫 My Tickets — Threads assigned to you",            value="my_tickets"),
        app_commands.Choice(name="📖 Guide — Staff duty quick reference",              value="guide"),
        app_commands.Choice(name="📋 Open Tickets — All open support threads",        value="open_tickets"),
        app_commands.Choice(name="👤 User Lookup — Quick user profile",               value="user_lookup"),
        app_commands.Choice(name="📢 Announce — Send a staff DM to a user",           value="announce"),
        app_commands.Choice(name="🔍 Search VPS — Find any container",                value="search_vps"),
        app_commands.Choice(name="📝 Add Note — Internal staff note on a user",       value="note"),
        app_commands.Choice(name="📜 View Notes — See staff notes for a user",        value="view_notes"),
        app_commands.Choice(name="⚠️ Warn — Issue a formal warning",                   value="warn"),
        app_commands.Choice(name="📋 Warn Log — View a user's warning history",       value="warn_log"),
        app_commands.Choice(name="🔕 Archive Ticket — Close without resolving",       value="archive_ticket"),
        app_commands.Choice(name="📊 Server Stats — Full VPS and user statistics",    value="stats"),
        app_commands.Choice(name="🔒 Lock User — Block from opening tickets",         value="lock_user"),
        app_commands.Choice(name="🔓 Unlock User — Restore ticket access",            value="unlock_user"),
        app_commands.Choice(name="📤 Mass DM — Announcement to all VPS users",        value="mass_dm"),
        app_commands.Choice(name="🗂️ Audit — Full history of a container",            value="audit"),
    ])
    @app_commands.describe(action="Staff action",target_user="Target user",message="Message or reason",container="Container name")
    async def staff_cmd(self,interaction:discord.Interaction,action:str,target_user:discord.Member=None,message:str=None,container:str=None):
        await interaction.response.defer(ephemeral=True)
        uid=str(interaction.user.id)
        if not is_trial_staff(uid):
            return await interaction.followup.send(embed=create_error_embed("Access Denied","This command is for MoonNodes staff only."))

        # ── Trial Staff ──────────────────────────────────────────────────────
        if action=="my_tickets":
            from core.database import get_setting
            ch_id=get_setting("ticket_channel")
            if not ch_id or not interaction.guild:
                return await interaction.followup.send(embed=create_info_embed("My Tickets","No ticket channel configured."))
            ch=interaction.guild.get_channel(int(ch_id))
            if not ch: return await interaction.followup.send(embed=create_error_embed("Gone","Ticket channel not found."))
            my=[t for t in interaction.guild.threads if t.parent_id==int(ch_id) and not t.archived and any(m.id==interaction.user.id for m in t.members)]
            if not my: return await interaction.followup.send(embed=create_info_embed("My Tickets","No active tickets assigned to you."))
            embed=create_embed(f"Your Open Tickets ({len(my)})","\n".join(f"- {t.mention}" for t in my[:20]))
            return await interaction.followup.send(embed=embed)

        elif action=="guide":
            embed=create_embed("Staff Quick Reference","")
            add_field(embed,"Trial Staff (training)","Handle tickets, use Claim/Close buttons, stay professional",False)
            add_field(embed,"Staff","All above + user lookups, open tickets list, DM announcements",False)
            add_field(embed,"Hard Staff","All above + VPS search, internal notes on users",False)
            add_field(embed,"Mod","All above + warn users, archive tickets, lock/unlock ticket access",False)
            add_field(embed,"Hard Mod","All above + full server stats",False)
            add_field(embed,"Admin","All above + mass DM, container audits",False)
            return await interaction.followup.send(embed=embed)

        # ── Staff ────────────────────────────────────────────────────────────
        elif action=="open_tickets":
            if not is_staff(uid): return await interaction.followup.send(embed=_deny("Staff"))
            from core.database import get_setting
            ch_id=get_setting("ticket_channel")
            if not ch_id or not interaction.guild:
                return await interaction.followup.send(embed=create_info_embed("Tickets","No ticket channel configured."))
            ch=interaction.guild.get_channel(int(ch_id))
            if not ch: return await interaction.followup.send(embed=create_error_embed("Gone","Ticket channel not found."))
            threads=[t for t in interaction.guild.threads if t.parent_id==int(ch_id) and not t.archived]
            if not threads: return await interaction.followup.send(embed=create_info_embed("Open Tickets","No open tickets right now!"))
            embed=create_embed(f"Open Tickets ({len(threads)})","\n".join(f"- {t.mention} ({t.member_count} members)" for t in threads[:20]))
            return await interaction.followup.send(embed=embed)

        elif action=="user_lookup":
            if not is_staff(uid): return await interaction.followup.send(embed=_deny("Staff"))
            if not target_user: return await interaction.followup.send(embed=create_error_embed("Missing","Specify target_user."))
            t_uid=str(target_user.id)
            with data_lock: vps_list=list(vps_data.get(t_uid,[]))
            conn=get_db(); cur=conn.cursor()
            cur.execute("SELECT mooncoin,invites_used FROM users WHERE user_id=?",(t_uid,))
            row=cur.fetchone(); conn.close()
            embed=create_embed(f"User: {target_user.display_name}","")
            embed.set_thumbnail(url=target_user.display_avatar.url)
            add_field(embed,"User ID",str(target_user.id),True)
            add_field(embed,"Role",admin_data.get(t_uid,"User"),True)
            add_field(embed,"VPS",str(len(vps_list)),True)
            add_field(embed,"Coins",f"{row['mooncoin']:,}" if row else "0",True)
            add_field(embed,"Invites",str(row["invites_used"]) if row else "0",True)
            return await interaction.followup.send(embed=embed)

        elif action=="announce":
            if not is_staff(uid): return await interaction.followup.send(embed=_deny("Staff"))
            if not target_user or not message: return await interaction.followup.send(embed=create_error_embed("Missing","Provide target_user and message."))
            try:
                dm=discord.Embed(title="Staff Announcement",description=message,color=Theme.INFO,timestamp=datetime.now())
                dm.set_author(name="MoonNodes Staff",icon_url="https://imgur.com/6yfYDTP.png")
                dm.set_footer(text=f"Sent by {interaction.user.display_name}")
                await target_user.send(embed=dm)
                return await interaction.followup.send(embed=create_success_embed("Sent",f"Message delivered to {target_user.mention}."))
            except discord.Forbidden:
                return await interaction.followup.send(embed=create_error_embed("DMs Off",f"{target_user.mention} has DMs disabled."))

        # ── Hard Staff ───────────────────────────────────────────────────────
        elif action=="search_vps":
            if not is_hard_staff(uid): return await interaction.followup.send(embed=_deny("Hard Staff"))
            if not container: return await interaction.followup.send(embed=create_error_embed("Missing","Specify container name."))
            results=[]
            with data_lock:
                for o_uid,lst in vps_data.items():
                    for v in lst:
                        if container.lower() in v["container_name"].lower():
                            m=interaction.guild.get_member(int(o_uid)) if interaction.guild else None
                            results.append(f"- `{v['container_name']}` — {v.get('status','?').upper()} — Owner: {m.display_name if m else o_uid}")
            if not results: return await interaction.followup.send(embed=create_info_embed("No Results",f"No containers matching `{container}`."))
            return await interaction.followup.send(embed=create_embed(f"Search: {container}","\n".join(results[:20])))

        elif action=="note":
            if not is_hard_staff(uid): return await interaction.followup.send(embed=_deny("Hard Staff"))
            if not target_user or not message: return await interaction.followup.send(embed=create_error_embed("Missing","Provide target_user and message."))
            conn=get_db(); cur=conn.cursor()
            cur.execute("CREATE TABLE IF NOT EXISTS staff_notes (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT,note TEXT,by_id TEXT,at TEXT)")
            cur.execute("INSERT INTO staff_notes (user_id,note,by_id,at) VALUES (?,?,?,?)",(str(target_user.id),message,uid,datetime.now().isoformat()))
            conn.commit(); conn.close()
            return await interaction.followup.send(embed=create_success_embed("Note Saved",f"Staff note added for {target_user.mention}."))

        elif action=="view_notes":
            if not is_hard_staff(uid): return await interaction.followup.send(embed=_deny("Hard Staff"))
            if not target_user: return await interaction.followup.send(embed=create_error_embed("Missing","Specify target_user."))
            conn=get_db(); cur=conn.cursor()
            try:
                cur.execute("SELECT note,at FROM staff_notes WHERE user_id=? ORDER BY at DESC LIMIT 10",(str(target_user.id),))
                rows=cur.fetchall()
            except Exception: rows=[]
            conn.close()
            if not rows: return await interaction.followup.send(embed=create_info_embed("Notes",f"No notes for {target_user.mention}."))
            lines=[f"- {r['note']} — <t:{int(datetime.fromisoformat(r['at']).timestamp())}:R>" for r in rows]
            return await interaction.followup.send(embed=create_embed(f"Notes: {target_user.display_name}","\n".join(lines)))

        # ── Mod ──────────────────────────────────────────────────────────────
        elif action=="warn":
            if not is_mod(uid): return await interaction.followup.send(embed=_deny("Mod"))
            if not target_user or not message: return await interaction.followup.send(embed=create_error_embed("Missing","Provide target_user and message."))
            conn=get_db(); cur=conn.cursor()
            cur.execute("CREATE TABLE IF NOT EXISTS warnings (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id TEXT,reason TEXT,by_id TEXT,at TEXT)")
            cur.execute("INSERT INTO warnings (user_id,reason,by_id,at) VALUES (?,?,?,?)",(str(target_user.id),message,uid,datetime.now().isoformat()))
            conn.commit(); conn.close()
            try:
                dm=discord.Embed(title="You've Received a Warning",description=f"Reason: {message}",color=Theme.WARNING,timestamp=datetime.now())
                dm.set_author(name="MoonNodes Moderation",icon_url="https://imgur.com/6yfYDTP.png")
                await target_user.send(embed=dm)
            except Exception: pass
            return await interaction.followup.send(embed=create_success_embed("Warning Issued",f"{target_user.mention} warned: {message}"))

        elif action=="warn_log":
            if not is_mod(uid): return await interaction.followup.send(embed=_deny("Mod"))
            if not target_user: return await interaction.followup.send(embed=create_error_embed("Missing","Specify target_user."))
            conn=get_db(); cur=conn.cursor()
            try:
                cur.execute("SELECT reason,at FROM warnings WHERE user_id=? ORDER BY at DESC LIMIT 10",(str(target_user.id),))
                rows=cur.fetchall()
            except Exception: rows=[]
            conn.close()
            if not rows: return await interaction.followup.send(embed=create_info_embed("Warnings","No warnings found."))
            lines=[f"- {r['reason']} — <t:{int(datetime.fromisoformat(r['at']).timestamp())}:R>" for r in rows]
            return await interaction.followup.send(embed=create_embed(f"Warn Log: {target_user.display_name}","\n".join(lines)))

        elif action=="archive_ticket":
            if not is_mod(uid): return await interaction.followup.send(embed=_deny("Mod"))
            if not isinstance(interaction.channel,discord.Thread):
                return await interaction.followup.send(embed=create_error_embed("Wrong Channel","Run inside a support thread."))
            await interaction.channel.send(embed=create_warning_embed("Ticket Archived",f"Archived by {interaction.user.display_name} without resolution."))
            await interaction.channel.edit(archived=True,locked=False)
            return await interaction.followup.send(embed=create_success_embed("Archived","Thread archived."))

        # ── Hard Mod ─────────────────────────────────────────────────────────
        elif action=="stats":
            if not is_hard_mod(uid): return await interaction.followup.send(embed=_deny("Hard Mod"))
            with data_lock:
                total=sum(len(v) for v in vps_data.values())
                running=sum(1 for lst in vps_data.values() for v in lst if v.get("status")=="running")
                susp=sum(1 for lst in vps_data.values() for v in lst if v.get("suspended"))
                users=len(vps_data)
            embed=create_embed("Server Stats","")
            add_field(embed,"Users",str(users),True)
            add_field(embed,"Total VPS",str(total),True)
            add_field(embed,"Running",str(running),True)
            add_field(embed,"Suspended",str(susp),True)
            add_field(embed,"Stopped",str(total-running-susp),True)
            add_field(embed,"Staff",str(len(admin_data)),True)
            return await interaction.followup.send(embed=embed)

        elif action in("lock_user","unlock_user"):
            if not is_hard_mod(uid): return await interaction.followup.send(embed=_deny("Hard Mod"))
            if not target_user: return await interaction.followup.send(embed=create_error_embed("Missing","Specify target_user."))
            locking=(action=="lock_user")
            conn=get_db(); cur=conn.cursor()
            cur.execute("CREATE TABLE IF NOT EXISTS ticket_locks (user_id TEXT PRIMARY KEY,locked INTEGER)")
            if locking: cur.execute("INSERT OR REPLACE INTO ticket_locks (user_id,locked) VALUES (?,1)",(str(target_user.id),))
            else: cur.execute("DELETE FROM ticket_locks WHERE user_id=?",(str(target_user.id),))
            conn.commit(); conn.close()
            word="locked from" if locking else "unlocked for"
            fn=create_warning_embed if locking else create_success_embed
            return await interaction.followup.send(embed=fn("Ticket Access Updated",f"{target_user.mention} is now **{word}** opening support tickets."))

        # ── Admin ────────────────────────────────────────────────────────────
        elif action=="mass_dm":
            if not is_admin_role(uid): return await interaction.followup.send(embed=_deny("Admin"))
            if not message: return await interaction.followup.send(embed=create_error_embed("Missing","Provide a message."))
            with data_lock: all_uids=list(vps_data.keys())
            await interaction.followup.send(embed=create_loading_embed("Sending","Sending to "+str(len(all_uids))+" users..."))
            sent=failed=0
            for u_id in all_uids:
                try:
                    user_obj=await self.bot.fetch_user(int(u_id))
                    dm=discord.Embed(title="MoonNodes Announcement",description=message,color=Theme.INFO,timestamp=datetime.now())
                    dm.set_author(name="MoonNodes VPS Manager",icon_url="https://imgur.com/6yfYDTP.png")
                    await user_obj.send(embed=dm); sent+=1
                except Exception: failed+=1
            return await interaction.followup.send(embed=create_success_embed("Mass DM Done",f"Sent to {sent} users. Failed: {failed}."))

        elif action=="audit":
            if not is_admin_role(uid): return await interaction.followup.send(embed=_deny("Admin"))
            if not container: return await interaction.followup.send(embed=create_error_embed("Missing","Specify container."))
            found=found_uid=None
            with data_lock:
                for u_id,lst in vps_data.items():
                    for v in lst:
                        if v["container_name"]==container: found=v; found_uid=u_id; break
            if not found: return await interaction.followup.send(embed=create_error_embed("Not Found",f"`{container}` not in database."))
            embed=create_embed(f"Audit: {container}","")
            add_field(embed,"Owner",f"<@{found_uid}>",True)
            add_field(embed,"Status",found.get("status","?").upper(),True)
            add_field(embed,"Node",found.get("node","local"),True)
            hist=found.get("suspension_history",[])
            if hist:
                lines=[f"- {h.get('reason','?')} — <t:{int(datetime.fromisoformat(h['time']).timestamp())}:R>" for h in hist[-5:]]
                add_field(embed,"Suspension History","\n".join(lines),False)
            return await interaction.followup.send(embed=embed)

async def setup(bot):
    await bot.add_cog(StaffCog(bot))
