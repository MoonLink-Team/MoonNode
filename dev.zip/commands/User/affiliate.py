import discord
from discord import app_commands
from discord.ext import commands

from core.config import ABEI, RA, MAIN_ADMIN_ID
from core.database import admin_data, get_db
from core.theme import create_embed, create_success_embed, create_error_embed, add_field


def is_admin_check(user_id):
    role = admin_data.get(str(user_id))
    return role in ["Owner", "Admin", "Dev"] or str(user_id) == str(MAIN_ADMIN_ID)


class AffiliateCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="affiliate", description="Check your referral credits or transfer credits")
    @app_commands.choices(admin_action=[
        app_commands.Choice(name="Add Credits",    value="add"),
        app_commands.Choice(name="Remove Credits", value="remove"),
    ])
    @app_commands.describe(
        target_user     = "User to view/transfer to",
        admin_action    = "[ADMIN] Add or remove credits",
        transfer_amount = "Amount to transfer or adjust",
    )
    async def affiliate_cmd(
        self, interaction: discord.Interaction,
        target_user: discord.Member = None,
        admin_action: str = None,
        transfer_amount: int = None,
    ):
        await interaction.response.defer()
        conn = get_db()
        cur  = conn.cursor()

        # ── Admin credit management ──────────────────────────────────────────
        if admin_action and is_admin_check(interaction.user.id):
            if not target_user or not transfer_amount:
                conn.close()
                return await interaction.followup.send(embed=create_error_embed("Error", "Provide a user and amount."))
            cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (str(target_user.id),))
            if admin_action == "add":
                cur.execute("UPDATE users SET credits = credits + ? WHERE user_id=?", (transfer_amount, str(target_user.id)))
            else:
                cur.execute("UPDATE users SET credits = max(0, credits - ?) WHERE user_id=?", (transfer_amount, str(target_user.id)))
            conn.commit()
            conn.close()
            return await interaction.followup.send(embed=create_success_embed("Balance Updated", f"Updated credits for {target_user.mention}."))

        # ── User credit transfer ─────────────────────────────────────────────
        if transfer_amount and target_user and not admin_action:
            if not ABEI:
                conn.close()
                return await interaction.followup.send(embed=create_error_embed("Disabled", "The economy system is disabled."))
            cur.execute("SELECT credits FROM users WHERE user_id=?", (str(interaction.user.id),))
            row = cur.fetchone()
            if not row or row["credits"] < transfer_amount:
                conn.close()
                return await interaction.followup.send(embed=create_error_embed("Insufficient Credits", "You don't have enough credits."))
            cur.execute("UPDATE users SET credits = credits - ? WHERE user_id=?", (transfer_amount, str(interaction.user.id)))
            cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (str(target_user.id),))
            cur.execute("UPDATE users SET credits = credits + ? WHERE user_id=?", (transfer_amount, str(target_user.id)))
            conn.commit()
            conn.close()
            return await interaction.followup.send(embed=create_success_embed("Transferred", f"Sent **{transfer_amount} credits** to {target_user.mention}."))

        # ── Show stats ───────────────────────────────────────────────────────
        if not RA and not ABEI:
            conn.close()
            return await interaction.followup.send(embed=create_error_embed("Disabled", "Affiliate & Economy features are disabled."))

        cur.execute("SELECT credits, total_referrals FROM users WHERE user_id=?", (str(interaction.user.id),))
        row = cur.fetchone()
        conn.close()

        credits   = row["credits"]          if row else 0
        total_refs = row["total_referrals"] if row else 0

        embed = create_embed("🤝 Affiliate & Economy Stats", "Invite friends to earn credits!")
        add_field(embed, "💰 Balance",        f"`{credits} Credits`", True)
        if RA:
            add_field(embed, "👥 Total Referrals", f"`{total_refs} users`", True)
        await interaction.followup.send(embed=embed)


async def setup(bot):
    await bot.add_cog(AffiliateCog(bot))
