import discord
from core.ext import vps_renewal_enabled, ext_disabled_embed
from discord import app_commands
from discord.ext import commands

from core.config import PUDC
from core.database import vps_data, data_lock, save_vps_data, get_db
from core.lxc import execute_lxc
from core.theme import create_success_embed, create_error_embed
from feature.plans.plans_manager import PLANS


class UpgradeCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="upgrade", description="Upgrade or downgrade your VPS plan using credits")
    @app_commands.describe(
        vps_number    = "Your VPS number (1, 2…)",
        new_plan_name = "Target premium plan name (e.g. premium, ultimate)",
    )
    async def upgrade_vps(self, interaction: discord.Interaction, vps_number: int, new_plan_name: str):
        if not PUDC:
            return await interaction.response.send_message(
                embed=create_error_embed("Disabled", "Plan upgrades are disabled."), ephemeral=True
            )
        await interaction.response.defer(ephemeral=True)

        plan = PLANS.get("premium", {}).get(new_plan_name.lower())
        if not plan:
            return await interaction.followup.send(embed=create_error_embed("Invalid Plan", "Plan not found. Check `/plans premium`."))

        uid = str(interaction.user.id)
        async with data_lock:
            if uid not in vps_data or vps_number < 1 or vps_number > len(vps_data[uid]):
                return await interaction.followup.send(embed=create_error_embed("Error", "Invalid VPS number."))
            vps = vps_data[uid][vps_number - 1]

        cost = 200  # Fixed cost; extend with dynamic logic as needed

        conn = get_db()
        cur  = conn.cursor()
        cur.execute("SELECT credits FROM users WHERE user_id=?", (uid,))
        row = cur.fetchone()
        if not row or row["credits"] < cost:
            conn.close()
            return await interaction.followup.send(embed=create_error_embed("Insufficient Credits", f"You need **{cost}** credits to upgrade."))
        cur.execute("UPDATE users SET credits = credits - ? WHERE user_id=?", (cost, uid))
        conn.commit()
        conn.close()

        node   = vps.get("node", "local")
        prefix = f"{node}:" if node != "local" else ""
        full   = f"{prefix}{vps['container_name']}"

        try:
            await execute_lxc(f"lxc config set {full} limits.memory {plan['ram']}GB")
            await execute_lxc(f"lxc config set {full} limits.cpu {plan['cpu']}")
            async with data_lock:
                vps["ram"]    = f"{plan['ram']}GB"
                vps["cpu"]    = str(plan["cpu"])
                vps["config"] = f"{plan['ram']}GB RAM / {plan['cpu']} CPU / {vps['storage']} Disk"
            await async_save_vps_data()
            await interaction.followup.send(embed=create_success_embed("Upgraded!", f"VPS upgraded to **{new_plan_name.title()}** plan."))
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Error", str(e)[:4000]))


async def setup(bot):
    await bot.add_cog(UpgradeCog(bot))
