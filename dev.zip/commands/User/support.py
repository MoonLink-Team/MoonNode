import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MAIN_ADMIN_ID
from core.ext import ticket_enabled, ext_disabled_embed
from core.database import admin_data, vps_data, data_lock, get_setting
from core.theme import create_success_embed, create_error_embed, create_info_embed, create_warning_embed, create_embed, add_field, Theme


def is_staff(user_id):
    role = admin_data.get(str(user_id))
    return role in ["Owner", "Admin", "Dev", "Mod"] or str(user_id) == str(MAIN_ADMIN_ID)


# ── Ticket control buttons (sent inside the thread) ───────────────────────────

class TicketControlView(discord.ui.View):
    def __init__(self, opener_id: str):
        super().__init__(timeout=None)  # persistent
        self.opener_id = opener_id

    @discord.ui.button(label="✅  Claim Ticket", style=discord.ButtonStyle.success, custom_id="ticket_claim")
    async def claim(self, interaction: discord.Interaction, _: discord.ui.Button):
        if not is_staff(interaction.user.id):
            return await interaction.response.send_message(embed=create_error_embed("Denied", "Staff only."), ephemeral=True)
        embed = create_success_embed(
            "Ticket Claimed",
            f"🛡️ **{interaction.user.display_name}** is now handling this ticket.\n"
            "The user has been notified."
        )
        await interaction.response.send_message(embed=embed)
        # DM the opener
        try:
            opener = await interaction.client.fetch_user(int(self.opener_id))
            dm = discord.Embed(
                title="🎫  Your Ticket Was Claimed",
                description=(
                    f"A staff member (**{interaction.user.display_name}**) has picked up your support ticket.\n\n"
                    "They will respond shortly in the ticket thread. Please stay patient!"
                ),
                color=Theme.SUCCESS, timestamp=datetime.now(),
            )
            dm.set_author(name="MoonNodes Support", icon_url="https://imgur.com/6yfYDTP.png")
            await opener.send(embed=dm)
        except Exception:
            pass

    @discord.ui.button(label="🔒  Close Ticket", style=discord.ButtonStyle.danger, custom_id="ticket_close")
    async def close(self, interaction: discord.Interaction, _: discord.ui.Button):
        if not is_staff(interaction.user.id):
            return await interaction.response.send_message(embed=create_error_embed("Denied", "Staff only."), ephemeral=True)
        embed = create_info_embed(
            "Ticket Closed",
            f"✅ Resolved by **{interaction.user.display_name}**.\nThis thread has been archived."
        )
        await interaction.response.send_message(embed=embed)
        # DM the opener
        try:
            opener = await interaction.client.fetch_user(int(self.opener_id))
            dm = discord.Embed(
                title="🔒  Your Support Ticket Was Closed",
                description=(
                    "Your ticket has been marked as **resolved** by a staff member.\n\n"
                    "If your issue is not resolved, open a new ticket with `/support`."
                ),
                color=Theme.ACCENT, timestamp=datetime.now(),
            )
            dm.set_author(name="MoonNodes Support", icon_url="https://imgur.com/6yfYDTP.png")
            await opener.send(embed=dm)
        except Exception:
            pass
        await interaction.channel.edit(archived=True, locked=True)

    @discord.ui.button(label="✔️  Mark Done", style=discord.ButtonStyle.secondary, custom_id="ticket_done")
    async def done(self, interaction: discord.Interaction, _: discord.ui.Button):
        if not is_staff(interaction.user.id):
            return await interaction.response.send_message(embed=create_error_embed("Denied", "Staff only."), ephemeral=True)
        embed = create_success_embed(
            "Ticket Marked as Done",
            f"Marked by **{interaction.user.display_name}**. Awaiting user confirmation before closing."
        )
        await interaction.response.send_message(embed=embed)


class SupportCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="support", description="Open a support ticket for one of your VPS")
    @app_commands.describe(
        vps_number="Your VPS number (1, 2, 3…)",
        issue     ="Describe your issue in detail",
    )
    async def support_cmd(self, interaction: discord.Interaction, vps_number: int, issue: str):
        await interaction.response.defer(ephemeral=True)

        # ── Extension gate ───────────────────────────────────────────────────
        if not ticket_enabled():
            return await interaction.followup.send(
                embed=create_error_embed(
                    "Support Tickets Disabled",
                    "The Ticket System extension is currently off.\n"
                    "An admin can enable it via `/system-admin action:Extension Toggle extension:Ticket System`."
                )
            )

        uid = str(interaction.user.id)
        with data_lock:
            user_list = vps_data.get(uid, [])
            if not user_list or vps_number < 1 or vps_number > len(user_list):
                return await interaction.followup.send(
                    embed=create_error_embed("Invalid VPS", f"VPS #{vps_number} not found. Use `/list` to see your VPS.")
                )
            vps = user_list[vps_number - 1]

        ticket_ch_id = get_setting("ticket_channel")
        if not ticket_ch_id or ticket_ch_id == "0":
            return await interaction.followup.send(
                embed=create_error_embed("Not Configured", "No ticket channel set. Ask an admin to run `/set`.")
            )

        channel = interaction.guild.get_channel(int(ticket_ch_id))
        if not channel:
            return await interaction.followup.send(
                embed=create_error_embed("Channel Gone", "The ticket channel no longer exists.")
            )

        thread_name = f"🎫 ticket — {interaction.user.name} — vps{vps_number}"[:100]

        # Ticket embed
        embed = discord.Embed(
            title="🎫  New Support Ticket",
            description=(
                f"{Theme.DIVIDER}\n"
                f"**User:** {interaction.user.mention}\n"
                f"**VPS #{vps_number}:** `{vps['container_name']}`\n"
                f"{Theme.DIVIDER}"
            ),
            color=Theme.WARNING, timestamp=datetime.now(),
        )
        embed.set_author(name="MoonNodes Support System", icon_url="https://imgur.com/6yfYDTP.png")
        embed.set_thumbnail(url=interaction.user.display_avatar.url)
        add_field(embed, "📋 Issue",  issue,                             False)
        add_field(embed, "⚙️ Specs",  vps.get("config", "Custom"),      True)
        add_field(embed, "📌 Status", vps.get("status","?").upper(),     True)
        add_field(embed, "🌐 Node",   vps.get("node", "local"),          True)
        embed.set_footer(text=f"User ID: {uid}")

        try:
            thread = await channel.create_thread(
                name=thread_name,
                type=discord.ChannelType.private_thread,
                invitable=False,
            )
            ctrl_view = TicketControlView(opener_id=uid)
            await thread.send(
                content=f"<@{MAIN_ADMIN_ID}> {interaction.user.mention}",
                embed=embed,
                view=ctrl_view,
            )
            await thread.add_user(interaction.user)

            confirm = discord.Embed(
                title="🎫  Ticket Opened Successfully",
                description=(
                    f"Your support thread is ready: {thread.mention}\n\n"
                    "Staff have been notified and will respond shortly.\n"
                    "Please describe your issue further inside the thread if needed."
                ),
                color=Theme.SUCCESS, timestamp=datetime.now(),
            )
            confirm.set_author(name="MoonNodes Support", icon_url="https://imgur.com/6yfYDTP.png")
            await interaction.followup.send(embed=confirm)

        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Failed", f"{str(e)[:2000]}"))


async def setup(bot):
    await bot.add_cog(SupportCog(bot))
