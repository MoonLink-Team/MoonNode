"""
/support — Open a support ticket. Adds an "Add User" button inside the thread.
"""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MAIN_ADMIN_ID
from core.ext import ticket_enabled
from core.database import admin_data, vps_data, data_lock, get_setting
from core.theme import Theme, add_field, create_error_embed, create_info_embed, create_success_embed


def is_staff(user_id):
    role = admin_data.get(str(user_id))
    return role in ["Owner","Admin","Dev","Mod","Hard Mod","Hard Staff","Staff","Trial Staff","Trial Mod"] \
           or str(user_id) == str(MAIN_ADMIN_ID)


class AddUserModal(discord.ui.Modal, title="➕  Add User to Ticket"):
    user_id_input = discord.ui.TextInput(
        label="User ID or @mention",
        placeholder="Paste a Discord User ID (e.g. 123456789012345678)",
        max_length=50,
    )

    def __init__(self, thread: discord.Thread):
        super().__init__()
        self.thread = thread

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        raw = self.user_id_input.value.strip().strip("<@!>").strip()
        try:
            uid = int(raw)
            user = await interaction.client.fetch_user(uid)
        except Exception:
            return await interaction.followup.send(
                embed=create_error_embed("Invalid User", f"`{raw}` is not a valid User ID."),
                ephemeral=True,
            )
        try:
            await self.thread.add_user(user)
            await interaction.followup.send(
                embed=create_success_embed("User Added", f"{user.mention} has been added to this ticket."),
                ephemeral=True,
            )
        except Exception as e:
            await interaction.followup.send(
                embed=create_error_embed("Failed", str(e)[:1000]),
                ephemeral=True,
            )


class TicketControlView(discord.ui.View):
    def __init__(self, opener_id: str):
        super().__init__(timeout=None)
        self.opener_id = opener_id

    @discord.ui.button(label="✅  Claim", style=discord.ButtonStyle.success, custom_id="ticket_claim")
    async def claim(self, interaction: discord.Interaction, _: discord.ui.Button):
        if not is_staff(interaction.user.id):
            return await interaction.response.send_message(
                embed=create_error_embed("Denied", "Staff only."), ephemeral=True)
        await interaction.response.send_message(
            embed=create_success_embed("Ticket Claimed",
                f"🛡️ **{interaction.user.display_name}** is now handling this ticket."))
        try:
            opener = await interaction.client.fetch_user(int(self.opener_id))
            dm = discord.Embed(
                title="🎫  Your Ticket Was Claimed",
                description=(
                    f"**{interaction.user.display_name}** has picked up your support ticket.\n\n"
                    "They will respond shortly. Please stay patient!"
                ),
                color=Theme.SUCCESS, timestamp=datetime.now(),
            )
            dm.set_author(name="MoonNodes Support", icon_url="https://imgur.com/6yfYDTP.png")
            await opener.send(embed=dm)
        except Exception: pass

    @discord.ui.button(label="➕  Add User", style=discord.ButtonStyle.secondary, custom_id="ticket_add_user")
    async def add_user(self, interaction: discord.Interaction, _: discord.ui.Button):
        if not is_staff(interaction.user.id):
            return await interaction.response.send_message(
                embed=create_error_embed("Denied", "Staff only."), ephemeral=True)
        await interaction.response.send_modal(AddUserModal(thread=interaction.channel))

    @discord.ui.button(label="🔒  Close", style=discord.ButtonStyle.danger, custom_id="ticket_close")
    async def close(self, interaction: discord.Interaction, _: discord.ui.Button):
        if not is_staff(interaction.user.id):
            return await interaction.response.send_message(
                embed=create_error_embed("Denied", "Staff only."), ephemeral=True)
        await interaction.response.send_message(
            embed=create_info_embed("Ticket Closed",
                f"✅ Resolved by **{interaction.user.display_name}**."))
        try:
            opener = await interaction.client.fetch_user(int(self.opener_id))
            dm = discord.Embed(
                title="🔒  Support Ticket Closed",
                description=(
                    "Your ticket has been **resolved** by a staff member.\n\n"
                    "If your issue is not resolved, open a new one with `/support`."
                ),
                color=Theme.ACCENT, timestamp=datetime.now(),
            )
            dm.set_author(name="MoonNodes Support", icon_url="https://imgur.com/6yfYDTP.png")
            await opener.send(embed=dm)
        except Exception: pass
        try:
            await interaction.channel.edit(archived=True, locked=True)
        except Exception: pass

    @discord.ui.button(label="✔️  Mark Done", style=discord.ButtonStyle.secondary, custom_id="ticket_done")
    async def done(self, interaction: discord.Interaction, _: discord.ui.Button):
        if not is_staff(interaction.user.id):
            return await interaction.response.send_message(
                embed=create_error_embed("Denied", "Staff only."), ephemeral=True)
        await interaction.response.send_message(
            embed=create_success_embed("Marked Done",
                f"Marked by **{interaction.user.display_name}**. Awaiting user confirmation."))


class SupportCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="support", description="Open a support ticket for your VPS")
    @app_commands.describe(vps_number="Your VPS number (1, 2, 3…)", issue="Describe your issue")
    async def support_cmd(self, interaction: discord.Interaction, vps_number: int, issue: str):
        await interaction.response.defer(ephemeral=True)

        if not ticket_enabled():
            return await interaction.followup.send(embed=create_error_embed(
                "Tickets Disabled",
                "The Ticket System is currently off.\nContact an admin to enable it."))

        uid = str(interaction.user.id)
        async with data_lock:
            user_list = vps_data.get(uid, [])
            if not user_list or vps_number < 1 or vps_number > len(user_list):
                return await interaction.followup.send(embed=create_error_embed(
                    "Invalid VPS", f"VPS #{vps_number} not found. Use `/list` to see your VPS."))
            vps = user_list[vps_number - 1]

        ticket_ch_id = get_setting("ticket_channel")
        if not ticket_ch_id or ticket_ch_id == "0":
            return await interaction.followup.send(embed=create_error_embed(
                "Not Configured", "No ticket channel set. Ask an admin to run `/set`."))

        channel = interaction.guild.get_channel(int(ticket_ch_id))
        if not channel:
            return await interaction.followup.send(embed=create_error_embed(
                "Channel Gone", "The configured ticket channel no longer exists."))

        thread_name = f"🎫 {interaction.user.name} • VPS #{vps_number}"[:100]

        embed = discord.Embed(
            title="🎫  New Support Ticket",
            description=(
                f"{Theme.DIVIDER}\n"
                f"**User:** {interaction.user.mention}\n"
                f"**VPS #{vps_number}:** `{vps['container_name']}`\n"
                f"{Theme.DIVIDER}"
            ),
            color=Theme.WARNING, timestamp=datetime.now(),
        )
        embed.set_author(name="MoonNodes Support System", icon_url="https://imgur.com/6yfYDTP.png")
        embed.set_thumbnail(url=interaction.user.display_avatar.url)
        add_field(embed, "📋 Issue",  issue,                       False)
        add_field(embed, "⚙️ Specs",  vps.get("config","Custom"),  True)
        add_field(embed, "📌 Status", vps.get("status","?").upper(),True)
        add_field(embed, "🌐 Node",   vps.get("node","local"),      True)
        embed.set_footer(text=f"User ID: {uid}")

        try:
            thread = await channel.create_thread(
                name=thread_name,
                type=discord.ChannelType.private_thread,
                invitable=False,
            )
            ctrl = TicketControlView(opener_id=uid)
            await thread.send(
                content=f"<@{MAIN_ADMIN_ID}> {interaction.user.mention}",
                embed=embed, view=ctrl,
            )
            await thread.add_user(interaction.user)

            confirm = discord.Embed(
                title="🎫  Ticket Opened",
                description=(
                    f"Your support thread is ready: {thread.mention}\n\n"
                    "Staff have been notified and will respond shortly."
                ),
                color=Theme.SUCCESS, timestamp=datetime.now(),
            )
            confirm.set_author(name="MoonNodes Support", icon_url="https://imgur.com/6yfYDTP.png")
            await interaction.followup.send(embed=confirm)
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Failed", str(e)[:2000]))


async def setup(bot):
    await bot.add_cog(SupportCog(bot))
