"""
/support — Open a support ticket as a dedicated channel inside a category.

/set setting:Ticket Category value:<CATEGORY_ID>
The bot creates a new text channel inside that category for each ticket.
Staff get: Claim · Add User · Close · Mark Done buttons.
"""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MAIN_ADMIN_ID
from core.ext import ticket_enabled
from core.database import admin_data, vps_data, data_lock, get_setting
from core.theme import Theme, add_field, create_error_embed, create_info_embed, create_success_embed


def is_staff(uid):
    role = admin_data.get(str(uid))
    return role in ["Owner","Admin","Dev","Hard Admin","Manager","Mod","Hard Mod",
                    "Hard Staff","Staff","Trial Staff","Trial Mod"] \
           or str(uid) == str(MAIN_ADMIN_ID)


class AddUserModal(discord.ui.Modal, title="➕ Add User to Ticket"):
    user_id_input = discord.ui.TextInput(
        label="User ID",
        placeholder="Paste a Discord User ID  (e.g. 123456789012345678)",
        max_length=50,
    )
    def __init__(self, channel: discord.TextChannel):
        super().__init__()
        self.channel = channel

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        raw = self.user_id_input.value.strip().strip("<@!>")
        try:
            uid  = int(raw)
            user = await interaction.client.fetch_user(uid)
        except Exception:
            return await interaction.followup.send(
                embed=create_error_embed("Invalid User", f"`{raw}` is not a valid User ID."), ephemeral=True)
        try:
            await self.channel.set_permissions(user, read_messages=True, send_messages=True)
            await self.channel.send(f"➕ {user.mention} has been added to this ticket by {interaction.user.mention}.")
            await interaction.followup.send(
                embed=create_success_embed("User Added", f"{user.mention} can now see this ticket."), ephemeral=True)
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Failed", str(e)[:500]), ephemeral=True)


class TicketControlView(discord.ui.View):
    def __init__(self, opener_id: str):
        super().__init__(timeout=None)
        self.opener_id = opener_id

    @discord.ui.button(label="✅ Claim", style=discord.ButtonStyle.success, custom_id="tkt_claim")
    async def claim(self, interaction: discord.Interaction, _: discord.ui.Button):
        if not is_staff(interaction.user.id):
            return await interaction.response.send_message(
                embed=create_error_embed("Denied", "Staff only."), ephemeral=True)
        await interaction.response.send_message(
            embed=create_success_embed("Ticket Claimed",
                f"🛡️ **{interaction.user.display_name}** is now handling this ticket."))
        try:
            opener = await interaction.client.fetch_user(int(self.opener_id))
            dm = discord.Embed(title="🎫 Your Ticket Was Claimed",
                description=f"**{interaction.user.display_name}** has picked up your support ticket. They'll respond shortly.",
                color=Theme.SUCCESS, timestamp=datetime.now())
            dm.set_author(name="MoonNodes Support", icon_url="https://imgur.com/6yfYDTP.png")
            await opener.send(embed=dm)
        except Exception: pass

    @discord.ui.button(label="➕ Add User", style=discord.ButtonStyle.secondary, custom_id="tkt_adduser")
    async def add_user(self, interaction: discord.Interaction, _: discord.ui.Button):
        if not is_staff(interaction.user.id):
            return await interaction.response.send_message(
                embed=create_error_embed("Denied", "Staff only."), ephemeral=True)
        await interaction.response.send_modal(AddUserModal(channel=interaction.channel))

    @discord.ui.button(label="🔒 Close", style=discord.ButtonStyle.danger, custom_id="tkt_close")
    async def close(self, interaction: discord.Interaction, _: discord.ui.Button):
        if not is_staff(interaction.user.id):
            return await interaction.response.send_message(
                embed=create_error_embed("Denied", "Staff only."), ephemeral=True)
        await interaction.response.send_message(
            embed=create_info_embed("Ticket Closed", f"✅ Resolved by **{interaction.user.display_name}**."))
        try:
            opener = await interaction.client.fetch_user(int(self.opener_id))
            dm = discord.Embed(title="🔒 Support Ticket Closed",
                description="Your ticket has been resolved.\nIf your issue persists, open a new one with `/support`.",
                color=Theme.ACCENT, timestamp=datetime.now())
            dm.set_author(name="MoonNodes Support", icon_url="https://imgur.com/6yfYDTP.png")
            await opener.send(embed=dm)
        except Exception: pass
        await discord.utils.sleep_until(datetime.now())
        try: await interaction.channel.delete(reason="Ticket closed")
        except Exception: pass

    @discord.ui.button(label="✔️ Mark Done", style=discord.ButtonStyle.secondary, custom_id="tkt_done")
    async def done(self, interaction: discord.Interaction, _: discord.ui.Button):
        if not is_staff(interaction.user.id):
            return await interaction.response.send_message(
                embed=create_error_embed("Denied", "Staff only."), ephemeral=True)
        await interaction.response.send_message(
            embed=create_success_embed("Marked Done",
                f"Marked by **{interaction.user.display_name}**. Awaiting user confirmation."))


class SupportCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="support", description="Open a support ticket for your VPS")
    @app_commands.describe(vps_number="Your VPS number (1, 2…)", issue="Describe your issue")
    async def support_cmd(self, interaction: discord.Interaction, vps_number: int, issue: str):
        await interaction.response.defer(ephemeral=True)

        if not ticket_enabled():
            return await interaction.followup.send(embed=create_error_embed(
                "Tickets Disabled",
                "The ticket system is currently off.\nAsk an admin to run `/system action:Extension Toggle extension:Ticket System ext_state:Enable`."))

        uid = str(interaction.user.id)
        async with data_lock:
            user_list = vps_data.get(uid, [])
            if not user_list or vps_number < 1 or vps_number > len(user_list):
                return await interaction.followup.send(embed=create_error_embed(
                    "Invalid VPS", f"VPS #{vps_number} not found. Use `/list` to see your VPS."))
            vps = dict(user_list[vps_number - 1])

        cat_id = get_setting("ticket_channel")
        if not cat_id or cat_id == "0":
            return await interaction.followup.send(embed=create_error_embed(
                "Not Configured",
                "No ticket category set.\nAdmin: `/set setting:Ticket Category value:<CATEGORY_ID>`"))

        try:
            category = interaction.guild.get_channel(int(cat_id))
        except Exception:
            category = None

        if not category or not isinstance(category, discord.CategoryChannel):
            return await interaction.followup.send(embed=create_error_embed(
                "Invalid Category",
                f"ID `{cat_id}` is not a category channel. Use `/set` to update it."))

        ch_name = f"ticket-{interaction.user.name}-vps{vps_number}"[:100]

        # Check if user already has an open ticket
        for ch in category.channels:
            if isinstance(ch, discord.TextChannel) and str(interaction.user.id) in ch.topic or "":
                return await interaction.followup.send(embed=create_error_embed(
                    "Already Open",
                    f"You already have an open ticket: {ch.mention}\nClose it before opening a new one."))

        embed = discord.Embed(
            title="🎫 New Support Ticket",
            description=(
                f"{Theme.DIVIDER}\n"
                f"**User:** {interaction.user.mention}\n"
                f"**VPS #{vps_number}:** `{vps['container_name']}`\n"
                f"{Theme.DIVIDER}"
            ),
            color=Theme.WARNING, timestamp=datetime.now(),
        )
        embed.set_author(name="MoonNodes Support System", icon_url="https://imgur.com/6yfYDTP.png")
        embed.set_thumbnail(url=interaction.user.display_avatar.url)
        add_field(embed, "📋 Issue",   issue,                      False)
        add_field(embed, "⚙️ Specs",   vps.get("config","Custom"), True)
        add_field(embed, "📌 Status",  vps.get("status","?").upper(), True)
        add_field(embed, "🌐 Node",    vps.get("node","local"),    True)
        embed.set_footer(text=f"User ID: {uid} · MoonNodes Support")

        try:
            # Overwrites: deny @everyone, allow opener + staff roles
            overwrites = {
                interaction.guild.default_role: discord.PermissionOverwrite(read_messages=False),
                interaction.user:               discord.PermissionOverwrite(read_messages=True, send_messages=True),
                interaction.guild.me:           discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_channels=True),
            }
            channel = await category.create_text_channel(
                name=ch_name,
                topic=f"Ticket by {interaction.user.id} | VPS #{vps_number}",
                overwrites=overwrites,
            )
            ctrl = TicketControlView(opener_id=uid)
            await channel.send(
                content=f"<@{MAIN_ADMIN_ID}> {interaction.user.mention}",
                embed=embed, view=ctrl,
            )
            confirm = discord.Embed(
                title="🎫 Ticket Opened",
                description=f"Your support channel is ready: {channel.mention}\n\nStaff will respond shortly.",
                color=Theme.SUCCESS, timestamp=datetime.now(),
            )
            confirm.set_author(name="MoonNodes Support", icon_url="https://imgur.com/6yfYDTP.png")
            await interaction.followup.send(embed=confirm)
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Failed to Create Ticket", str(e)[:2000]))


async def setup(bot):
    await bot.add_cog(SupportCog(bot))
