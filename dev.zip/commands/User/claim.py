"""
/claim — Claim a Free or Premium VPS.

Free plans can require invites (inv) or MoonCoins (coin).
Premium plans require a payment screenshot forwarded to admins.
"""

import re
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import CLAIM_PREMIUM, CLAIM_FREE, MAIN_ADMIN_ID
from core.database import admin_data, get_db, get_setting, vps_data, data_lock
from core.theme import Theme, add_field, create_embed, create_error_embed, create_info_embed, create_loading_embed, create_success_embed, create_warning_embed
from feature.plans.plans_manager import PLANS
from ui.os_select import OSSelectView


def _get_coins(user_id: str) -> int:
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("SELECT mooncoin FROM users WHERE user_id=?", (user_id,))
    row = cur.fetchone()
    conn.close()
    return row["mooncoin"] if row else 0


def _spend_coins(user_id: str, amount: int):
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (user_id,))
    cur.execute("UPDATE users SET mooncoin = mooncoin - ? WHERE user_id=?", (amount, user_id))
    conn.commit()
    conn.close()


def _get_invites(user_id: str) -> int:
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("SELECT invites_used FROM users WHERE user_id=?", (user_id,))
    row = cur.fetchone()
    conn.close()
    return row["invites_used"] if row else 0


def _spend_invites(user_id: str, amount: int):
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (user_id,))
    cur.execute("UPDATE users SET invites_used = invites_used - ? WHERE user_id=?", (amount, user_id))
    conn.commit()
    conn.close()


class ClaimCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="claim", description="Claim a Free or Premium VPS plan")
    @app_commands.choices(claim_type=[
        app_commands.Choice(name="Premium",  value="premium"),
        app_commands.Choice(name="Free",     value="free"),
    ])
    @app_commands.choices(option=[
        app_commands.Choice(name="Pay with Invites",    value="inv"),
        app_commands.Choice(name="Pay with MoonCoins",  value="coin"),
    ])
    @app_commands.describe(
        claim_type   = "Premium (payment) or Free (inv/coin)",
        option       = "Free plan payment method: inv or coin",
        code_or_plan = "Plan name — see /plans (e.g. basic, starter)",
        proof        = "Payment screenshot (Premium only)",
    )
    async def claim_cmd(
        self,
        interaction: discord.Interaction,
        claim_type: str,
        code_or_plan: str,
        option: str = None,
        proof: discord.Attachment = None,
    ):
        await interaction.response.defer(ephemeral=True)
        uid       = str(interaction.user.id)
        plan_name = code_or_plan.lower().strip()

        # ── Guard: plan must exist ───────────────────────────────────────────
        if claim_type == "premium" and not CLAIM_PREMIUM:
            return await interaction.followup.send(embed=create_error_embed("Disabled", "Premium claims are currently disabled."))
        if claim_type == "free" and not CLAIM_FREE:
            return await interaction.followup.send(embed=create_error_embed("Disabled", "Free claims are currently disabled."))

        plans_for_type = PLANS.get(claim_type, {})
        if plan_name not in plans_for_type:
            return await interaction.followup.send(
                embed=create_error_embed("Invalid Plan", f"`{plan_name}` is not a valid **{claim_type}** plan. Use `/plans` to see available options.")
            )

        p = plans_for_type[plan_name]

        # ── Premium: forward proof to payment channel ────────────────────────
        if claim_type == "premium":
            if not proof or not proof.content_type.startswith("image/"):
                return await interaction.followup.send(
                    embed=create_error_embed("Proof Required", "Attach a **screenshot** of your payment receipt as an image.")
                )
            pay_ch_id = get_setting("payment_channel")
            if not pay_ch_id or pay_ch_id == "0":
                return await interaction.followup.send(
                    embed=create_error_embed("Not Configured", "Admins have not set a payment channel yet.")
                )

            embed = discord.Embed(
                title="💳  New Premium VPS Claim",
                color=Theme.WARNING,
                timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes — Claim Request", icon_url="https://imgur.com/6yfYDTP.png")
            embed.set_thumbnail(url=interaction.user.display_avatar.url)
            embed.add_field(name="User",   value=interaction.user.mention, inline=True)
            embed.add_field(name="Plan",   value=plan_name.title(),        inline=True)
            embed.add_field(name="Specs",  value=f"`{p['ram']}GB RAM · {p['cpu']} CPU · {p['disk']}GB Disk`", inline=False)
            embed.add_field(name="Price",  value=p.get("price","—"),        inline=True)
            embed.add_field(name="Validity", value=p.get("validity","—"),   inline=True)
            embed.set_image(url=proof.url)
            embed.set_footer(text=f"User ID: {uid}")

            channel = interaction.guild.get_channel(int(pay_ch_id))
            if channel:
                await channel.send(f"<@{MAIN_ADMIN_ID}> — New claim awaiting approval", embed=embed)

            return await interaction.followup.send(
                embed=create_success_embed(
                    "Claim Submitted ✅",
                    "Your payment proof has been forwarded to the admins.\n"
                    "They will review it and deploy your VPS shortly. Please be patient!"
                )
            )

        # ── Free: parse price requirement ────────────────────────────────────
        price_str = p.get("price", "Free").lower()

        inv_match  = re.search(r"invite\s+(\d+)", price_str)
        coin_match = re.search(r"coin\s+(\d+)", price_str)

        req_inv  = int(inv_match.group(1))  if inv_match  else 0
        req_coin = int(coin_match.group(1)) if coin_match else 0

        # Decide which payment method to use
        if req_inv > 0 or req_coin > 0:
            if option not in ("inv", "coin"):
                opts = []
                if req_inv  > 0: opts.append(f"**{req_inv} invites** (option: `inv`)")
                if req_coin > 0: opts.append(f"**{req_coin} MoonCoins** (option: `coin`)")
                return await interaction.followup.send(
                    embed=create_warning_embed(
                        "Choose Payment Method",
                        f"The **{plan_name.title()}** plan requires payment.\nAvailable options:\n" + "\n".join(f"• {o}" for o in opts)
                    )
                )

            if option == "inv":
                if req_inv == 0:
                    return await interaction.followup.send(embed=create_error_embed("Invalid", "This plan does not accept invite payments."))
                available = _get_invites(uid)
                if available < req_inv:
                    return await interaction.followup.send(
                        embed=create_error_embed(
                            "Not Enough Invites",
                            f"You need **{req_inv}** tracked invites.\nYou currently have **{available}**.\n\n"
                            "Invite friends to the server to earn invite credits."
                        )
                    )
                _spend_invites(uid, req_inv)

            elif option == "coin":
                if req_coin == 0:
                    return await interaction.followup.send(embed=create_error_embed("Invalid", "This plan does not accept MoonCoin payments."))
                balance = _get_coins(uid)
                if balance < req_coin:
                    return await interaction.followup.send(
                        embed=create_error_embed(
                            "Not Enough MoonCoins",
                            f"You need **{req_coin:,}** 🌙 MoonCoins.\nYour balance: **{balance:,}**.\n\n"
                            "Earn coins by chatting, inviting friends, joining events, and giveaways."
                        )
                    )
                _spend_coins(uid, req_coin)

        # ── Launch OS selector ───────────────────────────────────────────────
        validity_days = None
        if "validity" in p:
            m = re.search(r"(\d+)", p["validity"])
            if m:
                validity_days = int(m.group(1))

        from core import ACTIVE_STORAGE_POOL
        view = OSSelectView(
            ram=p["ram"], cpu=p["cpu"], disk=p["disk"],
            user=interaction.user, invoker=interaction,
            plan_name=plan_name, validity_days=validity_days,
            target_node="", storage_pool=ACTIVE_STORAGE_POOL,
        )
        paid_str = ""
        if option == "inv"  and req_inv  > 0: paid_str = f"Paid with **{req_inv} invites**.\n"
        if option == "coin" and req_coin > 0: paid_str = f"Paid with **{req_coin:,}** 🌙 MoonCoins.\n"

        await interaction.edit_original_response(
            embed=create_info_embed(
                f"Claiming {plan_name.title()} Plan",
                f"{paid_str}Choose your operating system below to continue:",
            ),
            view=view,
        )


async def setup(bot):
    await bot.add_cog(ClaimCog(bot))