"""
/claim — Claim a Free or Premium VPS plan.

Premium flow:
  1. User submits /claim + payment screenshot
  2. Bot posts to payment channel with Continue + Cancel buttons
  3. Admin clicks Continue → Node select → OS select → DM user "payment approved"
  4. Admin clicks Cancel → reason modal → DM user "payment cancelled + reason"

Free flow:
  1. User pays with invites or MoonCoins
  2. OS select → deploy immediately
"""

import re
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime, timedelta

from core.config import CLAIM_PREMIUM, CLAIM_FREE, MAIN_ADMIN_ID
from core.database import admin_data, get_db, get_setting, vps_data, data_lock
from core.theme import Theme, add_field, create_error_embed, create_info_embed, create_success_embed, create_warning_embed
from feature.plans.plans_manager import PLANS
from ui.os_select import OSSelectView
from ui.node_select import NodeSelectView


def _is_admin(uid):
    if str(uid) == str(MAIN_ADMIN_ID): return True
    return admin_data.get(str(uid), "") in ("Owner","Admin","Hard Admin","Manager")

def _get_coins(uid: str) -> int:
    try:
        conn = get_db(); cur = conn.cursor()
        cur.execute("SELECT mooncoin FROM users WHERE user_id=?", (uid,))
        row = cur.fetchone(); return row["mooncoin"] if row else 0
    except Exception: return 0

def _spend_coins(uid: str, amount: int):
    conn = get_db(); cur = conn.cursor()
    cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (uid,))
    cur.execute("UPDATE users SET mooncoin = mooncoin - ? WHERE user_id=?", (amount, uid))
    conn.commit()

def _get_invites(uid: str) -> int:
    try:
        conn = get_db(); cur = conn.cursor()
        cur.execute("SELECT COUNT(*) as cnt FROM invite_tracking WHERE inviter_id=? AND valid=1", (uid,))
        row = cur.fetchone(); return row["cnt"] if row else 0
    except Exception:
        try:
            conn = get_db(); cur = conn.cursor()
            cur.execute("SELECT invites_used FROM users WHERE user_id=?", (uid,))
            row = cur.fetchone(); return row["invites_used"] if row else 0
        except Exception: return 0

def _spend_invites(uid: str, amount: int):
    conn = get_db(); cur = conn.cursor()
    cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (uid,))
    cur.execute("UPDATE users SET invites_used = MAX(0, invites_used - ?) WHERE user_id=?", (amount, uid))
    conn.commit()


# ── Admin Cancel Modal ────────────────────────────────────────────────────────

class CancelReasonModal(discord.ui.Modal, title="❌  Cancel Claim — Enter Reason"):
    reason = discord.ui.TextInput(
        label="Reason for cancellation",
        placeholder="e.g. Payment amount does not match, wrong account, etc.",
        style=discord.TextStyle.paragraph,
        max_length=500,
    )

    def __init__(self, user_id: str, claim_id: int, plan_name: str):
        super().__init__()
        self.user_id   = user_id
        self.claim_id  = claim_id
        self.plan_name = plan_name

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer()
        reason_text = self.reason.value.strip()

        # Update DB
        try:
            conn = get_db(); cur = conn.cursor()
            cur.execute(
                "UPDATE claim_requests SET status='cancelled', handled_by=?, cancel_reason=? WHERE id=?",
                (str(interaction.user.id), reason_text, self.claim_id)
            )
            conn.commit()
        except Exception: pass

        # DM the user
        try:
            user = await interaction.client.fetch_user(int(self.user_id))
            dm = discord.Embed(
                title="❌  Your Payment Claim Was Cancelled",
                description=(
                    f"Your **{self.plan_name.title()}** VPS claim has been **cancelled** by a staff member.\n\n"
                    f"**Reason:** {reason_text}\n\n"
                    "If you believe this is a mistake, please open a support ticket with `/support`."
                ),
                color=0xED4245, timestamp=datetime.now(),
            )
            dm.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
            dm.set_footer(text="MoonNodes — Payment System")
            await user.send(embed=dm)
        except Exception: pass

        await interaction.message.edit(
            content="❌ **Claim cancelled.**",
            embed=interaction.message.embeds[0] if interaction.message.embeds else None,
            view=None,
        )
        await interaction.followup.send(
            embed=create_info_embed("Claim Cancelled", f"User `{self.user_id}` has been notified."),
            ephemeral=True,
        )


# ── Admin Approve Flow: payment channel buttons ───────────────────────────────

class ClaimApprovalView(discord.ui.View):
    def __init__(self, user_id: str, claim_id: int, plan: dict, plan_name: str, validity_days):
        super().__init__(timeout=None)
        self.user_id      = user_id
        self.claim_id     = claim_id
        self.plan         = plan
        self.plan_name    = plan_name
        self.validity_days = validity_days

    @discord.ui.button(label="✅  Continue — Approve & Deploy", style=discord.ButtonStyle.success, emoji="✅")
    async def approve(self, interaction: discord.Interaction, _: discord.ui.Button):
        if not _is_admin(interaction.user.id):
            return await interaction.response.send_message(
                embed=create_error_embed("No Permission", "Only admins can approve claims."), ephemeral=True)

        # Update DB
        try:
            conn = get_db(); cur = conn.cursor()
            cur.execute("UPDATE claim_requests SET status='approved', handled_by=? WHERE id=?",
                        (str(interaction.user.id), self.claim_id))
            conn.commit()
        except Exception: pass

        # DM user: payment approved
        try:
            user = await interaction.client.fetch_user(int(self.user_id))
            dm = discord.Embed(
                title="✅  Payment Approved!",
                description=(
                    f"Your **{self.plan_name.title()}** VPS payment has been **approved** by staff!\n\n"
                    "Your VPS is now being set up. You'll receive another DM when it's ready.\n\n"
                    "This usually takes 1–3 minutes."
                ),
                color=0x57F287, timestamp=datetime.now(),
            )
            dm.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
            await user.send(embed=dm)
        except Exception: pass

        # Disable buttons, show node select for admin
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(
            content=f"✅ **Approved by {interaction.user.mention}** — Select node to deploy:",
            view=self,
        )

        # Fetch target user for node_select → os_select
        try:
            from core import ACTIVE_STORAGE_POOL
            target_user = await interaction.client.fetch_user(int(self.user_id))

            node_view = await NodeSelectView.create(
                invoker_id    = str(interaction.user.id),
                ram           = self.plan["ram"],
                cpu           = self.plan["cpu"],
                disk          = self.plan["disk"],
                target_user   = target_user,
                plan_name     = self.plan_name,
                validity_days = self.validity_days,
                storage_pool  = ACTIVE_STORAGE_POOL,
                dm_user_on_deploy = True,  # flag to DM user when done
            )
            await interaction.followup.send(
                embed=create_info_embed("Step 1 – Select Node",
                    f"**User:** `{target_user}` | **Plan:** `{self.plan_name.title()}`"),
                view=node_view,
                ephemeral=True,
            )
        except Exception as e:
            await interaction.followup.send(
                embed=create_error_embed("Error", str(e)[:1000]), ephemeral=True)

    @discord.ui.button(label="❌  Cancel Claim", style=discord.ButtonStyle.danger, emoji="❌")
    async def cancel(self, interaction: discord.Interaction, _: discord.ui.Button):
        if not _is_admin(interaction.user.id):
            return await interaction.response.send_message(
                embed=create_error_embed("No Permission", "Only admins can cancel claims."), ephemeral=True)
        await interaction.response.send_modal(
            CancelReasonModal(self.user_id, self.claim_id, self.plan_name))


# ── /claim command ────────────────────────────────────────────────────────────

class ClaimCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="claim", description="Claim a Free or Premium VPS plan")
    @app_commands.choices(claim_type=[
        app_commands.Choice(name="Premium",        value="premium"),
        app_commands.Choice(name="Free",           value="free"),
    ])
    @app_commands.choices(option=[
        app_commands.Choice(name="Pay with Invites",   value="inv"),
        app_commands.Choice(name="Pay with MoonCoins", value="coin"),
    ])
    @app_commands.describe(
        claim_type   = "Premium (payment) or Free (inv/coin)",
        option       = "Free plan payment: inv or coin",
        code_or_plan = "Plan name — see /plans (e.g. basic, starter)",
        proof        = "Payment screenshot (Premium only)",
    )
    async def claim_cmd(
        self, interaction: discord.Interaction,
        claim_type: str,
        code_or_plan: str,
        option: str = None,
        proof: discord.Attachment = None,
    ):
        await interaction.response.defer(ephemeral=True)
        uid       = str(interaction.user.id)
        plan_name = code_or_plan.lower().strip()

        if claim_type == "premium" and not CLAIM_PREMIUM:
            return await interaction.followup.send(embed=create_error_embed("Disabled", "Premium claims are currently disabled."))
        if claim_type == "free" and not CLAIM_FREE:
            return await interaction.followup.send(embed=create_error_embed("Disabled", "Free claims are currently disabled."))

        plans_for_type = PLANS.get(claim_type, {})
        if plan_name not in plans_for_type:
            available = ", ".join(f"`{k}`" for k in plans_for_type) or "none"
            return await interaction.followup.send(embed=create_error_embed(
                "Invalid Plan",
                f"`{plan_name}` is not a valid **{claim_type}** plan.\n\n"
                f"Available: {available}\nUse `/plans` to see details."
            ))

        p = plans_for_type[plan_name]

        # ── Premium: forward proof to payment channel ─────────────────────────
        if claim_type == "premium":
            if not proof or not proof.content_type.startswith("image/"):
                return await interaction.followup.send(embed=create_error_embed(
                    "Proof Required", "Attach a **screenshot** of your payment as an image file."))

            pay_ch_id = get_setting("payment_channel")
            if not pay_ch_id or pay_ch_id == "0":
                return await interaction.followup.send(embed=create_error_embed(
                    "Not Configured", "Admins have not set a payment channel yet."))

            validity_days = None
            if "validity" in p:
                m = re.search(r"(\d+)", p.get("validity",""))
                if m: validity_days = int(m.group(1))

            # Save claim to DB
            claim_id = None
            try:
                conn = get_db(); cur = conn.cursor()
                cur.execute(
                    "INSERT INTO claim_requests (user_id,plan_name,plan_type,ram_gb,cpu_cores,disk_gb,validity_days,proof_url,status,created_at) "
                    "VALUES (?,?,?,?,?,?,?,?,'pending',?)",
                    (uid, plan_name, "premium", p["ram"], p["cpu"], p["disk"],
                     validity_days, proof.url, datetime.now().isoformat())
                )
                conn.commit()
                claim_id = cur.lastrowid
            except Exception: claim_id = 0

            embed = discord.Embed(
                title="💳  New Premium VPS Claim",
                description=(
                    f"{Theme.DIVIDER}\n"
                    f"**User:** {interaction.user.mention} (`{uid}`)\n"
                    f"**Plan:** `{plan_name.title()}` — {p.get('price','—')}\n"
                    f"{Theme.DIVIDER}"
                ),
                color=Theme.WARNING, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes — Claim Request", icon_url="https://imgur.com/6yfYDTP.png")
            embed.set_thumbnail(url=interaction.user.display_avatar.url)
            add_field(embed, "📦 Specs",    f"`{p['ram']}GB RAM · {p['cpu']} CPU · {p['disk']}GB Disk`", False)
            add_field(embed, "💰 Price",    p.get("price","—"),     True)
            add_field(embed, "⏳ Validity", p.get("validity","—"),  True)
            embed.set_image(url=proof.url)
            embed.set_footer(text=f"Claim ID #{claim_id} · {datetime.now().strftime('%Y-%m-%d %H:%M')}")

            approval_view = ClaimApprovalView(
                user_id=uid, claim_id=claim_id, plan=p,
                plan_name=plan_name, validity_days=validity_days,
            )

            channel = interaction.guild.get_channel(int(pay_ch_id))
            if channel:
                await channel.send(
                    content=f"<@{MAIN_ADMIN_ID}> — New premium claim awaiting approval",
                    embed=embed, view=approval_view,
                )

            return await interaction.followup.send(embed=create_success_embed(
                "Claim Submitted ✅",
                "Your payment proof has been forwarded to staff.\n"
                "You'll receive a DM when your payment is reviewed.\n\n"
                "⏱️ *Average review time: 1–12 hours*"
            ))

        # ── Free: check payment ───────────────────────────────────────────────
        price_str  = p.get("price","Free").lower()
        inv_match  = re.search(r"invite\s+(\d+)", price_str)
        coin_match = re.search(r"coin\s+(\d+)",   price_str)
        req_inv    = int(inv_match.group(1))  if inv_match  else 0
        req_coin   = int(coin_match.group(1)) if coin_match else 0

        if req_inv > 0 or req_coin > 0:
            if option not in ("inv", "coin"):
                opts = []
                if req_inv  > 0: opts.append(f"**{req_inv} invites** — option: `inv`")
                if req_coin > 0: opts.append(f"**{req_coin:,} MoonCoins** — option: `coin`")
                return await interaction.followup.send(embed=create_warning_embed(
                    "Choose Payment",
                    f"**{plan_name.title()}** plan requires payment. Available options:\n"
                    + "\n".join(f"› {o}" for o in opts)
                ))

            if option == "inv":
                if req_inv == 0:
                    return await interaction.followup.send(embed=create_error_embed("Invalid","This plan does not accept invite payments."))
                available = _get_invites(uid)
                if available < req_inv:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Not Enough Invites",
                        f"You need **{req_inv}** valid invites (users who stayed 7+ days).\n"
                        f"You have **{available}**.\n\nInvite friends to earn credits!"
                    ))
                _spend_invites(uid, req_inv)

            elif option == "coin":
                if req_coin == 0:
                    return await interaction.followup.send(embed=create_error_embed("Invalid","This plan does not accept MoonCoin payments."))
                balance = _get_coins(uid)
                if balance < req_coin:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Not Enough MoonCoins 🌙",
                        f"You need **{req_coin:,}** 🌙 MoonCoins.\n"
                        f"Your balance: **{balance:,}**.\n\n"
                        "Earn coins by chatting, inviting friends, joining events and giveaways."
                    ))
                _spend_coins(uid, req_coin)

        validity_days = None
        if "validity" in p:
            m = re.search(r"(\d+)", p.get("validity",""))
            if m: validity_days = int(m.group(1))

        from core import ACTIVE_STORAGE_POOL
        view = OSSelectView(
            ram=p["ram"], cpu=p["cpu"], disk=p["disk"],
            user=interaction.user, invoker=interaction,
            plan_name=plan_name, validity_days=validity_days,
            target_node="", storage_pool=ACTIVE_STORAGE_POOL,
        )
        paid_str = ""
        if option == "inv"  and req_inv  > 0: paid_str = f"Paid with **{req_inv} invites**.\n"
        if option == "coin" and req_coin > 0: paid_str = f"Paid with **{req_coin:,}** 🌙 MoonCoins.\n"

        await interaction.edit_original_response(
            embed=create_info_embed(
                f"🌙 Claiming {plan_name.title()} Plan",
                f"{paid_str}Choose your operating system below to continue:",
            ),
            view=view,
        )


async def setup(bot):
    await bot.add_cog(ClaimCog(bot))
