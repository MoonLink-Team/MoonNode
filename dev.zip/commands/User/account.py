"""
/account — View MoonCoin balance, stats, and admin management.

MoonCoin earning rules:
  - Invite someone   → +5 coins
  - Chat in main ch  → +1 coin (5 min cooldown)
  - Join giveaway    → +3 coins
  - Join event       → +7 coins
  - VIP role         → +1% multiplier
  - 1st server boost → +2% multiplier
  - 2nd server boost → +3% multiplier
"""

import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import ACCOUNT, MAIN_ADMIN_ID, VPS_USER_ROLE_ID
from core.database import admin_data, get_db
from core.theme import (
    create_embed, create_success_embed, create_error_embed,
    create_info_embed, add_field, Theme,
)


def _get_or_create_user(user_id: str) -> dict:
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (user_id,))
    conn.commit()
    cur.execute("SELECT * FROM users WHERE user_id=?", (user_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else {}


def _add_coins(user_id: str, amount: int):
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (user_id,))
    cur.execute("UPDATE users SET mooncoin = mooncoin + ? WHERE user_id=?", (amount, user_id))
    conn.commit()
    conn.close()


def _remove_coins(user_id: str, amount: int):
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (user_id,))
    cur.execute("UPDATE users SET mooncoin = MAX(0, mooncoin - ?) WHERE user_id=?", (amount, user_id))
    conn.commit()
    conn.close()


def _transfer_coins(from_id: str, to_id: str, amount: int) -> bool:
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("SELECT mooncoin FROM users WHERE user_id=?", (from_id,))
    row = cur.fetchone()
    if not row or row["mooncoin"] < amount:
        conn.close()
        return False
    cur.execute("UPDATE users SET mooncoin = mooncoin - ? WHERE user_id=?", (amount, from_id))
    cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (to_id,))
    cur.execute("UPDATE users SET mooncoin = mooncoin + ? WHERE user_id=?", (amount, to_id))
    conn.commit()
    conn.close()
    return True


def _get_boost_level(member: discord.Member) -> int:
    if not member:
        return 0
    if member.premium_since:
        # discord.py doesn't expose boost count per member directly; approximate by role/nitro
        # Count as 1 boost by default if premium_since set
        return 1
    return 0


def _get_multiplier_text(member: discord.Member, guild: discord.Guild) -> tuple[float, str]:
    mult      = 1.0
    bonuses   = []

    # VIP role
    vip_role = discord.utils.get(guild.roles, name="VIP")
    if vip_role and vip_role in member.roles:
        mult += 0.01
        bonuses.append("👑 VIP Role (+1%)")

    # Boosts
    boost_lvl = _get_boost_level(member)
    if boost_lvl >= 2:
        mult += 0.03
        bonuses.append("🚀 2x Boost (+3%)")
    elif boost_lvl >= 1:
        mult += 0.02
        bonuses.append("💜 1x Boost (+2%)")

    return mult, "\n".join(bonuses) if bonuses else "None active"


def is_admin_check(user_id):
    role = admin_data.get(str(user_id))
    return role in ["Owner", "Admin", "Dev"] or str(user_id) == str(MAIN_ADMIN_ID)


class AccountCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="account", description="View MoonCoin balance, stats, and earning info")
    @app_commands.choices(admin_action=[
        app_commands.Choice(name="Add Coins",      value="add"),
        app_commands.Choice(name="Remove Coins",   value="remove"),
        app_commands.Choice(name="Transfer Coins", value="transfer"),
        app_commands.Choice(name="Reset Account",  value="reset"),
    ])
    @app_commands.describe(
        target_user     = "View another user's account (or admin target)",
        admin_action    = "[ADMIN] Action to perform on the target user",
        transfer_amount = "Amount of MoonCoins to add/remove/transfer",
        transfer_to     = "Destination user for Transfer action",
    )
    async def account_cmd(
        self,
        interaction: discord.Interaction,
        target_user: discord.Member = None,
        admin_action: str = None,
        transfer_amount: int = None,
        transfer_to: discord.Member = None,
    ):
        await interaction.response.defer(ephemeral=True)

        if not ACCOUNT:
            return await interaction.followup.send(
                embed=create_error_embed("Disabled", "The account system is currently disabled.")
            )

        uid      = str(interaction.user.id)
        is_admin = is_admin_check(uid)

        # ── Admin actions ────────────────────────────────────────────────────
        if admin_action:
            if not is_admin:
                return await interaction.followup.send(
                    embed=create_error_embed("Denied", "Admin actions require the Admin or Owner role.")
                )
            if not target_user:
                return await interaction.followup.send(
                    embed=create_error_embed("Missing", "Specify a `target_user`.")
                )
            t_uid = str(target_user.id)

            if admin_action == "add":
                if not transfer_amount or transfer_amount <= 0:
                    return await interaction.followup.send(embed=create_error_embed("Error", "Specify a positive `transfer_amount`."))
                _add_coins(t_uid, transfer_amount)
                return await interaction.followup.send(
                    embed=create_success_embed(
                        "Coins Added",
                        f"Added **{transfer_amount:,}** 🌙 MoonCoins to {target_user.mention}."
                    )
                )

            elif admin_action == "remove":
                if not transfer_amount or transfer_amount <= 0:
                    return await interaction.followup.send(embed=create_error_embed("Error", "Specify a positive `transfer_amount`."))
                _remove_coins(t_uid, transfer_amount)
                return await interaction.followup.send(
                    embed=create_success_embed(
                        "Coins Removed",
                        f"Removed **{transfer_amount:,}** 🌙 MoonCoins from {target_user.mention}."
                    )
                )

            elif admin_action == "transfer":
                if not transfer_to or not transfer_amount or transfer_amount <= 0:
                    return await interaction.followup.send(embed=create_error_embed("Error", "Specify `target_user`, `transfer_to`, and `transfer_amount`."))
                ok = _transfer_coins(t_uid, str(transfer_to.id), transfer_amount)
                if not ok:
                    return await interaction.followup.send(embed=create_error_embed("Failed", "Insufficient balance or user not found."))
                return await interaction.followup.send(
                    embed=create_success_embed(
                        "Transfer Complete",
                        f"Moved **{transfer_amount:,}** 🌙 from {target_user.mention} → {transfer_to.mention}."
                    )
                )

            elif admin_action == "reset":
                conn = get_db()
                cur  = conn.cursor()
                cur.execute("UPDATE users SET mooncoin=0, invites_used=0 WHERE user_id=?", (t_uid,))
                conn.commit()
                conn.close()
                return await interaction.followup.send(
                    embed=create_success_embed("Account Reset", f"{target_user.mention}'s account has been reset to zero.")
                )

        # ── View account ─────────────────────────────────────────────────────
        view_uid    = str(target_user.id) if target_user else uid
        view_member = target_user or interaction.user
        data        = _get_or_create_user(view_uid)

        coins    = data.get("mooncoin",     0)
        invites  = data.get("invites_used", 0)
        credits  = data.get("credits",      0)

        mult, bonus_text = _get_multiplier_text(view_member, interaction.guild)

        # Count VPS owned
        from core.database import vps_data, data_lock
        with data_lock:
            vps_count = len(vps_data.get(view_uid, []))

        # Check marketplace listings
        conn = get_db()
        cur  = conn.cursor()
        try:
            cur.execute("SELECT COUNT(*) FROM marketplace WHERE seller_id=? AND active=1", (view_uid,))
            market_count = cur.fetchone()[0]
        except Exception:
            market_count = 0
        conn.close()

        embed = discord.Embed(
            title=f"🌙  {view_member.display_name}'s Account",
            color=Theme.PRIMARY,
            timestamp=datetime.now(),
        )
        embed.set_author(name="MoonNodes — Account", icon_url="https://imgur.com/6yfYDTP.png")
        embed.set_thumbnail(url=view_member.display_avatar.url)

        embed.add_field(
            name="💰  MoonCoin Balance",
            value=f"## 🌙 **{coins:,}**\n*Multiplier: ×{mult:.2f}*",
            inline=True,
        )
        embed.add_field(
            name="📊  Stats",
            value=(
                f"📨 Tracked Invites: **{invites}**\n"
                f"🖥️ VPS Owned: **{vps_count}**\n"
                f"🛒 Marketplace Listings: **{market_count}**\n"
                f"💳 Credits: **{credits}**"
            ),
            inline=True,
        )
        embed.add_field(
            name="✨  Active Bonuses",
            value=bonus_text,
            inline=False,
        )
        embed.add_field(
            name="🌙  How to Earn MoonCoins",
            value=(
                "• Invite someone to the server → **+5 coins**\n"
                "• Chat in main channel → **+1 coin** *(5 min cooldown)*\n"
                "• Join a giveaway → **+3 coins**\n"
                "• Join an event → **+7 coins**\n"
                "• VIP role → **+1% multiplier**\n"
                "• 1st server boost → **+2% multiplier**\n"
                "• 2nd server boost → **+3% multiplier**"
            ),
            inline=False,
        )
        embed.set_footer(text="Spend coins in /marketplace or /claim")
        await interaction.followup.send(embed=embed)

    # ── Background coin tracking ─────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        """Award coins to whoever invited the new member."""
        if not ACCOUNT:
            return
        try:
            invites_after = await member.guild.invites()
            # We track invite counts; attribute delta to inviter
            conn = get_db()
            cur  = conn.cursor()
            for inv in invites_after:
                if not inv.inviter:
                    continue
                inv_uid = str(inv.inviter.id)
                cur.execute("SELECT invite_count FROM users WHERE user_id=?", (inv_uid,))
                row = cur.fetchone()
                old = row["invite_count"] if row else 0
                if inv.uses > old:
                    diff = inv.uses - old
                    mult, _ = _get_multiplier_text(inv.inviter, member.guild)
                    reward  = int(5 * diff * mult)
                    cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (inv_uid,))
                    cur.execute(
                        "UPDATE users SET mooncoin=mooncoin+?, invites_used=invites_used+?, invite_count=? WHERE user_id=?",
                        (reward, diff, inv.uses, inv_uid)
                    )
            conn.commit()
            conn.close()
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        """Award 1 coin per message in the main chat channel (5 min cooldown)."""
        if not ACCOUNT or message.author.bot:
            return
        from core.config import MAIN_CHAT_ID
        if MAIN_CHAT_ID == 0 or message.channel.id != MAIN_CHAT_ID:
            return
        uid = str(message.author.id)
        conn = get_db()
        cur  = conn.cursor()
        try:
            cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (uid,))
            cur.execute("SELECT last_chat_coin FROM users WHERE user_id=?", (uid,))
            row = cur.fetchone()
            now = datetime.now()
            last_str = row["last_chat_coin"] if row and row["last_chat_coin"] else None
            if last_str:
                last = datetime.fromisoformat(last_str)
                if (now - last).total_seconds() < 300:  # 5 min cooldown
                    conn.close()
                    return
            mult, _ = _get_multiplier_text(message.author, message.guild)
            reward  = max(1, int(1 * mult))
            cur.execute(
                "UPDATE users SET mooncoin=mooncoin+?, last_chat_coin=? WHERE user_id=?",
                (reward, now.isoformat(), uid)
            )
            conn.commit()
        except Exception:
            pass
        finally:
            conn.close()


async def setup(bot):
    await bot.add_cog(AccountCog(bot))
