"""
/account — User account command.

Layout:
  /account                          → Balance overview (default)
  /account options:Balance          → Full balance + stats
  /account options:Transfer         → Send coins to another user

  User panel (options:VPS):
  /account options:VPS user_action:Share  share_action:Add|Remove  shared_user vps_number
  /account options:VPS user_action:Backup backup_action:Create|List|Restore  vps_number

Note: Admin coin and VPS actions have been moved to:
  - /set setting:MoonCoin            → coin management
  - /mod role::trident: action:Expire/Suspend/Unsuspend → VPS moderation
"""

import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime, timedelta

from core.config import MAIN_ADMIN_ID
from core.ext import account_enabled, ext_disabled_embed
from core.database import admin_data, vps_data, data_lock, async_save_vps_data, get_db
from core.lxc import execute_lxc
from core.theme import create_embed, create_success_embed, create_error_embed, create_info_embed, add_field, Theme


# ── Permission helpers ────────────────────────────────────────────────────────

def _is_admin(uid) -> bool:
    return int(uid) == int(MAIN_ADMIN_ID) or admin_data.get(str(uid)) in (
        "Owner", "Hard Admin", "Admin", "Manager", "Dev"
    )


# ── Coin helpers ──────────────────────────────────────────────────────────────

def _db_coins(uid: str) -> int:
    c = get_db(); r = c.cursor()
    r.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (uid,)); c.commit()
    r.execute("SELECT mooncoin FROM users WHERE user_id=?", (uid,))
    row = r.fetchone()
    return row["mooncoin"] if row else 0


def _mod_coins(uid: str, delta: int):
    c = get_db(); r = c.cursor()
    r.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (uid,)); c.commit()
    r.execute("UPDATE users SET mooncoin=MAX(0,mooncoin+?) WHERE user_id=?", (delta, uid))
    c.commit()


def _transfer_coins(from_id: str, to_id: str, amount: int) -> bool:
    c = get_db(); r = c.cursor()
    r.execute("SELECT mooncoin FROM users WHERE user_id=?", (from_id,))
    row = r.fetchone()
    if not row or row["mooncoin"] < amount:
        return False
    r.execute("UPDATE users SET mooncoin=mooncoin-? WHERE user_id=?", (amount, from_id))
    r.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (to_id,)); c.commit()
    r.execute("UPDATE users SET mooncoin=mooncoin+? WHERE user_id=?", (amount, to_id))
    c.commit()
    return True


def _get_user_data(uid: str) -> dict:
    c = get_db(); r = c.cursor()
    r.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (uid,)); c.commit()
    r.execute("SELECT * FROM users WHERE user_id=?", (uid,))
    row = r.fetchone()
    return dict(row) if row else {}


def _get_multiplier(member, guild):
    mult, bonuses = 1.0, []
    if not guild or not member:
        return mult, "None"
    vip = discord.utils.get(guild.roles, name="VIP")
    if vip and vip in member.roles:
        mult += 0.01; bonuses.append("👑 VIP (+1%)")
    if member.premium_since:
        mult += 0.02; bonuses.append("💜 Booster (+2%)")
    return mult, "\n".join(bonuses) if bonuses else "None"


# ── Expiry helpers ────────────────────────────────────────────────────────────

def _parse_expiry(vps: dict) -> str | None:
    return vps.get("expiry") or vps.get("expires_at")


def _expiry_display(vps: dict) -> str:
    exp = _parse_expiry(vps)
    if not exp:
        return "♾️ **Permanent** — no expiry set"
    try:
        ts = int(datetime.fromisoformat(exp).timestamp())
        return f"⏳ <t:{ts}:F> (<t:{ts}:R>)"
    except Exception:
        return f"⏳ `{exp}`"


# ─────────────────────────────────────────────────────────────────────────────

class AccountCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="account", description="Account overview: coins, VPS actions, sharing, backups, and expiry")
    # ── Top-level section ────────────────────────────────────────────────────
    @app_commands.choices(options=[
        app_commands.Choice(name="💰 Balance — MoonCoin balance & stats",    value="balance"),
        app_commands.Choice(name="🖥️ VPS — Share or backup your VPS",        value="vps"),
        app_commands.Choice(name="💳 Transfer — Send coins to another user", value="transfer"),
    ])
    # ── Admin category picker ────────────────────────────────────────────────
        app_commands.Choice(name="💾 Backup — Create, list, or restore",   value="backup"),
        app_commands.Choice(name="⬆️ Upgrade — Extend or upgrade your VPS",  value="upgrade"),
    ])
    @app_commands.choices(share_action=[
        app_commands.Choice(name="➕ Add User",    value="add"),
        app_commands.Choice(name="➖ Remove User", value="remove"),
        app_commands.Choice(name="📋 List Users",  value="list"),
    ])
    @app_commands.choices(backup_action=[
        app_commands.Choice(name="💾 Create Backup",  value="create"),
        app_commands.Choice(name="📋 List Backups",   value="list"),
        app_commands.Choice(name="🔄 Restore Latest", value="restore"),
        app_commands.Choice(name="🗑️ Delete Backup",  value="delete"),
    ])
    # ── Describe ─────────────────────────────────────────────────────────────
    @app_commands.describe(
        options          = "Which section to open (default: Balance)",
        target_user      = "Target user — for admin actions or viewing someone's balance",
        user_action      = "[User > VPS] Share or Backup",
        share_action     = "[User > Share] Add, Remove, or List shared users",
        backup_action    = "[User > Backup] Create, List, Restore, or Delete",
        transfer_amount  = "Coin amount (for transfer / admin coin actions)",
        transfer_to      = "Who to send coins to (for user transfer)",
        vps_number       = "VPS number (1, 2, 3…) — shown in /list",
        shared_user      = "Discord user to share VPS with",
        expiry_days      = "Days until expiry (for Add/Edit expiry actions)",
        reason           = "Reason — included in DM to user for suspend actions",
        snapshot_name    = "Snapshot name (for Delete Backup — leave blank for latest)",
    )
    async def account_cmd(
        self,
        interaction: discord.Interaction,
        options:           str = "balance",
        target_user:       discord.Member = None,
        user_action:       str = None,
        share_action:      str = None,
        backup_action:     str = None,
        transfer_amount:   int = None,
        transfer_to:       discord.Member = None,
        vps_number:        int = None,
        shared_user:       discord.Member = None,
        expiry_days:       int = None,
        reason:            str = "Admin action",
        snapshot_name:     str = None,
    ):
        await interaction.response.defer(ephemeral=True)

        if not account_enabled():
            return await interaction.followup.send(
                embed=ext_disabled_embed("Account & MoonCoin", "ACCOUNT")
            )

        uid = str(interaction.user.id)

        # ══════════════════════════════════════════════════════════════════════
        #  USER PANEL
        # ══════════════════════════════════════════════════════════════════════

        # ── 🖥️ VPS USER ACTIONS ──────────────────────────────────────────────
        if options == "vps":
            if not user_action:
                embed = discord.Embed(
                    title="🖥️  VPS Actions",
                    description=(
                        "Choose a `user_action`:\n\n"
                        "🤝 **Share** — grant or revoke VPS access for another user\n"
                        "💾 **Backup** — create, list, restore, or delete snapshots"
                    ),
                    color=Theme.PRIMARY,
                )
                embed.set_author(name="MoonNodes — Account", icon_url=Theme.ICON_URL)
                return await interaction.followup.send(embed=embed)

            if not vps_number:
                return await interaction.followup.send(embed=create_error_embed(
                    "Missing VPS Number", "Specify `vps_number` — use `/list` to find yours."
                ))

            async with data_lock:
                vps_list = list(vps_data.get(uid, []))

            if vps_number < 1 or vps_number > len(vps_list):
                return await interaction.followup.send(embed=create_error_embed(
                    "Invalid VPS", f"You don't have a VPS #{vps_number}. Use `/list` to check."
                ))

            vps    = vps_data[uid][vps_number - 1]
            name   = vps["container_name"]
            node   = vps.get("node", "local")
            prefix = f"{node}:" if node != "local" else ""

            # ── SHARE ────────────────────────────────────────────────────────
            if user_action == "share":
                if not share_action:
                    shared_list = vps.get("shared_with", [])
                    embed = discord.Embed(
                        title=f"🤝  Sharing — `{name}`",
                        description=(
                            f"**{len(shared_list)}** user(s) have access to this VPS.\n\n"
                            + ("\n".join(f"• <@{u}>" for u in shared_list) if shared_list else "*No users shared yet*")
                        ),
                        color=Theme.INFO,
                    )
                    embed.set_author(name="MoonNodes — Account", icon_url=Theme.ICON_URL)
                    return await interaction.followup.send(embed=embed)

                if share_action == "list":
                    shared_list = vps.get("shared_with", [])
                    embed = discord.Embed(
                        title=f"📋  Shared Users — `{name}`",
                        description="\n".join(f"• <@{u}>" for u in shared_list) or "*No users shared yet*",
                        color=Theme.INFO,
                    )
                    embed.set_author(name="MoonNodes — Account", icon_url=Theme.ICON_URL)
                    return await interaction.followup.send(embed=embed)

                if not shared_user:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing User", "Specify `shared_user`."
                    ))

                s_uid = str(shared_user.id)
                if share_action == "add":
                    if s_uid in vps.get("shared_with", []):
                        return await interaction.followup.send(embed=create_error_embed(
                            "Already Shared", f"{shared_user.mention} already has access to this VPS."
                        ))
                    async with data_lock:
                        vps.setdefault("shared_with", []).append(s_uid)
                    await async_save_vps_data()
                    try:
                        dm = discord.Embed(
                            title="🤝  VPS Access Granted",
                            description=(
                                f"**{interaction.user.display_name}** has shared their VPS **`{name}`** with you.\n\n"
                                "Go to `/manage` → **Shared VPS** tab to manage it."
                            ),
                            color=Theme.SUCCESS, timestamp=datetime.now(),
                        )
                        dm.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)
                        await shared_user.send(embed=dm)
                    except discord.Forbidden:
                        pass
                    embed = discord.Embed(
                        title="✅  Access Granted",
                        description=f"{shared_user.mention} can now manage **`{name}`**.",
                        color=Theme.SUCCESS, timestamp=datetime.now(),
                    )
                    embed.set_author(name="MoonNodes — Account", icon_url=Theme.ICON_URL)
                    return await interaction.followup.send(embed=embed)

                elif share_action == "remove":
                    if s_uid not in vps.get("shared_with", []):
                        return await interaction.followup.send(embed=create_error_embed(
                            "Not Shared", f"{shared_user.mention} doesn't have access to this VPS."
                        ))
                    async with data_lock:
                        vps["shared_with"].remove(s_uid)
                    await async_save_vps_data()
                    try:
                        dm = discord.Embed(
                            title="❌  VPS Access Revoked",
                            description=f"Your access to **`{name}`** (owned by {interaction.user.display_name}) has been removed.",
                            color=Theme.ERROR, timestamp=datetime.now(),
                        )
                        dm.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)
                        await shared_user.send(embed=dm)
                    except discord.Forbidden:
                        pass
                    embed = discord.Embed(
                        title="✅  Access Removed",
                        description=f"{shared_user.mention} no longer has access to **`{name}`**.",
                        color=Theme.SUCCESS, timestamp=datetime.now(),
                    )
                    embed.set_author(name="MoonNodes — Account", icon_url=Theme.ICON_URL)
                    return await interaction.followup.send(embed=embed)

            # ── BACKUP ───────────────────────────────────────────────────────
            elif user_action == "backup":
                if not backup_action:
                    embed = discord.Embed(
                        title=f"💾  Backups — `{name}`",
                        description=(
                            "Choose a `backup_action`:\n\n"
                            "💾 **Create** — take a new snapshot\n"
                            "📋 **List** — see all snapshots\n"
                            "🔄 **Restore** — restore the latest snapshot\n"
                            "🗑️ **Delete** — remove a specific snapshot"
                        ),
                        color=Theme.INFO,
                    )
                    embed.set_author(name="MoonNodes — Account", icon_url=Theme.ICON_URL)
                    return await interaction.followup.send(embed=embed)

                if backup_action == "create":
                    snap = f"snap-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
                    try:
                        await execute_lxc(f"lxc snapshot {prefix}{name} {snap}")
                        embed = discord.Embed(
                            title="💾  Backup Created",
                            description=f"Snapshot **`{snap}`** saved for **`{name}`**.",
                            color=Theme.SUCCESS, timestamp=datetime.now(),
                        )
                        embed.set_author(name="MoonNodes — Account", icon_url=Theme.ICON_URL)
                        embed.set_footer(text="Use backup_action:Restore to recover from this snapshot")
                        return await interaction.followup.send(embed=embed)
                    except Exception as e:
                        return await interaction.followup.send(embed=create_error_embed("Backup Failed", str(e)[:2000]))

                elif backup_action == "list":
                    try:
                        info  = await execute_lxc(f"lxc info {prefix}{name}")
                        snaps = [l.strip() for l in str(info).splitlines()
                                 if l.strip().startswith("snap-") or l.strip().startswith("auto-")]
                        if not snaps:
                            return await interaction.followup.send(embed=create_info_embed(
                                "No Backups", f"No snapshots found for **`{name}`**."
                            ))
                        embed = discord.Embed(
                            title=f"📋  Backups — `{name}`",
                            description="\n".join(f"• `{s}`" for s in snaps[:20]),
                            color=Theme.INFO, timestamp=datetime.now(),
                        )
                        embed.set_footer(text=f"{len(snaps)} snapshot(s) total")
                        embed.set_author(name="MoonNodes — Account", icon_url=Theme.ICON_URL)
                        return await interaction.followup.send(embed=embed)
                    except Exception as e:
                        return await interaction.followup.send(embed=create_error_embed("Error", str(e)[:2000]))

                elif backup_action == "restore":
                    try:
                        info  = await execute_lxc(f"lxc info {prefix}{name}")
                        snaps = sorted([l.strip() for l in str(info).splitlines()
                                        if l.strip().startswith("snap-") or l.strip().startswith("auto-")])
                        if not snaps:
                            return await interaction.followup.send(embed=create_error_embed("No Backups", "No snapshots to restore."))
                        latest = snaps[-1]
                        await execute_lxc(f"lxc stop {prefix}{name}", timeout=30)
                        await execute_lxc(f"lxc restore {prefix}{name} {latest}")
                        await execute_lxc(f"lxc start {prefix}{name}", timeout=60)
                        embed = discord.Embed(
                            title="🔄  VPS Restored",
                            description=f"**`{name}`** restored to snapshot **`{latest}`** and is running.",
                            color=Theme.SUCCESS, timestamp=datetime.now(),
                        )
                        embed.set_author(name="MoonNodes — Account", icon_url=Theme.ICON_URL)
                        return await interaction.followup.send(embed=embed)
                    except Exception as e:
                        return await interaction.followup.send(embed=create_error_embed("Restore Failed", str(e)[:2000]))

                elif backup_action == "delete":
                    try:
                        info  = await execute_lxc(f"lxc info {prefix}{name}")
                        snaps = sorted([l.strip() for l in str(info).splitlines()
                                        if l.strip().startswith("snap-") or l.strip().startswith("auto-")])
                        if not snaps:
                            return await interaction.followup.send(embed=create_error_embed("No Backups", "No snapshots to delete."))
                        target_snap = snapshot_name or snaps[-1]
                        if target_snap not in snaps:
                            return await interaction.followup.send(embed=create_error_embed(
                                "Not Found", f"Snapshot `{target_snap}` not found. Use `backup_action:List` to see snapshots."
                            ))
                        await execute_lxc(f"lxc delete {prefix}{name}/{target_snap}")
                        embed = discord.Embed(
                            title="🗑️  Snapshot Deleted",
                            description=f"Snapshot **`{target_snap}`** removed from **`{name}`**.",
                            color=Theme.SUCCESS, timestamp=datetime.now(),
                        )
                        embed.set_author(name="MoonNodes — Account", icon_url=Theme.ICON_URL)
                        return await interaction.followup.send(embed=embed)
                    except Exception as e:
                        return await interaction.followup.send(embed=create_error_embed("Delete Failed", str(e)[:2000]))

        # ── ⬆️ UPGRADE ────────────────────────────────────────────────────────
        elif options == "upgrade":
            if not vps_number or vps_number < 1:
                return await interaction.followup.send(embed=create_error_embed(
                    "Missing VPS Number", "Provide `vps_number` to upgrade a specific VPS."))
            async with data_lock:
                vlist = vps_data.get(uid, [])
                if vps_number > len(vlist):
                    return await interaction.followup.send(embed=create_error_embed(
                        "Not Found", f"VPS #{vps_number} not found. Use `/list` to check."))
                vps = vlist[vps_number - 1]
            name = vps["container_name"]
            node = (vps.get("node") or "local").strip().rstrip(":") or "local"
            prefix = f"{node}:" if node != "local" else ""

            # Show current specs and upgrade options
            from feature.plans.plans_manager import PLANS
            all_plans = {**PLANS.get("free",{}), **PLANS.get("premium",{})}
            embed = discord.Embed(
                title=f"⬆️  Upgrade VPS — `{name}`",
                description=(
                    f"**Current specs:** `{vps.get('config','?')}`\n"
                    f"**Node:** `{node}`\n\n"
                    "To upgrade, contact an admin with `/support` and they can adjust your VPS specs.\n\n"
                    "**Available plans to upgrade to:**"
                ),
                color=Theme.INFO, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes — Account", icon_url=Theme.ICON_URL)
            for plan_name, p in list(all_plans.items())[:8]:
                embed.add_field(
                    name=f"📦 {plan_name.title()}",
                    value=f"`{p['ram']}GB RAM · {p['cpu']} CPU · {p['disk']}GB Disk`\n{p.get('price','?')}",
                    inline=True,
                )
            embed.set_footer(text="Open a ticket with /support to request an upgrade · MoonNodes")
            return await interaction.followup.send(embed=embed)

        # ── 💳 TRANSFER ───────────────────────────────────────────────────────
        elif options == "transfer":
            if not transfer_to or not transfer_amount or transfer_amount <= 0:
                embed = discord.Embed(
                    title="💳  Transfer MoonCoins",
                    description=(
                        "Send MoonCoins to another user.\n\n"
                        "**Required fields:**\n"
                        "• `transfer_to` — who to send to\n"
                        "• `transfer_amount` — how many coins\n\n"
                        f"Your balance: **{_db_coins(uid):,} 🌙**"
                    ),
                    color=Theme.INFO,
                )
                embed.set_author(name="MoonNodes — Account", icon_url=Theme.ICON_URL)
                return await interaction.followup.send(embed=embed)

            ok = _transfer_coins(uid, str(transfer_to.id), transfer_amount)
            if ok:
                try:
                    dm = discord.Embed(
                        title="🌙  Coins Received!",
                        description=(
                            f"**{interaction.user.display_name}** sent you **{transfer_amount:,} 🌙 MoonCoins**!\n\n"
                            f"Your balance has been updated."
                        ),
                        color=Theme.SUCCESS, timestamp=datetime.now(),
                    )
                    dm.set_author(name="MoonNodes", icon_url=Theme.ICON_URL)
                    await transfer_to.send(embed=dm)
                except discord.Forbidden:
                    pass
                embed = discord.Embed(
                    title="✅  Transfer Complete",
                    description=f"Sent **{transfer_amount:,} 🌙** to {transfer_to.mention}.",
                    color=Theme.SUCCESS, timestamp=datetime.now(),
                )
                embed.set_footer(text=f"Remaining balance: {_db_coins(uid):,} 🌙")
                embed.set_author(name="MoonNodes — Account", icon_url=Theme.ICON_URL)
                return await interaction.followup.send(embed=embed)
            return await interaction.followup.send(embed=create_error_embed(
                "Insufficient Balance",
                f"You only have **{_db_coins(uid):,} 🌙**. You need **{transfer_amount:,} 🌙**."
            ))

        # ── 💰 BALANCE (default) ──────────────────────────────────────────────
        view_uid  = str(target_user.id) if target_user else uid
        view_memb = target_user or interaction.user
        data      = _get_user_data(view_uid)

        coins   = data.get("mooncoin", 0)
        invites = data.get("invites_used", 0)
        credits = data.get("credits", 0)
        mult, bonus_text = _get_multiplier(view_memb, interaction.guild)

        async with data_lock:
            vps_count = len(vps_data.get(view_uid, []))

        # Tier badge
        try:
            conn = get_db(); cur = conn.cursor()
            cur.execute("SELECT tier FROM users WHERE user_id=?", (view_uid,))
            row = cur.fetchone()
            tier_key = row["tier"] if row and "tier" in row.keys() and row["tier"] else None
        except Exception:
            tier_key = None

        TIER_LABELS = {"basic": "⭐ Basic", "standard": "🌟 Standard", "pro": "💎 Pro", "elite": "🔱 Elite"}
        tier_display = TIER_LABELS.get(tier_key, "🆓 Free")

        embed = discord.Embed(
            title=f"🌙  {view_memb.display_name}'s Account",
            color=0xFFD700 if tier_key else Theme.PRIMARY,
            timestamp=datetime.now(),
        )
        embed.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)
        embed.set_thumbnail(url=view_memb.display_avatar.url)

        embed.add_field(
            name="💰  MoonCoins",
            value=f"```\n{coins:,} 🌙\n```*×{mult:.2f} multiplier*",
            inline=True,
        )
        embed.add_field(
            name="📊  Stats",
            value=(
                f"🖥️ VPS: **{vps_count}**\n"
                f"📨 Invites: **{invites}**\n"
                f"💳 Credits: **{credits:,}**"
            ),
            inline=True,
        )
        embed.add_field(name="🏅  Tier", value=tier_display, inline=True)

        if bonus_text and bonus_text != "None":
            embed.add_field(name="✨  Active Bonuses", value=bonus_text, inline=False)

        embed.add_field(
            name="🌙  How to Earn",
            value=(
                "• Invite a user → **+5 coins**\n"
                "• Chat in main channel → **+1 coin** *(5 min cooldown)*\n"
                "• Join a giveaway → **+3 coins**\n"
                "• Join an event → **+7 coins**\n"
                "• VIP role → **+1%** · Server Boost → **+2%** multiplier"
            ),
            inline=False,
        )
        embed.set_footer(text="Use /claim or /marketplace to spend your coins")
        await interaction.followup.send(embed=embed)

    # ── Coin earning listeners ─────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if not account_enabled() or message.author.bot:
            return
        from core.config import MAIN_CHAT_ID
        if MAIN_CHAT_ID == 0 or message.channel.id != MAIN_CHAT_ID:
            return
        uid = str(message.author.id)
        c = get_db(); r = c.cursor()
        try:
            r.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (uid,)); c.commit()
            r.execute("SELECT last_chat_coin FROM users WHERE user_id=?", (uid,))
            row = r.fetchone()
            now = datetime.now()
            if row and row["last_chat_coin"]:
                if (now - datetime.fromisoformat(row["last_chat_coin"])).total_seconds() < 300:
                    return
            mult, _ = _get_multiplier(message.author, message.guild)
            reward  = max(1, int(1 * mult))
            r.execute("UPDATE users SET mooncoin=mooncoin+?, last_chat_coin=? WHERE user_id=?",
                      (reward, now.isoformat(), uid))
            c.commit()
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        if not account_enabled() or not member.guild:
            return
        try:
            invites = await member.guild.invites()
            c = get_db(); r = c.cursor()
            for inv in invites:
                if not inv.inviter:
                    continue
                inv_uid = str(inv.inviter.id)
                r.execute("SELECT invite_count FROM users WHERE user_id=?", (inv_uid,))
                row = r.fetchone()
                old = row["invite_count"] if row else 0
                if inv.uses > old:
                    diff   = inv.uses - old
                    mult, _ = _get_multiplier(inv.inviter, member.guild)
                    reward = int(5 * diff * mult)
                    r.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (inv_uid,)); c.commit()
                    r.execute("UPDATE users SET mooncoin=mooncoin+?, invites_used=invites_used+?, invite_count=? WHERE user_id=?",
                              (reward, diff, inv.uses, inv_uid))
                    c.commit()
        except Exception:
            pass


async def setup(bot):
    await bot.add_cog(AccountCog(bot))
