"""
/account — MoonCoin balance, VPS actions (admin: suspend/unsuspend; user: share, backup), and coin management.
"""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import ACCOUNT, MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock, save_vps_data, get_db
from core.lxc import execute_lxc
from core.theme import create_embed, create_success_embed, create_error_embed, create_info_embed, add_field, Theme


def is_admin(uid):
    return str(uid) == str(MAIN_ADMIN_ID) or admin_data.get(str(uid)) in ("Owner", "Admin", "Dev")


def _db_coins(uid): 
    c = get_db(); r = c.cursor()
    r.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (uid,)); c.commit()
    r.execute("SELECT mooncoin FROM users WHERE user_id=?", (uid,)); row = r.fetchone(); c.close()
    return row["mooncoin"] if row else 0

def _mod_coins(uid, delta):
    c = get_db(); r = c.cursor()
    r.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (uid,)); c.commit()
    r.execute("UPDATE users SET mooncoin=MAX(0,mooncoin+?) WHERE user_id=?", (delta, uid)); c.commit(); c.close()

def _transfer_coins(from_id, to_id, amount):
    c = get_db(); r = c.cursor()
    r.execute("SELECT mooncoin FROM users WHERE user_id=?", (from_id,)); row = r.fetchone()
    if not row or row["mooncoin"] < amount: c.close(); return False
    r.execute("UPDATE users SET mooncoin=mooncoin-? WHERE user_id=?", (amount, from_id))
    r.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (to_id,)); c.commit()
    r.execute("UPDATE users SET mooncoin=mooncoin+? WHERE user_id=?", (amount, to_id)); c.commit(); c.close(); return True

def _get_user_data(uid):
    c = get_db(); r = c.cursor()
    r.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (uid,)); c.commit()
    r.execute("SELECT * FROM users WHERE user_id=?", (uid,)); row = r.fetchone(); c.close()
    return dict(row) if row else {}

def _get_multiplier(member, guild):
    mult, bonuses = 1.0, []
    vip = discord.utils.get(guild.roles, name="VIP")
    if vip and vip in member.roles:
        mult += 0.01; bonuses.append("👑 VIP (+1%)")
    if member.premium_since:
        mult += 0.02; bonuses.append("💜 Booster (+2%)")
    return mult, "\n".join(bonuses) if bonuses else "None"


class AccountCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="account", description="Manage your account: coins, VPS actions, sharing, and backups")
    @app_commands.choices(options=[
        app_commands.Choice(name="💰 Balance — View MoonCoin balance",             value="balance"),
        app_commands.Choice(name="🖥️ VPS — VPS actions (share, backup, suspend)",  value="vps"),
        app_commands.Choice(name="💳 Transfer — Send coins to another user",       value="transfer"),
    ])
    @app_commands.choices(admin_action=[
        app_commands.Choice(name="➕ Add Coins",        value="add"),
        app_commands.Choice(name="➖ Remove Coins",     value="remove"),
        app_commands.Choice(name="🔄 Transfer Coins",  value="transfer_admin"),
        app_commands.Choice(name="🔄 Reset Account",   value="reset"),
        app_commands.Choice(name="⛔ Suspend VPS",     value="suspend_vps"),
        app_commands.Choice(name="✅ Unsuspend VPS",   value="unsuspend_vps"),
    ])
    @app_commands.choices(user_action=[
        app_commands.Choice(name="🤝 Share — Add or remove VPS access",   value="share"),
        app_commands.Choice(name="💾 Backup — Create, list, or restore",  value="backup"),
    ])
    @app_commands.choices(share_action=[
        app_commands.Choice(name="➕ Add User",    value="add"),
        app_commands.Choice(name="➖ Remove User", value="remove"),
    ])
    @app_commands.choices(backup_action=[
        app_commands.Choice(name="💾 Create Backup",   value="create"),
        app_commands.Choice(name="📋 List Backups",    value="list"),
        app_commands.Choice(name="🔄 Restore Latest", value="restore"),
    ])
    @app_commands.describe(
        options         ="What section to use",
        target_user     ="Target user (for balance view or admin actions)",
        admin_action    ="[Admin only] Action on target user",
        user_action     ="[User] VPS sub-action",
        share_action    ="Add or remove shared access",
        backup_action   ="Backup operation",
        transfer_amount ="Coin amount",
        transfer_to     ="Coin transfer destination",
        vps_number      ="Your VPS number",
        shared_user     ="User to share VPS with",
        reason          ="Reason (for suspend/unsuspend)",
    )
    async def account_cmd(
        self, interaction: discord.Interaction,
        options: str = "balance",
        target_user: discord.Member = None,
        admin_action: str = None,
        user_action: str = None,
        share_action: str = None,
        backup_action: str = None,
        transfer_amount: int = None,
        transfer_to: discord.Member = None,
        vps_number: int = None,
        shared_user: discord.Member = None,
        reason: str = "Admin action",
    ):
        await interaction.response.defer(ephemeral=True)

        if not ACCOUNT:
            return await interaction.followup.send(embed=create_error_embed("Disabled", "Account system is off."))

        uid = str(interaction.user.id)

        # ── ADMIN ACTIONS ────────────────────────────────────────────────────
        if admin_action:
            if not is_admin(uid):
                return await interaction.followup.send(embed=create_error_embed("Denied", "Admin only."))
            if not target_user:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Specify `target_user`."))
            t_uid = str(target_user.id)

            if admin_action in ("add", "remove"):
                if not transfer_amount or transfer_amount <= 0:
                    return await interaction.followup.send(embed=create_error_embed("Missing", "Specify `transfer_amount`."))
                delta = transfer_amount if admin_action == "add" else -transfer_amount
                _mod_coins(t_uid, delta)
                action_word = "Added" if admin_action == "add" else "Removed"
                return await interaction.followup.send(
                    embed=create_success_embed(f"Coins {action_word}", f"**{transfer_amount:,}** 🌙 {action_word.lower()} {'to' if admin_action=='add' else 'from'} {target_user.mention}.")
                )

            elif admin_action == "transfer_admin":
                if not transfer_to or not transfer_amount:
                    return await interaction.followup.send(embed=create_error_embed("Missing", "Specify `transfer_to` and `transfer_amount`."))
                ok = _transfer_coins(t_uid, str(transfer_to.id), transfer_amount)
                return await interaction.followup.send(
                    embed=create_success_embed("Transferred", f"Moved **{transfer_amount:,}** 🌙 from {target_user.mention} → {transfer_to.mention}.") if ok
                    else create_error_embed("Failed", "Insufficient balance.")
                )

            elif admin_action == "reset":
                c = get_db(); r = c.cursor()
                r.execute("UPDATE users SET mooncoin=0, invites_used=0 WHERE user_id=?", (t_uid,)); c.commit(); c.close()
                return await interaction.followup.send(embed=create_success_embed("Reset", f"{target_user.mention}'s account reset."))

            elif admin_action in ("suspend_vps", "unsuspend_vps"):
                if not vps_number:
                    return await interaction.followup.send(embed=create_error_embed("Missing", "Specify `vps_number`."))
                with data_lock:
                    vps_list = vps_data.get(t_uid, [])
                    if vps_number < 1 or vps_number > len(vps_list):
                        return await interaction.followup.send(embed=create_error_embed("Invalid", f"VPS #{vps_number} not found."))
                    vps  = vps_list[vps_number - 1]
                    name = vps["container_name"]
                    node = vps.get("node", "local")
                prefix = f"{node}:" if node != "local" else ""

                if admin_action == "suspend_vps":
                    try:
                        await execute_lxc(f"lxc stop {prefix}{name}", timeout=30)
                    except Exception:
                        pass
                    with data_lock:
                        vps["suspended"] = True
                        vps["status"]    = "stopped"
                        vps.setdefault("suspension_history", []).append(
                            {"time": datetime.now().isoformat(), "reason": reason, "by": str(interaction.user.id)}
                        )
                    save_vps_data()
                    try:
                        dm = discord.Embed(title="⛔  VPS Suspended", color=Theme.ERROR,
                            description=f"Your VPS **`{name}`** has been suspended.\n**Reason:** {reason}\n\nContact support to appeal.")
                        dm.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                        await target_user.send(embed=dm)
                    except Exception: pass
                    return await interaction.followup.send(embed=create_success_embed("VPS Suspended", f"`{name}` suspended. Reason: {reason}"))

                else:  # unsuspend
                    try:
                        await execute_lxc(f"lxc start {prefix}{name}", timeout=60)
                    except Exception as e:
                        return await interaction.followup.send(embed=create_error_embed("Start Failed", str(e)[:2000]))
                    with data_lock:
                        vps["suspended"] = False
                        vps["status"]    = "running"
                    save_vps_data()
                    try:
                        dm = discord.Embed(title="✅  VPS Unsuspended", color=Theme.SUCCESS,
                            description=f"Your VPS **`{name}`** has been reactivated.\nUse `/manage` to manage it.")
                        dm.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                        await target_user.send(embed=dm)
                    except Exception: pass
                    return await interaction.followup.send(embed=create_success_embed("VPS Unsuspended", f"`{name}` reactivated."))

        # ── VPS USER ACTIONS ─────────────────────────────────────────────────
        if options == "vps":
            if not user_action:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Choose a `user_action` (Share or Backup)."))
            if not vps_number:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Specify `vps_number`."))

            with data_lock:
                vps_list = list(vps_data.get(uid, []))
            if vps_number < 1 or vps_number > len(vps_list):
                return await interaction.followup.send(embed=create_error_embed("Invalid", f"VPS #{vps_number} not found."))

            vps  = vps_data[uid][vps_number - 1]
            name = vps["container_name"]
            node = vps.get("node", "local")
            prefix = f"{node}:" if node != "local" else ""

            # SHARE
            if user_action == "share":
                if not share_action or not shared_user:
                    return await interaction.followup.send(embed=create_error_embed("Missing", "Choose `share_action` and `shared_user`."))
                s_uid = str(shared_user.id)
                with data_lock:
                    shared = vps.setdefault("shared_with", [])
                    if share_action == "add":
                        if s_uid in shared:
                            return await interaction.followup.send(embed=create_error_embed("Already Shared", f"{shared_user.mention} already has access."))
                        shared.append(s_uid)
                        save_vps_data()
                        try:
                            dm = discord.Embed(title="🤝  VPS Access Granted", color=Theme.SUCCESS,
                                description=f"**{interaction.user.display_name}** gave you access to VPS **`{name}`**.\n\nUse `/manage` → **Shared VPS** tab to manage it.")
                            dm.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                            await shared_user.send(embed=dm)
                        except Exception: pass
                        return await interaction.followup.send(embed=create_success_embed("Access Granted", f"{shared_user.mention} can now manage VPS #{vps_number}."))
                    else:
                        if s_uid not in shared:
                            return await interaction.followup.send(embed=create_error_embed("Not Shared", f"{shared_user.mention} doesn't have access."))
                        shared.remove(s_uid)
                        save_vps_data()
                        try:
                            dm = discord.Embed(title="❌  VPS Access Revoked", color=Theme.ERROR,
                                description=f"Your access to VPS **`{name}`** (owned by {interaction.user.display_name}) has been removed.")
                            dm.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                            await shared_user.send(embed=dm)
                        except Exception: pass
                        return await interaction.followup.send(embed=create_success_embed("Access Removed", f"{shared_user.mention} removed from VPS #{vps_number}."))

            # BACKUP
            elif user_action == "backup":
                if not backup_action:
                    return await interaction.followup.send(embed=create_error_embed("Missing", "Choose a `backup_action`."))

                if backup_action == "create":
                    snap = f"snap-{datetime.now().strftime('%Y%m%d-%H%M')}"
                    try:
                        await execute_lxc(f"lxc snapshot {prefix}{name} {snap}")
                        return await interaction.followup.send(embed=create_success_embed("Backup Created ✅", f"Snapshot **{snap}** saved for `{name}`."))
                    except Exception as e:
                        return await interaction.followup.send(embed=create_error_embed("Backup Failed", str(e)[:2000]))

                elif backup_action == "list":
                    try:
                        info = await execute_lxc(f"lxc info {prefix}{name}")
                        snaps = [l.strip() for l in str(info).splitlines() if l.strip().startswith("snap-") or l.strip().startswith("auto-")]
                        if not snaps:
                            return await interaction.followup.send(embed=create_info_embed("No Backups", f"No snapshots found for `{name}`."))
                        return await interaction.followup.send(embed=create_info_embed(f"Backups for `{name}`", "\n".join(f"• `{s}`" for s in snaps[:20])))
                    except Exception as e:
                        return await interaction.followup.send(embed=create_error_embed("Error", str(e)[:2000]))

                elif backup_action == "restore":
                    try:
                        info  = await execute_lxc(f"lxc info {prefix}{name}")
                        snaps = sorted([l.strip() for l in str(info).splitlines() if l.strip().startswith("snap-") or l.strip().startswith("auto-")])
                        if not snaps:
                            return await interaction.followup.send(embed=create_error_embed("No Backups", "No snapshots to restore."))
                        latest = snaps[-1]
                        await execute_lxc(f"lxc stop {prefix}{name}", timeout=30)
                        await execute_lxc(f"lxc restore {prefix}{name} {latest}")
                        await execute_lxc(f"lxc start {prefix}{name}", timeout=60)
                        return await interaction.followup.send(embed=create_success_embed("Restored ✅", f"VPS `{name}` restored to snapshot **{latest}**."))
                    except Exception as e:
                        return await interaction.followup.send(embed=create_error_embed("Restore Failed", str(e)[:2000]))

        # ── TRANSFER (user→user) ─────────────────────────────────────────────
        elif options == "transfer":
            if not transfer_to or not transfer_amount or transfer_amount <= 0:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Specify `transfer_to` and `transfer_amount`."))
            ok = _transfer_coins(uid, str(transfer_to.id), transfer_amount)
            if ok:
                try:
                    dm = discord.Embed(title="🌙  Coins Received!", color=Theme.SUCCESS,
                        description=f"**{interaction.user.display_name}** sent you **{transfer_amount:,} 🌙 MoonCoins**!\nYour balance updated.")
                    dm.set_author(name="MoonNodes", icon_url="https://imgur.com/6yfYDTP.png")
                    await transfer_to.send(embed=dm)
                except Exception: pass
                return await interaction.followup.send(embed=create_success_embed("Transfer Complete", f"Sent **{transfer_amount:,} 🌙** to {transfer_to.mention}."))
            return await interaction.followup.send(embed=create_error_embed("Failed", f"Insufficient balance. Your balance: **{_db_coins(uid):,}** 🌙"))

        # ── BALANCE ──────────────────────────────────────────────────────────
        view_uid  = str(target_user.id) if target_user else uid
        view_memb = target_user or interaction.user
        data      = _get_user_data(view_uid)

        coins   = data.get("mooncoin", 0)
        invites = data.get("invites_used", 0)
        mult, bonus_text = _get_multiplier(view_memb, interaction.guild)

        with data_lock:
            vps_count = len(vps_data.get(view_uid, []))

        embed = discord.Embed(
            title=f"🌙  {view_memb.display_name}'s Account",
            color=Theme.PRIMARY, timestamp=datetime.now(),
        )
        embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
        embed.set_thumbnail(url=view_memb.display_avatar.url)
        embed.add_field(name="💰  Balance", value=f"## 🌙 {coins:,}\n*×{mult:.2f} multiplier*", inline=True)
        embed.add_field(name="📊  Stats",   value=f"📨 Invites: **{invites}**\n🖥️ VPS Owned: **{vps_count}**", inline=True)
        embed.add_field(name="✨  Bonuses", value=bonus_text or "None", inline=False)
        embed.add_field(name="🌙  Earn Coins", value=(
            "• Invite → **+5** · Chat → **+1** *(5m cd)*\n"
            "• Giveaway → **+3** · Event → **+7**\n"
            "• VIP role → +1% · Boost → +2/3%"
        ), inline=False)
        embed.set_footer(text="Use /claim or /marketplace to spend coins")
        await interaction.followup.send(embed=embed)

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if not ACCOUNT or message.author.bot: return
        from core.config import MAIN_CHAT_ID
        if MAIN_CHAT_ID == 0 or message.channel.id != MAIN_CHAT_ID: return
        uid = str(message.author.id)
        c = get_db(); r = c.cursor()
        try:
            r.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (uid,)); c.commit()
            r.execute("SELECT last_chat_coin FROM users WHERE user_id=?", (uid,)); row = r.fetchone()
            now = datetime.now()
            if row and row["last_chat_coin"]:
                if (now - datetime.fromisoformat(row["last_chat_coin"])).total_seconds() < 300: c.close(); return
            mult, _ = _get_multiplier(message.author, message.guild)
            reward  = max(1, int(1 * mult))
            r.execute("UPDATE users SET mooncoin=mooncoin+?, last_chat_coin=? WHERE user_id=?",
                      (reward, now.isoformat(), uid)); c.commit()
        except Exception: pass
        finally: c.close()

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        if not ACCOUNT: return
        try:
            invites = await member.guild.invites()
            c = get_db(); r = c.cursor()
            for inv in invites:
                if not inv.inviter: continue
                inv_uid = str(inv.inviter.id)
                r.execute("SELECT invite_count FROM users WHERE user_id=?", (inv_uid,)); row = r.fetchone()
                old = row["invite_count"] if row else 0
                if inv.uses > old:
                    diff = inv.uses - old
                    mult, _ = _get_multiplier(inv.inviter, member.guild)
                    reward  = int(5 * diff * mult)
                    r.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (inv_uid,)); c.commit()
                    r.execute("UPDATE users SET mooncoin=mooncoin+?, invites_used=invites_used+?, invite_count=? WHERE user_id=?",
                              (reward, diff, inv.uses, inv_uid)); c.commit()
            c.close()
        except Exception: pass


async def setup(bot):
    await bot.add_cog(AccountCog(bot))
