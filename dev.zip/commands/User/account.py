"""
/account — Full user account panel.
Sections: Balance · VPS · Transfer · Backup · History · Upgrade
"""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config   import MAIN_ADMIN_ID
from core.ext      import account_enabled, ext_disabled_embed
from core.ratelimit import rate_limit
from core.database import admin_data, vps_data, data_lock, async_save_vps_data, get_db, add_coins
from core.lxc      import execute_lxc
from core.theme    import Theme, create_error_embed, create_info_embed, create_success_embed, create_warning_embed


# ── Helpers ───────────────────────────────────────────────────────────────────

def _is_admin(uid) -> bool:
    return int(uid) == int(MAIN_ADMIN_ID) or admin_data.get(str(uid)) in (
        "Owner", "Hard Admin", "Admin", "Manager", "Dev"
    )

def _ensure_user(uid: str):
    c = get_db()
    c.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (uid,))
    c.commit()

def _db_coins(uid: str) -> int:
    _ensure_user(uid)
    r = get_db().execute("SELECT mooncoin FROM users WHERE user_id=?", (uid,)).fetchone()
    return r["mooncoin"] if r else 0

def _get_user_data(uid: str) -> dict:
    _ensure_user(uid)
    r = get_db().execute("SELECT * FROM users WHERE user_id=?", (uid,)).fetchone()
    return dict(r) if r else {}

def _transfer_coins(from_id: str, to_id: str, amount: int) -> bool:
    conn = get_db()
    row  = conn.execute("SELECT mooncoin FROM users WHERE user_id=?", (from_id,)).fetchone()
    if not row or row["mooncoin"] < amount:
        return False
    add_coins(from_id, -amount, reason=f"transfer to {to_id}")
    add_coins(to_id,   amount,  reason=f"transfer from {from_id}")
    return True

def _get_multiplier(member, guild):
    mult, bonuses = 1.0, []
    if not guild or not member:
        return mult, []
    vip = discord.utils.get(guild.roles, name="VIP")
    if vip and vip in member.roles:
        mult += 0.01; bonuses.append("👑 VIP `+1%`")
    if member.premium_since:
        mult += 0.02; bonuses.append("💜 Server Boost `+2%`")
    return mult, bonuses

def _expiry_display(vps: dict) -> str:
    exp = vps.get("expiry") or vps.get("expires_at")
    if not exp:
        return "♾️ Permanent"
    try:
        ts = int(datetime.fromisoformat(exp).timestamp())
        return f"<t:{ts}:R>"
    except Exception:
        return f"`{exp}`"

def _coin_bar(coins: int, max_coins: int = 10000) -> str:
    pct    = min(coins / max_coins, 1.0)
    filled = round(pct * 12)
    return "█" * filled + "░" * (12 - filled)

TIER_META = {
    "elite":    ("🔱", "Elite",    0xFFD700),
    "pro":      ("💎", "Pro",      0x9B59B6),
    "standard": ("🌟", "Standard", 0x3498DB),
    "basic":    ("⭐", "Basic",    0x2ECC71),
}


# ── Cog ───────────────────────────────────────────────────────────────────────

class AccountCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="account", description="Balance · VPS · Coins · Backups")
    @app_commands.choices(section=[
        app_commands.Choice(name="💰 Balance   — Coins, stats & earn info",          value="balance"),
        app_commands.Choice(name="🖥️ VPS       — Your VPS overview",                 value="vps"),
        app_commands.Choice(name="🤝 Share     — Share VPS access with someone",     value="share"),
        app_commands.Choice(name="💾 Backup    — Snapshots: create, list, restore",  value="backup"),
        app_commands.Choice(name="💳 Transfer  — Send MoonCoins to another user",    value="transfer"),
        app_commands.Choice(name="📜 History   — Recent coin earn/spend log",        value="history"),
    ])
    @app_commands.choices(share_action=[
        app_commands.Choice(name="➕ Add User",    value="add"),
        app_commands.Choice(name="➖ Remove User", value="remove"),
        app_commands.Choice(name="📋 List Users",  value="list"),
    ])
    @app_commands.choices(backup_action=[
        app_commands.Choice(name="💾 Create Snapshot",  value="create"),
        app_commands.Choice(name="📋 List Snapshots",   value="list"),
        app_commands.Choice(name="🔄 Restore Latest",   value="restore"),
        app_commands.Choice(name="🗑️ Delete Snapshot",  value="delete"),
    ])
    @app_commands.describe(
        section       = "Which section to open (default: Balance)",
        vps_number    = "Your VPS number — shown in /list (e.g. 1, 2, 3)",
        shared_user   = "User to share access with or remove",
        share_action  = "Add, remove, or list shared users",
        backup_action = "Create, list, restore, or delete a snapshot",
        snapshot_name = "Snapshot name for delete (leave blank = latest)",
        transfer_to   = "User to send coins to",
        transfer_amount = "Number of coins to send",
        target_user   = "View another user's balance (admin only)",
    )
    @rate_limit(seconds=15)
    async def account_cmd(
        self,
        interaction:      discord.Interaction,
        section:          str = "balance",
        vps_number:       int = None,
        shared_user:      discord.Member = None,
        share_action:     str = None,
        backup_action:    str = None,
        snapshot_name:    str = None,
        transfer_to:      discord.Member = None,
        transfer_amount:  int = None,
        target_user:      discord.Member = None,
    ):
        await interaction.response.defer(ephemeral=True)

        if not account_enabled():
            return await interaction.followup.send(embed=ext_disabled_embed("Account", "ACCOUNT"))

        uid  = str(interaction.user.id)
        user = interaction.user

        # ── 💰 BALANCE ────────────────────────────────────────────────────────
        if section == "balance":
            view_uid  = str(target_user.id) if (target_user and _is_admin(uid)) else uid
            view_memb = target_user if (target_user and _is_admin(uid)) else user
            data      = _get_user_data(view_uid)

            coins     = data.get("mooncoin", 0)
            invites   = data.get("invites_used", 0)
            credits   = data.get("credits", 0)
            referrals = data.get("total_referrals", 0)
            tier_key  = data.get("tier")
            mult, bonuses = _get_multiplier(view_memb, interaction.guild)

            async with data_lock:
                vps_count = len(vps_data.get(view_uid, []))

            t_icon, t_name, t_color = TIER_META.get(tier_key, ("🆓", "Free", Theme.PRIMARY))
            bar = _coin_bar(coins)

            embed = discord.Embed(
                title=f"{t_icon} {view_memb.display_name}'s Account",
                color=t_color,
                timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes · Account", icon_url=Theme.ICON_URL)
            embed.set_thumbnail(url=view_memb.display_avatar.url)

            embed.add_field(
                name="🌙 MoonCoins",
                value=(
                    f"```\n{coins:,} 🌙\n```"
                    f"`{bar}` {min(coins/100, 100):.1f}%\n"
                    f"Multiplier: **×{mult:.2f}**"
                ),
                inline=True,
            )
            embed.add_field(
                name="📊 Stats",
                value=(
                    f"🖥️ VPS owned: **{vps_count}**\n"
                    f"📨 Invites: **{invites}**\n"
                    f"👥 Referrals: **{referrals}**\n"
                    f"💳 Credits: **{credits:,}**"
                ),
                inline=True,
            )
            embed.add_field(
                name=f"🏅 Tier — {t_name}",
                value=(
                    "\n".join(bonuses) if bonuses else "No active bonuses"
                ),
                inline=True,
            )
            embed.add_field(
                name="🌙 How to Earn Coins",
                value=(
                    "> 💬 Chat in main channel → **+1** *(5 min cooldown)*\n"
                    "> 📨 Invite a user → **+5 per invite**\n"
                    "> 🎉 Enter a giveaway → **+3**\n"
                    "> 📅 Attend an event → **+7**\n"
                    "> 👑 VIP role → **+1%** · 💜 Boost → **+2%** multiplier"
                ),
                inline=False,
            )
            embed.set_footer(text="Use /claim or /marketplace to spend coins · MoonNodes")
            return await interaction.followup.send(embed=embed)

        # ── 🖥️ VPS OVERVIEW ───────────────────────────────────────────────────
        if section == "vps":
            async with data_lock:
                vps_list = list(vps_data.get(uid, []))

            if not vps_list:
                embed = create_info_embed(
                    "🖥️ No VPS Found",
                    "You don't have any VPS yet.\n\n"
                    "**Get started:**\n"
                    "> `/plans` — browse available plans\n"
                    "> `/claim` — claim a free VPS with coins or invites",
                )
                return await interaction.followup.send(embed=embed)

            embed = discord.Embed(
                title=f"🖥️ Your VPS — {len(vps_list)} instance(s)",
                color=Theme.PRIMARY,
                timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes · Account", icon_url=Theme.ICON_URL)

            for i, vps in enumerate(vps_list, 1):
                name   = vps.get("container_name", "?")
                status = vps.get("status", "stopped")
                susp   = vps.get("suspended", False)
                st_icon = "🔴" if susp else ("🟢" if status == "running" else "⚫")
                shared = vps.get("shared_with", [])
                embed.add_field(
                    name=f"{st_icon} VPS #{i} — `{name}`",
                    value=(
                        f"**Specs:** `{vps.get('config','?')}`\n"
                        f"**Node:** `{vps.get('node','local')}`\n"
                        f"**Expiry:** {_expiry_display(vps)}\n"
                        f"**Shared:** {len(shared)} user(s)"
                    ),
                    inline=True,
                )

            embed.set_footer(text="Use /manage to control your VPS · /account section:Share to share access")
            return await interaction.followup.send(embed=embed)

        # ── 🤝 SHARE ──────────────────────────────────────────────────────────
        if section == "share":
            if not vps_number:
                return await interaction.followup.send(embed=create_error_embed(
                    "Missing VPS Number",
                    "Use `vps_number` to specify which VPS.\nRun `/list` or `/account section:VPS` to see your VPS numbers.",
                ))
            async with data_lock:
                vps_list = list(vps_data.get(uid, []))

            if vps_number < 1 or vps_number > len(vps_list):
                return await interaction.followup.send(embed=create_error_embed(
                    "VPS Not Found",
                    f"You don't have a VPS #{vps_number}. Run `/list` to check.",
                ))

            vps  = vps_data[uid][vps_number - 1]
            name = vps["container_name"]

            # List (no share_action or explicit list)
            if not share_action or share_action == "list":
                shared = vps.get("shared_with", [])
                embed  = discord.Embed(
                    title=f"🤝 Shared Access — `{name}`",
                    description=(
                        f"**{len(shared)}** user(s) can manage this VPS.\n\n"
                        + ("\n".join(f"> <@{u}>" for u in shared) if shared else "*No users have been shared yet.*")
                    ),
                    color=Theme.INFO,
                    timestamp=datetime.now(),
                )
                embed.set_author(name="MoonNodes · Account", icon_url=Theme.ICON_URL)
                embed.set_footer(text="Use share_action:Add or share_action:Remove to manage access")
                return await interaction.followup.send(embed=embed)

            if not shared_user:
                return await interaction.followup.send(embed=create_error_embed(
                    "Missing User",
                    "Provide `shared_user` — the user you want to add or remove.",
                ))

            s_uid = str(shared_user.id)

            if share_action == "add":
                if s_uid == uid:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Can't Share With Yourself", "You already own this VPS.",
                    ))
                if s_uid in vps.get("shared_with", []):
                    return await interaction.followup.send(embed=create_error_embed(
                        "Already Shared",
                        f"{shared_user.mention} already has access to **`{name}`**.",
                    ))
                async with data_lock:
                    vps.setdefault("shared_with", []).append(s_uid)
                await async_save_vps_data()
                try:
                    dm = discord.Embed(
                        title="🤝 VPS Access Granted",
                        description=(
                            f"**{user.display_name}** has shared their VPS **`{name}`** with you!\n\n"
                            "You can now manage it under `/manage` → **Shared VPS**."
                        ),
                        color=Theme.SUCCESS, timestamp=datetime.now(),
                    )
                    dm.set_author(name="MoonNodes", icon_url=Theme.ICON_URL)
                    await shared_user.send(embed=dm)
                except discord.Forbidden:
                    pass
                embed = create_success_embed(
                    "✅ Access Granted",
                    f"{shared_user.mention} can now manage **`{name}`**.\n"
                    f"They can find it under `/manage` → Shared VPS.",
                )
                return await interaction.followup.send(embed=embed)

            elif share_action == "remove":
                if s_uid not in vps.get("shared_with", []):
                    return await interaction.followup.send(embed=create_error_embed(
                        "Not Shared",
                        f"{shared_user.mention} doesn't have access to **`{name}`**.",
                    ))
                async with data_lock:
                    vps["shared_with"].remove(s_uid)
                await async_save_vps_data()
                try:
                    dm = discord.Embed(
                        title="❌ VPS Access Revoked",
                        description=(
                            f"Your shared access to **`{name}`** "
                            f"(owned by {user.display_name}) has been removed."
                        ),
                        color=Theme.ERROR, timestamp=datetime.now(),
                    )
                    dm.set_author(name="MoonNodes", icon_url=Theme.ICON_URL)
                    await shared_user.send(embed=dm)
                except discord.Forbidden:
                    pass
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ Access Removed",
                    f"{shared_user.mention} no longer has access to **`{name}`**.",
                ))

        # ── 💾 BACKUP ─────────────────────────────────────────────────────────
        if section == "backup":
            if not vps_number:
                return await interaction.followup.send(embed=create_error_embed(
                    "Missing VPS Number",
                    "Use `vps_number` to specify which VPS to back up.\nRun `/list` to see your VPS numbers.",
                ))
            async with data_lock:
                vps_list = list(vps_data.get(uid, []))

            if vps_number < 1 or vps_number > len(vps_list):
                return await interaction.followup.send(embed=create_error_embed(
                    "VPS Not Found", f"You don't have a VPS #{vps_number}.",
                ))

            vps    = vps_data[uid][vps_number - 1]
            name   = vps["container_name"]
            node   = vps.get("node", "local")
            prefix = f"{node}:" if node != "local" else ""

            if not backup_action:
                embed = discord.Embed(
                    title=f"💾 Backups — `{name}`",
                    description=(
                        "Choose a `backup_action`:\n\n"
                        "> 💾 **Create** — take a new snapshot now\n"
                        "> 📋 **List** — see all saved snapshots\n"
                        "> 🔄 **Restore** — roll back to the latest snapshot\n"
                        "> 🗑️ **Delete** — remove a specific snapshot"
                    ),
                    color=Theme.INFO,
                )
                embed.set_author(name="MoonNodes · Account", icon_url=Theme.ICON_URL)
                return await interaction.followup.send(embed=embed)

            if backup_action == "create":
                snap = f"snap-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
                try:
                    await execute_lxc(f"lxc snapshot {prefix}{name} {snap}")
                    # Save to DB
                    try:
                        from core.database import save_snapshot
                        save_snapshot(uid, name, snap, node)
                    except Exception:
                        pass
                    embed = discord.Embed(
                        title="💾 Snapshot Created",
                        description=(
                            f"**VPS:** `{name}`\n"
                            f"**Snapshot:** `{snap}`\n"
                            f"**Node:** `{node}`\n\n"
                            "Use `backup_action:Restore` to roll back to this point."
                        ),
                        color=Theme.SUCCESS, timestamp=datetime.now(),
                    )
                    embed.set_author(name="MoonNodes · Account", icon_url=Theme.ICON_URL)
                    embed.set_footer(text="MoonNodes · Snapshot")
                    return await interaction.followup.send(embed=embed)
                except Exception as e:
                    return await interaction.followup.send(embed=create_error_embed("Snapshot Failed", str(e)[:1500]))

            elif backup_action == "list":
                try:
                    info  = await execute_lxc(f"lxc info {prefix}{name}")
                    snaps = [l.strip() for l in str(info).splitlines()
                             if l.strip().startswith("snap-") or l.strip().startswith("auto-")]
                    if not snaps:
                        return await interaction.followup.send(embed=create_info_embed(
                            "No Snapshots",
                            f"**`{name}`** has no snapshots yet.\n\n"
                            "Use `backup_action:Create` to take your first snapshot.",
                        ))
                    embed = discord.Embed(
                        title=f"📋 Snapshots — `{name}`",
                        description="\n".join(f"> `{s}`" for s in snaps[:20]),
                        color=Theme.INFO, timestamp=datetime.now(),
                    )
                    embed.set_footer(text=f"{len(snaps)} snapshot(s) · Use backup_action:Delete to remove one")
                    embed.set_author(name="MoonNodes · Account", icon_url=Theme.ICON_URL)
                    return await interaction.followup.send(embed=embed)
                except Exception as e:
                    return await interaction.followup.send(embed=create_error_embed("Error", str(e)[:1500]))

            elif backup_action == "restore":
                try:
                    info  = await execute_lxc(f"lxc info {prefix}{name}")
                    snaps = sorted([l.strip() for l in str(info).splitlines()
                                    if l.strip().startswith("snap-") or l.strip().startswith("auto-")])
                    if not snaps:
                        return await interaction.followup.send(embed=create_error_embed(
                            "No Snapshots", "No snapshots to restore. Create one first with `backup_action:Create`.",
                        ))
                    latest = snaps[-1]
                    # Send progress message
                    prog = discord.Embed(
                        title="⏳ Restoring VPS…",
                        description=f"Rolling **`{name}`** back to `{latest}`.\nTakes a moment.",
                        color=0x5865F2,
                    )
                    await interaction.followup.send(embed=prog)
                    await execute_lxc(f"lxc stop {prefix}{name}", timeout=30)
                    await execute_lxc(f"lxc restore {prefix}{name} {latest}")
                    await execute_lxc(f"lxc start {prefix}{name}", timeout=60)
                    embed = discord.Embed(
                        title="✅ VPS Restored",
                        description=(
                            f"**`{name}`** has been restored to snapshot **`{latest}`** and is now running.\n\n"
                            "All changes made after that snapshot were rolled back."
                        ),
                        color=Theme.SUCCESS, timestamp=datetime.now(),
                    )
                    embed.set_author(name="MoonNodes · Account", icon_url=Theme.ICON_URL)
                    return await interaction.followup.send(embed=embed)
                except Exception as e:
                    return await interaction.followup.send(embed=create_error_embed("Restore Failed", str(e)[:1500]))

            elif backup_action == "delete":
                try:
                    info  = await execute_lxc(f"lxc info {prefix}{name}")
                    snaps = sorted([l.strip() for l in str(info).splitlines()
                                    if l.strip().startswith("snap-") or l.strip().startswith("auto-")])
                    if not snaps:
                        return await interaction.followup.send(embed=create_error_embed(
                            "No Snapshots", "Nothing to delete.",
                        ))
                    target = snapshot_name or snaps[-1]
                    if target not in snaps:
                        return await interaction.followup.send(embed=create_error_embed(
                            "Snapshot Not Found",
                            f"`{target}` not found.\n\nAvailable snapshots:\n"
                            + "\n".join(f"> `{s}`" for s in snaps),
                        ))
                    await execute_lxc(f"lxc delete {prefix}{name}/{target}")
                    try:
                        from core.database import delete_snapshot_record
                        delete_snapshot_record(name, target)
                    except Exception:
                        pass
                    return await interaction.followup.send(embed=create_success_embed(
                        "🗑️ Snapshot Deleted",
                        f"Snapshot **`{target}`** removed from **`{name}`**.",
                    ))
                except Exception as e:
                    return await interaction.followup.send(embed=create_error_embed("Delete Failed", str(e)[:1500]))

        # ── 💳 TRANSFER ───────────────────────────────────────────────────────
        if section == "transfer":
            balance = _db_coins(uid)
            if not transfer_to or not transfer_amount:
                embed = discord.Embed(
                    title="💳 Transfer MoonCoins",
                    description=(
                        "Send MoonCoins to any user.\n\n"
                        "**Required:**\n"
                        "> `transfer_to` — the user to send to\n"
                        "> `transfer_amount` — how many coins to send\n\n"
                        f"**Your balance:** `{balance:,} 🌙`"
                    ),
                    color=Theme.INFO,
                )
                embed.set_author(name="MoonNodes · Account", icon_url=Theme.ICON_URL)
                return await interaction.followup.send(embed=embed)

            if transfer_to.id == interaction.user.id:
                return await interaction.followup.send(embed=create_error_embed(
                    "Can't Transfer to Yourself", "Choose a different user to send coins to.",
                ))
            if transfer_amount <= 0:
                return await interaction.followup.send(embed=create_error_embed(
                    "Invalid Amount", "Transfer amount must be at least **1 coin**.",
                ))
            if transfer_amount > balance:
                return await interaction.followup.send(embed=create_error_embed(
                    "Insufficient Balance",
                    f"You only have **{balance:,} 🌙**.\n"
                    f"You need **{transfer_amount:,} 🌙** to complete this transfer.",
                ))

            ok = _transfer_coins(uid, str(transfer_to.id), transfer_amount)
            if not ok:
                return await interaction.followup.send(embed=create_error_embed(
                    "Transfer Failed", "Failed. Try again.",
                ))
            new_balance = _db_coins(uid)
            try:
                dm = discord.Embed(
                    title="🌙 MoonCoins Received!",
                    description=(
                        f"**{user.display_name}** sent you **{transfer_amount:,} 🌙**!\n\n"
                        f"Use `/account section:Balance` to check your new balance."
                    ),
                    color=0xFFD700, timestamp=datetime.now(),
                )
                dm.set_author(name="MoonNodes", icon_url=Theme.ICON_URL)
                await transfer_to.send(embed=dm)
            except discord.Forbidden:
                pass
            embed = discord.Embed(
                title="✅ Transfer Complete",
                description=(
                    f"Sent **{transfer_amount:,} 🌙** to {transfer_to.mention}.\n\n"
                    f"**Remaining balance:** `{new_balance:,} 🌙`"
                ),
                color=Theme.SUCCESS, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes · Account", icon_url=Theme.ICON_URL)
            return await interaction.followup.send(embed=embed)

        # ── 📜 HISTORY ────────────────────────────────────────────────────────
        if section == "history":
            cur = get_db().cursor()
            cur.execute(
                "SELECT delta, balance, reason, at FROM coin_ledger "
                "WHERE user_id=? ORDER BY at DESC LIMIT 15",
                (uid,),
            )
            rows = cur.fetchall()
            if not rows:
                return await interaction.followup.send(embed=create_info_embed(
                    "📜 No Coin History",
                    "No coin transactions recorded yet.\n\n"
                    "Earn coins by chatting, inviting users, or entering giveaways!",
                ))
            embed = discord.Embed(
                title="📜 Recent Coin Activity",
                color=Theme.PRIMARY,
                timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes · Account", icon_url=Theme.ICON_URL)
            lines = []
            for r in rows:
                sign  = "+" if r["delta"] >= 0 else ""
                icon  = "🟢" if r["delta"] >= 0 else "🔴"
                ts    = r["at"][:10]
                label = r["reason"] or "—"
                lines.append(f"{icon} `{sign}{r['delta']:,}` → `{r['balance']:,} 🌙` · {label} ·`{ts}`")
            embed.description = "\n".join(lines)
            embed.set_footer(text="Showing last 15 transactions · MoonNodes")
            return await interaction.followup.send(embed=embed)

    # ── Coin earning listeners ─────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if not account_enabled() or message.author.bot:
            return
        from core.config import MAIN_CHAT_ID
        if MAIN_CHAT_ID == 0 or message.channel.id != MAIN_CHAT_ID:
            return
        uid = str(message.author.id)
        c   = get_db()
        try:
            c.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (uid,)); c.commit()
            row = c.execute("SELECT last_chat_coin FROM users WHERE user_id=?", (uid,)).fetchone()
            now = datetime.now()
            if row and row["last_chat_coin"]:
                if (now - datetime.fromisoformat(row["last_chat_coin"])).total_seconds() < 300:
                    return
            mult, _ = _get_multiplier(message.author, message.guild)
            reward  = max(1, int(1 * mult))
            add_coins(uid, reward, reason="chat")
            c.execute("UPDATE users SET last_chat_coin=? WHERE user_id=?", (now.isoformat(), uid))
            c.commit()
        except Exception:
            pass

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        if not account_enabled() or not member.guild:
            return
        try:
            invites = await member.guild.invites()
            c = get_db()
            for inv in invites:
                if not inv.inviter:
                    continue
                inv_uid = str(inv.inviter.id)
                row     = c.execute("SELECT invite_count FROM users WHERE user_id=?", (inv_uid,)).fetchone()
                old     = row["invite_count"] if row else 0
                if inv.uses > old:
                    diff  = inv.uses - old
                    mult, _ = _get_multiplier(inv.inviter, member.guild)
                    reward  = int(5 * diff * mult)
                    c.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (inv_uid,)); c.commit()
                    add_coins(inv_uid, reward, reason=f"invite ({diff} user(s))")
                    c.execute("UPDATE users SET invites_used=invites_used+?, invite_count=? WHERE user_id=?",
                              (diff, inv.uses, inv_uid))
                    c.commit()
        except Exception:
            pass


async def setup(bot):
    await bot.add_cog(AccountCog(bot))
