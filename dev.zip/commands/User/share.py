import discord
from discord import app_commands
from discord.ext import commands

from core.database import vps_data, data_lock, save_vps_data
from core.theme import create_success_embed, create_error_embed


class ShareCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="share", description="Grant or revoke access to your VPS for another user")
    @app_commands.choices(action=[
        app_commands.Choice(name="Add User",    value="add"),
        app_commands.Choice(name="Remove User", value="ruser"),
    ])
    @app_commands.describe(
        action      = "Add or remove access",
        shared_user = "The user to share with",
        vps_number  = "Your VPS number (1, 2…)",
    )
    async def share_cmd(
        self, interaction: discord.Interaction,
        action: str, shared_user: discord.Member, vps_number: int,
    ):
        await interaction.response.defer(ephemeral=True)
        uid = str(interaction.user.id)

        with data_lock:
            if uid not in vps_data or vps_number < 1 or vps_number > len(vps_data[uid]):
                return await interaction.followup.send(embed=create_error_embed("Error", "Invalid VPS number."))
            vps = vps_data[uid][vps_number - 1]

            vps.setdefault("shared_with", [])
            sid = str(shared_user.id)

            if action == "add":
                if sid not in vps["shared_with"]:
                    vps["shared_with"].append(sid)
                msg = f"Granted access to {shared_user.mention}."
            else:
                if sid in vps["shared_with"]:
                    vps["shared_with"].remove(sid)
                msg = f"Removed access for {shared_user.mention}."

        save_vps_data()
        await interaction.followup.send(embed=create_success_embed("Access Updated", msg))


async def setup(bot):
    await bot.add_cog(ShareCog(bot))
