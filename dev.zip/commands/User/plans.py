import discord
from discord import app_commands
from discord.ext import commands

from core.config import ENABLE_PLANS, MAIN_ADMIN_ID
from core.database import admin_data, get_payments
from core.theme import create_info_embed, create_error_embed, create_success_embed
from feature.plans.plans_manager import PLANS, save_plans
from ui.plans_view import PlansView


def is_admin_check(user_id):
    role = admin_data.get(str(user_id))
    return role in ["Owner", "Admin", "Dev"] or str(user_id) == str(MAIN_ADMIN_ID)


class PlansCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="plans", description="Browse VPS plans or manage them (Admin)")
    @app_commands.choices(plan_type=[
        app_commands.Choice(name="Premium", value="premium"),
        app_commands.Choice(name="Free",    value="free"),
    ])
    @app_commands.choices(action=[
        app_commands.Choice(name="List (Public)", value="list"),
        app_commands.Choice(name="Add (Admin)",   value="add"),
        app_commands.Choice(name="Edit (Admin)",  value="edit"),
        app_commands.Choice(name="Remove (Admin)","remove"),
    ])
    @app_commands.describe(
        plan_name="Plan name (e.g. basic, pro)",
        ram_gb="RAM in GB", cpu_cores="CPU cores", disk_gb="Disk in GB",
        price="Price string (e.g. ₱150 or invite 4)",
        validity="Validity period (e.g. 30 Days)",
        emoji="Emoji icon",
    )
    async def manage_plans(
        self, interaction: discord.Interaction,
        plan_type: str, action: str,
        plan_name: str = None, ram_gb: int = None, cpu_cores: int = None,
        disk_gb: int = None, price: str = None, validity: str = None, emoji: str = "📦",
    ):
        is_list = (action == "list")
        await interaction.response.defer(ephemeral=not is_list)

        if not ENABLE_PLANS:
            return await interaction.followup.send(embed=create_error_embed("Disabled", "Plans feature is currently disabled."))

        if is_list:
            embed = create_info_embed("VPS Plans")
            desc  = ""
            data  = PLANS.get(plan_type, {})
            view  = None

            if plan_type == "premium":
                desc += "💰 **Premium VPS Plans**\n\n"
                for name, p in data.items():
                    desc += f"{p.get('emoji','📦')} **{name.title()} Plan** — {p.get('price','?')}\n"
                    desc += f"• {p.get('ram')}GB RAM  •  {p.get('cpu')} CPU Cores  •  {p.get('disk')}GB Disk\n"
                    if p.get("validity"):
                        desc += f"• {p.get('validity')} Validity\n"
                    desc += "• Full Root Access\n\n"

                desc += "📞 **How to Purchase**\n"
                desc += "1. Select a payment method below.\n"
                desc += "2. Screenshot your payment confirmation.\n"
                desc += "3. Open a ticket with `/support`.\n"
                desc += "4. Your VPS will be activated within 24 h.\n"

                methods = get_payments()
                if methods:
                    view = PlansView(methods)
            else:
                for name, p in data.items():
                    desc += f"{p.get('emoji','📦')} **{name.title()} Plan** — {p.get('price','Free')}\n"
                    desc += f"• {p.get('ram')}GB RAM  •  {p.get('cpu')} CPU  •  {p.get('disk')}GB Disk\n\n"

            embed.description = desc
            if view:
                return await interaction.followup.send(embed=embed, view=view)
            return await interaction.followup.send(embed=embed)

        # Admin add/edit/remove
        if not is_admin_check(interaction.user.id):
            return await interaction.followup.send(embed=create_error_embed("Denied", "Admin only."))
        if not plan_name:
            return await interaction.followup.send(embed=create_error_embed("Error", "Provide a plan_name."))

        p_key = plan_name.lower()

        if action == "remove":
            if p_key not in PLANS.get(plan_type, {}):
                return await interaction.followup.send(embed=create_error_embed("Not Found", f"`{plan_name}` not found."))
            del PLANS[plan_type][p_key]
            save_plans()
            return await interaction.followup.send(embed=create_success_embed("Removed", f"Plan **{plan_name}** removed."))

        if action in ("add", "edit"):
            if ram_gb is None or cpu_cores is None or disk_gb is None:
                return await interaction.followup.send(embed=create_error_embed("Error", "Provide ram_gb, cpu_cores, and disk_gb."))
            if action == "add" and p_key in PLANS.get(plan_type, {}):
                return await interaction.followup.send(embed=create_error_embed("Exists", f"Plan **{plan_name}** already exists. Use `edit`."))
            if action == "edit" and p_key not in PLANS.get(plan_type, {}):
                return await interaction.followup.send(embed=create_error_embed("Not Found", f"Plan **{plan_name}** not found. Use `add`."))

            PLANS[plan_type][p_key] = {
                "ram": ram_gb, "cpu": cpu_cores, "disk": disk_gb,
                "price": price or ("TBD" if plan_type == "premium" else ""),
                "emoji": emoji,
            }
            if validity:
                PLANS[plan_type][p_key]["validity"] = validity
            save_plans()
            return await interaction.followup.send(embed=create_success_embed("Saved", f"Plan **{plan_name}** {action}ed."))


async def setup(bot):
    await bot.add_cog(PlansCog(bot))
