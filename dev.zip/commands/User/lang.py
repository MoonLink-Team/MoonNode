"""
/lang — Set your preferred language for bot messages and DMs.
"""

import discord
from discord import app_commands
from discord.ext import commands

from core.lang  import SUPPORTED_LANGUAGES, set_user_lang, get_user_lang
from core.theme import create_success_embed


class LangCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="lang", description="Set your preferred language for bot messages and DMs")
    @app_commands.choices(language=[
        app_commands.Choice(name=label, value=code)
        for code, label in SUPPORTED_LANGUAGES.items()
    ])
    @app_commands.describe(language="Your preferred language")
    async def lang_cmd(self, interaction: discord.Interaction, language: str):
        await interaction.response.defer(ephemeral=True, thinking=True)
        uid = str(interaction.user.id)
        set_user_lang(uid, language)
        label = SUPPORTED_LANGUAGES.get(language, language)
        embed = create_success_embed(
            "✅ Language Updated",
            f"Your preferred language has been set to **{label}**.\n\n"
            "All future bot messages and DMs will use this language.\n"
            "*You can change it again at any time with `/lang`.*"
        )
        embed.set_author(name="MoonNodes — Language Settings", icon_url="https://imgur.com/6yfYDTP.png")
        await interaction.followup.send(embed=embed, ephemeral=True)


async def setup(bot):
    await bot.add_cog(LangCog(bot))
