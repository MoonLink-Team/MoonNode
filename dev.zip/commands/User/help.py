"""
/help — Role-based interactive help with tab navigation.
"""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config   import MAIN_ADMIN_ID
from core.database import admin_data

ICON  = "https://imgur.com/6yfYDTP.png"

def _role(uid: int) -> str:
    if str(uid) == str(MAIN_ADMIN_ID): return "Owner"
    return admin_data.get(str(uid), "User")

# ── Pages ─────────────────────────────────────────────────────────────────────

PAGES = {
    "User": [
        {
            "title": "🌙 MoonNodes — VPS Commands",
            "color": 0x5865F2,
            "fields": [
                ("🖥️ Your VPS",
                 "> `/list` — See all your VPS with live status\n"
                 "> `/manage` — Start · Stop · Restart · SSH · Console · Snapshots\n"
                 "> `/status` — Live host CPU, RAM & disk\n"
                 "> `/history vps_name:X` — CPU/RAM usage graph (24h · 7d · 30d)\n"
                 "> `/support` — Open a support ticket with staff"),
                ("📦 Getting a VPS",
                 "> `/plans` — Browse all free and premium plans\n"
                 "> `/claim claim_type:Free option:coin` — Claim free VPS with 🌙 coins\n"
                 "> `/claim claim_type:Free option:inv` — Claim free VPS with invites\n"
                 "> `/claim claim_type:Premium proof:URL` — Claim paid plan"),
            ],
        },
        {
            "title": "🌙 Account & Marketplace",
            "color": 0xFFD700,
            "fields": [
                ("💰 Account",
                 "> `/account` — Coin balance, stats & earn info\n"
                 "> `/account section:VPS` — Overview of all your VPS\n"
                 "> `/account section:Share vps_number:1 shared_user:@X` — Share access\n"
                 "> `/account section:Backup vps_number:1 backup_action:Create` — Snapshot\n"
                 "> `/account section:Backup vps_number:1 backup_action:List` — View snapshots\n"
                 "> `/account section:Transfer transfer_to:@X transfer_amount:50` — Send coins\n"
                 "> `/account section:History` — Recent coin transactions"),
                ("🛒 Marketplace",
                 "> `/marketplace pick_one:Browse` — All active listings\n"
                 "> `/marketplace pick_one:Sell` — List your VPS for sale\n"
                 "> `/marketplace pick_one:Buy` — Purchase a listing\n"
                 "> `/marketplace pick_one:Edit` — Update your listing\n"
                 "> `/marketplace pick_one:Remove` — Remove your listing"),
            ],
        },
        {
            "title": "🌙 Coins & Settings",
            "color": 0xFFD700,
            "fields": [
                ("🌙 Earning MoonCoins",
                 "> 💬 **Chat** in main channel → **+1 coin** *(5 min cooldown)*\n"
                 "> 📨 **Invite** a user → **+5 coins**\n"
                 "> 🎉 **Enter giveaway** → **+3 coins**\n"
                 "> 📅 **Attend event** → **+7 coins**\n"
                 "> 👑 VIP role → **+1% multiplier** · 💜 Boost → **+2%**"),
                ("⚙️ Settings & Misc",
                 "> `/lang` — Set your preferred language\n"
                 "> `/status` — Live system status dashboard\n"
                 "> `/history` — VPS resource usage history\n"
                 "> `/giveaway action:List` — View active giveaways"),
            ],
        },
    ],
    "Staff": [
        {
            "title": "🌟 Staff Tools",
            "color": 0x57F287,
            "fields": [
                ("🎫 Tickets",
                 "> `/staff role:Staff action:My Tickets` — Your open tickets\n"
                 "> `/staff role:Staff action:All Tickets` — All open tickets\n"
                 "> `/staff role:Staff action:Close Ticket` — Close + save transcript\n"
                 "> `/staff role:Staff action:Claim Ticket` — Assign to yourself"),
                ("👤 User Tools",
                 "> `/staff role:Staff action:User Lookup target_user:@X` — Quick info\n"
                 "> `/staff role:Staff action:Add Note target_user:@X message:X` — Add note\n"
                 "> `/staff role:Staff action:View Notes target_user:@X` — Read notes"),
            ],
        },
        {
            "title": "⭐ Hard Staff Tools",
            "color": 0x57F287,
            "fields": [
                ("🔍 Investigation",
                 "> `/staff role:Hard Staff action:User Info target_user:@X` — Full profile\n"
                 "> `/staff role:Hard Staff action:VPS Info container:X` — VPS details\n"
                 "> `/staff role:Hard Staff action:List VPS target_user:@X` — All user VPS\n"
                 "> `/staff role:Hard Staff action:Suspension Logs` — Recent suspensions"),
                ("⚠️ Actions",
                 "> `/staff role:Hard Staff action:Warn User target_user:@X message:X`\n"
                 "> `/staff role:Hard Staff action:Warn Log target_user:@X`\n"
                 "> `/staff role:Hard Staff action:DM User target_user:@X message:X`\n"
                 "> `/staff role:Hard Staff action:Server Stats` — Live container counts"),
            ],
        },
    ],
    "Admin": [
        {
            "title": "🛡️ Admin — VPS & Deployment",
            "color": 0xED4245,
            "fields": [
                ("🚀 Deploy & Manage",
                 "> `/create user:@X plan_name:starter` — Deploy from plan\n"
                 "> `/create user:@X ram_gb:2 cpu_cores:2 disk_gb:20` — Custom specs\n"
                 "> `/create user:@X vm_mode:KVM` — Full VM\n"
                 "> `/delete container_name:X` — Remove VPS permanently\n"
                 "> `/account admin_action:VPS target_user:@X` — Admin VPS panel"),
                ("⚙️ Configuration",
                 "> `/set setting:Channel` — Configure all channels in one panel\n"
                 "> `/set setting:MoonCoin mooncoin_action:Add value:X` — Add earn rule\n"
                 "> `/set setting:DM Commands command_dm_action:Enable` — Allow DMs\n"
                 "> `/set setting:DM Commands command_dm_action:Block value:cmd` — Block cmd"),
            ],
        },
        {
            "title": "🛡️ Admin — Moderation & System",
            "color": 0xED4245,
            "fields": [
                ("🔨 Moderation",
                 "> `/mod action:Suspend container_name:X reason:X` — Suspend VPS\n"
                 "> `/mod action:Unsuspend container_name:X` — Reactivate VPS\n"
                 "> `/mod action:Mute target_user:@X reason:X` — Mute user\n"
                 "> `/mod action:Unmute target_user:@X` — Unmute user\n"
                 "> `/mod action:Blocklist target_user:@X reason:X` — Block from bot\n"
                 "> `/mod action:Whitelist container_name:X` — Whitelist VPS"),
                ("🔧 System",
                 "> `/system` — Extension manager\n"
                 "> `/nodes action:Add name:X` — Register remote node\n"
                 "> `/nodes action:List` — All nodes + status\n"
                 "> `/admin action:List` — All staff roles\n"
                 "> `/admin action:Add target_user:@X role:Admin` — Grant staff role"),
            ],
        },
        {
            "title": "🛡️ Admin — Coins & Giveaways",
            "color": 0xED4245,
            "fields": [
                ("🌙 MoonCoins",
                 "> `/set setting:MoonCoin mooncoin_action:Grant target_user:@X value:50`\n"
                 "> `/set setting:MoonCoin mooncoin_action:Deduct target_user:@X value:25`\n"
                 "> `/set setting:MoonCoin mooncoin_action:View` — All earn rules\n"
                 "> `/set setting:MoonCoin mooncoin_action:Set Cooldown value:rule option:s`"),
                ("🎉 Giveaways",
                 "> `/giveaway action:Create duration_minutes:60 ram:2 cpu:2 disk:20`\n"
                 "> `/giveaway action:List` — All active giveaways\n"
                 "> `/giveaway action:Cancel target_id:XXXX` — Cancel a giveaway"),
            ],
        },
    ],
    "Owner": [
        {
            "title": "👑 Owner Tools",
            "color": 0xFFD700,
            "fields": [
                ("🔐 Security & Infrastructure",
                 "> `/af2f` — Manage admin 2FA codes\n"
                 "> `/set setting:AF2F Channel value:channel_id` — Set 2FA channel\n"
                 "> `/nodes action:Add name:X` — Register LXD/Incus node\n"
                 "> `/nodes action:Remove name:X` — Remove a node\n"
                 "> `/system action:Extension Toggle extension:X` — Toggle features"),
                ("⚙️ Bot Config",
                 "> `/set setting:Channel` — All channel settings\n"
                 "> `/set setting:CPU Alert Threshold % value:90` — CPU alert %\n"
                 "> `/set setting:RAM Alert Threshold % value:90` — RAM alert %\n"
                 "> `/set setting:Backup Snapshot Limit value:3` — Max snapshots per VPS"),
            ],
        },
    ],
}

ROLE_PAGES = {
    "User":       PAGES["User"],
    "Trial Mod":  PAGES["User"] + PAGES["Staff"],
    "Trial Staff":PAGES["User"] + PAGES["Staff"],
    "Mod":        PAGES["User"] + PAGES["Staff"],
    "Hard Mod":   PAGES["User"] + PAGES["Staff"],
    "Staff":      PAGES["User"] + PAGES["Staff"],
    "Hard Staff": PAGES["User"] + PAGES["Staff"],
    "Manager":    PAGES["User"] + PAGES["Staff"] + PAGES["Admin"],
    "Admin":      PAGES["User"] + PAGES["Staff"] + PAGES["Admin"],
    "Hard Admin": PAGES["User"] + PAGES["Staff"] + PAGES["Admin"],
    "Dev":        PAGES["User"] + PAGES["Staff"] + PAGES["Admin"],
    "Owner":      PAGES["User"] + PAGES["Staff"] + PAGES["Admin"] + PAGES["Owner"],
}


# ── View ──────────────────────────────────────────────────────────────────────

class HelpView(discord.ui.View):
    def __init__(self, uid: int, pages: list):
        super().__init__(timeout=300)
        self.uid   = uid
        self.pages = pages
        self.page  = 0
        self._sync()

    def _sync(self):
        self.prev_btn.disabled = (self.page == 0)
        self.next_btn.disabled = (self.page >= len(self.pages) - 1)
        self.page_btn.label    = f"{self.page + 1} / {len(self.pages)}"

    def build_embed(self) -> discord.Embed:
        p     = self.pages[self.page]
        embed = discord.Embed(
            title=p["title"],
            color=p.get("color", 0x5865F2),
            timestamp=datetime.now(),
        )
        embed.set_author(name="MoonNodes — Help Centre", icon_url=ICON)
        for name, value in p.get("fields", []):
            embed.add_field(name=name, value=value, inline=False)
        embed.set_footer(text=f"Page {self.page+1}/{len(self.pages)} · /support to open a ticket · MoonNodes")
        return embed

    async def _guard(self, inter: discord.Interaction) -> bool:
        if inter.user.id != self.uid:
            await inter.response.send_message(
                embed=discord.Embed(
                    description="This help panel belongs to someone else. Run `/help` to open your own.",
                    color=0xED4245,
                ),
                ephemeral=True,
            )
            return False
        return True

    @discord.ui.button(label="◀", style=discord.ButtonStyle.secondary)
    async def prev_btn(self, inter: discord.Interaction, _: discord.ui.Button):
        if not await self._guard(inter): return
        self.page -= 1
        self._sync()
        await inter.response.edit_message(embed=self.build_embed(), view=self)

    @discord.ui.button(label="1 / 1", style=discord.ButtonStyle.secondary, disabled=True)
    async def page_btn(self, inter: discord.Interaction, _: discord.ui.Button):
        pass

    @discord.ui.button(label="▶", style=discord.ButtonStyle.secondary)
    async def next_btn(self, inter: discord.Interaction, _: discord.ui.Button):
        if not await self._guard(inter): return
        self.page += 1
        self._sync()
        await inter.response.edit_message(embed=self.build_embed(), view=self)


# ── Cog ───────────────────────────────────────────────────────────────────────

class HelpCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="help", description="Browse all commands available to your role")
    async def help_cmd(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        role  = _role(interaction.user.id)
        pages = ROLE_PAGES.get(role, PAGES["User"])
        view  = HelpView(interaction.user.id, pages)
        await interaction.followup.send(embed=view.build_embed(), view=view, ephemeral=True)


async def setup(bot):
    await bot.add_cog(HelpCog(bot))
