"""
/help — Role-based interactive help system.
Each role sees only the commands relevant to them.
"""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MAIN_ADMIN_ID
from core.database import admin_data
from core.theme import Theme, create_embed

ICON = "https://imgur.com/6yfYDTP.png"


def _role(uid) -> str:
    if str(uid) == str(MAIN_ADMIN_ID): return "Owner"
    return admin_data.get(str(uid), "User")


# ── Page content per role ─────────────────────────────────────────────────────

PAGES = {
    "User": [
        {
            "title": "🌙  MoonNodes — Your VPS",
            "color": 0x5865F2,
            "fields": [
                ("🖥️  VPS Control",
                 "› `/list` — View all your VPS instances and their live status\n"
                 "› `/manage` — Full control panel: **Start · Stop · Restart · SSH · Console · Reinstall**\n"
                 "  ↳ Switch between **My VPS** and **Shared VPS** tabs\n"
                 "› `/status` — Live CPU, RAM, and Disk usage of the host node\n"
                 "› `/backup vps_number:` — Create, restore, list, or delete VPS snapshots"),
                ("📦  Plans & Claiming",
                 "› `/plans plan_type:Free` — Browse free plans (pay with Invites or Coins)\n"
                 "› `/plans plan_type:Premium` — Browse paid plans with pricing info\n"
                 "› `/claim claim_type:Free option:inv code_or_plan:basic` — Claim with invites\n"
                 "› `/claim claim_type:Free option:coin code_or_plan:basic` — Claim with coins\n"
                 "› `/claim claim_type:Premium code_or_plan:starter proof:` — Submit payment proof\n"
                 "› `/upgrade` — Upgrade or extend your current VPS plan"),
            ],
        },
        {
            "title": "🌙  Account & Marketplace",
            "color": 0xFFD700,
            "fields": [
                ("💰  Account",
                 "› `/account options:Balance` — View your MoonCoin balance and multipliers\n"
                 "› `/account options:VPS user_action:Share share_action:Add vps_number:` — Grant VPS access\n"
                 "› `/account options:VPS user_action:Share share_action:Remove vps_number:` — Revoke access\n"
                 "› `/account options:VPS user_action:Backup backup_action:Create vps_number:` — Create backup\n"
                 "› `/account options:VPS user_action:Backup backup_action:Restore vps_number:` — Restore backup\n"
                 "› `/support vps_number: issue:` — Open a private support ticket with staff"),
                ("🛒  Marketplace",
                 "› `/marketplace pick_one:List` — Browse all VPS listings\n"
                 "› `/marketplace pick_one:Sell vps_number: price: price_type:` — List your VPS for sale\n"
                 "› `/marketplace pick_one:Buy sell_name: user:` — Purchase a listing\n"
                 "› `/marketplace pick_one:Edit sell_name:` — Edit your existing listing\n"
                 "› `/marketplace pick_one:Remove sell_name:` — Remove your listing"),
                ("🌙  Earning MoonCoins",
                 "› Invite someone → **+5 coins** per person\n"
                 "› Chat in main channel → **+1 coin** *(5 min cooldown)*\n"
                 "› Join a giveaway → **+3 coins**\n"
                 "› Join an event → **+7 coins**\n"
                 "› VIP role → **+1% multiplier** on all earnings\n"
                 "› Server Boost → **+2% multiplier** *(stacks!)*"),
            ],
        },
    ],
    "Mod": [
        {
            "title": "🔨  Moderation Tools",
            "color": 0x57F287,
            "fields": [
                ("🔍  Lookups & Search",
                 "› `/mod action:User Info target_user:` — Full user profile with VPS count and coins\n"
                 "› `/mod action:VPS Info container_name:` — Detailed container info and stats\n"
                 "› `/mod action:List VPS target_user:` — All VPS instances owned by a user\n"
                 "› `/mod action:Search container_name:` — Find any container by partial name\n"
                 "› `/mod action:Server Stats` — Global VPS count, users, running, suspended"),
                ("🎫  Tickets & Warnings",
                 "› `/mod action:Open Tickets` — List all open support threads\n"
                 "› `/mod action:Suspension Logs` — View recent VPS suspension history\n"
                 "› `/mod action:DM User target_user: message:` — Message a user as MoonNodes Staff\n"
                 "› `/mod action:Warn User target_user: message:` — Issue a formal warning (saved to DB)\n"
                 "› `/mod action:Warn Log target_user:` — View a user's full warning history"),
            ],
        },
    ],
    "Admin": [
        {
            "title": "🛡️  Admin — VPS Management",
            "color": 0x5865F2,
            "fields": [
                ("🔧  Create & Delete",
                 "› `/create user: plan_name: plan_type:` — Deploy a new VPS (Node → OS selector)\n"
                 "› `/delete user: vps_number: reason:` — Permanently delete a VPS\n"
                 "› `/manage user_id:` — Admin-view any user's VPS control panel\n"
                 "› `/list action:All VPS` — View all VPS instances across every user"),
                ("⚖️  Suspension & Coins",
                 "› `/account admin_action:VPS vps_action:Suspend vps_number: target_user:` — Suspend VPS\n"
                 "› `/account admin_action:VPS vps_action:Unsuspend vps_number: target_user:` — Unsuspend VPS\n"
                 "› `/account admin_action:Coin coin_action:Add target_user: transfer_amount:` — Give coins\n"
                 "› `/account admin_action:Coin coin_action:Remove target_user: transfer_amount:` — Remove coins\n"
                 "› `/giveaway action:Create` — Start a VPS giveaway with timer and auto-deploy"),
                ("⚙️  Configuration",
                 "› `/role action:Add permission: user:` — Assign a staff role to a user\n"
                 "› `/role action:Promote user:` — Promote one tier up\n"
                 "› `/role action:Demote user:` — Demote one tier down\n"
                 "› `/role action:List` — View full staff directory\n"
                 "› `/set setting: value:` — Configure channels, thresholds, and schedules\n"
                 "› `/payment action:Add/Edit payment_name: image:` — Add or update a payment method"),
            ],
        },
        {
            "title": "🌐  Node Management",
            "color": 0x00CED1,
            "fields": [
                ("🖥️  Node Commands",
                 "› `/node pick_one:List` — All registered nodes with host and port\n"
                 "› `/node pick_one:Status option:` — Live CPU / RAM / Disk stats per node\n"
                 "› `/node pick_one:Create name: host: port:` — Register a new remote node\n"
                 "› `/node pick_one:Edit option:id` — Edit node details via modal\n"
                 "› `/node pick_one:Delete option:id` — Remove a node from the cluster\n"
                 "› `/node pick_one:Migrate vps_name: to_node:` — Live-migrate a VPS between nodes"),
                ("📋  System Listings",
                 "› `/system action:List list_runtime:incus` — List all Incus containers\n"
                 "› `/system action:List list_runtime:lxc` — List all LXD containers\n"
                 "› `/system action:List list_node_id:2` — List containers on a specific node\n"
                 "› `/system action:Clean DB` — Remove stale or empty VPS entries from the database"),
            ],
        },
    ],
    "Dev": [
        {
            "title": "💻  Developer Tools",
            "color": 0xEB459E,
            "fields": [
                ("🔧  Diagnostics",
                 "› `/dev action:Config Dump` — Print all runtime config values\n"
                 "› `/dev action:DB Stats` — Row counts for every database table\n"
                 "› `/dev action:Runtime` — Container runtime binary path and version\n"
                 "› `/dev action:Test LXC` — Run `lxc list` live and show the output\n"
                 "› `/dev action:Host Stats` — Live CPU, RAM, and Disk from the host machine"),
                ("🔄  Operations",
                 "› `/dev action:Error Log` — Show the last 20 lines of bot.log\n"
                 "› `/dev action:Reload Cog cog_name:` — Hot-reload a cog without restarting\n"
                 "› `/dev action:Test DM` — Send yourself a test direct message\n"
                 "› `/dev action:Extension State` — Show all extension on/off flags\n"
                 "› `/dev action:Purge Cache` — Reload vps_data and admin_data from disk"),
            ],
        },
    ],
    "Owner": [
        {
            "title": "👑  Owner — System Control",
            "color": 0xFFD700,
            "fields": [
                ("🔌  Extensions",
                 "› `/system action:Extension Toggle extension: ext_state:` — Enable or disable any feature\n"
                 "› `/system action:View Extensions` — See all extension on/off states\n"
                 "› `/system action:Maintenance Mode` — Toggle bot maintenance mode instantly\n"
                 "› `/system action:Clean DB` — Remove stale VPS entries from the database"),
                ("🔐  Security & Coins",
                 "› `/system action:A2FA Management a2fa_action: new_pin:` — Set or remove your admin PIN\n"
                 "› `/system action:MoonCoin Earning mooncoin_action: earning_name: earning_amount:`\n"
                 "  ↳ Add, edit, remove, or list custom coin earning rules\n"
                 "› `/system action:Premium premium_action:Set premium_user: premium_tier:` — Assign premium tier"),
                ("🔌  Available Extensions",
                 "Multi-Node Support · Scheduled Backups · Ticket System\n"
                 "Auto Expire & Suspend · Renewal Reminders · Admin 2FA\n"
                 "Multi-Server Tickets · Backup Limits · Marketplace\n"
                 "Account & MoonCoin · VPS Renewal · VPS Monitoring Alerts\n"
                 "VPS Templates · Multi-language"),
            ],
        },
    ],
}

ROLE_PAGES = {
    "Owner":       ["User", "Mod", "Admin", "Dev", "Owner"],
    "Hard Admin":  ["User", "Mod", "Admin"],
    "Admin":       ["User", "Mod", "Admin"],
    "Manager":     ["User", "Mod", "Admin"],
    "Hard Mod":    ["User", "Mod"],
    "Mod":         ["User", "Mod"],
    "Hard Staff":  ["User"],
    "Staff":       ["User"],
    "Trial Staff": ["User"],
    "Trial Mod":   ["User"],
    "Partner":     ["User"],
    "Dev":         ["User", "Dev", "Admin"],
    "User":        ["User"],
}

TAB_LABELS = {
    "User":  ("🌙 User",   discord.ButtonStyle.primary),
    "Mod":   ("🔨 Mod",    discord.ButtonStyle.success),
    "Admin": ("🛡️ Admin",  discord.ButtonStyle.secondary),
    "Dev":   ("💻 Dev",    discord.ButtonStyle.danger),
    "Owner": ("👑 Owner",  discord.ButtonStyle.primary),
}


class HelpView(discord.ui.View):
    def __init__(self, uid: int, role: str):
        super().__init__(timeout=300)
        self.uid      = uid
        self.role     = role
        self.tabs     = [p for p in ROLE_PAGES.get(role, ["User"]) if p in PAGES]
        self.cur_tab  = 0
        self.cur_page = 0
        self._build()

    def _build(self):
        self.clear_items()

        # Row 0 — tab buttons
        for i, tab in enumerate(self.tabs):
            label, style = TAB_LABELS.get(tab, (tab, discord.ButtonStyle.secondary))
            active = (i == self.cur_tab)
            btn = discord.ui.Button(
                label=label, row=0,
                style=discord.ButtonStyle.primary if active else discord.ButtonStyle.secondary,
                disabled=active,
            )
            _i = i
            async def cb(inter, _idx=_i):
                if inter.user.id != self.uid:
                    return await inter.response.send_message(
                        "This menu belongs to someone else.", ephemeral=True
                    )
                self.cur_tab  = _idx
                self.cur_page = 0
                self._build()
                await inter.response.edit_message(embed=self._embed(), view=self)
            btn.callback = cb
            self.add_item(btn)

        # Row 1 — prev/next within a tab's sub-pages
        pages = PAGES.get(self.tabs[self.cur_tab], []) if self.tabs else []
        if len(pages) > 1:
            prev = discord.ui.Button(
                label="◀ Prev", row=1,
                style=discord.ButtonStyle.secondary,
                disabled=(self.cur_page == 0),
            )
            nxt = discord.ui.Button(
                label="Next ▶", row=1,
                style=discord.ButtonStyle.secondary,
                disabled=(self.cur_page >= len(pages) - 1),
            )

            async def go_prev(inter):
                if inter.user.id != self.uid:
                    return await inter.response.send_message("Not yours.", ephemeral=True)
                self.cur_page = max(0, self.cur_page - 1)
                self._build()
                await inter.response.edit_message(embed=self._embed(), view=self)

            async def go_next(inter):
                if inter.user.id != self.uid:
                    return await inter.response.send_message("Not yours.", ephemeral=True)
                self.cur_page = min(len(pages) - 1, self.cur_page + 1)
                self._build()
                await inter.response.edit_message(embed=self._embed(), view=self)

            prev.callback = go_prev
            nxt.callback  = go_next
            self.add_item(prev)
            self.add_item(nxt)

    def _embed(self) -> discord.Embed:
        if not self.tabs:
            return create_embed("Help", "No pages available.")
        tab   = self.tabs[self.cur_tab]
        pages = PAGES.get(tab, [])
        if not pages:
            return create_embed("Help", "No pages for this tab.")
        page  = pages[min(self.cur_page, len(pages) - 1)]
        total = len(pages)

        embed = discord.Embed(
            title=page["title"],
            color=page["color"],
            timestamp=datetime.now(),
        )
        embed.set_author(name="MoonNodes VPS Manager", icon_url=ICON)
        for name, value in page["fields"]:
            embed.add_field(name=name, value=value[:1024], inline=False)
        sub = f" — Page {self.cur_page + 1}/{total}" if total > 1 else ""
        embed.set_footer(text=f"Role: {self.role}{sub} · MoonNodes VPS Manager")
        return embed


class HelpCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="help", description="Show commands available to your role")
    async def help_cmd(self, interaction: discord.Interaction):
        role = _role(interaction.user.id)
        view = HelpView(interaction.user.id, role)
        await interaction.response.send_message(embed=view._embed(), view=view, ephemeral=True)


async def setup(bot):
    await bot.add_cog(HelpCog(bot))
