"""
/help — Role-based interactive help with tab navigation and pagination.
"""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config   import MAIN_ADMIN_ID
from core.database import admin_data

ICON  = "https://imgur.com/6yfYDTP.png"
COLOR = 0x5865F2

def _role(uid: int) -> str:
    if str(uid) == str(MAIN_ADMIN_ID): return "Owner"
    return admin_data.get(str(uid), "User")


# ── Page definitions ──────────────────────────────────────────────────────────

USER_PAGES = [
    {
        "title": "🌙 MoonNodes — VPS Control",
        "color": 0x5865F2,
        "fields": [
            ("🖥️ Managing Your VPS",
             "> `/list` — All your VPS with live status\n"
             "> `/manage` — Start · Stop · Restart · SSH · Console · Reinstall · Snapshots\n"
             "> `/status` — Live host CPU, RAM & disk per node\n"
             "> `/history vps_name:X` — CPU/RAM history graph (24h, 7d, 30d)\n"
             "> `/support issue:X` — Open a support ticket with staff"),
            ("📦 Getting a VPS",
             "> `/plans plan_type:Free` — Browse free plans (coins / invites)\n"
             "> `/plans plan_type:Premium` — Browse paid plans\n"
             "> `/claim claim_type:Free option:coin code_or_plan:X` — Claim with 🌙 coins\n"
             "> `/claim claim_type:Free option:inv code_or_plan:X` — Claim with invites\n"
             "> `/claim claim_type:Premium code_or_plan:X proof:URL` — Claim paid plan"),
        ],
    },
    {
        "title": "🌙 Account & Marketplace",
        "color": 0xFFD700,
        "fields": [
            ("💰 Account",
             "> `/account options:Balance` — Coin balance + earn history\n"
             "> `/account options:Transfer` — Send 🌙 coins to another user\n"
             "> `/account options:VPS user_action:Share share_action:Add` — Share VPS access\n"
             "> `/account options:Backup backup_action:Create` — Take a snapshot\n"
             "> `/account options:Backup backup_action:List` — View snapshots\n"
             "> `/account options:Backup backup_action:Restore Latest` — Restore latest"),
            ("🛒 Marketplace",
             "> `/marketplace pick_one:Browse` — All active listings\n"
             "> `/marketplace pick_one:Sell` — List your VPS for sale\n"
             "> `/marketplace pick_one:Buy` — Purchase a listing\n"
             "> `/marketplace pick_one:Edit` — Update your listing\n"
             "> `/marketplace pick_one:Remove` — Take your listing down"),
        ],
    },
    {
        "title": "🌙 MoonCoins & Settings",
        "color": 0xFFD700,
        "fields": [
            ("🌙 Earning MoonCoins",
             "> **Chat** — Earn 1 coin per message (5m cooldown)\n"
             "> **Invites** — Earn 5 coins per valid invite\n"
             "> **Giveaways** — Earn 3 coins per entry\n"
             "> **Events** — Earn 7 coins for event participation\n"
             "> `/account options:Balance` — Check your current balance"),
            ("⚙️ Settings",
             "> `/lang language:X` — Set your preferred language (English / Español)\n"
             "> `/status` — View live system and VPS status\n"
             "> `/history` — Browse your VPS resource usage over time"),
        ],
    },
]

STAFF_PAGES = [
    {
        "title": "🌟 Staff Tools",
        "color": 0x57F287,
        "fields": [
            ("🎫 Ticket Management",
             "> `/staff role:Staff action:My Tickets` — Your open tickets\n"
             "> `/staff role:Staff action:All Tickets` — All open ticket channels\n"
             "> `/staff role:Staff action:Close Ticket` — Close + transcript current ticket\n"
             "> `/staff role:Staff action:Claim Ticket` — Assign ticket to yourself"),
            ("👤 User Tools",
             "> `/staff role:Staff action:User Lookup target_user:@X` — Quick user info\n"
             "> `/staff role:Staff action:Add Note target_user:@X message:X` — Add staff note\n"
             "> `/staff role:Staff action:View Notes target_user:@X` — Read staff notes"),
        ],
    },
    {
        "title": "⭐ Hard Staff Tools",
        "color": 0x57F287,
        "fields": [
            ("🔍 Investigations",
             "> `/staff role:Hard Staff action:User Info target_user:@X` — Full user profile\n"
             "> `/staff role:Hard Staff action:VPS Info container:X` — VPS details\n"
             "> `/staff role:Hard Staff action:List VPS target_user:@X` — All VPS for user\n"
             "> `/staff role:Hard Staff action:Suspension Logs` — Recent suspension history"),
            ("⚠️ Actions",
             "> `/staff role:Hard Staff action:Warn User target_user:@X message:reason`\n"
             "> `/staff role:Hard Staff action:Warn Log target_user:@X` — Warning history\n"
             "> `/staff role:Hard Staff action:DM User target_user:@X message:X` — Staff DM\n"
             "> `/staff role:Hard Staff action:Server Stats` — Live container counts"),
        ],
    },
]

ADMIN_PAGES = [
    {
        "title": "🛡️ Admin Tools — VPS Management",
        "color": 0xED4245,
        "fields": [
            ("🖥️ Deploy & Manage VPS",
             "> `/create user:@X plan_name:X` — Deploy VPS from plan\n"
             "> `/create user:@X ram_gb:2 cpu_cores:2 disk_gb:20` — Custom specs\n"
             "> `/create user:@X vm_mode:KVM` — Full virtualisation VM\n"
             "> `/delete container_name:X` — Remove a VPS and its data\n"
             "> `/account admin_action:VPS target_user:@X` — Admin-view user VPS panel"),
            ("⚙️ Bulk Actions",
             "> `/set setting:Channel` — Configure all bot channels in one panel\n"
             "> `/set setting:MoonCoin mooncoin_action:Add value:X option:amount` — Add earn rule\n"
             "> `/set setting:DM Commands command_dm_action:enable` — Allow DM commands\n"
             "> `/set setting:DM Commands command_dm_action:block value:cmd` — Block a command"),
        ],
    },
    {
        "title": "🛡️ Admin Tools — Moderation & System",
        "color": 0xED4245,
        "fields": [
            ("🔨 Moderation",
             "> `/mod action:Suspend container_name:X reason:X` — Suspend VPS\n"
             "> `/mod action:Unsuspend container_name:X` — Reactivate VPS\n"
             "> `/mod action:Mute target_user:@X reason:X` — Mute a user\n"
             "> `/mod action:Unmute target_user:@X` — Unmute a user\n"
             "> `/mod action:Blocklist target_user:@X reason:X` — Block from all commands\n"
             "> `/mod action:Whitelist container_name:X` — Mark VPS as whitelisted"),
            ("🔧 System",
             "> `/system` — Extension manager · toggle features on/off\n"
             "> `/nodes action:Add name:X` — Register a remote node\n"
             "> `/nodes action:List` — All registered nodes + status\n"
             "> `/admin action:List` — All staff roles\n"
             "> `/admin action:Add target_user:@X role:Admin` — Grant staff role"),
        ],
    },
    {
        "title": "🛡️ Admin Tools — MoonCoins & Giveaways",
        "color": 0xED4245,
        "fields": [
            ("🌙 MoonCoins",
             "> `/set setting:MoonCoin mooncoin_action:Grant target_user:@X value:50` — Give coins\n"
             "> `/set setting:MoonCoin mooncoin_action:Deduct target_user:@X value:25` — Remove coins\n"
             "> `/set setting:MoonCoin mooncoin_action:View` — All earn rules\n"
             "> `/set setting:MoonCoin mooncoin_action:Set Cooldown value:X option:seconds`"),
            ("🎉 Giveaways",
             "> `/giveaway action:Start prize:X end:Xh` — Launch a VPS giveaway\n"
             "> `/giveaway action:End` — End giveaway early and draw winner\n"
             "> `/giveaway action:List` — All active giveaways\n"
             "> `/giveaway action:Cancel giveaway_id:X` — Cancel without drawing"),
        ],
    },
]

OWNER_PAGES = [
    {
        "title": "👑 Owner Tools",
        "color": 0xFFD700,
        "fields": [
            ("🔐 Security",
             "> `/af2f` — Manage admin 2FA (enable, generate, verify)\n"
             "> `/set setting:AF2F Channel value:channel_id` — Set 2FA code channel"),
            ("🖥️ Infrastructure",
             "> `/nodes action:Add name:X` — Register remote LXD/Incus node\n"
             "> `/nodes action:Remove name:X` — Remove a node\n"
             "> `/nodes action:List` — All nodes + online status\n"
             "> `/system action:Extension Toggle extension:X` — Enable/disable features"),
        ],
    },
]


def _get_pages(role: str) -> list:
    pages = list(USER_PAGES)
    if role in ("Staff", "Hard Mod", "Mod", "Hard Staff", "Trial Staff", "Trial Mod",
                "Manager", "Admin", "Hard Admin", "Dev", "Owner"):
        pages += STAFF_PAGES
    if role in ("Admin", "Hard Admin", "Dev", "Owner"):
        pages += ADMIN_PAGES
    if role == "Owner":
        pages += OWNER_PAGES
    return pages


# ── Help View ─────────────────────────────────────────────────────────────────

class HelpView(discord.ui.View):
    def __init__(self, uid: int, pages: list):
        super().__init__(timeout=300)
        self.uid   = uid
        self.pages = pages
        self.page  = 0
        self._update_buttons()

    def _update_buttons(self):
        self.prev_btn.disabled = (self.page == 0)
        self.next_btn.disabled = (self.page >= len(self.pages) - 1)
        self.page_btn.label    = f"{self.page + 1} / {len(self.pages)}"

    def _build_embed(self) -> discord.Embed:
        p     = self.pages[self.page]
        embed = discord.Embed(
            title     = p["title"],
            color     = p.get("color", COLOR),
            timestamp = datetime.now(),
        )
        embed.set_author(name="MoonNodes — Help", icon_url=ICON)
        for name, value in p.get("fields", []):
            embed.add_field(name=name, value=value, inline=False)
        embed.set_footer(
            text=f"MoonNodes · Page {self.page + 1}/{len(self.pages)} "
                 f"· Use /support to open a ticket"
        )
        return embed

    async def _check(self, inter: discord.Interaction) -> bool:
        if inter.user.id != self.uid:
            await inter.response.send_message(
                embed=discord.Embed(description="This help panel belongs to someone else.", color=0xED4245),
                ephemeral=True,
            )
            return False
        return True

    @discord.ui.button(label="◀", style=discord.ButtonStyle.secondary, custom_id="help_prev")
    async def prev_btn(self, inter: discord.Interaction, _: discord.ui.Button):
        if not await self._check(inter): return
        self.page -= 1
        self._update_buttons()
        await inter.response.edit_message(embed=self._build_embed(), view=self)

    @discord.ui.button(label="1 / 1", style=discord.ButtonStyle.secondary, custom_id="help_page", disabled=True)
    async def page_btn(self, inter: discord.Interaction, _: discord.ui.Button):
        pass

    @discord.ui.button(label="▶", style=discord.ButtonStyle.secondary, custom_id="help_next")
    async def next_btn(self, inter: discord.Interaction, _: discord.ui.Button):
        if not await self._check(inter): return
        self.page += 1
        self._update_buttons()
        await inter.response.edit_message(embed=self._build_embed(), view=self)


# ── Cog ───────────────────────────────────────────────────────────────────────

class HelpCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="help", description="Browse all commands available to your role")
    async def help_cmd(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        role  = _role(interaction.user.id)
        pages = _get_pages(role)
        view  = HelpView(interaction.user.id, pages)
        await interaction.followup.send(embed=view._build_embed(), view=view, ephemeral=True)


async def setup(bot):
    await bot.add_cog(HelpCog(bot))
