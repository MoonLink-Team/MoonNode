import discord
from discord import app_commands
from discord.ext import commands

from core.config import MAIN_ADMIN_ID
from core.database import admin_data
from core.theme import create_embed, add_field


def is_admin_check(user_id):
    role = admin_data.get(str(user_id))
    return role in ["Owner", "Admin", "Dev"] or str(user_id) == str(MAIN_ADMIN_ID)


class HelpCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="help", description="Show all available commands and how to use them")
    async def help_cmd(self, interaction: discord.Interaction):
        await interaction.response.defer()

        uid      = interaction.user.id
        is_admin = is_admin_check(uid)

        embed = create_embed(
            "📚 MoonNodes — Command Reference",
            "Your all-in-one VPS management assistant.\nAll commands are slash commands — type `/` to get started.",
        )

        # ── User commands ────────────────────────────────────────────────────
        user_cmds = (
            "> 🖥️ `/list` — View all your active VPS instances\n"
            "> 🎛️ `/manage` — Open the VPS control panel\n"
            ">   ↳ Tabs: **My VPS** (your own) · **Shared VPS** (shared with you)\n"
            ">   ↳ Actions: Start · Stop · Reinstall OS · Web SSH · Console · Software Installer\n"
            "> 💾 `/backup action: vps_number:` — Create or restore VPS snapshots\n"
            "> 🤝 `/share` — Grant another user access to your VPS\n"
            "> 💳 `/plans` — Browse Free & Premium plans with pricing\n"
            "> 🚀 `/claim` — Claim a VPS plan or redeem a promo code\n"
            "> 💱 `/transfer` — Sell or gift your VPS to another user\n"
            "> ⬆️ `/upgrade` — Upgrade your plan using credits\n"
            "> 🎫 `/support vps_number: issue:` — Open a support ticket for a specific VPS\n"
            "> 📡 `/status` — View live host node resource stats"
        )
        add_field(embed, "👤 User Commands", user_cmds, False)

        # ── Admin commands ───────────────────────────────────────────────────
        if is_admin:
            admin_cmds = (
                "> 👑 `/role` — Assign or remove staff roles (Owner / Admin / Mod / Dev)\n"
                "> ⚙️ `/set` — Configure channels, thresholds, scheduled backups, backup limits\n"
                "> 💳 `/payment` — Add or remove payment methods shown in `/plans`\n"
                "> 🔨 `/create` — Deploy a new VPS for a user (Node → OS selection)\n"
                "> 🗑️ `/delete` — Permanently delete a VPS container\n"
                "> ⚖️ `/vps` — Suspend or unsuspend a VPS\n"
                "> 🎉 `/giveaway` — Start, cancel, or list VPS giveaways\n"
                "> 📋 `/list-all` — View all VPS across all users and nodes\n"
                "> 👥 `/affiliate` — Manage referral credits (view, transfer, add, remove)\n"
                "> 🌐 **Node Management:**\n"
                ">   `/node list` — List all registered nodes\n"
                ">   `/node status [id]` — Live CPU / RAM / Disk per node\n"
                ">   `/node create name: host: port:` — Register a new LXD remote node\n"
                ">   `/node edit id:` — Edit a node's connection details\n"
                ">   `/node delete id:` — Remove a node from the cluster\n"
                ">   `/node migrate vps_name: to_node:` — Move a VPS to another node\n"
                ">   `/lxc-list [node_id]` — List raw LXC containers on a node\n"
                "> ⚙️ `/system-admin` — Extension toggles, maintenance mode, A2FA, DB clean"
            )
            add_field(embed, "🛡️ Admin / Owner Commands", admin_cmds, False)

        embed.set_footer(text="MoonNodes VPS Manager  •  Use /plans to get started  •  /support for help")
        await interaction.followup.send(embed=embed)


async def setup(bot):
    await bot.add_cog(HelpCog(bot))
