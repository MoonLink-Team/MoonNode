"""
/help — Role-based interactive help. Tabs per role, max 5 per row.
"""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MAIN_ADMIN_ID
from core.database import admin_data

ICON = "https://imgur.com/6yfYDTP.png"

def _role(uid) -> str:
    if str(uid) == str(MAIN_ADMIN_ID): return "Owner"
    return admin_data.get(str(uid), "User")


PAGES = {
    "User": [
        {
            "title": "🌙 MoonNodes — VPS Control",
            "color": 0x5865F2,
            "fields": [
                ("🖥️ VPS Management",
                 "› `/list` — All your VPS + live status\n"
                 "› `/manage` — Start · Stop · Restart · SSH · Console · Reinstall\n"
                 "› `/status` — Host CPU, RAM, Disk stats\n"
                 "› `/account options:VPS user_action:Backup` — Create, list, restore snapshots\n"
                 "› `/account options:VPS user_action:Upgrade` — Extend or upgrade your plan\n"
                 "› `/support vps_number: issue:` — Open a ticket channel with staff"),
                ("📦 Plans & Claiming",
                 "› `/plans plan_type:Free` — Free plans (Coins or Invites)\n"
                 "› `/plans plan_type:Premium` — Paid plans\n"
                 "› `/plans action:🌙 MoonCoin Plans` — Browse coin-only plans\n"
                 "› `/plans action:📨 Invite Plans` — Browse invite-only plans\n"
                 "› `/claim claim_type:Free option:inv code_or_plan:basic` — Claim with invites\n"
                 "› `/claim claim_type:Free option:coin code_or_plan:basic` — Claim with coins\n"
                 "› `/claim claim_type:Premium code_or_plan:starter proof:` — Pay & claim"),
            ],
        },
        {
            "title": "🌙 Account & Marketplace",
            "color": 0xFFD700,
            "fields": [
                ("💰 Account",
                 "› `/account options:Balance` — MoonCoin balance + multipliers\n"
                 "› `/account options:VPS user_action:Share share_action:Add` — Share VPS access\n"
                 "› `/account options:VPS user_action:Share share_action:Remove` — Revoke access\n"
                 "› `/account options:Transfer` — Send coins to another user"),
                ("🛒 Marketplace",
                 "› `/marketplace pick_one:List` — Browse all listings\n"
                 "› `/marketplace pick_one:Sell` — List your VPS for sale\n"
                 "› `/marketplace pick_one:Buy` — Purchase a listing\n"
                 "› `/marketplace pick_one:Dark Market` — Admin listings (buy with coins)"),
                ("🌙 Earning MoonCoins",
                 "› Invite (stayed 7+ days) → **+5 coins**\n"
                 "› Chat in main channel → **+1 coin** *(5 min cooldown)*\n"
                 "› Join giveaway → **+3 coins**\n"
                 "› Join event → **+7 coins**\n"
                 "› VIP role → **+1%** · Server Boost → **+2%** multiplier"),
            ],
        },
    ],
    "Staff": [
        {
            "title": "🌟 Staff Tools",
            "color": 0x57F287,
            "fields": [
                ("🎫 Tickets (All Staff)",
                 "› `/staff role:Staff action:My Tickets` — Your ticket channels\n"
                 "› `/staff role:Staff action:All Tickets` — All open tickets\n"
                 "› `/staff role:Staff action:Close Ticket` — Delete ticket channel\n"
                 "› `/staff role:Staff action:Claim Ticket` — Assign to yourself\n\n"
                 "*Ticket channel buttons:*\n"
                 "› **✅ Claim** · **➕ Add User** · **🔒 Close** · **✔️ Mark Done**"),
                ("👤 User Tools (All Staff)",
                 "› `/staff role:Staff action:User Lookup` — Quick profile + VPS summary\n"
                 "› `/staff role:Staff action:Add Note` — Private staff note\n"
                 "› `/staff role:Staff action:View Notes` — Read staff notes"),
            ],
        },
        {
            "title": "⭐ Hard Staff Tools",
            "color": 0xFFA500,
            "fields": [
                ("🔍 Hard Staff Only",
                 "› `/staff role:Hard Staff action:User Info` — Full profile + coins + warns\n"
                 "› `/staff role:Hard Staff action:VPS Info` — Container lookup\n"
                 "› `/staff role:Hard Staff action:List VPS` — All VPS by user\n"
                 "› `/staff role:Hard Staff action:Server Stats` — Global counts\n"
                 "› `/staff role:Hard Staff action:Open Tickets` — All open tickets\n"
                 "› `/staff role:Hard Staff action:Suspension Logs` — Recent suspensions\n"
                 "› `/staff role:Hard Staff action:DM User` — Send staff DM\n"
                 "› `/staff role:Hard Staff action:Warn User` — Issue a warning\n"
                 "› `/staff role:Hard Staff action:Warn Log` — View warning history"),
            ],
        },
    ],
    "Mod": [
        {
            "title": "⚒️ Mod Tools",
            "color": 0x57F287,
            "fields": [
                ("🔍 Standard Mod",
                 "› `/mod role:Mod action:User Info` — Full user profile\n"
                 "› `/mod role:Mod action:VPS Info` — Container details\n"
                 "› `/mod role:Mod action:List VPS` — All VPS by user\n"
                 "› `/mod role:Mod action:Search VPS` — Find by name\n"
                 "› `/mod role:Mod action:Server Stats` — Global VPS stats\n"
                 "› `/mod role:Mod action:Open Tickets` — All open ticket channels\n"
                 "› `/mod role:Mod action:Suspension Logs` — Recent suspensions\n"
                 "› `/mod role:Mod action:DM User` — Message a user as staff\n"
                 "› `/mod role:Mod action:Warn User` — Issue a formal warning\n"
                 "› `/mod role:Mod action:Warn Log` — View warning history"),
            ],
        },
        {
            "title": "🔱 Hard Mod Tools",
            "color": 0xFF6B35,
            "fields": [
                ("🔑 Hard Mod Only",
                 "› `/mod role:Hard Mod action:Suspend VPS` — Force-suspend a container\n"
                 "› `/mod role:Hard Mod action:Unsuspend VPS` — Re-enable a container\n"
                 "› `/mod role:Hard Mod action:Clear Warnings` — Wipe all warnings for user\n"
                 "› `/mod role:Hard Mod action:Staff Announce` — DM broadcast to all staff\n"
                 "› `/mod role:Hard Mod action:Lock Channel` — Lock a channel\n"
                 "› `/mod role:Hard Mod action:Unlock Channel` — Unlock a channel\n"
                 "› `/mod role:Hard Mod action:Purge` — Delete messages (max 100)"),
            ],
        },
    ],
    "Manager": [
        {
            "title": "💼 Manager Tools",
            "color": 0x9B59B6,
            "fields": [
                ("📋 Manager Access",
                 "› Full Mod + Hard Mod access\n"
                 "› Full Staff + Hard Staff access\n"
                 "› `/role action:Add permission: user:` — Assign staff roles\n"
                 "› `/role action:Promote user:` — Promote one tier up\n"
                 "› `/role action:Demote user:` — Demote one tier down\n"
                 "› `/role action:List` — View full staff directory\n"
                 "› `/set` — Configure channels and thresholds\n"
                 "› `/payment` — Manage payment methods"),
                ("🛡️ VPS Management",
                 "› `/create user: plan_name:` — Deploy VPS for any user\n"
                 "› `/delete user: vps_number:` — Permanently delete a VPS\n"
                 "› `/manage user_id:` — Admin-view any user's VPS panel\n"
                 "› `/list action:All VPS` — View all VPS across all users\n"
                 "› `/set setting:MoonCoin` — Manage MoonCoin rules & balances\n"
                 "› `/mod role::trident: action:Suspend/Expire` — VPS moderation"),
            ],
        },
    ],
    "Admin": [
        {
            "title": "🛡️ Admin — VPS Management",
            "color": 0x5865F2,
            "fields": [
                ("🔧 Create & Delete",
                 "› `/create user: plan_name: plan_type:` — Deploy VPS (node → OS)\n"
                 "› `/delete user: vps_number: reason:` — Permanently delete a VPS\n"
                 "› `/manage user_id:` — Admin-view any user's VPS panel\n"
                 "› `/list action:All VPS` — All VPS across every user"),
                ("⚖️ Coins & Suspension",
                 "› `/set setting:MoonCoin mooncoin_action:Grant` — Give coins to user\n"
                 "› `/set setting:MoonCoin mooncoin_action:Deduct` — Remove coins from user\n"
                 "› `/mod role::trident: action:Suspend VPS` — Suspend VPS (AF2F required)\n"
                 "› `/mod role::trident: action:Unsuspend VPS` — Unsuspend VPS (AF2F required)\n"
                 "› `/mod role::trident: action:Expire` — Set/edit VPS expiry (AF2F required)\n"
                 "› `/giveaway action:Create` — Start a VPS giveaway"),
                ("🌐 Node Management",
                 "› `/node pick_one:List` — All nodes + ping + stats\n"
                 "› `/node pick_one:Status` — Live stats per node\n"
                 "› `/node pick_one:Create name: runtime: api_key:` — Register node\n"
                 "› `/node pick_one:Edit` — Edit node details\n"
                 "› `/node pick_one:Delete` — Remove a node\n"
                 "› `/node pick_one:Migrate vps_name: to_node:` — Move VPS"),
            ],
        },
        {
            "title": "⚙️ Admin — Config",
            "color": 0x00CED1,
            "fields": [
                ("📋 Settings",
                 "› `/set setting:Log Channel` — Set log channel\n"
                 "› `/set setting:Ticket Category` — Set ticket category ID\n"
                 "› `/set setting:Payment Channel` — Set payment channel\n"
                 "› `/set setting:Update Channel` — Set update/announce channel\n"
                 "› `/set setting:Claim Channel` — Set free claim channel\n"
                 "› `/set setting:Main Chat Channel` — Set coin-earning chat channel\n"
"› `/payment` — Add/remove payment method images"),
                ("📊 System Listings",
                 "› `/system action:List list_runtime:incus` — All Incus containers\n"
                 "› `/system action:List list_runtime:lxc` — All LXC containers\n"
                 "› `/system action:Clean DB` — Remove stale VPS entries"),
            ],
        },
    ],
    "Dev": [
        {
            "title": "💻 Developer Tools",
            "color": 0xEB459E,
            "fields": [
                ("🔧 Diagnostics",
                 "› `/dev action:Config Dump` — All runtime config values\n"
                 "› `/dev action:DB Stats` — Row counts per table\n"
                 "› `/dev action:Runtime` — Active runtime binary + version\n"
                 "› `/dev action:Test LXC` — Run `lxc list` live\n"
                 "› `/dev action:Host Stats` — Live host CPU, RAM, Disk"),
                ("🔄 Operations",
                 "› `/dev action:Error Log` — Last 20 lines of bot.log\n"
                 "› `/dev action:Reload Cog cog_name:` — Hot-reload a cog\n"
                 "› `/dev action:Test DM` — Send yourself a test DM\n"
                 "› `/dev action:Extension State` — All extension on/off flags\n"
                 "› `/dev action:Purge Cache` — Reload data from disk"),
            ],
        },
    ],
    "Owner": [
        {
            "title": "👑 Owner — System Control",
            "color": 0xFFD700,
            "fields": [
                ("🔌 Extensions",
                 "› `/system action:Extension Toggle extension: ext_state:` — Toggle features\n"
                 "› `/system action:View Extensions` — All on/off states\n"
                 "› `/system action:Maintenance Mode` — Toggle maintenance + notify update channel\n"
                 "› `/system action:Clean DB` — Remove stale VPS entries"),
                ("🔐 Security & Economy",
                 "› `/system action:A2FA Management` — Set/remove admin PIN\n"
                 "› `/system action:MoonCoin Earning` — Add/edit/remove coin rules\n"
                 "› `/system action:Premium` — Assign premium tiers"),
                ("💾 Database & Updates",
                 "› `/system action:Database` — Install from backup or delete DB\n"
                 "› `/system action:Update Bot` — Pull latest from GitHub + unzip\n\n"
                 "**Available Extensions:**\n"
                 "Scheduled Backups · Ticket System · Auto Expire & Suspend\n"
                 "Renewal Reminders · **Bot 2FA** · Backup Limits · Marketplace\n"
                 "Account & MoonCoin · VPS Monitoring Alerts · **DM Commands**"),
            ],
        },
    ],
}

ROLE_TABS = {
    "Owner":       ["User", "Staff", "Mod", "Manager", "Admin", "Dev", "Owner"],
    "Hard Admin":  ["User", "Staff", "Mod", "Manager", "Admin"],
    "Admin":       ["User", "Staff", "Mod", "Admin"],
    "Manager":     ["User", "Staff", "Mod", "Manager"],
    "Hard Mod":    ["User", "Staff", "Mod"],
    "Mod":         ["User", "Staff", "Mod"],
    "Hard Staff":  ["User", "Staff"],
    "Staff":       ["User", "Staff"],
    "Trial Staff": ["User", "Staff"],
    "Trial Mod":   ["User", "Staff"],
    "Partner":     ["User"],
    "Dev":         ["User", "Dev", "Admin"],
    "User":        ["User"],
}

TAB_LABELS = {
    "User":    ("🌙 User",     discord.ButtonStyle.primary),
    "Staff":   ("🌟 Staff",    discord.ButtonStyle.success),
    "Mod":     ("⚒️ Mod",      discord.ButtonStyle.secondary),
    "Manager": ("💼 Manager",  discord.ButtonStyle.secondary),
    "Admin":   ("🛡️ Admin",   discord.ButtonStyle.secondary),
    "Dev":     ("💻 Dev",      discord.ButtonStyle.danger),
    "Owner":   ("👑 Owner",    discord.ButtonStyle.primary),
}


class HelpView(discord.ui.View):
    def __init__(self, uid: int, role: str):
        super().__init__(timeout=300)
        self.uid      = uid
        self.role     = role
        self.tabs     = [t for t in ROLE_TABS.get(role, ["User"]) if t in PAGES]
        self.cur_tab  = 0
        self.cur_page = 0
        self._build()

    def _build(self):
        self.clear_items()
        # Max 5 per row — row 0 = first 5 tabs, row 1 = overflow tabs, row 2 = nav
        for i, tab in enumerate(self.tabs):
            label, _ = TAB_LABELS.get(tab, (tab, discord.ButtonStyle.secondary))
            active   = (i == self.cur_tab)
            row      = 0 if i < 5 else 1
            btn = discord.ui.Button(
                label=label, row=row,
                style=discord.ButtonStyle.primary if active else discord.ButtonStyle.secondary,
                disabled=active,
            )
            _i = i
            async def cb(inter, _idx=_i):
                if inter.user.id != self.uid:
                    return await inter.response.send_message("This menu belongs to someone else.", ephemeral=True)
                self.cur_tab  = _idx
                self.cur_page = 0
                self._build()
                await inter.response.edit_message(embed=self._embed(), view=self)
            btn.callback = cb
            self.add_item(btn)

        pages   = PAGES.get(self.tabs[self.cur_tab], []) if self.tabs else []
        nav_row = 2
        if len(pages) > 1:
            prev = discord.ui.Button(label="◀ Prev", row=nav_row, style=discord.ButtonStyle.secondary,
                                     disabled=(self.cur_page == 0))
            nxt  = discord.ui.Button(label="Next ▶", row=nav_row, style=discord.ButtonStyle.secondary,
                                     disabled=(self.cur_page >= len(pages) - 1))
            async def go_prev(inter):
                if inter.user.id != self.uid: return await inter.response.send_message("Not yours.", ephemeral=True)
                self.cur_page = max(0, self.cur_page - 1); self._build()
                await inter.response.edit_message(embed=self._embed(), view=self)
            async def go_next(inter):
                if inter.user.id != self.uid: return await inter.response.send_message("Not yours.", ephemeral=True)
                self.cur_page = min(len(pages) - 1, self.cur_page + 1); self._build()
                await inter.response.edit_message(embed=self._embed(), view=self)
            prev.callback = go_prev; nxt.callback = go_next
            self.add_item(prev); self.add_item(nxt)

    def _embed(self) -> discord.Embed:
        if not self.tabs: return discord.Embed(title="Help", description="No pages available.", color=0x5865F2)
        tab   = self.tabs[self.cur_tab]
        pages = PAGES.get(tab, [])
        if not pages: return discord.Embed(title="Help", description="No pages.", color=0x5865F2)
        page  = pages[min(self.cur_page, len(pages) - 1)]
        total = len(pages)
        embed = discord.Embed(title=page["title"], color=page["color"], timestamp=datetime.now())
        embed.set_author(name="MoonNodes VPS Manager", icon_url=ICON)
        for name, value in page["fields"]:
            embed.add_field(name=name, value=value[:1024], inline=False)
        sub = f" — Page {self.cur_page + 1}/{total}" if total > 1 else ""
        embed.set_footer(text=f"Role: {self.role}{sub} · MoonNodes")
        return embed


class HelpCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="help", description="Show commands available to your role")
    async def help_cmd(self, interaction: discord.Interaction):
        role = _role(interaction.user.id)
        view = HelpView(interaction.user.id, role)
        await interaction.response.send_message(embed=view._embed(), view=view, ephemeral=True)


async def setup(bot):
    await bot.add_cog(HelpCog(bot))
