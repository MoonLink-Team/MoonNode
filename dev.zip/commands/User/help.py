"""
/help — Role-based interactive help. Tabs and pages depend on the user's role.
"""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MAIN_ADMIN_ID
from core.database import admin_data

ICON = "https://imgur.com/6yfYDTP.png"

def _role(uid) -> str:
    if str(uid) == str(MAIN_ADMIN_ID): return "Owner"
    return admin_data.get(str(uid), "User")


PAGES = {
    "User": [
        {
            "title": "🌙  MoonNodes — VPS Control",
            "color": 0x5865F2,
            "fields": [
                ("🖥️  VPS Management",
                 "› `/list` — View all your VPS and their live status\n"
                 "› `/manage` — Control panel: **Start · Stop · Restart · SSH · Console · Reinstall**\n"
                 "  ↳ Switch between **My VPS** and **Shared VPS** tabs\n"
                 "› `/status` — Live CPU, RAM, and Disk stats for the host\n"
                 "› `/backup vps_number:` — Create, restore, list, or delete snapshots"),
                ("📦  Plans & Claiming",
                 "› `/plans plan_type:Free` — Browse free plans (pay with Invites or Coins)\n"
                 "› `/plans plan_type:Premium` — Browse paid plans with pricing\n"
                 "› `/claim claim_type:Free option:inv code_or_plan:basic` — Claim with invites\n"
                 "› `/claim claim_type:Free option:coin code_or_plan:basic` — Claim with coins\n"
                 "› `/claim claim_type:Premium code_or_plan:starter proof:` — Submit payment proof\n"
                 "› `/upgrade` — Upgrade or extend your current VPS plan"),
            ],
        },
        {
            "title": "🌙  Account & Marketplace",
            "color": 0xFFD700,
            "fields": [
                ("💰  Account",
                 "› `/account options:Balance` — View your MoonCoin balance and multipliers\n"
                 "› `/account options:VPS user_action:Share share_action:Add vps_number:` — Share VPS access\n"
                 "› `/account options:VPS user_action:Share share_action:Remove vps_number:` — Revoke access\n"
                 "› `/account options:VPS user_action:Backup backup_action:Create vps_number:` — Create backup\n"
                 "› `/support vps_number: issue:` — Open a private support ticket"),
                ("🛒  Marketplace",
                 "› `/marketplace pick_one:List` — Browse all VPS listings\n"
                 "› `/marketplace pick_one:Sell vps_number: price: price_type:` — List your VPS\n"
                 "› `/marketplace pick_one:Buy sell_name: user:` — Buy a listing\n"
                 "› `/marketplace pick_one:Edit sell_name:` — Edit your listing\n"
                 "› `/marketplace pick_one:Remove sell_name:` — Remove your listing\n"
                 "› `/marketplace pick_one:Dark Market` — Admin listings (buy only)"),
                ("🌙  Earning MoonCoins",
                 "› Invite someone → **+5 coins** *(must stay 7 days to count)*\n"
                 "› Chat in main channel → **+1 coin** *(5 min cooldown)*\n"
                 "› Join a giveaway → **+3 coins**\n"
                 "› Join an event → **+7 coins**\n"
                 "› VIP role → **+1% multiplier** · Server Boost → **+2% multiplier**"),
            ],
        },
    ],
    "Staff": [
        {
            "title": "🌟  Staff Tools",
            "color": 0x57F287,
            "fields": [
                ("🎫  Tickets",
                 "› `/staff action:My Tickets` — Your assigned support threads\n"
                 "› `/staff action:All Tickets` — All open support threads\n"
                 "› `/staff action:Close Ticket` — Archive and lock a ticket thread\n"
                 "› `/staff action:Claim Ticket` — Assign a ticket to yourself\n\n"
                 "*Inside a ticket thread, use the buttons:*\n"
                 "› **✅ Claim** — Assign to yourself\n"
                 "› **➕ Add User** — Add another user to the thread\n"
                 "› **🔒 Close** — Archive and lock\n"
                 "› **✔️ Mark Done** — Flag as resolved"),
                ("👤  User Tools",
                 "› `/staff action:User Lookup` — Quick profile and VPS summary\n"
                 "› `/staff action:Add Note` — Add a private staff note to a user\n"
                 "› `/staff action:View Notes` — Read staff notes for a user"),
            ],
        },
    ],
    "HardStaff": [
        {
            "title": "⭐  Hard Staff — Extended Access",
            "color": 0xFFA500,
            "fields": [
                ("🔍  Lookups",
                 "› `/hardstaff action:User Info target_user:` — Full user profile\n"
                 "› `/hardstaff action:VPS Info container_name:` — Detailed container info\n"
                 "› `/hardstaff action:List VPS target_user:` — All VPS by user\n"
                 "› `/hardstaff action:Server Stats` — Global VPS counts and usage"),
                ("📋  Management",
                 "› `/hardstaff action:Warn User target_user: message:` — Issue a formal warning\n"
                 "› `/hardstaff action:Warn Log target_user:` — View warning history\n"
                 "› `/hardstaff action:DM User target_user: message:` — Send a staff DM\n"
                 "› `/hardstaff action:Suspension Logs` — Recent VPS suspension history\n"
                 "› `/hardstaff action:Open Tickets` — All open ticket threads"),
            ],
        },
    ],
    "Mod": [
        {
            "title": "🔨  Moderation Tools",
            "color": 0x57F287,
            "fields": [
                ("🔍  Lookups & Search",
                 "› `/mod action:User Info target_user:` — Full user profile\n"
                 "› `/mod action:VPS Info container_name:` — Container info\n"
                 "› `/mod action:List VPS target_user:` — All VPS by user\n"
                 "› `/mod action:Search container_name:` — Find a container\n"
                 "› `/mod action:Server Stats` — Global VPS stats"),
                ("⚠️  Moderation",
                 "› `/mod action:Open Tickets` — All open support threads\n"
                 "› `/mod action:Suspension Logs` — VPS suspension history\n"
                 "› `/mod action:DM User target_user: message:` — Message a user as staff\n"
                 "› `/mod action:Warn User target_user: message:` — Issue a warning\n"
                 "› `/mod action:Warn Log target_user:` — View warning history"),
            ],
        },
        {
            "title": "🔱  Hard Mod — Senior Mod Tools",
            "color": 0xFF6B35,
            "fields": [
                ("🔑  Hard Mod Only",
                 "› `/hardmod action:Suspend VPS vps_number: target_user:` — Force suspend a VPS\n"
                 "› `/hardmod action:Unsuspend VPS vps_number: target_user:` — Unsuspend a VPS\n"
                 "› `/hardmod action:Clear Warnings target_user:` — Clear all warnings for a user\n"
                 "› `/hardmod action:Staff Announce message:` — DM broadcast to all staff\n"
                 "› `/hardmod action:Lock Channel channel:` — Lock a channel\n"
                 "› `/hardmod action:Unlock Channel channel:` — Unlock a channel\n"
                 "› `/hardmod action:Purge count: channel:` — Delete messages"),
            ],
        },
    ],
    "Admin": [
        {
            "title": "🛡️  Admin — VPS Management",
            "color": 0x5865F2,
            "fields": [
                ("🔧  Create & Delete",
                 "› `/create user: plan_name: plan_type:` — Deploy a VPS (node → OS select)\n"
                 "› `/delete user: vps_number: reason:` — Permanently delete a VPS\n"
                 "› `/manage user_id:` — Admin-view any user's VPS panel\n"
                 "› `/list action:All VPS` — View all VPS across every user"),
                ("⚖️  Coins & Suspension",
                 "› `/account admin_action:VPS vps_action:Suspend` — Suspend a VPS\n"
                 "› `/account admin_action:VPS vps_action:Unsuspend` — Unsuspend a VPS\n"
                 "› `/account admin_action:Coin coin_action:Add target_user: transfer_amount:` — Give coins\n"
                 "› `/account admin_action:Coin coin_action:Remove target_user: transfer_amount:` — Remove coins\n"
                 "› `/giveaway action:Create` — Start a VPS giveaway"),
                ("⚙️  Config & Nodes",
                 "› `/role action:Add permission: user:` — Assign staff role\n"
                 "› `/role action:List` — View full staff directory\n"
                 "› `/set setting: value:` — Configure channels and thresholds\n"
                 "› `/payment action:Add/Edit payment_name: image:` — Add payment method\n"
                 "› `/node pick_one:List` — View all registered nodes\n"
                 "› `/node pick_one:Status` — Live node stats\n"
                 "› `/node pick_one:Create name: runtime: api_key:` — Register new node\n"
                 "› `/node pick_one:Migrate vps_name: to_node:` — Move VPS between nodes"),
            ],
        },
    ],
    "Dev": [
        {
            "title": "💻  Developer Tools",
            "color": 0xEB459E,
            "fields": [
                ("🔧  Diagnostics",
                 "› `/dev action:Config Dump` — Print all runtime config values\n"
                 "› `/dev action:DB Stats` — Row counts per database table\n"
                 "› `/dev action:Runtime` — Active runtime binary + version\n"
                 "› `/dev action:Test LXC` — Run `lxc list` and show output\n"
                 "› `/dev action:Host Stats` — Live host CPU, RAM, Disk"),
                ("🔄  Operations",
                 "› `/dev action:Error Log` — Last 20 lines of bot.log\n"
                 "› `/dev action:Reload Cog cog_name:` — Hot-reload a cog\n"
                 "› `/dev action:Test DM` — Send yourself a test DM\n"
                 "› `/dev action:Extension State` — Show all extension on/off flags\n"
                 "› `/dev action:Purge Cache` — Reload data from disk"),
            ],
        },
    ],
    "Owner": [
        {
            "title": "👑  Owner — System Control",
            "color": 0xFFD700,
            "fields": [
                ("🔌  Extensions",
                 "› `/system action:Extension Toggle extension: ext_state:` — Enable/disable features\n"
                 "› `/system action:View Extensions` — See all extension states\n"
                 "› `/system action:Maintenance Mode` — Toggle maintenance mode\n"
                 "› `/system action:Clean DB` — Remove stale VPS entries"),
                ("🔐  Security & Economy",
                 "› `/system action:A2FA Management a2fa_action: new_pin:` — Set admin PIN\n"
                 "› `/system action:MoonCoin Earning` — Manage coin earning rules\n"
                 "› `/system action:Premium premium_action:Set premium_user: premium_tier:` — Assign premium"),
                ("🔌  Available Extensions",
                 "Multi-Node · Scheduled Backups · Ticket System · Auto Expire\n"
                 "Renewal Reminders · Admin 2FA · Multi-Server Tickets\n"
                 "Backup Limits · Marketplace · Account & MoonCoin\n"
                 "VPS Renewal · VPS Monitoring · VPS Templates"),
            ],
        },
    ],
}

# Which tab groups each role sees
ROLE_TABS = {
    "Owner":       ["User", "Staff", "HardStaff", "Mod", "Admin", "Dev", "Owner"],
    "Hard Admin":  ["User", "Staff", "HardStaff", "Mod", "Admin"],
    "Admin":       ["User", "Staff", "HardStaff", "Mod", "Admin"],
    "Manager":     ["User", "Staff", "HardStaff", "Mod", "Admin"],
    "Hard Mod":    ["User", "Staff", "HardStaff", "Mod"],
    "Mod":         ["User", "Staff", "HardStaff", "Mod"],
    "Hard Staff":  ["User", "Staff", "HardStaff"],
    "Staff":       ["User", "Staff"],
    "Trial Staff": ["User", "Staff"],
    "Trial Mod":   ["User", "Staff"],
    "Partner":     ["User"],
    "Dev":         ["User", "Dev", "Admin"],
    "User":        ["User"],
}

TAB_LABELS = {
    "User":      ("🌙 User",        discord.ButtonStyle.primary),
    "Staff":     ("🌟 Staff",       discord.ButtonStyle.success),
    "HardStaff": ("⭐ Hard Staff",  discord.ButtonStyle.success),
    "Mod":       ("🔨 Mod",         discord.ButtonStyle.secondary),
    "Admin":     ("🛡️ Admin",       discord.ButtonStyle.secondary),
    "Dev":       ("💻 Dev",         discord.ButtonStyle.danger),
    "Owner":     ("👑 Owner",       discord.ButtonStyle.primary),
}


class HelpView(discord.ui.View):
    def __init__(self, uid: int, role: str):
        super().__init__(timeout=300)
        self.uid      = uid
        self.role     = role
        self.tabs     = [t for t in ROLE_TABS.get(role, ["User"]) if t in PAGES]
        self.cur_tab  = 0
        self.cur_page = 0
        self._build()

    def _build(self):
        self.clear_items()
        for i, tab in enumerate(self.tabs):
            label, _ = TAB_LABELS.get(tab, (tab, discord.ButtonStyle.secondary))
            active = (i == self.cur_tab)
            btn = discord.ui.Button(
                label=label, row=0,
                style=discord.ButtonStyle.primary if active else discord.ButtonStyle.secondary,
                disabled=active,
            )
            _i = i
            async def cb(inter, _idx=_i):
                if inter.user.id != self.uid:
                    return await inter.response.send_message("This menu belongs to someone else.", ephemeral=True)
                self.cur_tab  = _idx
                self.cur_page = 0
                self._build()
                await inter.response.edit_message(embed=self._embed(), view=self)
            btn.callback = cb
            self.add_item(btn)

        pages = PAGES.get(self.tabs[self.cur_tab], []) if self.tabs else []
        if len(pages) > 1:
            prev = discord.ui.Button(label="◀ Prev", row=1, style=discord.ButtonStyle.secondary,
                                      disabled=(self.cur_page == 0))
            nxt  = discord.ui.Button(label="Next ▶", row=1, style=discord.ButtonStyle.secondary,
                                      disabled=(self.cur_page >= len(pages) - 1))
            async def go_prev(inter):
                if inter.user.id != self.uid: return await inter.response.send_message("Not yours.", ephemeral=True)
                self.cur_page = max(0, self.cur_page - 1); self._build()
                await inter.response.edit_message(embed=self._embed(), view=self)
            async def go_next(inter):
                if inter.user.id != self.uid: return await inter.response.send_message("Not yours.", ephemeral=True)
                self.cur_page = min(len(pages) - 1, self.cur_page + 1); self._build()
                await inter.response.edit_message(embed=self._embed(), view=self)
            prev.callback = go_prev; nxt.callback = go_next
            self.add_item(prev); self.add_item(nxt)

    def _embed(self) -> discord.Embed:
        if not self.tabs: return discord.Embed(title="Help", description="No pages available.", color=0x5865F2)
        tab   = self.tabs[self.cur_tab]
        pages = PAGES.get(tab, [])
        if not pages: return discord.Embed(title="Help", description="No pages.", color=0x5865F2)
        page  = pages[min(self.cur_page, len(pages) - 1)]
        total = len(pages)
        embed = discord.Embed(title=page["title"], color=page["color"], timestamp=datetime.now())
        embed.set_author(name="MoonNodes VPS Manager", icon_url=ICON)
        for name, value in page["fields"]:
            embed.add_field(name=name, value=value[:1024], inline=False)
        sub = f" — Page {self.cur_page + 1}/{total}" if total > 1 else ""
        embed.set_footer(text=f"Role: {self.role}{sub} · MoonNodes")
        return embed


class HelpCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="help", description="Show commands available to your role")
    async def help_cmd(self, interaction: discord.Interaction):
        role = _role(interaction.user.id)
        view = HelpView(interaction.user.id, role)
        await interaction.response.send_message(embed=view._embed(), view=view, ephemeral=True)


async def setup(bot):
    await bot.add_cog(HelpCog(bot))
