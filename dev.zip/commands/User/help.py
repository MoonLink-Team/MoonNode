import discord
from discord import app_commands
from discord.ext import commands

from core.config import MAIN_ADMIN_ID
from core.database import admin_data
from core.theme import create_embed, add_field, Theme


def is_admin_check(user_id):
    role = admin_data.get(str(user_id))
    return role in ["Owner", "Admin", "Dev"] or str(user_id) == str(MAIN_ADMIN_ID)


class HelpView(discord.ui.View):
    PAGES = ["user", "vps_mgmt", "admin", "node"]

    USER_FIELDS = [
        ("👤 General", (
            "`/help` — Show this menu\n"
            "`/list` — Your active VPS instances\n"
            "`/status` — Live host node stats\n"
            "`/plans` — Browse Free & Premium plans"
        )),
        ("🎛️ VPS Control", (
            "`/manage` — Open VPS control panel\n"
            "  ↳ **My VPS** tab: Start · Stop · Reinstall · SSH · Console · Software\n"
            "  ↳ **Shared VPS** tab: Manage VPS others shared with you"
        )),
        ("💾 VPS Actions", (
            "`/backup action: vps_number:` — Snapshot / restore\n"
            "`/share` — Share VPS access with another user\n"
            "`/upgrade` — Upgrade your plan\n"
            "`/claim claim_type: option: code_or_plan:` — Claim Free/Premium VPS\n"
            "`/support vps_number: issue:` — Open a support ticket"
        )),
    ]

    VPS_MGMT_FIELDS = [
        ("🛠️ Admin VPS", (
            "`/create user: plan_name: plan_type:` — Deploy VPS (Node → OS select)\n"
            "`/delete user: vps_number: reason:` — Delete a VPS\n"
            "`/vps action: container_name:` — Suspend / Unsuspend\n"
            "`/list-all` — View all VPS across all users & nodes\n"
            "`/manage user:@user` — Manage any user's VPS"
        )),
        ("⚙️ Config & Staff", (
            "`/role action: permission: user:` — Assign / remove staff roles\n"
            "`/set setting: value:` — Configure channels, thresholds, schedules\n"
            "`/payment action: payment_name:` — Manage payment methods\n"
            "`/giveaway action:` — Start / cancel / list giveaways\n"
            "`/system-admin action:` — Extensions, A2FA, DB clean, maintenance"
        )),
        ("🛒 Marketplace", (
            "`/marketplace pick_one:List` — Browse VPS listings\n"
            "`/marketplace pick_one:Sell vps_number: price:` — List your VPS\n"
            "`/marketplace pick_one:Buy sell_name: user:` — Purchase a listing\n"
            "`/marketplace pick_one:Edit sell_name:` — Edit your listing\n"
            "`/marketplace pick_one:Remove sell_name:` — Remove listing\n"
            "`/marketplace pick_one:Payment` — Manage marketplace payment methods"
        )),
        ("🌙 Account", (
            "`/account` — View MoonCoin balance & stats\n"
            "`/account target_user:` — View another user's account\n"
            "`/account admin_action: transfer_amount:` — Admin: add/remove coins"
        )),
    ]

    ADMIN_FIELDS = [
        ("🔧 /set Settings", (
            "`Log Channel` / `Payment Channel` / `Ticket Channel`\n"
            "`CPU Threshold %` / `RAM Threshold %`\n"
            "`Backup Limits` — value + option + date + time\n"
            "`Scheduled Backups` — value + option + date + time\n"
            "`marketplace` — Enable/disable marketplace"
        )),
        ("🔌 Extensions", (
            "Toggle via `/system-admin action:Extension Toggle`\n"
            "• **Multi-Node Support** — LXD cluster\n"
            "• **Scheduled Backups** — Auto snapshots daily\n"
            "• **Ticket System** — Private support threads\n"
            "• **Auto Expire & Suspend** — Auto-stop on expiry\n"
            "• **Renewal Reminders** — DM 3 days before expiry\n"
            "• **Admin 2FA** — PIN for admin actions\n"
            "• **Backup Limits** — Cap snapshots per VPS"
        )),
    ]

    NODE_FIELDS = [
        ("🌐 Node Commands", (
            "`/node list` — List all registered nodes\n"
            "`/node status [id]` — Live CPU/RAM/Disk per node\n"
            "`/node create name: host: port:` — Register new node\n"
            "`/node edit id:` — Edit node connection details\n"
            "`/node delete id:` — Remove a node\n"
            "`/node migrate vps_name: to_node:` — Move VPS between nodes\n"
            "`/lxc-list [node_id]` — Raw LXC container list"
        )),
        ("💡 MoonCoin Earning", (
            "• Invite someone → **+5 coins**\n"
            "• Chat in main channel → **+1 coin** (5 min cooldown)\n"
            "• Join a giveaway → **+3 coins**\n"
            "• Join an event → **+7 coins**\n"
            "• Have VIP role → **+1% coin multiplier**\n"
            "• Boost server (1st time) → **+2% multiplier**\n"
            "• Boost server (2nd time) → **+3% multiplier**"
        )),
    ]

    def __init__(self, interaction: discord.Interaction, is_admin: bool):
        super().__init__(timeout=300)
        self.interaction = interaction
        self.is_admin    = is_admin
        self.page        = "user"

    def _make_embed(self) -> discord.Embed:
        page_titles = {
            "user":     "👤 User Commands",
            "vps_mgmt": "🛡️ Admin & Features",
            "admin":    "⚙️ Settings & Extensions",
            "node":     "🌐 Nodes & MoonCoin",
        }
        embed = create_embed(
            f"📚 MoonNodes — {page_titles[self.page]}",
            "Type `/` in any channel to use a command.",
            color=Theme.PRIMARY,
        )
        fields = {
            "user":     self.USER_FIELDS,
            "vps_mgmt": self.VPS_MGMT_FIELDS if self.is_admin else self.VPS_MGMT_FIELDS[:1],
            "admin":    self.ADMIN_FIELDS,
            "node":     self.NODE_FIELDS,
        }[self.page]

        for name, value in fields:
            add_field(embed, name, value, inline=False)

        pages = ["user", "vps_mgmt", "admin", "node"] if self.is_admin else ["user", "node"]
        idx   = pages.index(self.page) + 1
        embed.set_footer(text=f"Page {idx}/{len(pages)} — MoonNodes VPS Manager")
        return embed

    @discord.ui.button(label="👤 User", style=discord.ButtonStyle.primary,  row=0)
    async def btn_user(self, interaction: discord.Interaction, _):
        self.page = "user"
        await interaction.response.edit_message(embed=self._make_embed(), view=self)

    @discord.ui.button(label="🛡️ Admin", style=discord.ButtonStyle.secondary, row=0)
    async def btn_admin(self, interaction: discord.Interaction, _):
        if not self.is_admin:
            return await interaction.response.send_message("Admin only.", ephemeral=True)
        self.page = "vps_mgmt"
        await interaction.response.edit_message(embed=self._make_embed(), view=self)

    @discord.ui.button(label="⚙️ Settings", style=discord.ButtonStyle.secondary, row=0)
    async def btn_settings(self, interaction: discord.Interaction, _):
        if not self.is_admin:
            return await interaction.response.send_message("Admin only.", ephemeral=True)
        self.page = "admin"
        await interaction.response.edit_message(embed=self._make_embed(), view=self)

    @discord.ui.button(label="🌐 Node", style=discord.ButtonStyle.secondary, row=0)
    async def btn_node(self, interaction: discord.Interaction, _):
        self.page = "node"
        await interaction.response.edit_message(embed=self._make_embed(), view=self)


class HelpCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="help", description="Show all available commands and how to use them")
    async def help_cmd(self, interaction: discord.Interaction):
        is_admin = is_admin_check(interaction.user.id)
        view     = HelpView(interaction, is_admin)
        await interaction.response.send_message(embed=view._make_embed(), view=view)


async def setup(bot):
    await bot.add_cog(HelpCog(bot))
