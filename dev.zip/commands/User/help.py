"""
/help — Role-based interactive help. Tabs per role, paginated.
"""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MAIN_ADMIN_ID
from core.database import admin_data

ICON = "https://imgur.com/6yfYDTP.png"

def _role(uid) -> str:
    if str(uid) == str(MAIN_ADMIN_ID): return "Owner"
    return admin_data.get(str(uid), "User")


PAGES = {
    "User": [
        {
            "title": "🌙 MoonNodes — VPS Control",
            "color": 0x5865F2,
            "fields": [
                ("🖥️ Managing Your VPS",
                 "› `/list` — See all your VPS with live status\n"
                 "› `/manage` — Full control: Start · Stop · Restart · SSH · Console · Reinstall · Backups\n"
                 "› `/status` — Live host CPU, RAM and Disk usage\n"
                 "› `/support vps_number: issue:` — Open a staff support ticket"),
                ("📦 Plans & Claiming",
                 "› `/plans plan_type:Free` — Browse free plans (coins or invites)\n"
                 "› `/plans plan_type:Premium` — Browse paid plans\n"
                 "› `/plans action:🌙 MoonCoin Plans` — Coin-only plans\n"
                 "› `/plans action:📨 Invite Plans` — Invite-only plans\n"
                 "› `/claim claim_type:Free option:inv code_or_plan:<name>` — Claim with invites\n"
                 "› `/claim claim_type:Free option:coin code_or_plan:<name>` — Claim with coins\n"
                 "› `/claim claim_type:Premium code_or_plan:<name> proof:<url>` — Claim paid plan"),
            ],
        },
        {
            "title": "🌙 Account & Marketplace",
            "color": 0xFFD700,
            "fields": [
                ("💰 Account",
                 "› `/account options:Balance` — MoonCoin balance + earning history\n"
                 "› `/account options:Transfer` — Send MoonCoins to another user\n"
                 "› `/account options:VPS user_action:Share share_action:Add` — Share VPS access\n"
                 "› `/account options:VPS user_action:Share share_action:Remove` — Revoke access\n"
                 "› `/account options:VPS user_action:Share share_action:List` — See who has access\n"
                 "› `/account options:Backup backup_action:Create` — Snapshot your VPS\n"
                 "› `/account options:Backup backup_action:List` — View your snapshots\n"
                 "› `/account options:Backup backup_action:Restore Latest` — Restore latest\n"
                 "› `/account options:Backup backup_action:Delete` — Delete a snapshot"),
                ("🛒 Marketplace",
                 "› `/marketplace pick_one:Browse` — All active VPS listings\n"
                 "› `/marketplace pick_one:View` — Details of a specific listing\n"
                 "› `/marketplace pick_one:Sell` — List your VPS for sale\n"
                 "› `/marketplace pick_one:Buy` — Purchase a listing\n"
                 "› `/marketplace pick_one:Edit` — Change your listing price or name\n"
                 "› `/marketplace pick_one:Remove` — Take your listing down\n"
                 "› `/marketplace pick_one:My Listings` — See listings you've posted"),
                ("🌙 Earning MoonCoins",
                 "› Invite someone who stays 7+ days → **+5 coins**\n"
                 "› Chat in main channel → **+1 coin** *(5 min cooldown)*\n"
                 "› Join a giveaway → **+3 coins**\n"
                 "› Join an event → **+7 coins**\n"
                 "› VIP role → **+1%** · Server Boost → **+2%** multiplier"),
            ],
        },
    ],

    "Staff": [
        {
            "title": "🌟 Staff Tools",
            "color": 0x57F287,
            "fields": [
                ("🎫 Ticket Actions",
                 "› `/staff role:Staff action:My Tickets` — Your assigned ticket channels\n"
                 "› `/staff role:Staff action:All Tickets` — All open ticket channels\n"
                 "› `/staff role:Staff action:Close Ticket` — Delete a ticket channel\n"
                 "› `/staff role:Staff action:Claim Ticket` — Assign ticket to yourself\n\n"
                 "*Inside ticket channels:*\n"
                 "› **✅ Claim** · **➕ Add User** · **🔒 Close** · **✔️ Mark Done**"),
                ("👤 User Tools",
                 "› `/staff role:Staff action:User Lookup` — Quick profile + VPS summary\n"
                 "› `/staff role:Staff action:Add Note` — Add a private staff note\n"
                 "› `/staff role:Staff action:View Notes` — Read staff notes on a user"),
            ],
        },
        {
            "title": "⭐ Hard Staff Tools",
            "color": 0xFFA500,
            "fields": [
                ("🔍 Hard Staff Only  `[HS]`",
                 "› `/staff role:Hard Staff action:User Info [HS]` — Full profile + coins + warns\n"
                 "› `/staff role:Hard Staff action:VPS Info [HS]` — Container details\n"
                 "› `/staff role:Hard Staff action:List VPS [HS]` — All VPS by user\n"
                 "› `/staff role:Hard Staff action:Server Stats [HS]` — Global VPS counts\n"
                 "› `/staff role:Hard Staff action:Open Tickets [HS]` — All open tickets\n"
                 "› `/staff role:Hard Staff action:Susp Logs [HS]` — Recent suspensions\n"
                 "› `/staff role:Hard Staff action:DM User [HS]` — Send a staff DM\n"
                 "› `/staff role:Hard Staff action:Warn User [HS]` — Issue a warning\n"
                 "› `/staff role:Hard Staff action:Warn Log [HS]` — View warning history"),
            ],
        },
    ],

    "Mod": [
        {
            "title": "⚒️ Mod Tools",
            "color": 0x57F287,
            "fields": [
                ("🔍 Standard Mod",
                 "› `/mod role:Mod action:User Info` — Full user profile\n"
                 "› `/mod role:Mod action:VPS Info` — Container details\n"
                 "› `/mod role:Mod action:List VPS` — All VPS by user\n"
                 "› `/mod role:Mod action:Search VPS` — Find container by name\n"
                 "› `/mod role:Mod action:Server Stats` — Global VPS stats\n"
                 "› `/mod role:Mod action:Open Tickets` — All open tickets\n"
                 "› `/mod role:Mod action:Suspension Logs` — Recent suspensions\n"
                 "› `/mod role:Mod action:DM User` — Message a user as staff\n"
                 "› `/mod role:Mod action:Warn User` — Issue a formal warning\n"
                 "› `/mod role:Mod action:Warn Log` — Warning history"),
            ],
        },
        {
            "title": "🔱 Hard Mod Tools",
            "color": 0xFF6B35,
            "fields": [
                ("🔑 Hard Mod Only  `[HM]`",
                 "› `/mod role:Hard Mod action:Suspend VPS [HM] 🔐AF2F` — Force-suspend a VPS\n"
                 "› `/mod role:Hard Mod action:Unsuspend VPS [HM] 🔐AF2F` — Re-enable a VPS\n"
                 "› `/mod role:Hard Mod action:Expire [HM] 🔐AF2F` — Set / edit / remove expiry\n"
                 "› `/mod role:Hard Mod action:Blocklist [HM]` — Manage user blocklist\n"
                 "› `/mod role:Hard Mod action:Mute [HM]` — Manage user mutes\n"
                 "› `/mod role:Hard Mod action:Clear Warnings [HM]` — Wipe all warnings\n"
                 "› `/mod role:Hard Mod action:Staff Announce [HM]` — Broadcast DM to all staff\n"
                 "› `/mod role:Hard Mod action:Lock Channel [HM]` — Lock a channel\n"
                 "› `/mod role:Hard Mod action:Unlock Channel [HM]` — Unlock a channel\n"
                 "› `/mod role:Hard Mod action:Purge [HM]` — Delete messages (max 100)\n\n"
                 "🔐 **AF2F** = requires a 2-factor code when Bot 2FA extension is enabled."),
            ],
        },
    ],

    "Manager": [
        {
            "title": "💼 Manager Tools",
            "color": 0x9B59B6,
            "fields": [
                ("🗂️ Staff Management",
                 "› Full Mod + Hard Mod + Staff + Hard Staff access\n"
                 "› `/role action:Add permission:<role> user:` — Assign a staff role\n"
                 "› `/role action:Remove permission:<role> user:` — Remove a staff role\n"
                 "› `/role action:Promote user:` — Promote one tier\n"
                 "› `/role action:Demote user:` — Demote one tier\n"
                 "› `/role action:List` — Full staff directory"),
                ("🛡️ VPS & Settings",
                 "› `/create user: plan_name:` — Deploy VPS for any user\n"
                 "› `/delete user: vps_number:` — Permanently delete a VPS\n"
                 "› `/manage user_id:` — Admin-view any user's VPS panel\n"
                 "› `/list action:All VPS` — All VPS across all users\n"
                 "› `/set` — Configure channels and thresholds\n"
                 "› `/payment` — Manage payment method images\n"
                 "› `/set setting:🌙 MoonCoin mooncoin_action:Grant` — Give coins\n"
                 "› `/set setting:🌙 MoonCoin mooncoin_action:Deduct` — Remove coins"),
            ],
        },
    ],

    "Admin": [
        {
            "title": "🛡️ Admin — VPS Management",
            "color": 0x5865F2,
            "fields": [
                ("🔧 Create & Delete",
                 "› `/create user: plan_name: plan_type:` — Deploy a VPS (node → OS picker)\n"
                 "  Optional: `ram_gb:` `cpu_cores:` `disk_gb:` `validity_days:` `vm_mode:`\n"
                 "› `/delete user: vps_number: reason:` — Permanently delete a VPS\n"
                 "› `/manage user_id:` — Admin-view any user's full VPS panel\n"
                 "› `/list action:All VPS` — All VPS across every user"),
                ("🌐 Node Management",
                 "› `/node pick_one:List` — All nodes + ping + stats\n"
                 "› `/node pick_one:Status` — Live CPU/RAM/Disk per node\n"
                 "› `/node pick_one:Create name: runtime: api_key:` — Register a node\n"
                 "› `/node pick_one:Edit` — Edit a node's API key or name\n"
                 "› `/node pick_one:Delete` — Remove a node from the cluster\n"
                 "› `/node pick_one:Migrate vps_name: to_node:` — Move a VPS"),
                ("⚖️ Economy & Giveaways",
                 "› `/set setting:🌙 MoonCoin mooncoin_action:Grant target_user: value:` — Give coins\n"
                 "› `/set setting:🌙 MoonCoin mooncoin_action:Deduct target_user: value:` — Take coins\n"
                 "› `/giveaway action:Create` — Start a VPS giveaway\n"
                 "› `/giveaway action:Cancel` — Cancel an active giveaway\n"
                 "› `/giveaway action:List` — See all active giveaways"),
            ],
        },
        {
            "title": "⚙️ Admin — Config",
            "color": 0x00CED1,
            "fields": [
                ("📡 Channel Setup",
                 "› `/set setting:📡 Channel` — **All-in-one channel UI** (recommended)\n"
                 "  Configures: Log · Payment · Ticket Category · Update · Main Chat · AF2F · Claim\n\n"
                 "Or set individually:\n"
                 "`/set setting:📋 Log Channel value:<id>`\n"
                 "`/set setting:💳 Payment Channel value:<id>`\n"
                 "`/set setting:🎫 Ticket Category value:<id>`\n"
                 "`/set setting:📢 Update Channel value:<id>`\n"
                 "`/set setting:🎟️ Claim Channel value:<id>`\n"
                 "`/set setting:💬 Main Chat Channel value:<id>`\n"
                 "`/set setting:🔐 AF2F Channel value:<id>`"),
                ("📊 Other Settings",
                 "› `/set setting:📊 CPU Threshold % value:<0-100>`\n"
                 "› `/set setting:📊 RAM Threshold % value:<0-100>`\n"
                 "› `/set setting:💾 Backup Limits value:<max_snapshots>`\n"
                 "› `/set setting:🕐 Scheduled Backups time:<HH:MMam>`\n"
                 "› `/set setting:💬 DM Commands command_dm_action:Prefix value:!`\n"
                 "› `/set setting:🌙 MoonCoin Manage earn rules — Add/Remove/View`\n"
                 "› `/payment` — Add/remove payment method images\n"
                 "› `/system action:📋 List` — All containers on the node\n"
                 "› `/system action:🧹 Clean DB` — Remove stale VPS entries"),
            ],
        },
    ],

    "Dev": [
        {
            "title": "💻 Developer Tools",
            "color": 0xEB459E,
            "fields": [
                ("🔧 Diagnostics",
                 "› `/dev action:Config Dump` — All runtime config values\n"
                 "› `/dev action:DB Stats` — Row counts per table\n"
                 "› `/dev action:Runtime` — Active runtime binary + version\n"
                 "› `/dev action:Test LXC` — Run `lxc list` live\n"
                 "› `/dev action:Host Stats` — Live host CPU, RAM, Disk"),
                ("🔄 Operations",
                 "› `/dev action:Error Log` — Last 20 lines of bot.log\n"
                 "› `/dev action:Reload Cog cog_name:` — Hot-reload a cog (no restart)\n"
                 "› `/dev action:Test DM` — Send yourself a test DM\n"
                 "› `/dev action:Extension State` — All extension on/off flags\n"
                 "› `/dev action:Purge Cache` — Reload vps_data + admin_data from DB"),
            ],
        },
    ],

    "Owner": [
        {
            "title": "👑 Owner — System Control",
            "color": 0xFFD700,
            "fields": [
                ("🔌 Extensions",
                 "› `/system action:🔌 Extension Toggle extension:<name> ext_state:Enable/Disable`\n"
                 "› `/system action:👁️ View Extensions` — All extension on/off states\n\n"
                 "**Available extensions:**\n"
                 "`Scheduled Backups` · `Ticket System` · `Auto Expire & Suspend`\n"
                 "`Renewal Reminders` · `Bot 2FA (AF2F)` · `Backup Limits`\n"
                 "`Marketplace` · `Account & MoonCoin` · `VPS Monitoring Alerts` · `DM Commands`"),
                ("🔐 Security & A2FA",
                 "› `/system action:🔐 A2FA Management a2fa_action:Set / Edit PIN new_pin:<4 digits>`\n"
                 "  *(Works even before enabling the extension — set PIN first, then enable)*\n"
                 "› `/system action:🔐 A2FA Management a2fa_action:Remove PIN` — Clear your PIN\n"
                 "› `/af2f code:<6-digit-code>` — Submit AF2F code after a protected command\n\n"
                 "**Commands gated by AF2F** *(non-owner staff only)*:\n"
                 "`/create` `/delete` `/node` `/role` `/set` `/system` `/payment`\n"
                 "`/manage user_id:<other>` · `/mod` Suspend / Unsuspend / Expire"),
                ("💾 Database & Updates",
                 "› `/system action:💾 Database` — Download backup · Upload restore · Delete DB\n"
                 "  *(Upload sends the file to your DM)*\n"
                 "› `/system action:🔄 Update Bot` — Pull latest ZIP from GitHub + restart\n"
                 "› `/system action:🚧 Maintenance Mode` — Lock all commands + notify channel\n"
                 "› `/system action:🧹 Clean DB` — Remove orphaned VPS entries\n"
                 "› `/system action:🌙 MoonCoin Earning` — Add/edit/remove coin earn rules"),
            ],
        },
    ],
}

ROLE_TABS = {
    "Owner":       ["User", "Staff", "Mod", "Manager", "Admin", "Dev", "Owner"],
    "Hard Admin":  ["User", "Staff", "Mod", "Manager", "Admin"],
    "Admin":       ["User", "Staff", "Mod", "Admin"],
    "Manager":     ["User", "Staff", "Mod", "Manager"],
    "Hard Mod":    ["User", "Staff", "Mod"],
    "Mod":         ["User", "Staff", "Mod"],
    "Hard Staff":  ["User", "Staff"],
    "Staff":       ["User", "Staff"],
    "Trial Staff": ["User", "Staff"],
    "Trial Mod":   ["User", "Staff"],
    "Partner":     ["User"],
    "Dev":         ["User", "Dev", "Admin"],
    "User":        ["User"],
}

TAB_LABELS = {
    "User":    ("🌙 User",    discord.ButtonStyle.primary),
    "Staff":   ("🌟 Staff",   discord.ButtonStyle.success),
    "Mod":     ("⚒️ Mod",     discord.ButtonStyle.secondary),
    "Manager": ("💼 Manager", discord.ButtonStyle.secondary),
    "Admin":   ("🛡️ Admin",  discord.ButtonStyle.secondary),
    "Dev":     ("💻 Dev",     discord.ButtonStyle.danger),
    "Owner":   ("👑 Owner",   discord.ButtonStyle.primary),
}


class HelpView(discord.ui.View):
    def __init__(self, uid: int, role: str):
        super().__init__(timeout=300)
        self.uid      = uid
        self.role     = role
        self.tabs     = [t for t in ROLE_TABS.get(role, ["User"]) if t in PAGES]
        self.cur_tab  = 0
        self.cur_page = 0
        self._build()

    def _build(self):
        self.clear_items()
        for i, tab in enumerate(self.tabs):
            label, _ = TAB_LABELS.get(tab, (tab, discord.ButtonStyle.secondary))
            active   = (i == self.cur_tab)
            row      = 0 if i < 5 else 1
            btn = discord.ui.Button(
                label=label, row=row,
                style=discord.ButtonStyle.primary if active else discord.ButtonStyle.secondary,
                disabled=active,
            )
            _i = i
            async def cb(inter, _idx=_i):
                if inter.user.id != self.uid:
                    return await inter.response.send_message("This menu is not yours.", ephemeral=True)
                self.cur_tab  = _idx
                self.cur_page = 0
                self._build()
                await inter.response.edit_message(embed=self._embed(), view=self)
            btn.callback = cb
            self.add_item(btn)

        pages   = PAGES.get(self.tabs[self.cur_tab], []) if self.tabs else []
        nav_row = 2
        if len(pages) > 1:
            prev = discord.ui.Button(label="◀ Prev", row=nav_row, style=discord.ButtonStyle.secondary,
                                     disabled=(self.cur_page == 0))
            nxt  = discord.ui.Button(label="Next ▶", row=nav_row, style=discord.ButtonStyle.secondary,
                                     disabled=(self.cur_page >= len(pages) - 1))
            async def go_prev(inter):
                if inter.user.id != self.uid:
                    return await inter.response.send_message("Not yours.", ephemeral=True)
                self.cur_page = max(0, self.cur_page - 1)
                self._build()
                await inter.response.edit_message(embed=self._embed(), view=self)
            async def go_next(inter):
                if inter.user.id != self.uid:
                    return await inter.response.send_message("Not yours.", ephemeral=True)
                self.cur_page = min(len(pages) - 1, self.cur_page + 1)
                self._build()
                await inter.response.edit_message(embed=self._embed(), view=self)
            prev.callback = go_prev
            nxt.callback  = go_next
            self.add_item(prev)
            self.add_item(nxt)

    def _embed(self) -> discord.Embed:
        if not self.tabs:
            return discord.Embed(title="Help", description="No pages available.", color=0x5865F2)
        tab   = self.tabs[self.cur_tab]
        pages = PAGES.get(tab, [])
        if not pages:
            return discord.Embed(title="Help", description="No pages.", color=0x5865F2)
        page  = pages[min(self.cur_page, len(pages) - 1)]
        total = len(pages)
        embed = discord.Embed(title=page["title"], color=page["color"], timestamp=datetime.now())
        embed.set_author(name="MoonNodes VPS Manager", icon_url=ICON)
        for name, value in page["fields"]:
            embed.add_field(name=name, value=value[:1024], inline=False)
        sub = f" — Page {self.cur_page + 1}/{total}" if total > 1 else ""
        embed.set_footer(text=f"Role: {self.role}{sub} · MoonNodes")
        return embed


class HelpCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="help", description="Show commands available to your role")
    async def help_cmd(self, interaction: discord.Interaction):
        role = _role(interaction.user.id)
        view = HelpView(interaction.user.id, role)
        await interaction.response.send_message(embed=view._embed(), view=view, ephemeral=True)


async def setup(bot):
    await bot.add_cog(HelpCog(bot))
