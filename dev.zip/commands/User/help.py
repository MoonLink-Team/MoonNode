import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MAIN_ADMIN_ID
from core.database import admin_data
from core.theme import create_embed, add_field, Theme


def _get_role(user_id) -> str:
    if str(user_id) == str(MAIN_ADMIN_ID):
        return "Owner"
    return admin_data.get(str(user_id), "User")

# ── Page definitions per role ─────────────────────────────────────────────────

PAGES = {
    "User": {
        "🌙 MoonNodes": [
            ("🖥️ VPS Management", (
                "`/list` — View all your active VPS\n"
                "`/manage` — Control panel: Start · Stop · Reinstall · SSH · Console · Software\n"
                "  ↳ **My VPS** tab: your own containers\n"
                "  ↳ **Shared VPS** tab: VPS others shared with you\n"
                "`/backup action: vps_number:` — Create or restore snapshots\n"
                "`/share` — Grant another user access to your VPS"
            )),
            ("📋 Plans & Claims", (
                "`/plans plan_type:Free|Premium` — Browse available VPS plans\n"
                "`/claim claim_type:Free option:inv|coin code_or_plan:` — Claim a free VPS\n"
                "`/claim claim_type:Premium code_or_plan: proof:` — Submit payment for premium\n"
                "`/upgrade` — Upgrade your current VPS plan"
            )),
            ("🌙 Account & Market", (
                "`/account` — View your MoonCoin balance and earning stats\n"
                "`/marketplace pick_one:List` — Browse VPS listings\n"
                "`/marketplace pick_one:Sell` — List your VPS for sale\n"
                "`/marketplace pick_one:Buy` — Purchase a listing\n"
                "`/status` — Live host node resource stats\n"
                "`/support vps_number: issue:` — Open a support ticket"
            )),
            ("🌙 Earning MoonCoins", (
                "• Invite someone → **+5 🌙**\n"
                "• Chat in main channel → **+1 🌙** *(5 min cooldown)*\n"
                "• Join a giveaway → **+3 🌙**\n"
                "• Join an event → **+7 🌙**\n"
                "• VIP role → **+1% multiplier**\n"
                "• Boost server (1×) → **+2% multiplier**\n"
                "• Boost server (2×) → **+3% multiplier**"
            )),
        ],
    },
    "Mod": {
        "🔨 Mod Tools": [
            ("🔨 Moderation", (
                "`/manage user:@user` — View/manage any user's VPS\n"
                "`/list-all` — See all VPS across all users\n"
                "`/support` — Handle and close support tickets"
            )),
        ],
    },
    "Admin": {
        "🛡️ Admin Panel": [
            ("🛠️ VPS Admin", (
                "`/create user: plan_name: plan_type:` — Deploy VPS (Node → OS)\n"
                "`/delete user: vps_number: reason:` — Delete a VPS\n"
                "`/vps action: container_name:` — Suspend / Unsuspend\n"
                "`/list-all` — All VPS across all users & nodes\n"
                "`/manage user:@user` — Admin-manage any user's VPS"
            )),
            ("⚙️ Configuration", (
                "`/role` — Assign / remove staff roles\n"
                "`/set setting: value:` — Channels, thresholds, schedules\n"
                "`/payment action: payment_name:` — Manage payment methods\n"
                "`/giveaway action:` — Start / cancel / list giveaways\n"
                "`/system-admin action:` — Extensions, A2FA, maintenance"
            )),
            ("🌐 Node Management", (
                "`/node pick_one:List` — All registered nodes\n"
                "`/node pick_one:Status` — Live CPU/RAM/Disk per node\n"
                "`/node pick_one:Create` — Register a new LXD/Incus node\n"
                "`/node pick_one:Edit node_id:` — Edit node details\n"
                "`/node pick_one:Delete node_id:` — Remove a node\n"
                "`/node pick_one:Migrate` — Move VPS between nodes\n"
                "`/lxc-list node_id:` — Raw container list"
            )),
            ("🛒 Marketplace Admin", (
                "`/marketplace pick_one:Payment` — Add/remove payment methods\n"
                "`/marketplace pick_one:Remove sell_name:` — Remove any listing\n"
                "`/account admin_action: target_user:` — Manage user coins\n"
                "`/system-admin extension:Marketplace` — Toggle marketplace on/off"
            )),
        ],
    },
    "Dev": {
        "💻 Dev Tools": [
            ("💻 Developer", (
                "`/lxc-list node_id:` — Raw container list on any node\n"
                "`/system-admin action:Clean DB` — Remove stale DB entries\n"
                "`/system-admin action:View Extensions` — See all extension states\n"
                "`/node pick_one:Status` — Live node resource stats\n"
                "All Admin commands are also available"
            )),
        ],
    },
    "Owner": {
        "👑 Owner Tools": [
            ("👑 Full Control", (
                "`/role action: permission: user:` — Assign Owner/Admin/Mod/Dev roles\n"
                "`/system-admin action:Extension Toggle` — Enable/disable features\n"
                "`/system-admin action:Maintenance Mode` — Toggle maintenance\n"
                "`/system-admin action:A2FA Management` — Set admin PIN\n"
                "`/node pick_one:Create|Delete` — Cluster management"
            )),
        ],
    },
}

# Role hierarchy for what pages each role sees
ROLE_ACCESS = {
    "Owner": ["User", "Mod", "Admin", "Dev", "Owner"],
    "Admin": ["User", "Admin"],
    "Dev":   ["User", "Dev", "Admin"],
    "Mod":   ["User", "Mod"],
    "User":  ["User"],
}

ROLE_COLORS = {
    "Owner": 0xFFD700,
    "Admin": 0x5865F2,
    "Dev":   0xEB459E,
    "Mod":   0x57F287,
    "User":  Theme.PRIMARY,
}


class HelpView(discord.ui.View):
    def __init__(self, user_id, role: str):
        super().__init__(timeout=300)
        self.user_id   = user_id
        self.role      = role
        self.accessible = ROLE_ACCESS.get(role, ["User"])
        self.page_keys  = [p for p in self.accessible if p in PAGES]
        self.current    = 0
        self._rebuild_buttons()

    def _rebuild_buttons(self):
        self.clear_items()
        icons = {"User": "🌙", "Mod": "🔨", "Admin": "🛡️", "Dev": "💻", "Owner": "👑"}
        for i, key in enumerate(self.page_keys):
            label = f"{icons.get(key,'')} {list(PAGES[key].keys())[0]}"
            btn   = discord.ui.Button(
                label=label[:80],
                style=discord.ButtonStyle.primary if i == self.current else discord.ButtonStyle.secondary,
                row=0,
            )
            idx = i
            async def cb(inter, _idx=idx):
                if str(inter.user.id) != str(self.user_id):
                    return await inter.response.send_message("This menu isn't yours.", ephemeral=True)
                self.current = _idx
                self._rebuild_buttons()
                await inter.response.edit_message(embed=self._make_embed(), view=self)
            btn.callback = cb
            self.add_item(btn)

    def _make_embed(self) -> discord.Embed:
        page_key  = self.page_keys[self.current]
        page_data = PAGES[page_key]
        title_key = list(page_data.keys())[0]
        fields    = page_data[title_key]
        color     = ROLE_COLORS.get(page_key, Theme.PRIMARY)

        embed = discord.Embed(
            title=f"📚  MoonNodes — {title_key}",
            description=f"{Theme.DIVIDER}\nPage **{self.current+1}/{len(self.page_keys)}**\n{Theme.DIVIDER}",
            color=color, timestamp=datetime.now(),
        )
        embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
        for name, value in fields:
            embed.add_field(name=name, value=value[:1024], inline=False)
        embed.set_footer(text=f"Logged in as {self.role} • MoonNodes VPS Manager")
        return embed


class HelpCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="help", description="Show commands available to your role")
    async def help_cmd(self, interaction: discord.Interaction):
        role  = _get_role(interaction.user.id)
        view  = HelpView(interaction.user.id, role)
        await interaction.response.send_message(embed=view._make_embed(), view=view, ephemeral=True)


async def setup(bot):
    await bot.add_cog(HelpCog(bot))
