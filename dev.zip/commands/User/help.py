import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MAIN_ADMIN_ID
from core.database import admin_data
from core.theme import Theme


def _get_role(user_id) -> str:
    if str(user_id) == str(MAIN_ADMIN_ID):
        return "Owner"
    return admin_data.get(str(user_id), "User")


# ── Page content ─────────────────────────────────────────────────────────────

PAGES = {
    "User": [
        {
            "title": "🖥️  VPS & Plans",
            "color": 0x5865F2,
            "fields": [
                ("Managing Your VPS", (
                    "<:dot:> `/list` — View all your VPS instances\n"
                    "<:dot:> `/manage` — VPS control panel\n"
                    "    › **My VPS** — Start, Stop, Reinstall, SSH, Console\n"
                    "    › **Shared VPS** — Manage VPS others shared with you\n"
                    "<:dot:> `/status` — Live host resource stats"
                )),
                ("Plans & Claiming", (
                    "<:dot:> `/plans plan_type:Free` — Browse free plans\n"
                    "<:dot:> `/plans plan_type:Premium` — Browse paid plans\n"
                    "<:dot:> `/claim claim_type:Free option:inv code_or_plan:basic`\n"
                    "<:dot:> `/claim claim_type:Free option:coin code_or_plan:basic`\n"
                    "<:dot:> `/claim claim_type:Premium code_or_plan:starter proof:`\n"
                    "<:dot:> `/upgrade` — Upgrade your current plan"
                )),
            ],
        },
        {
            "title": "🌙  Account & Market",
            "color": 0xFFD700,
            "fields": [
                ("Account Actions", (
                    "<:dot:> `/account options:Balance` — Coins, stats, multipliers\n"
                    "<:dot:> `/account options:Transfer transfer_to: transfer_amount:` — Send coins\n"
                    "<:dot:> `/account options:VPS user_action:Share share_action:Add User vps_number:`\n"
                    "<:dot:> `/account options:VPS user_action:Backup backup_action:Create vps_number:`\n"
                    "<:dot:> `/account options:VPS user_action:Backup backup_action:Restore vps_number:`\n"
                    "<:dot:> `/support vps_number: issue:` — Open a support ticket"
                )),
                ("Marketplace", (
                    "<:dot:> `/marketplace pick_one:List` — Browse listings\n"
                    "<:dot:> `/marketplace pick_one:Sell vps_number: price: price_type:` — Sell VPS\n"
                    "<:dot:> `/marketplace pick_one:Buy sell_name: user:` — Buy listing\n"
                    "<:dot:> `/marketplace pick_one:Edit sell_name:` — Edit your listing\n"
                    "<:dot:> `/marketplace pick_one:Remove sell_name:` — Remove listing"
                )),
                ("Earning 🌙 MoonCoins", (
                    "🔹 Invite someone → **+5 coins**\n"
                    "🔹 Chat in main channel → **+1 coin** *(5 min cooldown)*\n"
                    "🔹 Join a giveaway → **+3 coins**\n"
                    "🔹 Join an event → **+7 coins**\n"
                    "🔸 VIP role → **+1% multiplier**\n"
                    "🔸 Server Boost → **+2% multiplier** *(stacks!)*"
                )),
            ],
        },
    ],
    "Mod": [
        {
            "title": "🔨  Mod Tools",
            "color": 0x57F287,
            "fields": [
                ("Moderation Commands", (
                    "<:dot:> `/mod action:User Info target_user:` — Stats & VPS count\n"
                    "<:dot:> `/mod action:VPS Info container_name:` — Container details\n"
                    "<:dot:> `/mod action:List VPS target_user:` — All VPS for a user\n"
                    "<:dot:> `/mod action:Search container_name:` — Find any container\n"
                    "<:dot:> `/mod action:Server Stats` — Global VPS overview\n"
                    "<:dot:> `/mod action:Tickets` — Open support threads\n"
                    "<:dot:> `/mod action:Suspension Logs` — Suspension history\n"
                    "<:dot:> `/mod action:DM User target_user: message:` — DM as MoonNodes\n"
                    "<:dot:> `/mod action:Warn User target_user: message:` — Issue warning\n"
                    "<:dot:> `/mod action:Warn Log target_user:` — Warning history"
                )),
            ],
        },
    ],
    "Admin": [
        {
            "title": "🛡️  Admin — VPS & Staff",
            "color": 0x5865F2,
            "fields": [
                ("VPS Management", (
                    "<:dot:> `/create user: plan_name: plan_type:` — Deploy VPS\n"
                    "<:dot:> `/delete user: vps_number: reason:` — Delete VPS *(DMs owner)*\n"
                    "<:dot:> `/account admin_action:Suspend VPS target_user: vps_number:` — Suspend\n"
                    "<:dot:> `/account admin_action:Unsuspend VPS target_user: vps_number:` — Unsuspend\n"
                    "<:dot:> `/list action:All VPS` — All VPS across all users\n"
                    "<:dot:> `/manage user:@user` — Manage any user's VPS"
                )),
                ("Staff & Config", (
                    "<:dot:> `/role action:Add permission:Admin user:` — Add staff role\n"
                    "<:dot:> `/role action:Remove user:` — Remove staff role\n"
                    "<:dot:> `/role action:List` — View all staff\n"
                    "<:dot:> `/set setting:Log Channel value:` — Set log channel\n"
                    "<:dot:> `/set setting:Ticket Channel value:` — Set support channel\n"
                    "<:dot:> `/set setting:Scheduled Backups value: option: date: time:`\n"
                    "<:dot:> `/payment action:Add/Edit payment_name: image:` — Payment method\n"
                    "<:dot:> `/giveaway action:Create` — Start a giveaway\n"
                    "<:dot:> `/account admin_action:Add Coins target_user: transfer_amount:`"
                )),
            ],
        },
        {
            "title": "🌐  Admin — Nodes",
            "color": 0x00CED1,
            "fields": [
                ("Node Cluster", (
                    "<:dot:> `/node pick_one:List` — All registered nodes\n"
                    "<:dot:> `/node pick_one:Status option:` — Live CPU/RAM/Disk\n"
                    "<:dot:> `/node pick_one:Create name: host: port:` — Register node\n"
                    "<:dot:> `/node pick_one:Edit option:id` — Edit node *(modal)*\n"
                    "<:dot:> `/node pick_one:Delete option:id` — Remove node\n"
                    "<:dot:> `/node pick_one:Migrate vps_name: to_node:` — Move VPS\n"
                    "<:dot:> `/lxc-list node_id:` — Raw container list on node"
                )),
            ],
        },
    ],
    "Dev": [
        {
            "title": "💻  Dev Tools",
            "color": 0xEB459E,
            "fields": [
                ("Developer Commands", (
                    "<:dot:> `/dev action:Config Dump` — All runtime config values\n"
                    "<:dot:> `/dev action:DB Stats` — Row counts per table\n"
                    "<:dot:> `/dev action:Runtime` — Runtime binary & version\n"
                    "<:dot:> `/dev action:Test LXC` — Run live `lxc list`\n"
                    "<:dot:> `/dev action:Host Stats` — CPU / RAM / Disk\n"
                    "<:dot:> `/dev action:Error Log` — Last 20 log lines\n"
                    "<:dot:> `/dev action:Reload Cog option:commands.User.help`\n"
                    "<:dot:> `/dev action:Test DM` — Send yourself a test DM\n"
                    "<:dot:> `/dev action:Extension State` — All feature flags\n"
                    "<:dot:> `/dev action:Purge Cache` — Reload data from disk"
                )),
            ],
        },
    ],
    "Owner": [
        {
            "title": "👑  Owner Controls",
            "color": 0xFFD700,
            "fields": [
                ("System Commands", (
                    "<:dot:> `/system action:Extension Toggle extension: ext_state:` — Toggle features\n"
                    "<:dot:> `/system action:View Extensions` — All on/off states\n"
                    "<:dot:> `/system action:Maintenance Mode` — Toggle maintenance\n"
                    "<:dot:> `/system action:A2FA Management a2fa_action: new_pin:`\n"
                    "<:dot:> `/system action:Clean DB` — Remove stale DB entries\n"
                    "<:dot:> `/system action:MoonCoin Earning mooncoin_action: earning_name: earning_amount:`"
                )),
                ("Available Extensions", (
                    "🔌 Multi-Node Support · Scheduled Backups\n"
                    "🔌 Ticket System · Auto Expire & Suspend\n"
                    "🔌 Renewal Reminders · Admin 2FA\n"
                    "🔌 Multi-Server Tickets · Backup Limits\n"
                    "🔌 Marketplace · Account & MoonCoin\n"
                    "🔌 VPS Renewal · VPS Monitoring Alerts\n"
                    "🔌 VPS Templates · Multi-language"
                )),
            ],
        },
    ],
}

ROLE_PAGES = {
    "Owner": ["User", "Mod", "Admin", "Dev", "Owner"],
    "Admin": ["User", "Admin"],
    "Dev":   ["User", "Dev", "Admin"],
    "Mod":   ["User", "Mod"],
    "User":  ["User"],
}

PAGE_BUTTONS = {
    "User":  ("🌙 User",  discord.ButtonStyle.primary),
    "Mod":   ("🔨 Mod",   discord.ButtonStyle.success),
    "Admin": ("🛡️ Admin", discord.ButtonStyle.secondary),
    "Dev":   ("💻 Dev",   discord.ButtonStyle.danger),
    "Owner": ("👑 Owner", discord.ButtonStyle.primary),
}


class HelpView(discord.ui.View):
    def __init__(self, user_id: int, role: str):
        super().__init__(timeout=300)
        self.user_id    = user_id
        self.role       = role
        self.role_pages = ROLE_PAGES.get(role, ["User"])
        self.cur_role   = self.role_pages[0]
        self.cur_subpage = 0
        self._build()

    # ── Button builders ───────────────────────────────────────────────────────

    def _build(self):
        self.clear_items()

        # Row 0: role tab buttons
        for rp in self.role_pages:
            label, style = PAGE_BUTTONS.get(rp, (rp, discord.ButtonStyle.secondary))
            active = (rp == self.cur_role)
            btn = discord.ui.Button(
                label=label,
                style=discord.ButtonStyle.primary if active else discord.ButtonStyle.secondary,
                emoji=None,
                disabled=active,
                row=0,
            )
            _rp = rp
            async def role_cb(inter, _r=_rp):
                if inter.user.id != self.user_id:
                    return await inter.response.send_message("This menu isn't yours.", ephemeral=True)
                self.cur_role    = _r
                self.cur_subpage = 0
                self._build()
                await inter.response.edit_message(embed=self._embed(), view=self)
            btn.callback = role_cb
            self.add_item(btn)

        # Row 1: subpage prev/next if needed
        pages = PAGES.get(self.cur_role, [])
        if len(pages) > 1:
            prev = discord.ui.Button(label="◀ Prev", style=discord.ButtonStyle.secondary,
                                     disabled=(self.cur_subpage == 0), row=1)
            nxt  = discord.ui.Button(label="Next ▶", style=discord.ButtonStyle.secondary,
                                     disabled=(self.cur_subpage >= len(pages) - 1), row=1)

            async def prev_cb(inter):
                if inter.user.id != self.user_id:
                    return await inter.response.send_message("This menu isn't yours.", ephemeral=True)
                self.cur_subpage = max(0, self.cur_subpage - 1)
                self._build()
                await inter.response.edit_message(embed=self._embed(), view=self)

            async def next_cb(inter):
                if inter.user.id != self.user_id:
                    return await inter.response.send_message("This menu isn't yours.", ephemeral=True)
                self.cur_subpage = min(len(pages) - 1, self.cur_subpage + 1)
                self._build()
                await inter.response.edit_message(embed=self._embed(), view=self)

            prev.callback = prev_cb
            nxt.callback  = next_cb
            self.add_item(prev)
            self.add_item(nxt)

    def _embed(self) -> discord.Embed:
        pages  = PAGES.get(self.cur_role, [])
        page   = pages[min(self.cur_subpage, len(pages) - 1)]
        total  = len(pages)

        embed = discord.Embed(
            title=page["title"],
            color=page["color"],
            timestamp=datetime.now(),
        )
        embed.set_author(
            name="MoonNodes VPS Manager",
            icon_url="https://imgur.com/6yfYDTP.png",
        )

        for name, value in page["fields"]:
            # Replace <:dot:> with a bullet (custom emoji won't render in all servers)
            clean_value = value.replace("<:dot:>", "›")
            embed.add_field(name=name, value=clean_value[:1024], inline=False)

        # Footer with role + page position
        sub_info = f" • Page {self.cur_subpage + 1}/{total}" if total > 1 else ""
        embed.set_footer(text=f"Role: {self.role}{sub_info} • MoonNodes VPS Manager")
        return embed


class HelpCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="help", description="Show commands available to your role")
    async def help_cmd(self, interaction: discord.Interaction):
        role = _get_role(interaction.user.id)
        view = HelpView(interaction.user.id, role)
        await interaction.response.send_message(
            embed=view._embed(), view=view, ephemeral=True
        )


async def setup(bot):
    await bot.add_cog(HelpCog(bot))
