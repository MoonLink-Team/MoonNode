import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MAIN_ADMIN_ID
from core.database import admin_data
from core.theme import create_embed, Theme


def _get_role(user_id) -> str:
    if str(user_id) == str(MAIN_ADMIN_ID):
        return "Owner"
    return admin_data.get(str(user_id), "User")


PAGES = {
    "User": {
        "🌙 User Commands": [
            ("🖥️  VPS Management", (
                "`/list` — View your VPS instances\n"
                "`/list action:All VPS` — View all VPS **(Admin only)**\n"
                "`/manage` — Control panel: Start · Stop · Reinstall · SSH · Console · Software Installer\n"
                "  ↳ **My VPS** tab: your containers\n"
                "  ↳ **Shared VPS** tab: containers others shared with you"
            )),
            ("📦  Plans & Claims", (
                "`/plans plan_type:Free` — Free plans (pay with Invites or 🌙 Coins)\n"
                "`/plans plan_type:Premium` — Premium plans (payment screenshot)\n"
                "`/claim claim_type:Free option:inv code_or_plan:basic` — Claim with invites\n"
                "`/claim claim_type:Free option:coin code_or_plan:basic` — Claim with coins\n"
                "`/claim claim_type:Premium code_or_plan:starter proof:` — Submit payment\n"
                "`/upgrade` — Upgrade your current VPS plan"
            )),
            ("🌙  Account & MoonCoin", (
                "`/account options:Balance` — View your MoonCoin balance\n"
                "`/account options:Transfer transfer_to: transfer_amount:` — Send coins\n"
                "`/account options:VPS user_action:Share` — Share VPS access\n"
                "`/account options:VPS user_action:Backup backup_action:Create` — Backup VPS\n"
                "`/account options:VPS user_action:Backup backup_action:Restore` — Restore latest\n"
                "`/backup` — Quick backup command"
            )),
            ("🛒  Marketplace", (
                "`/marketplace pick_one:List` — Browse VPS listings\n"
                "`/marketplace pick_one:Sell vps_number: price: price_type:` — List your VPS\n"
                "`/marketplace pick_one:Buy sell_name: user:` — Buy a listing\n"
                "`/marketplace pick_one:Edit sell_name:` — Edit your listing\n"
                "`/marketplace pick_one:Remove sell_name:` — Remove your listing\n"
                "`/status` — Live host node stats · `/support` — Open a ticket"
            )),
            ("💡  Earning MoonCoins", (
                "• Invite someone → **+5 🌙** per person\n"
                "• Chat in main channel → **+1 🌙** *(5 min cooldown)*\n"
                "• Join a giveaway → **+3 🌙**\n"
                "• Join an event → **+7 🌙**\n"
                "• VIP role → **+1% multiplier** on all earnings\n"
                "• Server Boost → **+2% multiplier** (stacks!)"
            )),
        ],
    },
    "Mod": {
        "🔨 Mod Commands": [
            ("🔨  Moderation Tools", (
                "`/mod action:User Info target_user:` — View user stats & VPS\n"
                "`/mod action:VPS Info container_name:` — Container details\n"
                "`/mod action:List VPS target_user:` — All VPS for a user\n"
                "`/mod action:Search container_name:` — Find any container\n"
                "`/mod action:Server Stats` — Total VPS, users, running counts\n"
                "`/mod action:Tickets` — List all open support threads\n"
                "`/mod action:Suspension Logs` — View suspension history\n"
                "`/mod action:DM User target_user: message:` — DM as MoonNodes\n"
                "`/mod action:Warn User target_user: message:` — Issue a warning\n"
                "`/mod action:Warn Log target_user:` — View warning history"
            )),
        ],
    },
    "Admin": {
        "🛡️ Admin Commands": [
            ("🛠️  VPS Admin", (
                "`/create user: plan_name: plan_type:` — Deploy VPS (Node → OS)\n"
                "`/delete user: vps_number: reason:` — Delete a VPS (DMs owner)\n"
                "`/account admin_action:Suspend VPS target_user: vps_number:` — Suspend VPS\n"
                "`/account admin_action:Unsuspend VPS target_user: vps_number:` — Unsuspend VPS\n"
                "`/account admin_action:Add Coins target_user: transfer_amount:` — Give coins\n"
                "`/list action:All VPS` — All VPS across all users"
            )),
            ("⚙️  Config & Staff", (
                "`/role action:Add permission:Admin user:` — Assign staff role\n"
                "`/role action:Remove user:` — Remove staff role\n"
                "`/role action:List` — View all staff with join dates\n"
                "`/set setting:Log Channel value:` — Set log channel\n"
                "`/set setting:Ticket Channel value:` — Set support channel\n"
                "`/set setting:CPU Threshold % value:` — Set CPU alert %\n"
                "`/set setting:Scheduled Backups value: option: date: time:` — Schedule backups\n"
                "`/set setting:Backup Limits value: option: date: time:` — Set backup cap\n"
                "`/payment action:Add/Edit payment_name: image:` — Add payment method\n"
                "`/giveaway action:Create` — Start a VPS giveaway"
            )),
            ("🌐  Node Management", (
                "`/node pick_one:List` — All registered nodes\n"
                "`/node pick_one:Status [option:id]` — Live CPU/RAM/Disk\n"
                "`/node pick_one:Create [name: host: port:]` — Register node (modal)\n"
                "`/node pick_one:Edit option:id` — Edit node (modal)\n"
                "`/node pick_one:Delete option:id` — Remove node\n"
                "`/node pick_one:Migrate [vps_name: to_node:]` — Move VPS (modal)\n"
                "`/lxc-list node_id:` — Raw container list"
            )),
        ],
    },
    "Dev": {
        "💻 Dev Commands": [
            ("💻  Developer Tools", (
                "`/dev action:Config Dump` — All runtime config values\n"
                "`/dev action:DB Stats` — Row counts per table\n"
                "`/dev action:Runtime` — Container runtime & version\n"
                "`/dev action:Test LXC` — Run lxc list & show output\n"
                "`/dev action:Host Stats` — Live CPU/RAM/Disk\n"
                "`/dev action:Error Log` — Last 20 lines of bot.log\n"
                "`/dev action:Reload Cog option:commands.User.help` — Reload cog\n"
                "`/dev action:Test DM` — Send test DM to yourself\n"
                "`/dev action:Extension State` — All extension on/off flags\n"
                "`/dev action:Purge Cache` — Reload all data from disk"
            )),
        ],
    },
    "Owner": {
        "👑 Owner Commands": [
            ("👑  Full System Control", (
                "`/system action:Extension Toggle extension: ext_state:` — Enable/disable features\n"
                "`/system action:View Extensions` — All extension states\n"
                "`/system action:Maintenance Mode` — Toggle maintenance\n"
                "`/system action:A2FA Management a2fa_action: new_pin:` — Set admin PIN\n"
                "`/system action:Clean DB` — Remove stale entries\n"
                "`/system action:MoonCoin Earning mooncoin_action: earning_name: earning_amount:` — Manage coin rules"
            )),
            ("🔌  Extensions Available", (
                "Multi-Node · Scheduled Backups · Ticket System\n"
                "Auto Expire & Suspend · Renewal Reminders · Admin 2FA\n"
                "Multi-Server Tickets · Backup Limits · Marketplace\n"
                "Account & MoonCoin · VPS Renewal · VPS Monitoring Alerts\n"
                "VPS Templates · Multi-language"
            )),
        ],
    },
}

ROLE_ACCESS = {
    "Owner": ["User", "Mod", "Admin", "Dev", "Owner"],
    "Admin": ["User", "Admin"],
    "Dev":   ["User", "Dev", "Admin"],
    "Mod":   ["User", "Mod"],
    "User":  ["User"],
}

ROLE_COLORS = {
    "Owner": 0xFFD700,
    "Admin": 0x5865F2,
    "Dev":   0xEB459E,
    "Mod":   0x57F287,
    "User":  Theme.PRIMARY,
}


class HelpView(discord.ui.View):
    def __init__(self, user_id, role: str):
        super().__init__(timeout=300)
        self.user_id    = user_id
        self.role       = role
        self.accessible = [p for p in ROLE_ACCESS.get(role, ["User"]) if p in PAGES]
        self.current    = 0
        self._build()

    def _build(self):
        self.clear_items()
        icons = {"User": "🌙", "Mod": "🔨", "Admin": "🛡️", "Dev": "💻", "Owner": "👑"}
        for i, key in enumerate(self.accessible):
            label = f"{icons.get(key,'')} {list(PAGES[key].keys())[0]}"
            btn   = discord.ui.Button(
                label=label[:80],
                style=discord.ButtonStyle.primary if i == self.current else discord.ButtonStyle.secondary,
                row=0,
            )
            idx = i
            async def cb(inter, _i=idx):
                if str(inter.user.id) != str(self.user_id):
                    return await inter.response.send_message("This menu isn't yours.", ephemeral=True)
                self.current = _i
                self._build()
                await inter.response.edit_message(embed=self._embed(), view=self)
            btn.callback = cb
            self.add_item(btn)

    def _embed(self) -> discord.Embed:
        key    = self.accessible[self.current]
        data   = PAGES[key]
        title  = list(data.keys())[0]
        fields = data[title]
        color  = ROLE_COLORS.get(key, Theme.PRIMARY)
        embed  = discord.Embed(
            title=f"📚  MoonNodes — {title}",
            description=f"{Theme.DIVIDER}\nPage **{self.current+1}/{len(self.accessible)}**\n{Theme.DIVIDER}",
            color=color, timestamp=datetime.now(),
        )
        embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
        for name, value in fields:
            embed.add_field(name=name, value=value[:1024], inline=False)
        embed.set_footer(text=f"Role: {self.role} • MoonNodes VPS Manager")
        return embed


class HelpCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="help", description="Show commands available to your role")
    async def help_cmd(self, interaction: discord.Interaction):
        role = _get_role(interaction.user.id)
        view = HelpView(interaction.user.id, role)
        await interaction.response.send_message(embed=view._embed(), view=view, ephemeral=True)


async def setup(bot):
    await bot.add_cog(HelpCog(bot))
