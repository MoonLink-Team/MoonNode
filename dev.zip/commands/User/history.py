"""
/history — View CPU/RAM usage history for your VPS over the last 24h or 7d.
"""

import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime, timedelta

from core.config    import MAIN_ADMIN_ID
from core.database  import admin_data, vps_data, data_lock, get_db
from core.theme     import Theme, create_error_embed
from core.ratelimit import rate_limit


def _sparkline(values: list, width: int = 20) -> str:
    """Generate a text sparkline from a list of 0-100 floats."""
    blocks = " ▁▂▃▄▅▆▇█"
    if not values:
        return "`no data`"
    mn, mx = min(values), max(values)
    span   = mx - mn or 1
    result = "".join(blocks[min(8, int((v - mn) / span * 8))] for v in values[-width:])
    avg    = sum(values) / len(values)
    return f"`{result}` avg {avg:.1f}%"


class HistoryCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="history", description="CPU/RAM history for your VPS")
    @app_commands.describe(
        vps_name = "Container name (leave blank to see a list of yours)",
        period   = "Time range to show",
    )
    @app_commands.choices(period=[
        app_commands.Choice(name="Last 24 hours", value="24h"),
        app_commands.Choice(name="Last 7 days",   value="7d"),
        app_commands.Choice(name="Last 30 days",  value="30d"),
    ])
    @rate_limit(seconds=20, admin_bypass=True)
    async def history_cmd(
        self,
        interaction: discord.Interaction,
        vps_name: str = None,
        period:   str = "24h",
    ):
        await interaction.response.defer(ephemeral=True, thinking=True)

        uid      = str(interaction.user.id)
        is_admin = (interaction.user.id == MAIN_ADMIN_ID or uid in admin_data)

        # Resolve which VPS the user owns
        async with data_lock:
            user_vps = [
                v["container_name"]
                for v in vps_data.get(uid, [])
            ]
            if is_admin and not user_vps:
                # Admin with no VPS — show all containers as choices
                user_vps = [
                    v["container_name"]
                    for lst in vps_data.values()
                    for v in lst
                ]

        if not user_vps:
            return await interaction.followup.send(
                embed=create_error_embed("No VPS Found", "You don't have any VPS to view history for."),
                ephemeral=True,
            )

        # If no name given, list options
        if not vps_name:
            lines = "\n".join(f"• `{n}`" for n in user_vps[:20])
            embed = discord.Embed(
                title="📊 VPS Usage History",
                description=f"You have **{len(user_vps)}** VPS. Specify one with the `vps_name` option:\n\n{lines}",
                color=Theme.PRIMARY,
            )
            embed.set_footer(text="Re-run the command with vps_name set")
            return await interaction.followup.send(embed=embed, ephemeral=True)

        # Check ownership
        if vps_name not in user_vps and not is_admin:
            return await interaction.followup.send(
                embed=create_error_embed("Access Denied", f"You don't own a VPS named `{vps_name}`."),
                ephemeral=True,
            )

        # Fetch from DB
        hours  = {"24h": 24, "7d": 168, "30d": 720}[period]
        since  = (datetime.now() - timedelta(hours=hours)).isoformat()
        cur    = get_db().cursor()
        cur.execute(
            "SELECT cpu_pct, ram_pct, disk_pct, sampled_at FROM usage_history "
            "WHERE container_name=? AND sampled_at >= ? ORDER BY sampled_at ASC",
            (vps_name, since),
        )
        rows = cur.fetchall()

        if not rows:
            embed = discord.Embed(
                title=f"📊 Usage History — `{vps_name}`",
                description=(
                    f"No data recorded for the last **{period}**.\n\n"
                    "Usage data is sampled every 5 minutes when the VPS is running.\n"
                    "*If your VPS was stopped during this period, no data will appear.*"
                ),
                color=Theme.WARNING,
            )
            embed.set_footer(text="MoonNodes · Usage")
            return await interaction.followup.send(embed=embed, ephemeral=True)

        cpu_vals  = [r["cpu_pct"]  for r in rows]
        ram_vals  = [r["ram_pct"]  for r in rows]
        disk_vals = [r["disk_pct"] for r in rows]

        def _stats(vals: list) -> str:
            return f"avg {sum(vals)/len(vals):.1f}% · peak {max(vals):.1f}% · low {min(vals):.1f}%"

        embed = discord.Embed(
            title=f"📊 Usage History — `{vps_name}`",
            description=f"**{len(rows)}** samples over the last **{period}**",
            color=Theme.PRIMARY,
            timestamp=datetime.now(),
        )
        embed.set_author(name="MoonNodes · Usage", icon_url="https://imgur.com/6yfYDTP.png")
        embed.add_field(
            name="💠 CPU Usage",
            value=f"{_sparkline(cpu_vals)}\n{_stats(cpu_vals)}",
            inline=False,
        )
        embed.add_field(
            name="🧬 RAM Usage",
            value=f"{_sparkline(ram_vals)}\n{_stats(ram_vals)}",
            inline=False,
        )
        embed.add_field(
            name="💾 Disk Usage",
            value=f"{_sparkline(disk_vals)}\n{_stats(disk_vals)}",
            inline=False,
        )
        first_ts = datetime.fromisoformat(rows[0]["sampled_at"])
        last_ts  = datetime.fromisoformat(rows[-1]["sampled_at"])
        embed.set_footer(
            text=f"MoonNodes · {first_ts.strftime('%b %d %H:%M')} → {last_ts.strftime('%b %d %H:%M')}"
        )
        await interaction.followup.send(embed=embed, ephemeral=True)


async def setup(bot):
    await bot.add_cog(HistoryCog(bot))
