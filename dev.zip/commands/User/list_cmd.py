import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock
from core.theme import create_embed, create_error_embed, create_info_embed, add_field, Theme


def is_admin(uid):
    return str(uid) == str(MAIN_ADMIN_ID) or admin_data.get(str(uid)) in ("Owner", "Admin", "Dev", "Mod")


class ListCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="list", description="View your VPS instances — admins can use action:All to see everyone's")
    @app_commands.choices(action=[
        app_commands.Choice(name="My VPS — Show only your VPS",      value="mine"),
        app_commands.Choice(name="All VPS — View all users (Admin)", value="all"),
    ])
    @app_commands.describe(action="What to list (default: your own VPS)")
    async def list_cmd(self, interaction: discord.Interaction, action: str = "mine"):
        await interaction.response.defer(ephemeral=(action == "all"))

        uid = str(interaction.user.id)

        # ── All VPS (admin only) ─────────────────────────────────────────────
        if action == "all":
            if not is_admin(uid):
                return await interaction.followup.send(
                    embed=create_error_embed("Access Denied", "Only admins can view all VPS instances."),
                    ephemeral=True,
                )
            with data_lock:
                snapshot = dict(vps_data)

            total   = sum(len(v) for v in snapshot.values())
            running = sum(1 for lst in snapshot.values() for v in lst if v.get("status") == "running")
            susp    = sum(1 for lst in snapshot.values() for v in lst if v.get("suspended"))

            embed = discord.Embed(
                title="🌐  All VPS — Network Overview",
                description=(
                    f"{Theme.DIVIDER}\n"
                    f"**{total}** total · **{running}** running · **{susp}** suspended\n"
                    f"{Theme.DIVIDER}"
                ),
                color=Theme.PRIMARY, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")

            chunks = []
            for owner_uid, vps_list in snapshot.items():
                member = interaction.guild.get_member(int(owner_uid))
                name   = member.display_name if member else f"<@{owner_uid}>"
                for i, vps in enumerate(vps_list, 1):
                    suspended = vps.get("suspended", False)
                    status    = vps.get("status", "stopped")
                    icon      = "⛔" if suspended else ("🟢" if status == "running" else "🔴")
                    exp       = ""
                    if vps.get("expiry"):
                        try:
                            ts  = int(datetime.fromisoformat(vps["expiry"]).timestamp())
                            exp = f" · <t:{ts}:R>"
                        except Exception:
                            pass
                    chunks.append(
                        f"{icon} **{name}** — `{vps['container_name']}` · {vps.get('config','?')} "
                        f"· {vps.get('node','local')}{exp}"
                    )

            # Split into fields of max 1024 chars
            batch, current = [], ""
            for line in chunks:
                if len(current) + len(line) + 1 > 1024:
                    batch.append(current.strip())
                    current = ""
                current += line + "\n"
            if current:
                batch.append(current.strip())

            for idx, block in enumerate(batch[:5], 1):
                embed.add_field(name=f"VPS List (Part {idx})", value=block or "*empty*", inline=False)

            if len(batch) > 5:
                embed.set_footer(text=f"Showing first 5 blocks of {len(batch)} total")
            return await interaction.followup.send(embed=embed)

        # ── My VPS (user) ────────────────────────────────────────────────────
        with data_lock:
            vps_list = list(vps_data.get(uid, []))

        if not vps_list:
            return await interaction.followup.send(
                embed=create_info_embed(
                "No VPS Found",
                "You don't have any VPS instances yet.\n\n"
                "**Get started:**\n"
                "› `/plans` — Browse available plans\n"
                "› `/claim` — Claim a free or premium VPS\n"
                "› `/marketplace pick_one:Buy` — Buy from the marketplace"
            )
            )

        embed = discord.Embed(
            title="🖥️  Your VPS Instances",
            description=f"{Theme.DIVIDER}\nYou have **{len(vps_list)}** VPS instance(s)\n{Theme.DIVIDER}",
            color=Theme.PRIMARY, timestamp=datetime.now(),
        )
        embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
        embed.set_thumbnail(url=interaction.user.display_avatar.url)

        for i, vps in enumerate(vps_list, 1):
            status    = vps.get("status", "stopped")
            suspended = vps.get("suspended", False)
            icon      = "⛔" if suspended else ("🟢" if status == "running" else "🔴")
            node      = vps.get("node", "local")

            exp_text = ""
            if vps.get("expiry"):
                try:
                    ts       = int(datetime.fromisoformat(vps["expiry"]).timestamp())
                    exp_text = f"\n⏳ Expires: <t:{ts}:R>"
                except Exception:
                    pass

            shared = vps.get("shared_with", [])
            share_text = f"\n🤝 Shared with {len(shared)} user(s)" if shared else ""

            embed.add_field(
                name=f"{icon}  VPS #{i} — `{vps['container_name']}`",
                value=(
                    f"**Status:** `{'SUSPENDED' if suspended else status.upper()}`\n"
                    f"**Specs:** {vps.get('config','?')}\n"
                    f"**Node:** `{node}`\n"
                    f"**OS:** {vps.get('os_version','?')}"
                    f"{exp_text}{share_text}"
                ),
                inline=True,
            )

        embed.set_footer(text="Use /manage to control your VPS")
        await interaction.followup.send(embed=embed)


async def setup(bot):
    await bot.add_cog(ListCog(bot))
