"""
/marketplace — Buy and sell VPS instances between users.
Requires MARKETPLACE=True in .env.
"""

import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MARKETPLACE, MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock, get_db, get_setting, set_setting
from core.theme import (
    create_embed, create_success_embed, create_error_embed,
    create_info_embed, create_warning_embed, add_field, Theme,
)


def _get_listings() -> list:
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS marketplace (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            seller_id TEXT NOT NULL,
            sell_name TEXT UNIQUE NOT NULL,
            container_name TEXT NOT NULL,
            price TEXT NOT NULL,
            price_type TEXT NOT NULL,
            validity TEXT,
            listed_at TEXT NOT NULL,
            active INTEGER DEFAULT 1
        )
    """)
    conn.commit()
    cur.execute("SELECT * FROM marketplace WHERE active=1 ORDER BY listed_at DESC")
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


def _get_listing(sell_name: str) -> dict | None:
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("SELECT * FROM marketplace WHERE sell_name=? AND active=1", (sell_name,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def _create_listing(seller_id, sell_name, container_name, price, price_type, validity):
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS marketplace (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            seller_id TEXT NOT NULL,
            sell_name TEXT UNIQUE NOT NULL,
            container_name TEXT NOT NULL,
            price TEXT NOT NULL,
            price_type TEXT NOT NULL,
            validity TEXT,
            listed_at TEXT NOT NULL,
            active INTEGER DEFAULT 1
        )
    """)
    cur.execute("""
        INSERT INTO marketplace (seller_id, sell_name, container_name, price, price_type, validity, listed_at)
        VALUES (?,?,?,?,?,?,?)
    """, (seller_id, sell_name, container_name, price, price_type, validity, datetime.now().isoformat()))
    conn.commit()
    conn.close()


def _delete_listing(sell_name: str):
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("UPDATE marketplace SET active=0 WHERE sell_name=?", (sell_name,))
    conn.commit()
    conn.close()


def _spend_coins(user_id: str, amount: int):
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (user_id,))
    cur.execute("UPDATE users SET mooncoin = mooncoin - ? WHERE user_id=?", (amount, user_id))
    conn.commit()
    conn.close()


def _add_coins(user_id: str, amount: int):
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (user_id,))
    cur.execute("UPDATE users SET mooncoin = mooncoin + ? WHERE user_id=?", (amount, user_id))
    conn.commit()
    conn.close()


def _get_coins(user_id: str) -> int:
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("SELECT mooncoin FROM users WHERE user_id=?", (user_id,))
    row = cur.fetchone()
    conn.close()
    return row["mooncoin"] if row else 0


def _get_invites(user_id: str) -> int:
    conn = get_db()
    cur  = conn.cursor()
    cur.execute("SELECT invites_used FROM users WHERE user_id=?", (user_id,))
    row = cur.fetchone()
    conn.close()
    return row["invites_used"] if row else 0


class MarketplaceCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="marketplace", description="Buy, sell, or browse VPS listings")
    @app_commands.choices(pick_one=[
        app_commands.Choice(name="📋 List",       value="list"),
        app_commands.Choice(name="💰 Sell",       value="sell"),
        app_commands.Choice(name="🛒 Buy",        value="buy"),
        app_commands.Choice(name="✏️ Edit",       value="edit"),
        app_commands.Choice(name="🗑️ Remove",     value="remove"),
        app_commands.Choice(name="💳 Payment",    value="payment"),
    ])
    @app_commands.choices(price_type=[
        app_commands.Choice(name="🌙 MoonCoins", value="coin"),
        app_commands.Choice(name="📨 Invites",   value="inv"),
        app_commands.Choice(name="💵 Real Money",value="real"),
    ])
    @app_commands.describe(
        pick_one    = "What you want to do",
        sell_name   = "Listing name (unique slug, e.g. 'my-vps-sale')",
        vps_number  = "Your VPS number to sell (from /list)",
        price       = "Price amount (e.g. 500 for coins, 150 for money)",
        price_type  = "Currency: MoonCoins, Invites, or Real Money",
        validity    = "How long the VPS is valid for (e.g. '30 Days')",
        user        = "Seller's Discord user (for Buy)",
        new_name    = "New listing name (for Edit)",
        new_price   = "New price (for Edit)",
        payment_name= "Payment method name (for Payment action)",
        image       = "QR code image (for Payment action)",
        pay_action  = "Add/Edit or Remove payment method",
    )
    async def marketplace_cmd(
        self,
        interaction: discord.Interaction,
        pick_one: str,
        sell_name: str = None,
        vps_number: int = None,
        price: str = None,
        price_type: str = None,
        validity: str = None,
        user: discord.Member = None,
        new_name: str = None,
        new_price: str = None,
        payment_name: str = None,
        image: discord.Attachment = None,
        pay_action: str = None,
    ):
        await interaction.response.defer(ephemeral=(pick_one != "list"))

        if not MARKETPLACE:
            return await interaction.followup.send(
                embed=create_error_embed("Disabled", "The marketplace is currently disabled by the server owner."),
                ephemeral=True,
            )

        uid = str(interaction.user.id)

        # ── LIST ─────────────────────────────────────────────────────────────
        if pick_one == "list":
            listings = _get_listings()
            if not listings:
                return await interaction.followup.send(
                    embed=create_info_embed("No Listings", "The marketplace is empty. Be the first to sell a VPS with `/marketplace pick_one:Sell`!")
                )

            embed = discord.Embed(
                title="🛒  MoonNodes Marketplace",
                description=f"**{len(listings)}** active listing(s). Use `/marketplace pick_one:Buy` to purchase.",
                color=Theme.PRIMARY,
                timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
            embed.set_footer(text="Prices shown as listed by sellers")

            for lst in listings[:9]:  # max 9 to stay under field limit
                seller = interaction.guild.get_member(int(lst["seller_id"]))
                s_name = seller.display_name if seller else f"<@{lst['seller_id']}>"
                icons  = {"coin": "🌙", "inv": "📨", "real": "💵"}
                icon   = icons.get(lst["price_type"], "💰")
                embed.add_field(
                    name=f"🔖 {lst['sell_name']}",
                    value=(
                        f"**Container:** `{lst['container_name']}`\n"
                        f"**Price:** {icon} `{lst['price']}` ({lst['price_type']})\n"
                        f"**Validity:** {lst.get('validity') or 'Permanent'}\n"
                        f"**Seller:** {s_name}"
                    ),
                    inline=True,
                )
            return await interaction.followup.send(embed=embed)

        # ── SELL ─────────────────────────────────────────────────────────────
        elif pick_one == "sell":
            if not sell_name or vps_number is None or not price or not price_type:
                return await interaction.followup.send(
                    embed=create_error_embed("Missing Fields", "Required: `sell_name`, `vps_number`, `price`, `price_type`")
                )

            with data_lock:
                user_vps = vps_data.get(uid, [])
            if vps_number < 1 or vps_number > len(user_vps):
                return await interaction.followup.send(
                    embed=create_error_embed("Invalid VPS", f"VPS #{vps_number} not found. Use `/list` to see your VPS.")
                )

            vps      = user_vps[vps_number - 1]
            existing = _get_listing(sell_name)
            if existing:
                return await interaction.followup.send(
                    embed=create_error_embed("Name Taken", f"A listing named `{sell_name}` already exists.")
                )

            _create_listing(uid, sell_name, vps["container_name"], price, price_type, validity)
            embed = create_success_embed(
                "VPS Listed ✅",
                f"Your VPS `{vps['container_name']}` is now listed as **{sell_name}**."
            )
            add_field(embed, "Price",    f"{price} ({price_type})",       True)
            add_field(embed, "Validity", validity or "Permanent",          True)
            add_field(embed, "Note",
                "Buyers will contact you through the marketplace. "
                "Remove your listing anytime with `/marketplace pick_one:Remove`.", False)
            return await interaction.followup.send(embed=embed)

        # ── BUY ──────────────────────────────────────────────────────────────
        elif pick_one == "buy":
            if not sell_name or not user:
                return await interaction.followup.send(
                    embed=create_error_embed("Missing Fields", "Required: `sell_name`, `user` (the seller)")
                )

            lst = _get_listing(sell_name)
            if not lst or lst["seller_id"] != str(user.id):
                return await interaction.followup.send(
                    embed=create_error_embed("Not Found", f"Listing `{sell_name}` not found or doesn't belong to {user.mention}.")
                )
            if lst["seller_id"] == uid:
                return await interaction.followup.send(embed=create_error_embed("Error", "You cannot buy your own listing."))

            icons  = {"coin": "🌙", "inv": "📨", "real": "💵"}
            icon   = icons.get(lst["price_type"], "💰")
            amount = lst["price"]

            # Handle coin payment
            if lst["price_type"] == "coin":
                try:
                    cost = int(amount)
                except ValueError:
                    return await interaction.followup.send(embed=create_error_embed("Error", "Invalid coin price format."))
                bal = _get_coins(uid)
                if bal < cost:
                    return await interaction.followup.send(
                        embed=create_error_embed("Insufficient Coins", f"You need **{cost:,}** 🌙 MoonCoins. You have **{bal:,}**.")
                    )
                _spend_coins(uid, cost)
                _add_coins(lst["seller_id"], cost)

            elif lst["price_type"] == "inv":
                try:
                    cost = int(amount)
                except ValueError:
                    return await interaction.followup.send(embed=create_error_embed("Error", "Invalid invite price format."))
                inv_bal = _get_invites(uid)
                if inv_bal < cost:
                    return await interaction.followup.send(
                        embed=create_error_embed("Insufficient Invites", f"You need **{cost}** invites. You have **{inv_bal}**.")
                    )

            elif lst["price_type"] == "real":
                # Real money: show payment methods and open a ticket
                pay_ch_id = get_setting("ticket_channel")
                embed = create_warning_embed(
                    "Real Money Purchase",
                    f"This listing costs **{icon} {amount}**.\n\n"
                    "To complete this purchase:\n"
                    "1. Open a support ticket with `/support`\n"
                    "2. Tell the staff you want to buy listing `{sell_name}` from {user.mention}\n"
                    "3. Staff will verify payment and transfer the VPS"
                )
                return await interaction.followup.send(embed=embed)

            # Mark listing as sold
            _delete_listing(sell_name)

            # Transfer VPS ownership in DB
            with data_lock:
                seller_vps = vps_data.get(lst["seller_id"], [])
                for i, v in enumerate(seller_vps):
                    if v["container_name"] == lst["container_name"]:
                        v2 = seller_vps.pop(i)
                        vps_data.setdefault(uid, []).append(v2)
                        break

            from core.database import save_vps_data
            save_vps_data()

            # Notify seller
            try:
                seller = await self.bot.fetch_user(int(lst["seller_id"]))
                dm = create_success_embed(
                    "Your VPS Was Sold! 🎉",
                    f"Listing **{sell_name}** (`{lst['container_name']}`) was purchased by {interaction.user.mention}.\n"
                    + (f"You received **{amount:,} 🌙 MoonCoins**." if lst["price_type"] == "coin" else "")
                )
                await seller.send(embed=dm)
            except Exception:
                pass

            embed = create_success_embed(
                "Purchase Successful! 🛒",
                f"You bought **{sell_name}** (`{lst['container_name']}`) from {user.mention}.\n"
                f"The VPS is now in your `/list`."
            )
            add_field(embed, "Paid", f"{icon} {amount}", True)
            return await interaction.followup.send(embed=embed)

        # ── EDIT ─────────────────────────────────────────────────────────────
        elif pick_one == "edit":
            if not sell_name:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `sell_name`."))
            lst = _get_listing(sell_name)
            if not lst or lst["seller_id"] != uid:
                return await interaction.followup.send(embed=create_error_embed("Not Found", "Listing not found or not yours."))

            conn = get_db()
            cur  = conn.cursor()
            if new_name:
                cur.execute("UPDATE marketplace SET sell_name=? WHERE sell_name=?", (new_name, sell_name))
            if new_price:
                cur.execute("UPDATE marketplace SET price=? WHERE sell_name=?", (new_price, new_name or sell_name))
            if validity:
                cur.execute("UPDATE marketplace SET validity=? WHERE sell_name=?", (validity, new_name or sell_name))
            conn.commit()
            conn.close()

            embed = create_success_embed("Listing Updated", f"Listing **{sell_name}** has been updated.")
            if new_name:   add_field(embed, "New Name",    new_name,  True)
            if new_price:  add_field(embed, "New Price",   new_price, True)
            if validity:   add_field(embed, "New Validity",validity,  True)
            return await interaction.followup.send(embed=embed)

        # ── REMOVE ───────────────────────────────────────────────────────────
        elif pick_one == "remove":
            if not sell_name:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `sell_name`."))
            lst = _get_listing(sell_name)
            is_admin = admin_data.get(uid) in ("Owner", "Admin") or uid == str(MAIN_ADMIN_ID)
            if not lst or (lst["seller_id"] != uid and not is_admin):
                return await interaction.followup.send(embed=create_error_embed("Not Found", "Listing not found or not yours."))
            _delete_listing(sell_name)
            return await interaction.followup.send(embed=create_success_embed("Removed", f"Listing **{sell_name}** has been removed from the marketplace."))

        # ── PAYMENT ──────────────────────────────────────────────────────────
        elif pick_one == "payment":
            is_admin = admin_data.get(uid) in ("Owner", "Admin") or uid == str(MAIN_ADMIN_ID)
            if not is_admin:
                return await interaction.followup.send(embed=create_error_embed("Denied", "Only admins can manage payment methods."))

            if pay_action in (None, "add", "Add/Edit") and payment_name and image:
                conn = get_db()
                cur  = conn.cursor()
                cur.execute("INSERT OR REPLACE INTO payments (name, image_url) VALUES (?,?)", (payment_name, image.url))
                conn.commit()
                conn.close()
                return await interaction.followup.send(embed=create_success_embed("Payment Saved", f"**{payment_name}** added/updated."))
            elif pay_action == "remove" and payment_name:
                conn = get_db()
                cur  = conn.cursor()
                cur.execute("DELETE FROM payments WHERE name=?", (payment_name,))
                conn.commit()
                conn.close()
                return await interaction.followup.send(embed=create_success_embed("Removed", f"**{payment_name}** removed."))
            else:
                return await interaction.followup.send(
                    embed=create_info_embed("Payment Help",
                        "Use `/marketplace pick_one:Payment pay_action:Add/Edit payment_name: image:` to add.\n"
                        "Use `/marketplace pick_one:Payment pay_action:remove payment_name:` to remove.")
                )


async def setup(bot):
    await bot.add_cog(MarketplaceCog(bot))
