"""
/marketplace — Buy, sell, and browse VPS listings.
Supports MoonCoins, Invites, and Real Money transactions.
"""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MAIN_ADMIN_ID
from core.ext import marketplace_enabled, ext_disabled_embed
from core.database import admin_data, vps_data, data_lock, get_db, get_setting, save_vps_data
from core.theme import Theme, add_field, create_embed, create_error_embed, create_info_embed, create_success_embed, create_warning_embed


PRICE_ICONS = {"coin": "🌙", "inv": "📨", "real": "💵"}


def _is_admin(uid):
    return str(uid) == str(MAIN_ADMIN_ID) or admin_data.get(str(uid)) in ("Owner", "Admin")


def _init_table(cur):
    cur.execute("""CREATE TABLE IF NOT EXISTS marketplace (
        id             INTEGER PRIMARY KEY AUTOINCREMENT,
        seller_id      TEXT    NOT NULL,
        sell_name      TEXT    UNIQUE NOT NULL,
        container_name TEXT    NOT NULL,
        price          TEXT    NOT NULL,
        price_type     TEXT    NOT NULL,
        validity       TEXT,
        description    TEXT,
        listed_at      TEXT    NOT NULL,
        active         INTEGER DEFAULT 1
    )""")


def _get_listings(active_only=True):
    conn = get_db(); cur = conn.cursor()
    _init_table(cur); conn.commit()
    if active_only:
        cur.execute("SELECT * FROM marketplace WHERE active=1 ORDER BY listed_at DESC")
    else:
        cur.execute("SELECT * FROM marketplace ORDER BY listed_at DESC")
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


def _get_listing(sell_name):
    conn = get_db(); cur = conn.cursor()
    _init_table(cur); conn.commit()
    cur.execute("SELECT * FROM marketplace WHERE sell_name=? AND active=1", (sell_name,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def _db_coins(uid):
    conn = get_db(); cur = conn.cursor()
    cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (uid,)); conn.commit()
    cur.execute("SELECT mooncoin FROM users WHERE user_id=?", (uid,)); row = cur.fetchone(); conn.close()
    return row["mooncoin"] if row else 0


def _mod_coins(uid, delta):
    conn = get_db(); cur = conn.cursor()
    cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (uid,)); conn.commit()
    cur.execute("UPDATE users SET mooncoin=MAX(0,mooncoin+?) WHERE user_id=?", (delta, uid)); conn.commit(); conn.close()


def _listing_embed(lst: dict, guild: discord.Guild = None) -> discord.Embed:
    """Build a rich embed for a single listing."""
    icon    = PRICE_ICONS.get(lst.get("price_type","coin"), "💰")
    seller  = guild.get_member(int(lst["seller_id"])) if guild else None
    s_name  = seller.display_name if seller else f"<@{lst['seller_id']}>"
    listed  = datetime.fromisoformat(lst["listed_at"]).strftime("%b %d, %Y")
    embed   = discord.Embed(
        title=f"🔖  {lst['sell_name']}",
        description=lst.get("description") or "No description provided.",
        color=Theme.PRIMARY,
    )
    embed.set_author(name="MoonNodes Marketplace", icon_url=Theme.ICON_URL)
    embed.add_field(name="📦  Container", value=f"`{lst['container_name']}`", inline=True)
    embed.add_field(name="💰  Price",     value=f"{icon} **{lst['price']}** ({lst['price_type']})", inline=True)
    embed.add_field(name="⏳  Validity",  value=lst.get("validity") or "Permanent", inline=True)
    embed.add_field(name="👤  Seller",    value=s_name,  inline=True)
    embed.add_field(name="📅  Listed",    value=listed,  inline=True)
    embed.set_footer(text="Use /marketplace pick_one:Buy to purchase")
    return embed


class MarketplaceCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="marketplace", description="Buy, sell, and browse VPS listings")
    @app_commands.choices(pick_one=[
        app_commands.Choice(name="📋 Browse — View all active VPS listings",           value="list"),
        app_commands.Choice(name="🔍 View — See details of one listing",              value="view"),
        app_commands.Choice(name="💰 Sell — List your VPS for sale",                  value="sell"),
        app_commands.Choice(name="🛒 Buy — Purchase a listed VPS",                    value="buy"),
        app_commands.Choice(name="✏️ Edit — Change your listing's price or name",     value="edit"),
        app_commands.Choice(name="🗑️ Remove — Take your listing down",                value="remove"),
        app_commands.Choice(name="💳 Payment — Manage accepted payment methods",      value="payment"),
        app_commands.Choice(name="📊 My Listings — See listings you've posted",       value="mine"),
    ])
    @app_commands.choices(price_type=[
        app_commands.Choice(name="🌙 MoonCoins",  value="coin"),
        app_commands.Choice(name="📨 Invites",    value="inv"),
        app_commands.Choice(name="💵 Real Money", value="real"),
    ])
    @app_commands.choices(pay_action=[
        app_commands.Choice(name="➕ Add / Edit payment method", value="add"),
        app_commands.Choice(name="🗑️ Remove payment method",    value="remove"),
        app_commands.Choice(name="📋 List payment methods",     value="list"),
    ])
    @app_commands.describe(
        pick_one    ="What you want to do",
        sell_name   ="Listing slug — unique ID for your listing (e.g. fast-vps-sale)",
        vps_number  ="Your VPS number from /list (for Sell)",
        price       ="Price amount (e.g. 500 for coins, 10 for invites, 150 for real money)",
        price_type  ="Currency type: MoonCoins, Invites, or Real Money",
        validity    ="How long the VPS is valid for (e.g. 30 Days)",
        description ="Short description shown in the listing",
        user        ="Seller's Discord user — required for Buy",
        new_name    ="New listing slug (for Edit)",
        new_price   ="New price amount (for Edit)",
        payment_name="Payment method name (for Payment action)",
        image       ="Payment QR code or logo image",
        pay_action  ="Add, remove, or list payment methods",
    )
    async def marketplace_cmd(
        self, interaction: discord.Interaction,
        pick_one:     str,
        sell_name:    str = None,
        vps_number:   int = None,
        price:        str = None,
        price_type:   str = None,
        validity:     str = None,
        description:  str = None,
        user:         discord.Member = None,
        new_name:     str = None,
        new_price:    str = None,
        payment_name: str = None,
        image:        discord.Attachment = None,
        pay_action:   str = None,
    ):
        await interaction.response.defer(ephemeral=(pick_one not in ("list", "view", "mine")))

        if not marketplace_enabled():
            return await interaction.followup.send(embed=ext_disabled_embed("Marketplace", "MARKETPLACE"))

        uid = str(interaction.user.id)

        # ── BROWSE ───────────────────────────────────────────────────────────
        if pick_one == "list":
            listings = _get_listings()
            if not listings:
                return await interaction.followup.send(embed=create_info_embed(
                    "🛒  Marketplace is Empty",
                    "No VPS listings right now.\n\nBe the first to list yours with `/marketplace pick_one:Sell`!"
                ))

            embed = discord.Embed(
                title="🛒  MoonNodes Marketplace",
                description=(
                    f"{Theme.DIVIDER}\n"
                    f"**{len(listings)}** active listing(s)\n"
                    f"{Theme.DIVIDER}"
                ),
                color=Theme.PRIMARY, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes Marketplace", icon_url=Theme.ICON_URL)

            for lst in listings[:8]:
                icon   = PRICE_ICONS.get(lst.get("price_type","coin"), "💰")
                seller = interaction.guild.get_member(int(lst["seller_id"])) if interaction.guild else None
                s_name = seller.display_name if seller else f"<@{lst['seller_id']}>"
                embed.add_field(
                    name=f"🔖  {lst['sell_name']}",
                    value=(
                        f"📦 `{lst['container_name']}`\n"
                        f"{icon} **{lst['price']}** ({lst['price_type']})\n"
                        f"⏳ {lst.get('validity') or 'Permanent'} · 👤 {s_name}"
                    ),
                    inline=True,
                )

            if len(listings) > 8:
                embed.set_footer(text=f"Showing 8 of {len(listings)} listings · Use /marketplace pick_one:View sell_name: for details")
            else:
                embed.set_footer(text="Use /marketplace pick_one:View sell_name: to see full details")

            methods = []
            try:
                conn = get_db(); cur = conn.cursor()
                cur.execute("SELECT name FROM payments"); methods = [r["name"] for r in cur.fetchall()]; conn.close()
            except Exception: pass
            if methods:
                embed.add_field(name="💳  Accepted Payment", value=" · ".join(methods), inline=False)

            return await interaction.followup.send(embed=embed)

        # ── VIEW ─────────────────────────────────────────────────────────────
        elif pick_one == "view":
            if not sell_name:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Provide a `sell_name`."))
            lst = _get_listing(sell_name)
            if not lst:
                return await interaction.followup.send(embed=create_error_embed("Not Found", f"No listing named `{sell_name}`."))
            return await interaction.followup.send(embed=_listing_embed(lst, interaction.guild))

        # ── MY LISTINGS ───────────────────────────────────────────────────────
        elif pick_one == "mine":
            all_lst = _get_listings()
            mine    = [l for l in all_lst if l["seller_id"] == uid]
            if not mine:
                return await interaction.followup.send(embed=create_info_embed("No Listings", "You have no active listings. Use `/marketplace pick_one:Sell` to add one."))
            embed = discord.Embed(title="📦  Your Listings", color=Theme.PRIMARY, timestamp=datetime.now())
            embed.set_author(name="MoonNodes Marketplace", icon_url=Theme.ICON_URL)
            for lst in mine:
                icon = PRICE_ICONS.get(lst.get("price_type","coin"), "💰")
                embed.add_field(
                    name=f"🔖 {lst['sell_name']}",
                    value=f"📦 `{lst['container_name']}`\n{icon} {lst['price']} ({lst['price_type']})\n⏳ {lst.get('validity') or 'Permanent'}",
                    inline=True,
                )
            return await interaction.followup.send(embed=embed)

        # ── SELL ─────────────────────────────────────────────────────────────
        elif pick_one == "sell":
            if not all([sell_name, vps_number, price, price_type]):
                return await interaction.followup.send(embed=create_error_embed(
                    "Missing Fields",
                    "Required: `sell_name`, `vps_number`, `price`, `price_type`\n\n"
                    "**Example:** `/marketplace pick_one:Sell sell_name:my-vps vps_number:1 price:500 price_type:coin`"
                ))
            with data_lock:
                user_vps = vps_data.get(uid, [])
            if vps_number < 1 or vps_number > len(user_vps):
                return await interaction.followup.send(embed=create_error_embed("Invalid VPS", f"VPS #{vps_number} not found. Use `/list` to see your VPS."))
            if _get_listing(sell_name):
                return await interaction.followup.send(embed=create_error_embed("Name Taken", f"A listing named `{sell_name}` already exists. Choose a different name."))

            vps_entry = user_vps[vps_number - 1]
            conn = get_db(); cur = conn.cursor()
            _init_table(cur)
            cur.execute(
                "INSERT INTO marketplace (seller_id,sell_name,container_name,price,price_type,validity,description,listed_at) VALUES (?,?,?,?,?,?,?,?)",
                (uid, sell_name, vps_entry["container_name"], price, price_type, validity, description, datetime.now().isoformat())
            )
            conn.commit(); conn.close()

            embed = create_success_embed(
                "VPS Listed! 🎉",
                f"Your VPS **`{vps_entry['container_name']}`** is now listed as **{sell_name}**."
            )
            embed.add_field(name="💰 Price",    value=f"{PRICE_ICONS.get(price_type,'💰')} {price} ({price_type})", inline=True)
            embed.add_field(name="⏳ Validity", value=validity or "Permanent",  inline=True)
            if description:
                embed.add_field(name="📝 Description", value=description, inline=False)
            embed.add_field(name="💡 Tip", value="Buyers will be notified when they purchase. Use `/marketplace pick_one:Edit` to update the price anytime.", inline=False)
            return await interaction.followup.send(embed=embed)

        # ── BUY ──────────────────────────────────────────────────────────────
        elif pick_one == "buy":
            if not sell_name or not user:
                return await interaction.followup.send(embed=create_error_embed("Missing Fields", "Required: `sell_name`, `user` (the seller)"))
            lst = _get_listing(sell_name)
            if not lst or lst["seller_id"] != str(user.id):
                return await interaction.followup.send(embed=create_error_embed("Not Found", f"Listing `{sell_name}` not found or doesn't belong to {user.mention}."))
            if lst["seller_id"] == uid:
                return await interaction.followup.send(embed=create_error_embed("Can't Buy Your Own", "You cannot purchase your own listing."))

            icon = PRICE_ICONS.get(lst["price_type"], "💰")

            if lst["price_type"] == "coin":
                try: cost = int(lst["price"])
                except ValueError:
                    return await interaction.followup.send(embed=create_error_embed("Invalid Price", "The listing has an invalid coin price."))
                bal = _db_coins(uid)
                if bal < cost:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Insufficient Coins",
                        f"You need **{cost:,} 🌙 MoonCoins** but only have **{bal:,}**.\n"
                        "Earn more by inviting friends, chatting, or joining events!"
                    ))
                _mod_coins(uid, -cost)
                _mod_coins(lst["seller_id"], cost)

            elif lst["price_type"] == "inv":
                return await interaction.followup.send(embed=create_warning_embed(
                    "Invite Payment",
                    "This listing uses Invite payment. Contact the seller to arrange the transfer."
                ))
            elif lst["price_type"] == "real":
                return await interaction.followup.send(embed=create_warning_embed(
                    "Real Money Purchase",
                    f"This listing costs **{icon} {lst['price']}** (real money).\n\n"
                    "**To purchase:**\n"
                    "1. Open a support ticket with `/support`\n"
                    "2. Tell staff you want to buy listing `" + sell_name + "` from " + user.mention + "\n"
                    "3. Complete payment via the accepted methods\n"
                    "4. Staff will transfer the VPS to you"
                ))

            # Transfer VPS
            conn = get_db(); cur = conn.cursor()
            cur.execute("UPDATE marketplace SET active=0 WHERE sell_name=?", (sell_name,))
            conn.commit(); conn.close()

            old_cname = lst["container_name"]
            with data_lock:
                seller_vps = vps_data.get(lst["seller_id"], [])
                for i, v in enumerate(seller_vps):
                    if v["container_name"] == old_cname:
                        transferred = seller_vps.pop(i)
                        vps_data.setdefault(uid, []).append(transferred)
                        break
            save_vps_data()

            # DM seller
            try:
                dm = discord.Embed(title="💰  Your VPS Was Sold!", color=0xFFD700, timestamp=datetime.now())
                dm.description = (
                    f"Listing **{sell_name}** (`{old_cname}`) was purchased by {interaction.user.mention}!\n\n"
                    + (f"You received **{int(lst['price']):,} 🌙 MoonCoins**." if lst["price_type"] == "coin" else "")
                )
                dm.set_author(name="MoonNodes Marketplace", icon_url=Theme.ICON_URL)
                await user.send(embed=dm)
            except Exception: pass

            embed = create_success_embed(
                "Purchase Complete! 🛒",
                f"You bought **{sell_name}** (`{old_cname}`) from {user.mention}.\nThe VPS is now in your `/list`!"
            )
            embed.add_field(name="Paid", value=f"{icon} {lst['price']}", inline=True)
            return await interaction.followup.send(embed=embed)

        # ── EDIT ─────────────────────────────────────────────────────────────
        elif pick_one == "edit":
            if not sell_name:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `sell_name`."))
            lst = _get_listing(sell_name)
            if not lst or (lst["seller_id"] != uid and not _is_admin(uid)):
                return await interaction.followup.send(embed=create_error_embed("Not Found", "Listing not found or you don't own it."))

            conn = get_db(); cur = conn.cursor()
            changes = []
            if new_name   and new_name   != sell_name:
                cur.execute("UPDATE marketplace SET sell_name=?  WHERE sell_name=?", (new_name, sell_name))
                changes.append(f"Name → **{new_name}**")
            if new_price:
                cur.execute("UPDATE marketplace SET price=?      WHERE sell_name=?", (new_price, new_name or sell_name))
                changes.append(f"Price → **{new_price}**")
            if validity:
                cur.execute("UPDATE marketplace SET validity=?   WHERE sell_name=?", (validity, new_name or sell_name))
                changes.append(f"Validity → **{validity}**")
            if description:
                cur.execute("UPDATE marketplace SET description=? WHERE sell_name=?", (description, new_name or sell_name))
                changes.append("Description updated")
            conn.commit(); conn.close()

            if not changes:
                return await interaction.followup.send(embed=create_warning_embed("Nothing Changed", "Provide at least one field to update."))
            embed = create_success_embed("Listing Updated", f"**{sell_name}** has been updated:\n" + "\n".join(f"• {c}" for c in changes))
            return await interaction.followup.send(embed=embed)

        # ── REMOVE ───────────────────────────────────────────────────────────
        elif pick_one == "remove":
            if not sell_name:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `sell_name`."))
            lst = _get_listing(sell_name)
            if not lst or (lst["seller_id"] != uid and not _is_admin(uid)):
                return await interaction.followup.send(embed=create_error_embed("Not Found", "Listing not found or you don't own it."))
            conn = get_db(); cur = conn.cursor()
            cur.execute("UPDATE marketplace SET active=0 WHERE sell_name=?", (sell_name,))
            conn.commit(); conn.close()
            return await interaction.followup.send(embed=create_success_embed("Listing Removed", f"**{sell_name}** has been taken down from the marketplace."))

        # ── PAYMENT ──────────────────────────────────────────────────────────
        elif pick_one == "payment":
            if not _is_admin(uid):
                return await interaction.followup.send(embed=create_error_embed("Denied", "Only admins can manage payment methods."))

            conn = get_db(); cur = conn.cursor()

            if pay_action == "list" or not pay_action:
                cur.execute("SELECT name, image_url FROM payments")
                rows = cur.fetchall(); conn.close()
                if not rows:
                    return await interaction.followup.send(embed=create_info_embed("No Payment Methods", "No methods saved yet. Use `pay_action:Add / Edit` to add one."))
                embed = create_embed("💳  Payment Methods", f"{len(rows)} method(s) configured.")
                for r in rows:
                    embed.add_field(name=r["name"], value=r["image_url"][:100], inline=True)
                return await interaction.followup.send(embed=embed)

            elif pay_action == "add":
                if not payment_name or not image:
                    conn.close()
                    return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `payment_name` and attach an `image`."))
                cur.execute("INSERT OR REPLACE INTO payments (name, image_url) VALUES (?,?)", (payment_name, image.url))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed("Payment Saved", f"**{payment_name}** added/updated."))

            elif pay_action == "remove":
                if not payment_name:
                    conn.close()
                    return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `payment_name`."))
                cur.execute("DELETE FROM payments WHERE name=?", (payment_name,))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed("Payment Removed", f"**{payment_name}** removed."))

            conn.close()


async def setup(bot):
    await bot.add_cog(MarketplaceCog(bot))
