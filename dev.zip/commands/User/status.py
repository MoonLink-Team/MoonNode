"""
/status — Live system status dashboard.

Shows:
  • Host CPU / RAM / Disk usage per node
  • VPS counts (running / stopped / suspended / total)
  • Bot uptime
  • Per-user: their own VPS quick-view
"""

import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime, timezone
import time

from core.config   import MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock, get_db
from core.theme    import Theme, create_embed, create_error_embed, add_field
from core.lang     import t, get_user_lang
from core.ratelimit import rate_limit

_BOT_START = time.monotonic()


def _fmt_uptime(seconds: float) -> str:
    s = int(seconds)
    d, s = divmod(s, 86400)
    h, s = divmod(s, 3600)
    m, s = divmod(s, 60)
    parts = []
    if d: parts.append(f"{d}d")
    if h: parts.append(f"{h}h")
    if m: parts.append(f"{m}m")
    parts.append(f"{s}s")
    return " ".join(parts)


def _fmt_bar(pct: float, width: int = 10) -> str:
    filled = round(pct / 100 * width)
    bar    = "█" * filled + "░" * (width - filled)
    emoji  = "🔴" if pct >= 90 else "🟡" if pct >= 70 else "🟢"
    return f"{emoji} `{bar}` {pct:.1f}%"


class StatusCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="status", description="Live host stats · VPS counts · uptime")
    @app_commands.describe(ephemeral="Only show the result to you (default: True)")
    @rate_limit(seconds=15, admin_bypass=True)
    async def status_cmd(self, interaction: discord.Interaction, ephemeral: bool = True):
        await interaction.response.defer(ephemeral=ephemeral, thinking=True)

        uid  = str(interaction.user.id)
        lang = get_user_lang(uid)
        is_admin = (
            interaction.user.id == MAIN_ADMIN_ID
            or uid in admin_data
        )

        # ── VPS counts ────────────────────────────────────────────────────────
        total = running = stopped = suspended = 0
        user_vps_lines = []
        async with data_lock:
            for owner_uid, lst in vps_data.items():
                for vps in lst:
                    total += 1
                    st = vps.get("status", "stopped")
                    if vps.get("suspended"):
                        suspended += 1
                    elif st == "running":
                        running += 1
                    else:
                        stopped += 1
                    # Collect user's own VPS
                    if owner_uid == uid:
                        name   = vps.get("container_name", "?")
                        status = "🔴 Suspended" if vps.get("suspended") else ("🟢 Running" if st == "running" else "⚫ Stopped")
                        exp    = vps.get("expiry")
                        exp_s  = f"<t:{int(datetime.fromisoformat(exp).timestamp())}:R>" if exp else "No expiry"
                        user_vps_lines.append(f"• **`{name}`** — {status} · expires {exp_s}")

        # ── Host stats via lxc ────────────────────────────────────────────────
        node_fields = []
        try:
            from core.lxc import get_host_cpu_pct, get_host_ram, get_host_disk, get_nodes as _get_nodes
        except ImportError:
            get_host_cpu_pct = get_host_ram = get_host_disk = None

        nodes = ["local"]
        try:
            from core.database import get_nodes as db_get_nodes
            nodes = db_get_nodes()
        except Exception:
            pass

        for node in nodes[:4]:  # max 4 nodes
            try:
                if get_host_cpu_pct:
                    cpu_pct  = await get_host_cpu_pct(node)
                    ram_info = await get_host_ram(node)
                    dsk_info = await get_host_disk(node)

                    # Parse percentages
                    import re
                    ram_pct = 0.0
                    dsk_pct = 0.0
                    m = re.search(r"\((\d+\.?\d*)%\)", str(ram_info))
                    if m: ram_pct = float(m.group(1))
                    m = re.search(r"\((\d+\.?\d*)%\)", str(dsk_info))
                    if m: dsk_pct = float(m.group(1))

                    node_fields.append((
                        f"{'🌐' if node != 'local' else '🖥️'} {node.capitalize()}",
                        f"CPU: {_fmt_bar(cpu_pct)}\nRAM: {_fmt_bar(ram_pct)}\nDisk: {_fmt_bar(dsk_pct)}",
                    ))
                else:
                    node_fields.append((f"🖥️ {node.capitalize()}", "*Host stats unavailable*"))
            except Exception:
                node_fields.append((f"🖥️ {node.capitalize()}", "❌ Could not reach node"))

        # ── Build embed ───────────────────────────────────────────────────────
        embed = discord.Embed(
            title=t("status_title", lang),
            color=Theme.PRIMARY,
            timestamp=datetime.now(),
        )
        embed.set_author(name="MoonNodes", icon_url=Theme.ICON_URL)

        # Host resources
        for name_f, val_f in node_fields:
            embed.add_field(name=name_f, value=val_f, inline=True)

        # VPS overview (admin sees all, user sees summary)
        if is_admin:
            embed.add_field(
                name=t("status_vps", lang),
                value=(
                    f"🟢 {t('status_running', lang)}: **{running}**\n"
                    f"⚫ {t('status_stopped', lang)}: **{stopped}**\n"
                    f"🔴 {t('status_suspended', lang)}: **{suspended}**\n"
                    f"📦 {t('status_total', lang)}: **{total}**"
                ),
                inline=True,
            )

        # Bot uptime
        embed.add_field(
            name=t("status_uptime", lang),
            value=f"`{_fmt_uptime(time.monotonic() - _BOT_START)}`",
            inline=True,
        )

        # User's own VPS
        if user_vps_lines:
            embed.add_field(
                name="🖥️ Your VPS",
                value="\n".join(user_vps_lines[:5]) or "*None*",
                inline=False,
            )
        elif not is_admin:
            embed.add_field(
                name="🖥️ Your VPS",
                value="No VPS yet. Use `/plans` to get one.",
                inline=False,
            )

        embed.set_footer(text=t("status_footer", lang))
        await interaction.followup.send(embed=embed, ephemeral=ephemeral)


async def setup(bot):
    await bot.add_cog(StatusCog(bot))
