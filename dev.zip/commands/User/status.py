import discord
from discord import app_commands
from discord.ext import commands

from core.monitoring import get_cpu_usage_async, get_ram_usage_async, get_uptime_async
from core.database import vps_data, data_lock
from core.theme import create_embed, add_field, Theme


class StatusCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="status", description="Check host node live stats and bot health")
    async def status_cmd(self, interaction: discord.Interaction):
        await interaction.response.defer()

        cpu_pct  = await get_cpu_usage_async()
        ram_pct  = await get_ram_usage_async()
        uptime   = await get_uptime_async()

        async with data_lock:
            total_vps   = sum(len(v) for v in vps_data.values())
            running_vps = sum(
                1 for lst in vps_data.values()
                for v in lst if v.get("status") == "running"
            )

        embed = create_embed("📡 Host Node Status", "Live resource metrics for the main server node.")
        add_field(embed, f"{Theme.CPU} CPU Usage",  Theme.progress_bar(cpu_pct),  False)
        add_field(embed, f"{Theme.RAM} RAM Usage",  Theme.progress_bar(ram_pct),  False)
        add_field(embed, "⏱️ Uptime",    f"`{uptime}`",                             True)
        add_field(embed, "🖥️ VPS Total", f"`{running_vps} running / {total_vps} total`", True)
        embed.set_footer(text="Stats refresh every command call • MoonNodes System")
        await interaction.followup.send(embed=embed)


async def setup(bot):
    await bot.add_cog(StatusCog(bot))
