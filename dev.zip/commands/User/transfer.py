import discord
from discord import app_commands
from discord.ext import commands

from core.config import MSTC
from core.database import vps_data, data_lock, save_vps_data, get_db
from core.theme import create_success_embed, create_error_embed


class TransferCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="transfer", description="Transfer your VPS to another user (optionally for credits)")
    @app_commands.describe(
        vps_number  = "Your VPS number (1, 2…)",
        target_user = "Who receives the VPS",
        price       = "Credit price (0 = free gift)",
    )
    async def transfer_vps(
        self, interaction: discord.Interaction,
        vps_number: int,
        target_user: discord.Member,
        price: int = 0,
    ):
        if not MSTC:
            return await interaction.response.send_message(
                embed=create_error_embed("Disabled", "Marketplace transfers are disabled."), ephemeral=True
            )
        await interaction.response.defer(ephemeral=True)
        uid = str(interaction.user.id)

        async with data_lock:
            if uid not in vps_data or vps_number < 1 or vps_number > len(vps_data[uid]):
                return await interaction.followup.send(embed=create_error_embed("Error", "Invalid VPS number."))

        if price > 0:
            conn = get_db()
            cur  = conn.cursor()
            cur.execute("SELECT credits FROM users WHERE user_id=?", (str(target_user.id),))
            row = cur.fetchone()
            if not row or row["credits"] < price:
                conn.close()
                return await interaction.followup.send(
                    embed=create_error_embed("Transfer Failed", f"{target_user.mention} doesn't have enough credits ({price}).")
                )
            cur.execute("UPDATE users SET credits = credits - ? WHERE user_id=?", (price, str(target_user.id)))
            cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (uid,))
            cur.execute("UPDATE users SET credits = credits + ? WHERE user_id=?", (price, uid))
            conn.commit()
            conn.close()

        async with data_lock:
            vps_obj = vps_data[uid].pop(vps_number - 1)
            if not vps_data[uid]:
                del vps_data[uid]
            tid = str(target_user.id)
            vps_data.setdefault(tid, []).append(vps_obj)

        await async_save_vps_data()
        await interaction.followup.send(
            embed=create_success_embed(
                "Transferred",
                f"VPS transferred to {target_user.mention}"
                + (f" for **{price} credits**." if price > 0 else " for free."),
            )
        )


async def setup(bot):
    await bot.add_cog(TransferCog(bot))
