"""
/backup — Create, list, and restore VPS snapshots.

Snapshot syntax fix for Incus ≥0.5:
  OLD (LXD):  lxc snapshot <container> <name>
  NEW (Incus): incus snapshot create <container> <name>
  Bot auto-detects and falls back gracefully.
"""
import time
import discord
from discord import app_commands
from discord.ext import commands

from core.ext import backup_limit_enabled
from core.config import UBL_LIMIT
from core.database import vps_data, data_lock
from core.lxc import execute_lxc, IS_INCUS
from core.theme import create_success_embed, create_error_embed, create_info_embed


async def _snap_create(full_name: str, snap_name: str) -> None:
    """Create snapshot using correct syntax for current runtime."""
    if IS_INCUS:
        try:
            await execute_lxc(f"incus snapshot create {full_name} {snap_name}", timeout=60)
            return
        except Exception as e:
            if "unknown command" in str(e).lower() or "unknown subcommand" in str(e).lower():
                pass  # fall through to old syntax
            else:
                raise
    # LXD or old Incus fallback
    await execute_lxc(f"lxc snapshot {full_name} {snap_name}", timeout=60)


async def _snap_restore(full_name: str, snap_name: str) -> None:
    """Restore snapshot using correct syntax for current runtime."""
    if IS_INCUS:
        try:
            await execute_lxc(f"incus snapshot restore {full_name} {snap_name}", timeout=120)
            return
        except Exception as e:
            if "unknown command" in str(e).lower():
                pass
            else:
                raise
    await execute_lxc(f"lxc restore {full_name} {snap_name}", timeout=120)


async def _snap_list(full_name: str) -> list:
    """Return list of backup snapshot names."""
    try:
        out = await execute_lxc(f"lxc info {full_name}")
        if out and out is not True:
            return [l.strip() for l in str(out).splitlines() if "backup-" in l]
    except Exception:
        pass
    return []


class BackupCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="backup", description="Create or restore a snapshot of your VPS")
    @app_commands.choices(action=[
        app_commands.Choice(name="📸 Create Backup",   value="create"),
        app_commands.Choice(name="📋 List Backups",    value="list"),
        app_commands.Choice(name="♻️ Restore Latest",  value="restore"),
        app_commands.Choice(name="♻️ Restore by Name", value="restore_named"),
    ])
    @app_commands.describe(
        vps_number  = "Your VPS number (1, 2…)",
        snap_name   = "Snapshot name (restore_named only)",
    )
    async def backup_cmd(
        self, interaction: discord.Interaction,
        action: str, vps_number: int = 1, snap_name: str = None,
    ):
        await interaction.response.defer(ephemeral=True)
        uid = str(interaction.user.id)

        async with data_lock:
            user_list = vps_data.get(uid, [])
            if not user_list or vps_number < 1 or vps_number > len(user_list):
                return await interaction.followup.send(
                    embed=create_error_embed("Invalid VPS", f"You don't have a VPS #{vps_number}. Use `/list` to check."))
            vps = dict(user_list[vps_number - 1])

        name   = vps["container_name"]
        node   = (vps.get("node") or "local").strip().rstrip(":") or "local"
        prefix = f"{node}:" if node != "local" else ""
        full   = f"{prefix}{name}"

        try:
            if action == "create":
                if backup_limit_enabled():
                    snaps = await _snap_list(full)
                    limit = UBL_LIMIT
                    if "Premium"  in vps.get("config", ""): limit = 3
                    if "Ultimate" in vps.get("config", ""): limit = 5
                    if len(snaps) >= limit:
                        return await interaction.followup.send(
                            embed=create_error_embed("Limit Reached",
                                f"You've reached your backup limit (**{limit}** snapshots).\n"
                                "Open a ticket to delete old ones."))
                ts   = int(time.time())
                sname = f"backup-{ts}"
                await _snap_create(full, sname)
                await interaction.followup.send(embed=create_success_embed(
                    "📸 Backup Created",
                    f"Snapshot `{sname}` saved for **{name}**.\n"
                    f"Use `/backup action:List` to view all snapshots."))

            elif action == "list":
                snaps = await _snap_list(full)
                if not snaps:
                    return await interaction.followup.send(embed=create_info_embed(
                        f"No Backups — {name}", "No snapshots found. Create one with `/backup action:Create`."))
                desc = "\n".join(f"› `{s}`" for s in snaps)
                await interaction.followup.send(embed=create_info_embed(
                    f"📋 Backups — {name}", f"**{len(snaps)}** snapshot(s):\n{desc}"))

            elif action == "restore":
                snaps = await _snap_list(full)
                if not snaps:
                    return await interaction.followup.send(embed=create_error_embed(
                        "No Backups", "No snapshots found for this VPS."))
                latest = snaps[-1].split()[0]  # strip any trailing annotation
                await _snap_restore(full, latest)
                await interaction.followup.send(embed=create_success_embed(
                    "♻️ Restored", f"**{name}** restored to snapshot `{latest}`."))

            elif action == "restore_named":
                if not snap_name:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing", "Provide `snap_name` to restore a specific snapshot."))
                await _snap_restore(full, snap_name)
                await interaction.followup.send(embed=create_success_embed(
                    "♻️ Restored", f"**{name}** restored to snapshot `{snap_name}`."))

        except Exception as e:
            await interaction.followup.send(embed=create_error_embed(
                "Backup Error", str(e)[:3000]))


async def setup(bot):
    await bot.add_cog(BackupCog(bot))
