import time
import discord
from discord import app_commands
from discord.ext import commands

from core.ext import backup_limit_enabled
from core.config import UBL_LIMIT
from core.database import vps_data, data_lock
from core.lxc import execute_lxc
from core.theme import create_success_embed, create_error_embed, create_info_embed


class BackupCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="backup", description="Create or restore a snapshot of your VPS")
    @app_commands.choices(action=[
        app_commands.Choice(name="Create Backup",  value="create"),
        app_commands.Choice(name="List Backups",   value="list"),
        app_commands.Choice(name="Restore Latest", value="restore"),
    ])
    @app_commands.describe(vps_number="Your VPS number (1, 2…)")
    async def backup_cmd(self, interaction: discord.Interaction, action: str, vps_number: int = 1):
        await interaction.response.defer(ephemeral=True)
        uid = str(interaction.user.id)

        with data_lock:
            user_list = vps_data.get(uid, [])
            if not user_list or vps_number < 1 or vps_number > len(user_list):
                return await interaction.followup.send(embed=create_error_embed("Error", "Invalid VPS number."))
            vps = user_list[vps_number - 1]

        name   = vps["container_name"]
        node   = vps.get("node", "local")
        prefix = f"{node}:" if node != "local" else ""
        full   = f"{prefix}{name}"

        try:
            if action == "create":
                if backup_limit_enabled():
                    out   = await execute_lxc(f"lxc info {full}")
                    snaps = [l for l in out.splitlines() if "backup-" in l]
                    limit = UBL_LIMIT
                    if "Premium"  in vps.get("config", ""): limit = 3
                    if "Ultimate" in vps.get("config", ""): limit = 5
                    if len(snaps) >= limit:
                        return await interaction.followup.send(
                            embed=create_error_embed("Limit Reached", f"You've reached your backup limit ({limit}). Open a support ticket to delete old ones.")
                        )
                snap_name = f"backup-{int(time.time())}"
                await execute_lxc(f"lxc snapshot {full} {snap_name}")
                await interaction.followup.send(embed=create_success_embed("Backup Created", f"Snapshot `{snap_name}` saved."))

            elif action == "list":
                out   = await execute_lxc(f"lxc info {full}")
                snaps = [l.strip() for l in out.splitlines() if "backup-" in l]
                desc  = "\n".join(snaps) if snaps else "No backups found."
                await interaction.followup.send(embed=create_info_embed(f"Backups for {name}", f"```\n{desc}\n```"))

            elif action == "restore":
                cmd = (
                    f"lxc restore {full} "
                    f"$(lxc info {full} | grep backup- | tail -1 | awk '{{print $1}}')"
                )
                await execute_lxc(cmd)
                await interaction.followup.send(embed=create_success_embed("Restored", "VPS restored to the latest backup."))

        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Error", str(e)[:4000]))


async def setup(bot):
    await bot.add_cog(BackupCog(bot))
