import discord
from discord import app_commands
from discord.ext import commands

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock
from core.theme import create_error_embed, create_embed, create_info_embed, add_field, Theme
from ui.manage_view import ManageView


def is_admin_check(user_id, main_admin_id):
    role = admin_data.get(str(user_id))
    return role in ["Owner", "Admin", "Dev"] or str(user_id) == str(main_admin_id)


def _find_shared_vps(uid: str) -> list:
    """Find all VPS that have been shared with this user by others."""
    shared = []
    with data_lock:
        for owner_id, vps_list in vps_data.items():
            if owner_id == uid:
                continue
            for idx, vps in enumerate(vps_list):
                if uid in vps.get("shared_with", []):
                    # Attach owner info for display
                    entry = dict(vps)
                    entry["_owner_id"]  = owner_id
                    entry["_vps_index"] = idx
                    shared.append(entry)
    return shared


class ManageTabView(discord.ui.View):
    """
    Top-level tab switcher shown when the user runs /manage.
    Lets them toggle between 'My VPS' and 'Shared VPS'.
    """

    def __init__(self, uid: str, own_vps: list, shared_vps: list, bot):
        super().__init__(timeout=300)
        self.uid        = uid
        self.own_vps    = own_vps
        self.shared_vps = shared_vps
        self.bot        = bot

        # Disable the Shared tab if nothing is shared
        self.shared_btn.disabled = len(shared_vps) == 0

    @discord.ui.button(label="🖥️ My VPS", style=discord.ButtonStyle.primary, row=0, custom_id="tab_own")
    async def my_vps_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if str(interaction.user.id) != self.uid:
            return await interaction.response.send_message("Permission denied.", ephemeral=True)
        if not self.own_vps:
            return await interaction.response.send_message(
                embed=create_error_embed("No VPS", "You have no VPS instances. Use `/claim` to get one."),
                ephemeral=True,
            )
        view  = ManageView(self.uid, self.own_vps)
        embed = await view.get_initial_embed()
        await interaction.response.edit_message(embed=embed, view=view)

    @discord.ui.button(label="🤝 Shared VPS", style=discord.ButtonStyle.secondary, row=0, custom_id="tab_shared")
    async def shared_btn(self, interaction: discord.Interaction, button: discord.ui.Button):
        if str(interaction.user.id) != self.uid:
            return await interaction.response.send_message("Permission denied.", ephemeral=True)
        if not self.shared_vps:
            return await interaction.response.send_message(
                embed=create_error_embed("None Shared", "No one has shared a VPS with you yet."),
                ephemeral=True,
            )
        # Build a selection list for shared VPS
        embed = create_embed("🤝 Shared VPS", f"**{len(self.shared_vps)}** VPS shared with you.")
        for i, v in enumerate(self.shared_vps):
            owner_id = v["_owner_id"]
            member   = interaction.guild.get_member(int(owner_id))
            owner_name = member.display_name if member else f"<@{owner_id}>"
            add_field(
                embed,
                f"#{i+1} — `{v['container_name']}`",
                f"Owner: **{owner_name}**\nStatus: `{v.get('status','?').upper()}`\nSpecs: {v.get('config','?')}",
                inline=True,
            )
        view = SharedSelectView(self.uid, self.shared_vps)
        await interaction.response.edit_message(embed=embed, view=view)


class SharedSelectView(discord.ui.View):
    """Dropdown to pick which shared VPS to manage."""

    def __init__(self, uid: str, shared_vps: list):
        super().__init__(timeout=300)
        self.uid        = uid
        self.shared_vps = shared_vps

        options = [
            discord.SelectOption(
                label=f"#{i+1} — {v['container_name']}"[:100],
                description=f"Owner: {v['_owner_id']} | {v.get('config','?')}"[:100],
                value=str(i),
                emoji="🤝",
            )
            for i, v in enumerate(shared_vps)
        ]
        sel = discord.ui.Select(placeholder="▼ Select a shared VPS to manage", options=options)
        sel.callback = self._select
        self.add_item(sel)

    async def _select(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.uid:
            return await interaction.response.send_message("Permission denied.", ephemeral=True)
        await interaction.response.defer()
        idx  = int(interaction.data["values"][0])
        vps  = self.shared_vps[idx]
        view = ManageView(
            self.uid, [vps],
            is_shared=True,
            owner_id=vps["_owner_id"],
            actual_index=vps["_vps_index"],
        )
        embed = await view.get_initial_embed()
        await interaction.edit_original_response(embed=embed, view=view)


class ManageCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="manage", description="Open the VPS control panel — manage your own or shared VPS")
    @app_commands.describe(user_id="[ADMIN] Discord User ID to manage their VPS (paste ID, not @mention)")
    async def manage_vps(self, interaction: discord.Interaction, user_id: str = None):
        await interaction.response.defer()
        uid = str(interaction.user.id)

        # ── Admin managing another user ──────────────────────────────────────
        if user_id:
            if not is_admin_check(uid, MAIN_ADMIN_ID):
                return await interaction.followup.send(
                    embed=create_error_embed("Denied", "You don't have permission to manage other users."),
                    ephemeral=True,
                )
            # Sanitize - allow @mention format or raw ID
            target_uid = user_id.strip().lstrip("<@!").rstrip(">")
            if not target_uid.isdigit():
                return await interaction.followup.send(
                    embed=create_error_embed("Invalid ID", f"`{user_id}` is not a valid Discord User ID."),
                    ephemeral=True,
                )
            with data_lock:
                vps_list = list(vps_data.get(target_uid, []))
            if not vps_list:
                return await interaction.followup.send(
                    embed=create_error_embed("No VPS", f"User `{target_uid}` has no VPS instances."),
                    ephemeral=True,
                )
            # Try to get display name
            member = interaction.guild.get_member(int(target_uid)) if interaction.guild else None
            name = member.display_name if member else target_uid
            view  = ManageView(uid, vps_list, is_admin=True, owner_id=target_uid)
            embed = await view.get_initial_embed()
            return await interaction.followup.send(embed=embed, view=view)

        # ── Normal user ──────────────────────────────────────────────────────
        with data_lock:
            own_vps = list(vps_data.get(uid, []))
        shared_vps = _find_shared_vps(uid)

        has_own    = len(own_vps)    > 0
        has_shared = len(shared_vps) > 0

        if not has_own and not has_shared:
            return await interaction.followup.send(
                embed=create_error_embed("No VPS", "You have no VPS instances and none have been shared with you. Use `/claim` to get started."),
                ephemeral=True,
            )

        # If only own VPS, go straight to manage
        if has_own and not has_shared:
            view  = ManageView(uid, own_vps)
            embed = await view.get_initial_embed()
            return await interaction.followup.send(embed=embed, view=view)

        # If only shared VPS, go straight to shared view
        if has_shared and not has_own:
            embed = create_embed("🤝 Shared VPS", f"**{len(shared_vps)}** VPS shared with you.")
            for i, v in enumerate(shared_vps):
                owner_id   = v["_owner_id"]
                member     = interaction.guild.get_member(int(owner_id))
                owner_name = member.display_name if member else f"<@{owner_id}>"
                add_field(embed, f"#{i+1} — `{v['container_name']}`",
                          f"Owner: **{owner_name}**\nStatus: `{v.get('status','?').upper()}`\nSpecs: {v.get('config','?')}",
                          inline=True)
            view = SharedSelectView(uid, shared_vps)
            return await interaction.followup.send(embed=embed, view=view)

        # Both own and shared — show tab switcher
        embed = create_embed(
            "🎛️ VPS Control Panel",
            f"You have **{len(own_vps)}** own VPS and **{len(shared_vps)}** shared VPS.\n"
            "Choose a tab below to manage them.",
        )
        add_field(embed, "🖥️ My VPS",     f"{len(own_vps)} instance(s)",    True)
        add_field(embed, "🤝 Shared VPS", f"{len(shared_vps)} instance(s)", True)
        view = ManageTabView(uid, own_vps, shared_vps, self.bot)
        await interaction.followup.send(embed=embed, view=view)


async def setup(bot):
    await bot.add_cog(ManageCog(bot))
