"""
/hardmod — Commands exclusive to Hard Mod and above.
"""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock, get_db, async_save_vps_data
from core.lxc import execute_lxc
from core.theme import Theme, add_field, create_error_embed, create_info_embed, create_success_embed, create_warning_embed

HARD_MOD_ROLES = {"Owner", "Hard Admin", "Admin", "Manager", "Hard Mod"}


def is_hard_mod(uid):
    if str(uid) == str(MAIN_ADMIN_ID): return True
    return admin_data.get(str(uid), "") in HARD_MOD_ROLES


def has_hard_mod():
    async def predicate(interaction: discord.Interaction):
        if is_hard_mod(interaction.user.id): return True
        raise app_commands.CheckFailure("no_permission")
    return app_commands.check(predicate)


class BroadcastModal(discord.ui.Modal, title="📣 Staff Broadcast"):
    message = discord.ui.TextInput(
        label="Message to send to all staff",
        style=discord.TextStyle.paragraph,
        max_length=1000,
    )
    async def on_submit(self, interaction: discord.Interaction):
        self._val = self.message.value
        await interaction.response.defer()


class HardModCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="hardmod", description="[HARD MOD+] Senior moderation tools")
    @app_commands.choices(action=[
        app_commands.Choice(name="🔴 Suspend VPS — Force-suspend a user's container",    value="suspend"),
        app_commands.Choice(name="🟢 Unsuspend VPS — Re-enable a suspended container",   value="unsuspend"),
        app_commands.Choice(name="🗑️ Clear Warnings — Remove all warnings for a user",   value="clear_warns"),
        app_commands.Choice(name="📣 Staff Announce — DM broadcast to all staff",        value="broadcast"),
        app_commands.Choice(name="🔒 Lock Channel — Prevent users from sending messages", value="lock"),
        app_commands.Choice(name="🔓 Unlock Channel — Restore channel send permissions", value="unlock"),
        app_commands.Choice(name="🧹 Purge — Delete recent messages in a channel",       value="purge"),
    ])
    @app_commands.describe(
        action       = "Action to perform",
        target_user  = "Target user (@mention)",
        vps_number   = "VPS number (for suspend/unsuspend)",
        reason       = "Reason (for suspend/purge)",
        channel      = "Target channel (for lock/unlock/purge)",
        count        = "Number of messages to delete (purge, max 100)",
    )
    @has_hard_mod()
    async def hardmod_cmd(
        self, interaction: discord.Interaction,
        action:      str,
        target_user: discord.Member = None,
        vps_number:  int            = None,
        reason:      str            = "Staff action",
        channel:     discord.TextChannel = None,
        count:       int            = 10,
    ):
        uid  = str(interaction.user.id)
        irole = admin_data.get(uid, "")

        # ── Suspend VPS ───────────────────────────────────────────────────────
        if action == "suspend":
            if not target_user or not vps_number:
                return await interaction.response.send_message(
                    embed=create_error_embed("Missing", "Provide `target_user` and `vps_number`."), ephemeral=True)
            await interaction.response.defer(ephemeral=True)
            tid = str(target_user.id)
            async with data_lock:
                lst = vps_data.get(tid, [])
                if not lst or vps_number < 1 or vps_number > len(lst):
                    return await interaction.followup.send(embed=create_error_embed("Not Found", "Invalid VPS number."))
                vps  = lst[vps_number - 1]
                node = vps.get("node", "local")
                prefix = f"{node}:" if node != "local" else ""
                name = vps["container_name"]
            try:
                await execute_lxc(f"lxc stop {prefix}{name}", timeout=30)
            except Exception: pass
            async with data_lock:
                vps["suspended"] = True
                vps["status"]    = "stopped"
                vps.setdefault("suspension_history", []).append({
                    "time": datetime.now().isoformat(), "reason": reason, "by": uid,
                })
            await async_save_vps_data()
            embed = create_success_embed("VPS Suspended 🔴", f"`{name}` suspended.")
            add_field(embed, "Reason", reason, False)
            add_field(embed, "By",     interaction.user.mention, True)
            await interaction.followup.send(embed=embed)
            try:
                dm = discord.Embed(title="🔴 Your VPS Was Suspended",
                    description=f"**VPS:** `{name}`\n**Reason:** {reason}\n\nOpen a ticket with `/support` to appeal.",
                    color=0xED4245, timestamp=datetime.now())
                dm.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                await target_user.send(embed=dm)
            except Exception: pass

        # ── Unsuspend VPS ─────────────────────────────────────────────────────
        elif action == "unsuspend":
            if not target_user or not vps_number:
                return await interaction.response.send_message(
                    embed=create_error_embed("Missing", "Provide `target_user` and `vps_number`."), ephemeral=True)
            await interaction.response.defer(ephemeral=True)
            tid = str(target_user.id)
            async with data_lock:
                lst = vps_data.get(tid, [])
                if not lst or vps_number < 1 or vps_number > len(lst):
                    return await interaction.followup.send(embed=create_error_embed("Not Found", "Invalid VPS number."))
                vps  = lst[vps_number - 1]
                node = vps.get("node", "local")
                prefix = f"{node}:" if node != "local" else ""
                name = vps["container_name"]
            try:
                await execute_lxc(f"lxc start {prefix}{name}", timeout=30)
            except Exception: pass
            async with data_lock:
                vps["suspended"] = False
                vps["status"]    = "running"
            await async_save_vps_data()
            await interaction.followup.send(embed=create_success_embed("VPS Unsuspended 🟢", f"`{name}` is running again."))
            try:
                dm = discord.Embed(title="🟢 Your VPS Has Been Unsuspended",
                    description=f"**VPS:** `{name}`\nYour VPS is now **running** again.",
                    color=0x57F287, timestamp=datetime.now())
                dm.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                await target_user.send(embed=dm)
            except Exception: pass

        # ── Clear Warnings ────────────────────────────────────────────────────
        elif action == "clear_warns":
            if not target_user:
                return await interaction.response.send_message(
                    embed=create_error_embed("Missing", "Provide `target_user`."), ephemeral=True)
            await interaction.response.defer(ephemeral=True)
            conn = get_db(); cur = conn.cursor()
            cur.execute("DELETE FROM warnings WHERE user_id=?", (str(target_user.id),))
            deleted = cur.rowcount; conn.commit()
            await interaction.followup.send(embed=create_success_embed(
                "Warnings Cleared",
                f"Removed **{deleted}** warning(s) for {target_user.mention}."))

        # ── Staff Broadcast ───────────────────────────────────────────────────
        elif action == "broadcast":
            modal = BroadcastModal()
            await interaction.response.send_modal(modal)
            await modal.wait()
            msg_text = getattr(modal, "_val", None)
            if not msg_text: return
            sent = 0
            conn = get_db(); cur = conn.cursor()
            cur.execute("SELECT user_id FROM admins")
            rows = cur.fetchall()
            embed = discord.Embed(
                title="📣 Staff Broadcast",
                description=msg_text,
                color=0xFFD700, timestamp=datetime.now(),
            )
            embed.set_author(name=f"From: {interaction.user.display_name}", icon_url=interaction.user.display_avatar.url)
            embed.set_footer(text="MoonNodes Staff Broadcast")
            for row in rows:
                try:
                    u = await interaction.client.fetch_user(int(row["user_id"]))
                    await u.send(embed=embed); sent += 1
                except Exception: pass
            await interaction.followup.send(embed=create_success_embed("Broadcast Sent", f"Delivered to **{sent}** staff members."), ephemeral=True)

        # ── Lock Channel ──────────────────────────────────────────────────────
        elif action == "lock":
            ch = channel or interaction.channel
            await interaction.response.defer(ephemeral=True)
            try:
                await ch.set_permissions(interaction.guild.default_role, send_messages=False)
                await interaction.followup.send(embed=create_success_embed("Channel Locked 🔒", f"{ch.mention} is now locked."))
                await ch.send(embed=create_warning_embed("🔒 Channel Locked", f"This channel has been locked by {interaction.user.mention}."))
            except Exception as e:
                await interaction.followup.send(embed=create_error_embed("Failed", str(e)[:1000]))

        # ── Unlock Channel ────────────────────────────────────────────────────
        elif action == "unlock":
            ch = channel or interaction.channel
            await interaction.response.defer(ephemeral=True)
            try:
                await ch.set_permissions(interaction.guild.default_role, send_messages=True)
                await interaction.followup.send(embed=create_success_embed("Channel Unlocked 🔓", f"{ch.mention} is now open."))
                await ch.send(embed=create_info_embed("🔓 Channel Unlocked", f"Unlocked by {interaction.user.mention}."))
            except Exception as e:
                await interaction.followup.send(embed=create_error_embed("Failed", str(e)[:1000]))

        # ── Purge ─────────────────────────────────────────────────────────────
        elif action == "purge":
            ch = channel or interaction.channel
            count = max(1, min(count, 100))
            await interaction.response.defer(ephemeral=True)
            try:
                deleted_msgs = await ch.purge(limit=count)
                await interaction.followup.send(embed=create_success_embed(
                    "Messages Purged 🧹", f"Deleted **{len(deleted_msgs)}** messages in {ch.mention}."), ephemeral=True)
            except Exception as e:
                await interaction.followup.send(embed=create_error_embed("Failed", str(e)[:1000]))


async def setup(bot):
    await bot.add_cog(HardModCog(bot))
