"""
/mod — Mod + Hard Mod tools in one command.
User picks role: Mod or Hard Mod → sees appropriate action set.
Hard Mod actions are gated — only Hard Mod+ can use them.
"""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock, get_db, async_save_vps_data
from core.lxc import execute_lxc
from core.theme import Theme, add_field, create_embed, create_success_embed, create_error_embed, create_info_embed, create_warning_embed

MOD_ROLES      = {"Owner","Hard Admin","Admin","Manager","Hard Mod","Mod"}
HARD_MOD_ROLES = {"Owner","Hard Admin","Admin","Manager","Hard Mod"}

def _role(uid): return "Owner" if str(uid)==str(MAIN_ADMIN_ID) else admin_data.get(str(uid),"")
def is_mod(uid): return _role(uid) in MOD_ROLES
def is_hard_mod(uid): return _role(uid) in HARD_MOD_ROLES


class BroadcastModal(discord.ui.Modal, title="📣 Staff Broadcast"):
    message = discord.ui.TextInput(label="Message", style=discord.TextStyle.paragraph, max_length=1000)
    async def on_submit(self, inter): self._val = self.message.value; await inter.response.defer()


class ModCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="mod", description="[MOD/HARD MOD] Moderation tools")
    @app_commands.choices(role=[
        app_commands.Choice(name="⚒️ Mod — Standard moderation tools",    value="mod"),
        app_commands.Choice(name="🔱 Hard Mod — Senior moderation tools", value="hardmod"),
    ])
    @app_commands.choices(action=[
        # Mod actions
        app_commands.Choice(name="👤 User Info",          value="user_info"),
        app_commands.Choice(name="🖥️ VPS Info",           value="vps_info"),
        app_commands.Choice(name="📋 List VPS",           value="list_vps"),
        app_commands.Choice(name="🔍 Search VPS",         value="search"),
        app_commands.Choice(name="📊 Server Stats",       value="server_stats"),
        app_commands.Choice(name="🎫 Open Tickets",       value="tickets"),
        app_commands.Choice(name="📝 Suspension Logs",    value="susp_logs"),
        app_commands.Choice(name="💬 DM User",            value="dm_user"),
        app_commands.Choice(name="⚠️ Warn User",          value="warn"),
        app_commands.Choice(name="📜 Warn Log",           value="warn_log"),
        # Hard Mod only
        app_commands.Choice(name="🚫 Blocklist [HM] — Block user from all commands", value="blocklist"),
        app_commands.Choice(name="🔇 Mute [HM] — Block user from /manage and DM commands", value="mute"),
        app_commands.Choice(name="🔴 Suspend VPS [HM]",   value="suspend"),
        app_commands.Choice(name="🟢 Unsuspend VPS [HM]", value="unsuspend"),
        app_commands.Choice(name="🗑️ Clear Warnings [HM]",value="clear_warns"),
        app_commands.Choice(name="📣 Staff Announce [HM]",value="broadcast"),
        app_commands.Choice(name="🔒 Lock Channel [HM]",  value="lock"),
        app_commands.Choice(name="🔓 Unlock Channel [HM]",value="unlock"),
        app_commands.Choice(name="🧹 Purge [HM]",         value="purge"),
    ])
    @app_commands.describe(
        role           = "Your role scope: Mod or Hard Mod",
        action         = "Action to perform",
        target_user    = "Target user (@mention)",
        container_name = "Container name (VPS Info/Search)",
        message        = "Message (DM/Warn/Announce)",
        channel        = "Channel (lock/unlock/purge)",
        count          = "Messages to delete (purge, max 100)",
        vps_number     = "VPS number (suspend/unsuspend)",
        reason         = "Reason (suspend/purge)",
    )
    async def mod_cmd(
        self, interaction: discord.Interaction,
        role:           str,
        action:         str,
        target_user:    discord.Member = None,
        container_name: str = None,
        message:        str = None,
        channel:        discord.TextChannel = None,
        count:          int = 10,
        vps_number:     int = None,
        reason:         str = "Staff action",
        blocklist_time: str = None,
        mute_time:      str = None,
    ):
        await interaction.response.defer(ephemeral=True)
        uid = str(interaction.user.id)

        # Gate checks
        HARD_MOD_ACTIONS = {"suspend","unsuspend","clear_warns","broadcast","lock","unlock","purge"}
        if action in HARD_MOD_ACTIONS:
            if not is_hard_mod(uid):
                return await interaction.followup.send(embed=create_error_embed(
                    "🚫 No Permission",
                    "This action requires **Hard Mod** or above.\nUse `/help` to see your available commands."))
        else:
            if not is_mod(uid):
                return await interaction.followup.send(embed=create_error_embed(
                    "🚫 No Permission",
                    "This action requires **Mod** or above.\nUse `/help` to see your available commands."))

        # ── MOD ACTIONS ───────────────────────────────────────────────────────

        if action == "user_info":
            if not target_user:
                return await interaction.followup.send(embed=create_error_embed("Missing","Specify `target_user`."))
            tid  = str(target_user.id)
            conn = get_db(); cur = conn.cursor()
            cur.execute("SELECT mooncoin,invites_used FROM users WHERE user_id=?",(tid,))
            row  = cur.fetchone()
            cur.execute("SELECT COUNT(*) as cnt FROM warnings WHERE user_id=?",(tid,))
            wrow = cur.fetchone()
            async with data_lock:
                vlist = vps_data.get(tid,[])
            embed = create_embed(f"👤 {target_user.display_name}","")
            embed.set_thumbnail(url=target_user.display_avatar.url)
            add_field(embed,"User ID",   str(tid), True)
            add_field(embed,"Staff Role",admin_data.get(tid,"User"), True)
            add_field(embed,"Joined",    f"<t:{int(target_user.joined_at.timestamp())}:R>" if target_user.joined_at else "?", True)
            add_field(embed,"VPS Count", str(len(vlist)), True)
            add_field(embed,"🌙 Coins",  f"{(row['mooncoin'] if row else 0):,}", True)
            add_field(embed,"⚠️ Warns",  str(wrow['cnt'] if wrow else 0), True)
            return await interaction.followup.send(embed=embed)

        elif action == "vps_info":
            if not container_name:
                return await interaction.followup.send(embed=create_error_embed("Missing","Specify `container_name`."))
            found = owner = None
            async with data_lock:
                for uid2,lst in vps_data.items():
                    for v in lst:
                        if v["container_name"]==container_name:
                            found=v; owner=uid2; break
            if not found:
                return await interaction.followup.send(embed=create_error_embed("Not Found",f"`{container_name}` not in database."))
            embed = create_embed(f"🖥️ {container_name}","")
            add_field(embed,"Owner",  f"<@{owner}>", True)
            add_field(embed,"Status", found.get("status","?").upper(), True)
            add_field(embed,"Node",   found.get("node","local"), True)
            add_field(embed,"Specs",  found.get("config","?"), True)
            add_field(embed,"OS",     found.get("os_version","?"), True)
            return await interaction.followup.send(embed=embed)

        elif action == "list_vps":
            if not target_user:
                return await interaction.followup.send(embed=create_error_embed("Missing","Specify `target_user`."))
            async with data_lock:
                vlist = list(vps_data.get(str(target_user.id),[]))
            if not vlist:
                return await interaction.followup.send(embed=create_info_embed("No VPS",f"{target_user.mention} has no VPS."))
            embed = create_embed(f"📋 VPS — {target_user.display_name}",f"{len(vlist)} VPS instance(s)")
            for i,v in enumerate(vlist,1):
                st = "🟢" if v.get("status")=="running" else ("🔴" if v.get("suspended") else "⚫")
                add_field(embed,f"{st} VPS #{i} — {v['container_name']}",f"`{v.get('config','?')}` · `{v.get('node','local')}`",False)
            return await interaction.followup.send(embed=embed)

        elif action == "search":
            if not container_name:
                return await interaction.followup.send(embed=create_error_embed("Missing","Specify `container_name`."))
            results = []
            async with data_lock:
                for uid2,lst in vps_data.items():
                    for v in lst:
                        if container_name.lower() in v["container_name"].lower():
                            results.append((uid2,v))
            if not results:
                return await interaction.followup.send(embed=create_info_embed("No Results",f"No VPS matching `{container_name}`."))
            embed = create_embed(f"🔍 Search: {container_name}",f"{len(results)} result(s)")
            for uid2,v in results[:10]:
                add_field(embed,v["container_name"],f"Owner: <@{uid2}> · `{v.get('status','?')}` · `{v.get('node','local')}`",False)
            return await interaction.followup.send(embed=embed)

        elif action == "server_stats":
            async with data_lock:
                total   = sum(len(v) for v in vps_data.values())
                running = sum(1 for lst in vps_data.values() for v in lst if v.get("status")=="running")
                susp    = sum(1 for lst in vps_data.values() for v in lst if v.get("suspended"))
                owners  = len(vps_data)
            embed = create_embed("📊 Server Stats","")
            add_field(embed,"🖥️ Total VPS", str(total),   True)
            add_field(embed,"🟢 Running",   str(running), True)
            add_field(embed,"🔴 Suspended", str(susp),    True)
            add_field(embed,"👥 VPS Owners",str(owners),  True)
            return await interaction.followup.send(embed=embed)

        elif action == "tickets":
            from core.database import get_setting
            ch_id = get_setting("ticket_channel")
            if not ch_id or ch_id=="0":
                return await interaction.followup.send(embed=create_error_embed("Not Configured","No ticket category set."))
            cat = interaction.guild.get_channel(int(ch_id))
            if not cat: return await interaction.followup.send(embed=create_error_embed("Not Found","Category not found."))
            chans = [c for c in cat.channels if isinstance(c,discord.TextChannel)]
            if not chans: return await interaction.followup.send(embed=create_info_embed("No Tickets","No open ticket channels."))
            embed = create_embed(f"🎫 Open Tickets ({len(chans)})","")
            for c in chans[:10]: add_field(embed,c.name[:50],c.mention,False)
            return await interaction.followup.send(embed=embed)

        elif action == "susp_logs":
            logs=[]
            async with data_lock:
                for uid2,lst in vps_data.items():
                    for v in lst:
                        for s in v.get("suspension_history",[])[-2:]:
                            logs.append((v["container_name"],uid2,s))
            logs.sort(key=lambda x:x[2].get("time",""),reverse=True)
            embed = create_embed("📝 Suspension Logs","")
            for name,uid2,s in logs[:10]:
                add_field(embed,f"`{name}` — <@{uid2}>",f"Reason: {s.get('reason','?')} · {s.get('time','?')[:10]}",False)
            if not logs: embed.description="No suspensions on record."
            return await interaction.followup.send(embed=embed)

        elif action == "dm_user":
            if not target_user or not message:
                return await interaction.followup.send(embed=create_error_embed("Missing","Specify `target_user` and `message`."))
            try:
                dm = discord.Embed(title="📩 Message from MoonNodes Staff",description=message,color=0x5865F2,timestamp=datetime.now())
                dm.set_author(name=f"Staff: {interaction.user.display_name}",icon_url=interaction.user.display_avatar.url)
                dm.set_footer(text="MoonNodes · Reply with /support if you need help")
                await target_user.send(embed=dm)
                return await interaction.followup.send(embed=create_success_embed("DM Sent",f"Message delivered to {target_user.mention}."))
            except Exception as e:
                return await interaction.followup.send(embed=create_error_embed("Failed",str(e)[:500]))

        elif action == "warn":
            if not target_user or not message:
                return await interaction.followup.send(embed=create_error_embed("Missing","Specify `target_user` and `message`."))
            conn=get_db(); cur=conn.cursor()
            cur.execute("INSERT INTO warnings (user_id,reason,by_id,at) VALUES (?,?,?,?)",
                (str(target_user.id),message,uid,datetime.now().isoformat()))
            conn.commit()
            await interaction.followup.send(embed=create_success_embed("⚠️ Warning Issued",
                f"Warning recorded for {target_user.mention}.\n**Reason:** {message}"))
            try:
                dm=discord.Embed(title="⚠️ You Received a Warning",description=f"**Reason:** {message}",color=0xFFAA00,timestamp=datetime.now())
                dm.set_author(name="MoonNodes Staff",icon_url="https://imgur.com/6yfYDTP.png")
                await target_user.send(embed=dm)
            except Exception: pass

        elif action == "warn_log":
            if not target_user:
                return await interaction.followup.send(embed=create_error_embed("Missing","Specify `target_user`."))
            conn=get_db(); cur=conn.cursor()
            cur.execute("SELECT * FROM warnings WHERE user_id=? ORDER BY at DESC LIMIT 10",(str(target_user.id),))
            rows=cur.fetchall()
            embed=create_embed(f"📜 Warns — {target_user.display_name}","")
            if not rows: embed.description="No warnings on record."
            for r in rows:
                add_field(embed,f"Warn #{r['id']} — {r['at'][:10]}",f"**Reason:** {r['reason']}\nBy: <@{r['by_id']}>",False)
            return await interaction.followup.send(embed=embed)

        # ── HARD MOD ACTIONS ──────────────────────────────────────────────────

        elif action == "blocklist":
            if not target_user:
                return await interaction.followup.send(embed=create_error_embed("Missing","Specify `target_user`."))
            conn=get_db(); cur=conn.cursor()
            cur.execute("""CREATE TABLE IF NOT EXISTS blocklist
                (user_id TEXT PRIMARY KEY, reason TEXT, by_id TEXT, expires TEXT, at TEXT)""")
            if hasattr(interaction.data,"options") and any(o.get("name")=="option" for o in (interaction.data.get("options") or [])):
                # Remove from blocklist
                cur.execute("DELETE FROM blocklist WHERE user_id=?",(str(target_user.id),))
                conn.commit()
                return await interaction.followup.send(embed=create_success_embed("Blocklist Removed",
                    f"{target_user.mention} has been removed from the blocklist."))
            # Add to blocklist
            cur.execute("INSERT OR REPLACE INTO blocklist (user_id,reason,by_id,expires,at) VALUES (?,?,?,?,?)",
                (str(target_user.id), reason, uid, blocklist_time, datetime.now().isoformat()))
            conn.commit()
            await interaction.followup.send(embed=create_success_embed("🚫 Blocklisted",
                f"{target_user.mention} is now blocklisted.\n**Reason:** {reason}\n**Expires:** {blocklist_time or 'Never'}"))
            try:
                dm=discord.Embed(title="🚫 You Have Been Blocklisted",
                    description=f"**Reason:** {reason}\nYou cannot use any bot commands.",
                    color=0xED4245,timestamp=datetime.now())
                dm.set_author(name="MoonNodes VPS Manager",icon_url="https://imgur.com/6yfYDTP.png")
                await target_user.send(embed=dm)
            except Exception: pass

        elif action == "mute":
            if not target_user:
                return await interaction.followup.send(embed=create_error_embed("Missing","Specify `target_user`."))
            conn=get_db(); cur=conn.cursor()
            cur.execute("""CREATE TABLE IF NOT EXISTS muted_users
                (user_id TEXT PRIMARY KEY, reason TEXT, by_id TEXT, expires TEXT, at TEXT)""")
            cur.execute("INSERT OR REPLACE INTO muted_users (user_id,reason,by_id,expires,at) VALUES (?,?,?,?,?)",
                (str(target_user.id), reason, uid, mute_time, datetime.now().isoformat()))
            conn.commit()
            await interaction.followup.send(embed=create_success_embed("🔇 Muted",
                f"{target_user.mention} is now muted.\n**Reason:** {reason}\n**Expires:** {mute_time or 'Never'}\n> Cannot use /manage or DM commands."))
            try:
                dm=discord.Embed(title="🔇 You Have Been Muted",
                    description=f"**Reason:** {reason}\nYou cannot use /manage or DM commands.",
                    color=0xFFAA00,timestamp=datetime.now())
                dm.set_author(name="MoonNodes VPS Manager",icon_url="https://imgur.com/6yfYDTP.png")
                await target_user.send(embed=dm)
            except Exception: pass

        elif action == "suspend":
            if not target_user or not vps_number:
                return await interaction.followup.send(embed=create_error_embed("Missing","Specify `target_user` and `vps_number`."))
            tid=str(target_user.id)
            async with data_lock:
                lst=vps_data.get(tid,[])
                if not lst or vps_number<1 or vps_number>len(lst):
                    return await interaction.followup.send(embed=create_error_embed("Not Found","Invalid VPS number."))
                vps=lst[vps_number-1]; node=vps.get("node","local")
                prefix=f"{node}:" if node!="local" else ""; name=vps["container_name"]
            try: await execute_lxc(f"lxc stop {prefix}{name}",timeout=30)
            except Exception: pass
            async with data_lock:
                vps["suspended"]=True; vps["status"]="stopped"
                vps.setdefault("suspension_history",[]).append({"time":datetime.now().isoformat(),"reason":reason,"by":uid})
            await async_save_vps_data()
            await interaction.followup.send(embed=create_success_embed("🔴 VPS Suspended",f"`{name}` suspended.\n**Reason:** {reason}"))
            try:
                dm=discord.Embed(title="🔴 Your VPS Was Suspended",description=f"**VPS:** `{name}`\n**Reason:** {reason}",color=0xED4245,timestamp=datetime.now())
                dm.set_author(name="MoonNodes VPS Manager",icon_url="https://imgur.com/6yfYDTP.png")
                await target_user.send(embed=dm)
            except Exception: pass

        elif action == "unsuspend":
            if not target_user or not vps_number:
                return await interaction.followup.send(embed=create_error_embed("Missing","Specify `target_user` and `vps_number`."))
            tid=str(target_user.id)
            async with data_lock:
                lst=vps_data.get(tid,[])
                if not lst or vps_number<1 or vps_number>len(lst):
                    return await interaction.followup.send(embed=create_error_embed("Not Found","Invalid VPS number."))
                vps=lst[vps_number-1]; node=vps.get("node","local")
                prefix=f"{node}:" if node!="local" else ""; name=vps["container_name"]
            try: await execute_lxc(f"lxc start {prefix}{name}",timeout=30)
            except Exception: pass
            async with data_lock:
                vps["suspended"]=False; vps["status"]="running"
            await async_save_vps_data()
            await interaction.followup.send(embed=create_success_embed("🟢 VPS Unsuspended",f"`{name}` is running again."))
            try:
                dm=discord.Embed(title="🟢 Your VPS Has Been Unsuspended",description=f"**VPS:** `{name}`\nYour VPS is now running.",color=0x57F287,timestamp=datetime.now())
                dm.set_author(name="MoonNodes VPS Manager",icon_url="https://imgur.com/6yfYDTP.png")
                await target_user.send(embed=dm)
            except Exception: pass

        elif action == "clear_warns":
            if not target_user:
                return await interaction.followup.send(embed=create_error_embed("Missing","Specify `target_user`."))
            conn=get_db(); cur=conn.cursor()
            cur.execute("DELETE FROM warnings WHERE user_id=?",(str(target_user.id),))
            conn.commit()
            return await interaction.followup.send(embed=create_success_embed("Warnings Cleared",
                f"Removed {cur.rowcount} warning(s) for {target_user.mention}."))

        elif action == "broadcast":
            modal=BroadcastModal(); await interaction.response.send_modal(modal); await modal.wait()
            msg_text=getattr(modal,"_val",None)
            if not msg_text: return
            conn=get_db(); cur=conn.cursor(); cur.execute("SELECT user_id FROM admins"); rows=cur.fetchall()
            sent=0
            embed=discord.Embed(title="📣 Staff Broadcast",description=msg_text,color=0xFFD700,timestamp=datetime.now())
            embed.set_author(name=f"From: {interaction.user.display_name}",icon_url=interaction.user.display_avatar.url)
            for r in rows:
                try: u=await interaction.client.fetch_user(int(r["user_id"])); await u.send(embed=embed); sent+=1
                except Exception: pass
            await interaction.followup.send(embed=create_success_embed("Broadcast Sent",f"Delivered to **{sent}** staff."),ephemeral=True)

        elif action == "lock":
            ch=channel or interaction.channel
            try:
                await ch.set_permissions(interaction.guild.default_role,send_messages=False)
                await interaction.followup.send(embed=create_success_embed("🔒 Locked",f"{ch.mention} is now locked."))
                await ch.send(embed=create_warning_embed("🔒 Channel Locked",f"Locked by {interaction.user.mention}."))
            except Exception as e:
                await interaction.followup.send(embed=create_error_embed("Failed",str(e)[:500]))

        elif action == "unlock":
            ch=channel or interaction.channel
            try:
                await ch.set_permissions(interaction.guild.default_role,send_messages=True)
                await interaction.followup.send(embed=create_success_embed("🔓 Unlocked",f"{ch.mention} is now open."))
                await ch.send(embed=create_info_embed("🔓 Unlocked",f"Unlocked by {interaction.user.mention}."))
            except Exception as e:
                await interaction.followup.send(embed=create_error_embed("Failed",str(e)[:500]))

        elif action == "purge":
            ch=channel or interaction.channel; count=max(1,min(count,100))
            try:
                deleted=await ch.purge(limit=count)
                await interaction.followup.send(embed=create_success_embed("🧹 Purged",f"Deleted **{len(deleted)}** messages in {ch.mention}."),ephemeral=True)
            except Exception as e:
                await interaction.followup.send(embed=create_error_embed("Failed",str(e)[:500]))


async def setup(bot):
    await bot.add_cog(ModCog(bot))
