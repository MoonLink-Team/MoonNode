"""Mod-only commands: user lookups, VPS info, ticket management."""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock, get_db
from core.theme import create_embed, create_success_embed, create_error_embed, create_info_embed, add_field, Theme


def is_mod(uid):
    return str(uid) == str(MAIN_ADMIN_ID) or admin_data.get(str(uid)) in ("Owner", "Admin", "Mod")


class ModCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="mod", description="[MOD] Moderation tools")
    @app_commands.choices(action=[
        app_commands.Choice(name="👤 User Info — VPS count, coins, join date",               value="user_info"),
        app_commands.Choice(name="🖥️ VPS Info — Details for a specific container",           value="vps_info"),
        app_commands.Choice(name="📋 List VPS — All VPS for a specific user",                value="list_vps"),
        app_commands.Choice(name="🔍 Search — Find VPS by container name",                   value="search"),
        app_commands.Choice(name="📊 Server Stats — Total VPS, users, running",              value="server_stats"),
        app_commands.Choice(name="🎫 Tickets — List open support threads",                   value="tickets"),
        app_commands.Choice(name="📝 Suspension Logs — VPS suspension history",              value="susp_logs"),
        app_commands.Choice(name="💬 DM User — Send a DM as MoonNodes to a user",           value="dm_user"),
        app_commands.Choice(name="⚠️ Warn User — Log a warning for a user",                  value="warn"),
        app_commands.Choice(name="📜 Warn Log — View a user's warning history",              value="warn_log"),
    ])
    @app_commands.describe(
        action         ="Mod action to perform",
        target_user    ="Target Discord user",
        container_name ="Container name (for VPS Info / Search)",
        message        ="Message for DM / Warn",
    )
    async def mod_cmd(
        self, interaction: discord.Interaction,
        action: str,
        target_user: discord.Member = None,
        container_name: str = None,
        message: str = None,
    ):
        await interaction.response.defer(ephemeral=True)
        if not is_mod(interaction.user.id):
            return await interaction.followup.send(embed=create_error_embed("Denied", "Mod only."))

        # User Info
        if action == "user_info":
            if not target_user:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Specify `target_user`."))
            uid = str(target_user.id)
            conn = get_db(); cur = conn.cursor()
            cur.execute("SELECT mooncoin, invites_used FROM users WHERE user_id=?", (uid,))
            row = cur.fetchone(); conn.close()
            coins   = row["mooncoin"] if row else 0
            invites = row["invites_used"] if row else 0
            async with data_lock:
                vps_count = len(vps_data.get(uid, []))
            embed = create_embed(f"👤 {target_user.display_name}", "")
            embed.set_thumbnail(url=target_user.display_avatar.url)
            add_field(embed, "User ID",  str(target_user.id), True)
            add_field(embed, "Joined",   f"<t:{int(target_user.joined_at.timestamp())}:R>" if target_user.joined_at else "?", True)
            add_field(embed, "VPS",      str(vps_count), True)
            add_field(embed, "🌙 Coins", f"{coins:,}", True)
            add_field(embed, "Invites",  str(invites), True)
            add_field(embed, "Staff",    admin_data.get(uid, "User"), True)
            return await interaction.followup.send(embed=embed)

        # VPS Info
        elif action == "vps_info":
            if not container_name:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Specify `container_name`."))
            found = owner = None
            async with data_lock:
                for uid, lst in vps_data.items():
                    for v in lst:
                        if v["container_name"] == container_name:
                            found = v; owner = uid; break
            if not found:
                return await interaction.followup.send(embed=create_error_embed("Not Found", f"`{container_name}` not in database."))
            member = interaction.guild.get_member(int(owner))
            embed  = create_embed(f"🖥️ `{container_name}`", "")
            add_field(embed, "Owner",   member.mention if member else f"<@{owner}>", True)
            add_field(embed, "Status",  ("SUSPENDED" if found.get("suspended") else found.get("status","?")).upper(), True)
            add_field(embed, "Node",    found.get("node","local"), True)
            add_field(embed, "Specs",   found.get("config","?"), True)
            add_field(embed, "OS",      found.get("os_version","?"), True)
            return await interaction.followup.send(embed=embed)

        # List VPS for user
        elif action == "list_vps":
            if not target_user:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Specify `target_user`."))
            uid = str(target_user.id)
            async with data_lock:
                lst = list(vps_data.get(uid, []))
            if not lst:
                return await interaction.followup.send(embed=create_info_embed("No VPS", f"{target_user.mention} has no VPS."))
            embed = create_embed(f"🖥️ VPS for {target_user.display_name}", f"{len(lst)} instance(s)")
            for i, v in enumerate(lst, 1):
                icon = "⛔" if v.get("suspended") else ("🟢" if v.get("status")=="running" else "🔴")
                embed.add_field(name=f"{icon} #{i} `{v['container_name']}`", value=f"{v.get('config','?')} · {v.get('node','local')}", inline=True)
            return await interaction.followup.send(embed=embed)

        # Search by name
        elif action == "search":
            if not container_name:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Specify `container_name`."))
            results = []
            async with data_lock:
                for uid, lst in vps_data.items():
                    for v in lst:
                        if container_name.lower() in v["container_name"].lower():
                            m = interaction.guild.get_member(int(uid))
                            results.append(f"• `{v['container_name']}` — {m.mention if m else uid}")
            if not results:
                return await interaction.followup.send(embed=create_info_embed("No Results", f"No containers matching `{container_name}`."))
            return await interaction.followup.send(embed=create_info_embed(f"🔍 Search: `{container_name}`", "\n".join(results[:20])))

        # Server stats
        elif action == "server_stats":
            async with data_lock:
                total   = sum(len(v) for v in vps_data.values())
                running = sum(1 for lst in vps_data.values() for v in lst if v.get("status")=="running")
                susp    = sum(1 for lst in vps_data.values() for v in lst if v.get("suspended"))
                users   = len(vps_data)
            embed = create_embed("📊 Server Stats", "")
            add_field(embed, "Users with VPS", str(users), True)
            add_field(embed, "Total VPS",      str(total), True)
            add_field(embed, "Running",        str(running), True)
            add_field(embed, "Suspended",      str(susp), True)
            add_field(embed, "Stopped",        str(total-running-susp), True)
            return await interaction.followup.send(embed=embed)

        # Open tickets
        elif action == "tickets":
            ch_id = None
            try:
                from core.database import get_setting
                ch_id = get_setting("ticket_channel")
            except Exception:
                pass
            if not ch_id:
                return await interaction.followup.send(embed=create_info_embed("Tickets", "No ticket channel configured."))
            ch = interaction.guild.get_channel(int(ch_id))
            if not ch:
                return await interaction.followup.send(embed=create_error_embed("Gone", "Ticket channel not found."))
            threads = [t for t in interaction.guild.threads if t.parent_id == int(ch_id) and not t.archived]
            if not threads:
                return await interaction.followup.send(embed=create_info_embed("Open Tickets", "No open support threads."))
            lines = [f"• {t.mention} ({t.member_count} member(s))" for t in threads[:20]]
            return await interaction.followup.send(embed=create_info_embed(f"🎫 Open Tickets ({len(threads)})", "\n".join(lines)))

        # Suspension logs
        elif action == "susp_logs":
            logs = []
            async with data_lock:
                for uid, lst in vps_data.items():
                    for v in lst:
                        for h in v.get("suspension_history",[])[-5:]:
                            m = interaction.guild.get_member(int(uid))
                            logs.append(f"• **{v['container_name']}** ({m.display_name if m else uid}) — {h.get('reason','?')} — <t:{int(datetime.fromisoformat(h['time']).timestamp())}:R>")
            if not logs:
                return await interaction.followup.send(embed=create_info_embed("Suspension Logs", "No suspension events recorded."))
            return await interaction.followup.send(embed=create_info_embed("📝 Suspension Logs", "\n".join(logs[:20])))

        # DM user
        elif action == "dm_user":
            if not target_user or not message:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Specify `target_user` and `message`."))
            try:
                dm = discord.Embed(title="📬  Message from MoonNodes Staff", description=message, color=Theme.WARNING, timestamp=datetime.now())
                dm.set_author(name="MoonNodes Moderation", icon_url="https://imgur.com/6yfYDTP.png")
                dm.set_footer(text=f"Sent by {interaction.user.display_name}")
                await target_user.send(embed=dm)
                return await interaction.followup.send(embed=create_success_embed("DM Sent", f"Message delivered to {target_user.mention}."))
            except discord.Forbidden:
                return await interaction.followup.send(embed=create_error_embed("Failed", f"{target_user.mention} has DMs disabled."))

        # Warn
        elif action == "warn":
            if not target_user or not message:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Specify `target_user` and `message` (reason)."))
            uid = str(target_user.id)
            conn = get_db(); cur = conn.cursor()
            cur.execute("""CREATE TABLE IF NOT EXISTS warnings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT, reason TEXT, by_id TEXT, at TEXT)""")
            cur.execute("INSERT INTO warnings (user_id, reason, by_id, at) VALUES (?,?,?,?)",
                        (uid, message, str(interaction.user.id), datetime.now().isoformat()))
            conn.commit(); conn.close()
            try:
                dm = discord.Embed(title="⚠️  Warning", description=f"**Reason:** {message}", color=Theme.WARNING, timestamp=datetime.now())
                dm.set_author(name="MoonNodes Moderation", icon_url="https://imgur.com/6yfYDTP.png")
                await target_user.send(embed=dm)
            except Exception: pass
            return await interaction.followup.send(embed=create_success_embed("Warning Issued", f"{target_user.mention} warned: {message}"))

        # Warn log
        elif action == "warn_log":
            if not target_user:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Specify `target_user`."))
            uid = str(target_user.id)
            conn = get_db(); cur = conn.cursor()
            try:
                cur.execute("SELECT reason, at, by_id FROM warnings WHERE user_id=? ORDER BY at DESC LIMIT 10", (uid,))
                rows = cur.fetchall()
            except Exception:
                rows = []
            conn.close()
            if not rows:
                return await interaction.followup.send(embed=create_info_embed("No Warnings", f"{target_user.mention} has no warnings."))
            lines = [f"• {r['reason']} — <t:{int(datetime.fromisoformat(r['at']).timestamp())}:R>" for r in rows]
            return await interaction.followup.send(embed=create_info_embed(f"📜 Warnings for {target_user.display_name}", "\n".join(lines)))


async def setup(bot):
    await bot.add_cog(ModCog(bot))
