import discord
from discord import app_commands
from discord.ext import commands

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock, save_vps_data, get_db
from core.lxc import execute_lxc
from core.theme import create_success_embed, create_error_embed, create_info_embed, create_warning_embed, add_field
from ui.confirm_view import ConfirmView


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if int(uid) == int(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure(f"Required role: {', '.join(roles)}")
    return app_commands.check(predicate)


class DeleteCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="delete", description="[ADMIN] Permanently delete a user's VPS")
    @app_commands.describe(user="Target user", vps_number="VPS number (1, 2…)", reason="Reason")
    @has_role("Owner", "Admin", "Mod", "Dev")
    async def delete_vps(
        self,
        interaction: discord.Interaction,
        user: discord.Member,
        vps_number: int,
        reason: str = "Violated Rules",
    ):
        uid = str(user.id)
        async with data_lock:
            if uid not in vps_data or vps_number < 1 or vps_number > len(vps_data[uid]):
                return await interaction.response.send_message(
                    embed=create_error_embed("Error", "Invalid user or VPS number."), ephemeral=True
                )
            vps            = vps_data[uid][vps_number - 1]
            container_name = vps["container_name"]
            node           = vps.get("node", "local")
            prefix         = f"{node}:" if node != "local" else ""

        view = ConfirmView(str(interaction.user.id), requires_2fa=True)
        await interaction.response.send_message(
            embed=create_warning_embed("Delete VPS?", f"Delete `{container_name}`? All data will be lost."),
            view=view,
        )
        await view.wait()

        if not view.value:
            return await interaction.edit_original_response(embed=create_info_embed("Cancelled", "Deletion cancelled."), view=None)

        await interaction.edit_original_response(embed=create_info_embed("Deleting…", f"Removing `{container_name}`…"), view=None)

        try:
            await execute_lxc(f"lxc delete {prefix}{container_name} --force")
        except Exception:
            pass

        async with data_lock:
            if uid in vps_data and len(vps_data[uid]) >= vps_number:
                del vps_data[uid][vps_number - 1]
                if not vps_data[uid]:
                    del vps_data[uid]

        await async_save_vps_data()

        embed = create_success_embed("VPS Deleted")
        add_field(embed, "Container", f"`{container_name}`", True)
        add_field(embed, "Reason",    reason, True)
        await interaction.edit_original_response(embed=embed)

        # DM the VPS owner
        try:
            owner_user = await interaction.client.fetch_user(int(uid))
            dm = discord.Embed(
                title="🗑️  Your VPS Was Deleted",
                description=(
                    f"Your VPS **`{container_name}`** has been removed by a staff member.\n\n"
                    f"**Reason:** {reason}\n\n"
                    "If you believe this is a mistake, please open a support ticket with `/support`."
                ),
                color=0xED4245,
            )
            dm.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
            dm.set_footer(text="MoonNodes VPS Manager")
            await owner_user.send(embed=dm)
        except Exception:
            pass


async def setup(bot):
    await bot.add_cog(DeleteCog(bot))
