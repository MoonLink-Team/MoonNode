from core.lxc import normalize_os
import asyncio
import random
import time
import uuid
import discord
from discord import app_commands
from discord.ext import commands

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, active_giveaways
from core.theme import create_embed, create_success_embed, create_error_embed, create_info_embed, add_field
from core.lxc import deploy_container, get_best_node
from core import ACTIVE_STORAGE_POOL
from ui.plans_view import GiveawayView


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if uid == str(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure(f"Required role: {', '.join(roles)}")
    return app_commands.check(predicate)


async def _giveaway_task(g_id, duration_sec, winners_count, ram, cpu, disk, message, view):
    await asyncio.sleep(duration_sec)
    if g_id not in active_giveaways:
        return
    del active_giveaways[g_id]

    if not view.entrants:
        try:
            await message.reply(embed=create_error_embed("Giveaway Ended", "Nobody entered. No VPS deployed."))
        except Exception:
            pass
        return

    pool   = list(view.entrants)
    drawn  = random.sample(pool, min(winners_count, len(pool)))
    tags   = [f"<@{uid}>" for uid in drawn]

    congrats = create_success_embed("🎉 Giveaway Complete!", f"Winners: {', '.join(tags)}\n\nVPS instances are being created — check your DMs.")
    try:
        await message.reply(content=", ".join(tags), embed=congrats)
    except Exception:
        pass

    for uid in drawn:
        member = None
        # message.guild may be None if message was deleted or bot lost guild access
        guild = getattr(message, "guild", None)
        if guild:
            member = guild.get_member(uid)
            if not member:
                try:
                    member = await guild.fetch_member(uid)
                except Exception:
                    pass
        if not member:
            try:
                # Last resort: fetch user (no guild context)
                member = await message._state._get_or_fetch_user(uid)
            except Exception:
                pass
        if member:
            try:
                node_prefix = await get_best_node()
                vps_entry = await deploy_container(
                    user_id=str(uid), username=member.name,
                    ram=ram, cpu=cpu, disk=disk,
                
                    os_version=normalize_os("ubuntu:22.04"), validity_days=None,
                    target_node=node_prefix, storage_pool=ACTIVE_STORAGE_POOL,
                )
                dm = discord.Embed(
                    title="🎉  Congratulations — You Won a VPS!",
                    description=(
                        f"You were selected as a **giveaway winner** and your VPS has been deployed!\n\n"
                        f"**Container:** `{vps_entry.get('container_name','—')}`\n"
                        f"**Specs:** `{ram}GB RAM · {cpu} CPU · {disk}GB Disk`\n"
                        f"**OS:** Ubuntu 22.04 LTS\n\n"
                        f"Use `/manage` to start your VPS and get SSH access."
                    ),
                    color=0xFFD700,
                )
                dm.set_author(name="MoonNodes Giveaway", icon_url="https://imgur.com/6yfYDTP.png")
                dm.set_footer(text="Enjoy your free VPS! • MoonNodes")
                await member.send(embed=dm)
            except Exception as e:
                pass


class GiveawayCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="giveaway", description="[ADMIN] Start or manage a VPS giveaway")
    @app_commands.choices(action=[
        app_commands.Choice(name="Create", value="create"),
        app_commands.Choice(name="Cancel", value="delete"),
        app_commands.Choice(name="List",   value="list"),
    ])
    @app_commands.describe(
        duration_minutes="Duration in minutes",
        ram="RAM in GB", cpu="CPU cores", disk="Disk in GB",
        winners="Number of winners",
        description="Giveaway message",
        target_id="Giveaway ID to cancel",
    )
    @has_role("Owner", "Admin")
    async def giveaway_cmd(
        self, interaction: discord.Interaction,
        action: str,
        duration_minutes: int = None, ram: int = None, cpu: int = None,
        disk: int = None, winners: int = None, description: str = None,
        target_id: str = None,
    ):
        await interaction.response.defer(ephemeral=True)

        if action == "create":
            if not all([duration_minutes, ram, cpu, disk, winners]):
                return await interaction.followup.send(embed=create_error_embed("Error", "Provide duration, ram, cpu, disk, and winners."))

            g_id     = uuid.uuid4().hex[:6].upper()
            end_time = int(time.time() + duration_minutes * 60)

            embed = create_embed(f"🎉 VPS Giveaway `[{g_id}]`", description or "Click below to enter!")
            add_field(embed, "Specs",   f"```yaml\nRAM: {ram}GB\nCPU: {cpu} Cores\nDisk: {disk}GB\n```", False)
            add_field(embed, "Details", f"**Winners:** {winners}\n**Ends:** <t:{end_time}:R> (<t:{end_time}:F>)", False)

            view = GiveawayView(g_id)
            await interaction.followup.send(embed=create_success_embed("Started", f"Giveaway ID: `[{g_id}]`"))
            msg  = await interaction.channel.send(embed=embed, view=view)

            task = asyncio.create_task(_giveaway_task(g_id, duration_minutes * 60, winners, ram, cpu, disk, msg, view))
            active_giveaways[g_id] = {"task": task, "end": end_time, "msg": msg.jump_url}

        elif action == "delete":
            if not target_id or target_id not in active_giveaways:
                return await interaction.followup.send(embed=create_error_embed("Error", f"Giveaway `{target_id}` not found."))
            active_giveaways[target_id]["task"].cancel()
            del active_giveaways[target_id]
            await interaction.followup.send(embed=create_success_embed("Cancelled", f"Giveaway `[{target_id}]` cancelled."))

        elif action == "list":
            if not active_giveaways:
                return await interaction.followup.send(embed=create_info_embed("Empty", "No active giveaways."))
            embed = create_embed("⏳ Active Giveaways")
            for gid, data in active_giveaways.items():
                add_field(embed, f"ID: `{gid}`", f"Ends: <t:{data['end']}:R>\n[View]({data['msg']})", False)
            await interaction.followup.send(embed=embed)


async def setup(bot):
    await bot.add_cog(GiveawayCog(bot))
