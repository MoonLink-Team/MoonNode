"""
/giveaway — [ADMIN] Giveaway system.

Fixes:
  - message._state.bot removed (broken in discord.py 2.x) → pass bot ref explicitly
  - GiveawayView now registered with bot.add_view() so buttons survive restarts
  - list_lxd_remotes replaced with DB get_nodes()
  - Entries saved to DB so giveaway survives bot restart
  - Admin node-select sent as ephemeral in-channel, not DM (more reliable)
  - Winner OS-select DM has fallback if DMs closed
  - All error paths handled, no silent swallows
"""
import asyncio
import random
import time
import uuid
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config   import MAIN_ADMIN_ID
from core.database import admin_data, active_giveaways, get_db, save_giveaway, end_giveaway
from core.theme    import Theme, add_field, create_error_embed, create_info_embed, create_success_embed
from core          import ACTIVE_STORAGE_POOL
from ui.plans_view import GiveawayView


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if int(uid) == int(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure("🚫 no_permission")
    return app_commands.check(predicate)


# ── Winner OS select (sent via DM) ───────────────────────────────────────────

class WinnerOSSelectView(discord.ui.View):
    def __init__(self, bot, winner_id: int, ram: int, cpu: int, disk: int,
                 target_node: str, storage_pool: str):
        super().__init__(timeout=600)
        self.bot          = bot
        self.winner_id    = winner_id
        self.ram          = ram
        self.cpu          = cpu
        self.disk         = disk
        self.target_node  = target_node
        self.storage_pool = storage_pool

        from core.config import OS_OPTIONS
        select = discord.ui.Select(
            placeholder="▼  Choose your Operating System",
            options=[
                discord.SelectOption(
                    label=o["label"], value=o["value"],
                    description=o.get("desc", ""), emoji=o.get("emoji", "💿"),
                ) for o in OS_OPTIONS
            ],
        )
        select.callback = self._on_select
        self.add_item(select)

    async def _on_select(self, interaction: discord.Interaction):
        if interaction.user.id != self.winner_id:
            return await interaction.response.send_message(
                "This OS selection belongs to the giveaway winner, not you.", ephemeral=True)

        os_version = interaction.data["values"][0]
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(
            embed=discord.Embed(
                title="⏳ Deploying Your VPS…",
                description="This takes ~1 min.",
                color=0x5865F2,
            ),
            view=self,
        )
        try:
            from core.lxc import deploy_container
            winner = await self.bot.fetch_user(self.winner_id)
            entry  = await deploy_container(
                user_id      = str(self.winner_id),
                username     = winner.name,
                ram          = self.ram,
                cpu          = self.cpu,
                disk         = self.disk,
                os_version   = os_version,
                validity_days= None,
                target_node  = self.target_node,
                storage_pool = self.storage_pool,
            )
            name = entry["container_name"]
            done = discord.Embed(
                title="🎉 Your Giveaway VPS is Ready!",
                description=(
                    f"**Container:** `{name}`\n"
                    f"**Specs:** `{self.ram}GB RAM · {self.cpu} CPU · {self.disk}GB Disk`\n"
                    f"**OS:** `{os_version}`\n"
                    f"**Node:** `{self.target_node or 'local'}`\n\n"
                    "Use `/manage` in the server to get SSH access and start using your VPS!"
                ),
                color=0xFFD700,
                timestamp=datetime.now(),
            )
            done.set_author(name="MoonNodes", icon_url="https://imgur.com/6yfYDTP.png")
            done.set_footer(text="Enjoy your free VPS! · MoonNodes")
            await interaction.message.edit(embed=done, view=None)
        except Exception as e:
            err = create_error_embed("Deployment Failed", f"```\n{str(e)[:1400]}\n```")
            try:
                await interaction.edit_original_response(embed=err, view=None)
            except Exception:
                try:
                    await interaction.followup.send(embed=err, ephemeral=True)
                except Exception:
                    pass


# ── Admin node select (ephemeral, shown in-channel after draw) ────────────────

class AdminNodeSelectView(discord.ui.View):
    def __init__(self, bot, admin_id: int, winner_id: int, winner_obj: discord.User,
                 ram: int, cpu: int, disk: int, storage_pool: str):
        super().__init__(timeout=300)
        self.bot          = bot
        self.admin_id     = admin_id
        self.winner_id    = winner_id
        self.winner_obj   = winner_obj
        self.ram          = ram
        self.cpu          = cpu
        self.disk         = disk
        self.storage_pool = storage_pool

    @classmethod
    async def build(cls, bot, admin_id, winner_id, winner_obj, ram, cpu, disk, storage_pool):
        self = cls(bot, admin_id, winner_id, winner_obj, ram, cpu, disk, storage_pool)

        # Build node options from DB
        try:
            from core.database import get_nodes
            from core.lxc import get_node_stats
            nodes = get_nodes()
        except Exception:
            nodes = ["local"]

        options = []
        for node in nodes[:25]:
            try:
                stats = await get_node_stats(node)
                desc  = (f"RAM {stats['used_ram_mb']}MB/{stats['total_ram_mb']}MB "
                         f"· VPS {stats['vps_running']}/{stats['vps_count']}")
            except Exception:
                desc = "Stats unavailable"
            label = f"{'🏠 Local' if node == 'local' else f'🌐 {node}'}"
            options.append(discord.SelectOption(
                label=label[:100], value=node,
                description=desc[:100], emoji="🖥️",
            ))

        if not options:
            options = [discord.SelectOption(label="Local", value="local", emoji="🏠")]

        sel = discord.ui.Select(
            placeholder="▼ Select deployment node for winner",
            options=options,
        )
        sel.callback = self._on_select
        self.add_item(sel)
        return self

    async def _on_select(self, interaction: discord.Interaction):
        if interaction.user.id != self.admin_id:
            return await interaction.response.send_message("Admin only.", ephemeral=True)

        chosen_node = interaction.data["values"][0]
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(
            embed=create_success_embed(
                f"✅ Node Selected — `{chosen_node}`",
                f"Sending OS selection DM to **{self.winner_obj}**…",
            ),
            view=self,
        )

        os_view  = WinnerOSSelectView(
            bot          = self.bot,
            winner_id    = self.winner_id,
            ram          = self.ram,
            cpu          = self.cpu,
            disk         = self.disk,
            target_node  = chosen_node,
            storage_pool = self.storage_pool,
        )
        dm_embed = discord.Embed(
            title="🎉 You Won a VPS Giveaway!",
            description=(
                f"You won a VPS giveaway on **MoonNodes**! 🎉\n\n"
                f"**Specs:** `{self.ram}GB RAM · {self.cpu} CPU · {self.disk}GB Disk`\n"
                f"**Node:** `{chosen_node}`\n\n"
                "**Choose your operating system below to claim your VPS.**\n"
                "⏳ You have **10 minutes** to make your selection."
            ),
            color=0xFFD700,
            timestamp=datetime.now(),
        )
        dm_embed.set_author(name="MoonNodes", icon_url="https://imgur.com/6yfYDTP.png")
        dm_embed.set_footer(text="MoonNodes · Giveaway")

        try:
            await self.winner_obj.send(embed=dm_embed, view=os_view)
            await interaction.followup.send(
                embed=create_info_embed(
                    "✅ OS Select Sent",
                    f"DM sent to {self.winner_obj.mention}.\n"
                    "Waiting for them to pick an OS — their VPS will deploy automatically.",
                ),
                ephemeral=True,
            )
        except discord.Forbidden:
            # DMs closed — send OS select in the current channel instead
            await interaction.followup.send(
                embed=discord.Embed(
                    title="⚠️ DMs Closed — Select OS Here",
                    description=(
                        f"{self.winner_obj.mention} — **your DMs are closed!**\n\n"
                        "Please select your OS below to claim your VPS:"
                    ),
                    color=0xFFA500,
                ),
                view=os_view,
            )
        except Exception as e:
            await interaction.followup.send(
                embed=create_error_embed("DM Failed", str(e)[:500]),
                ephemeral=True,
            )


# ── Giveaway end task ─────────────────────────────────────────────────────────

async def _giveaway_task(bot, g_id, duration_sec, winners_count, ram, cpu, disk,
                         message, view, invoker_id, storage_pool):
    """Background task: sleeps until end, draws winner(s), kicks off deployment flow."""
    await asyncio.sleep(duration_sec)

    if g_id not in active_giveaways:
        return  # was cancelled
    del active_giveaways[g_id]

    entrants = list(view.entrants)
    if not entrants:
        try:
            await message.reply(embed=create_error_embed(
                "Giveaway Ended — No Entries",
                "Nobody entered this giveaway. No VPS has been deployed.",
            ))
        except Exception:
            pass
        end_giveaway(g_id)
        return

    # Persist winner in DB
    drawn = random.sample(entrants, min(winners_count, len(entrants)))
    end_giveaway(g_id, winner_id=str(drawn[0]))

    tags = [f"<@{uid}>" for uid in drawn]
    try:
        await message.reply(
            content=", ".join(tags),
            embed=create_success_embed(
                "🎉 Giveaway Winners!",
                f"**Winner(s):** {', '.join(tags)}\n\n"
                "Winners — check your DMs to select your OS and claim your VPS!\n"
                "*(Admin: check your DMs to pick the deployment node.)*"
            ),
        )
    except Exception:
        pass

    # Fetch invoker admin
    try:
        invoker = await bot.fetch_user(int(invoker_id))
    except Exception:
        invoker = None

    for winner_uid in drawn:
        try:
            winner_user = await bot.fetch_user(int(winner_uid))
        except Exception:
            continue

        # Award 3 giveaway coins
        try:
            from core.database import add_coins
            add_coins(str(winner_uid), 3, reason="giveaway_win")
        except Exception:
            pass

        # Send admin the node-select view via DM
        if invoker:
            try:
                node_view = await AdminNodeSelectView.build(
                    bot          = bot,
                    admin_id     = invoker.id,
                    winner_id    = winner_uid,
                    winner_obj   = winner_user,
                    ram          = ram,
                    cpu          = cpu,
                    disk         = disk,
                    storage_pool = storage_pool,
                )
                admin_dm = discord.Embed(
                    title="🎉 Giveaway Winner — Select Deployment Node",
                    description=(
                        f"**Winner:** {winner_user.mention} (`{winner_uid}`)\n"
                        f"**Specs:** `{ram}GB RAM · {cpu} CPU · {disk}GB Disk`\n\n"
                        "Select a node below. After you pick, the winner will receive an OS-select DM."
                    ),
                    color=0xFFD700,
                    timestamp=datetime.now(),
                )
                admin_dm.set_author(name="MoonNodes", icon_url="https://imgur.com/6yfYDTP.png")
                await invoker.send(embed=admin_dm, view=node_view)
            except Exception as e:
                # If admin DM fails, try the channel
                try:
                    await message.channel.send(
                        embed=create_info_embed(
                            "⚠️ Admin — Select Deployment Node",
                            f"Could not DM you. Winner: {winner_user.mention}\n"
                            f"Please use `/create user:{winner_uid}` to manually deploy.",
                        )
                    )
                except Exception:
                    pass


# ── /giveaway command ─────────────────────────────────────────────────────────

class GiveawayCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="giveaway", description="[ADMIN] Start or manage a VPS giveaway")
    @app_commands.choices(action=[
        app_commands.Choice(name="🎉 Create — Start a new VPS giveaway", value="create"),
        app_commands.Choice(name="❌ Cancel — Cancel an active giveaway", value="delete"),
        app_commands.Choice(name="📋 List   — Show all active giveaways", value="list"),
    ])
    @app_commands.describe(
        action           = "Action to perform",
        duration_minutes = "How long the giveaway runs (minutes)",
        ram              = "RAM in GB for the prize VPS",
        cpu              = "CPU cores for the prize VPS",
        disk             = "Disk in GB for the prize VPS",
        winners          = "Number of winners to draw",
        description      = "Announcement message shown on the giveaway embed",
        target_id        = "Giveaway ID to cancel (from /giveaway action:List)",
    )
    @has_role("Owner", "Admin")
    async def giveaway_cmd(
        self, interaction: discord.Interaction,
        action:           str,
        duration_minutes: int = None,
        ram:              int = None,
        cpu:              int = None,
        disk:             int = None,
        winners:          int = 1,
        description:      str = None,
        target_id:        str = None,
    ):
        await interaction.response.defer(ephemeral=True)

        # ── Create ────────────────────────────────────────────────────────────
        if action == "create":
            missing = [n for n, v in [
                ("duration_minutes", duration_minutes), ("ram", ram),
                ("cpu", cpu), ("disk", disk),
            ] if not v]
            if missing:
                return await interaction.followup.send(embed=create_error_embed(
                    "Missing Parameters",
                    f"Provide: {', '.join(f'`{m}`' for m in missing)}",
                ), ephemeral=True)

            g_id     = uuid.uuid4().hex[:6].upper()
            end_time = int(time.time() + duration_minutes * 60)
            winners  = max(1, winners)

            embed = discord.Embed(
                title=f"🎉 VPS Giveaway — `[{g_id}]`",
                description=description or "Press **Enter Giveaway** to join!",
                color=0xFFD700,
                timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes", icon_url="https://imgur.com/6yfYDTP.png")
            add_field(embed, "📦 Prize Specs",
                      f"```yaml\nRAM:  {ram}GB\nCPU:  {cpu} Core(s)\nDisk: {disk}GB\n```", False)
            add_field(embed, "🏆 Winners",  str(winners),        True)
            add_field(embed, "⏳ Ends",     f"<t:{end_time}:R>", True)
            add_field(embed, "📅 End Time", f"<t:{end_time}:F>", True)
            embed.set_footer(text="Click below to enter · MoonNodes")

            view = GiveawayView(g_id)
            # Register view with bot so it works after restarts
            self.bot.add_view(view)

            msg = await interaction.channel.send(embed=embed, view=view)

            task = asyncio.create_task(_giveaway_task(
                bot          = self.bot,
                g_id         = g_id,
                duration_sec = duration_minutes * 60,
                winners_count= winners,
                ram          = ram,
                cpu          = cpu,
                disk         = disk,
                message      = msg,
                view         = view,
                invoker_id   = str(interaction.user.id),
                storage_pool = ACTIVE_STORAGE_POOL,
            ))

            active_giveaways[g_id] = {
                "task":       task,
                "end":        end_time,
                "msg":        msg.jump_url,
                "message_id": str(msg.id),
                "channel_id": str(msg.channel.id),
                "created_by": str(interaction.user.id),
                "entries":    [],
            }

            # Persist to DB
            save_giveaway(g_id, {
                "channel_id":  str(interaction.channel_id),
                "message_id":  str(msg.id),
                "msg":         msg.jump_url,
                "prize":       f"{ram}GB RAM / {cpu} CPU / {disk}GB",
                "end":         datetime.fromtimestamp(end_time).isoformat(),
                "created_by":  str(interaction.user.id),
                "status":      "active",
                "entries":     [],
            })

            await interaction.followup.send(embed=create_success_embed(
                "🎉 Giveaway Started!",
                f"**ID:** `{g_id}`\n"
                f"**Prize:** `{ram}GB RAM · {cpu} CPU · {disk}GB Disk`\n"
                f"**Duration:** `{duration_minutes}` minute(s)\n"
                f"**Winners:** `{winners}`\n\n"
                f"[Jump to giveaway]({msg.jump_url})",
            ), ephemeral=True)

        # ── Cancel ────────────────────────────────────────────────────────────
        elif action == "delete":
            if not target_id:
                return await interaction.followup.send(embed=create_error_embed(
                    "Missing ID",
                    "Provide `target_id` — use `/giveaway action:List` to find it.",
                ), ephemeral=True)

            gid = target_id.upper().strip()
            if gid not in active_giveaways:
                return await interaction.followup.send(embed=create_error_embed(
                    "Not Found",
                    f"No active giveaway with ID `{gid}`.\n"
                    "Use `/giveaway action:List` to see all active giveaways.",
                ), ephemeral=True)

            active_giveaways[gid]["task"].cancel()
            del active_giveaways[gid]
            end_giveaway(gid)

            await interaction.followup.send(embed=create_success_embed(
                "✅ Giveaway Cancelled",
                f"Giveaway `[{gid}]` has been cancelled. No winner was drawn.",
            ), ephemeral=True)

        # ── List ──────────────────────────────────────────────────────────────
        elif action == "list":
            if not active_giveaways:
                return await interaction.followup.send(embed=create_info_embed(
                    "No Active Giveaways",
                    "There are no giveaways running right now.\n"
                    "Start one with `/giveaway action:Create`.",
                ), ephemeral=True)

            embed = discord.Embed(
                title=f"⏳ Active Giveaways ({len(active_giveaways)})",
                color=0xFFD700,
                timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes", icon_url="https://imgur.com/6yfYDTP.png")
            for gid, data in active_giveaways.items():
                entries = len(data.get("entries", []))
                add_field(
                    embed,
                    f"🎉 `[{gid}]`",
                    f"Ends: <t:{data['end']}:R>\n"
                    f"Entries: `{entries}`\n"
                    f"[Jump to message]({data['msg']})",
                    False,
                )
            await interaction.followup.send(embed=embed, ephemeral=True)


async def setup(bot):
    await bot.add_cog(GiveawayCog(bot))
