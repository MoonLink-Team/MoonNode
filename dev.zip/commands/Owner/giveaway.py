"""
/giveaway — [ADMIN] VPS Giveaway system.

Winner flow:
  1. Bot draws winner(s)
  2. Admin sees a node-select dropdown (only visible to them, ephemeral)
  3. After admin picks a node, winner gets an OS-select dropdown via DM
  4. Winner picks OS → VPS deployed → winner gets VPS-ready DM
"""
import asyncio
import random
import time
import uuid
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, active_giveaways, get_setting
from core.theme import Theme, add_field, create_embed, create_error_embed, create_info_embed, create_success_embed, create_warning_embed
from core.lxc import list_lxd_remotes, get_node_stats, deploy_container
from core import ACTIVE_STORAGE_POOL
from ui.plans_view import GiveawayView


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if int(uid) == int(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure("🚫 no_permission")
    return app_commands.check(predicate)


# ── Winner OS select (sent via DM) ───────────────────────────────────────────

class WinnerOSSelectView(discord.ui.View):
    """Sent in the winner's DM. They pick an OS, then the VPS is deployed."""
    def __init__(self, winner_id: int, ram: int, cpu: int, disk: int,
                 target_node: str, storage_pool: str, admin_interaction):
        super().__init__(timeout=600)
        self.winner_id       = winner_id
        self.ram             = ram
        self.cpu             = cpu
        self.disk            = disk
        self.target_node     = target_node
        self.storage_pool    = storage_pool
        self.admin_interaction = admin_interaction

        from core.config import OS_OPTIONS
        select = discord.ui.Select(
            placeholder="▼  Choose your Operating System",
            options=[
                discord.SelectOption(
                    label=o["label"], value=o["value"],
                    description=o.get("desc",""), emoji=o.get("emoji","💿")
                ) for o in OS_OPTIONS
            ]
        )
        select.callback = self._on_select
        self.add_item(select)

    async def _on_select(self, interaction: discord.Interaction):
        if interaction.user.id != self.winner_id:
            return await interaction.response.send_message("This isn't your giveaway selection.", ephemeral=True)

        os_version = interaction.data["values"][0]
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(
            embed=discord.Embed(title=f"{Theme.LOADING} Setting up your VPS…",
                description="Please wait while your VPS is being deployed!",
                color=0x5865F2),
            view=self,
        )
        try:
            winner = await interaction.client.fetch_user(self.winner_id)
            entry = await deploy_container(
                user_id      = str(self.winner_id),
                username     = winner.name,
                ram          = self.ram,
                cpu          = self.cpu,
                disk         = self.disk,
                os_version   = os_version,
                validity_days= None,
                target_node  = self.target_node,
                storage_pool = self.storage_pool,
            )
            name = entry["container_name"]
            dm = discord.Embed(
                title="🎉 Your Giveaway VPS is Ready!",
                description=(
                    f"Your VPS has been **deployed and is now online**!\n\n"
                    f"**Container:** `{name}`\n"
                    f"**Specs:** `{self.ram}GB RAM · {self.cpu} CPU · {self.disk}GB Disk`\n"
                    f"**OS:** `{os_version}`\n"
                    f"**Node:** `{self.target_node or 'local'}`\n\n"
                    "Use `/manage` in the server to get SSH access."
                ),
                color=0xFFD700, timestamp=datetime.now(),
            )
            dm.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
            dm.set_footer(text="Enjoy your free VPS! • MoonNodes")
            await interaction.edit_original_message(embed=dm, view=None)
        except Exception as e:
            await interaction.edit_original_message(
                embed=create_error_embed("Deployment Failed", str(e)[:1500]), view=None)


# ── Admin node select (ephemeral, only shown to admin after winner drawn) ─────

class AdminNodeSelectView(discord.ui.View):
    """Admin-only. After picking a node, the winner gets a DM with OS select."""
    def __init__(self, admin_id: int, winner_id: int, ram: int, cpu: int,
                 disk: int, storage_pool: str, winner_obj: discord.User):
        super().__init__(timeout=300)
        self.admin_id     = admin_id
        self.winner_id    = winner_id
        self.ram          = ram
        self.cpu          = cpu
        self.disk         = disk
        self.storage_pool = storage_pool
        self.winner_obj   = winner_obj

    @classmethod
    async def build(cls, admin_id, winner_id, ram, cpu, disk, storage_pool, winner_obj):
        self = cls(admin_id, winner_id, ram, cpu, disk, storage_pool, winner_obj)
        remotes = await list_lxd_remotes()
        nodes   = ["local"] + remotes
        options = []
        for node in nodes:
            stats = await get_node_stats(node)
            label = f"{'🏠 Local' if node == 'local' else f'🌐 {node}'}"
            desc  = f"RAM {stats['used_ram_mb']}MB/{stats['total_ram_mb']}MB ({stats['ram_pct']}%) | VPS {stats['vps_running']}/{stats['vps_count']}"
            options.append(discord.SelectOption(label=label[:100], value=node,
                description=desc[:100], emoji="🖥️"))
        if not options:
            options = [discord.SelectOption(label="Local", value="local", emoji="🏠")]
        sel = discord.ui.Select(placeholder="▼ Select deployment node for winner", options=options)
        sel.callback = self._on_select
        self.add_item(sel)
        return self

    async def _on_select(self, interaction: discord.Interaction):
        if interaction.user.id != self.admin_id:
            return await interaction.response.send_message("Admin only.", ephemeral=True)
        chosen_node = interaction.data["values"][0]
        for item in self.children:
            item.disabled = True
        await interaction.response.edit_message(
            embed=create_success_embed(f"Node Selected: {chosen_node}",
                f"Sending OS selection to {self.winner_obj.mention} via DM…"),
            view=self,
        )
        # DM the winner with OS select
        try:
            os_view = WinnerOSSelectView(
                winner_id    = self.winner_id,
                ram          = self.ram,
                cpu          = self.cpu,
                disk         = self.disk,
                target_node  = chosen_node,
                storage_pool = self.storage_pool,
                admin_interaction = interaction,
            )
            dm_embed = discord.Embed(
                title="🎉 You Won a VPS Giveaway!",
                description=(
                    f"**Congratulations!** You were selected as a giveaway winner on **MoonNodes**!\n\n"
                    f"**Specs:** `{self.ram}GB RAM · {self.cpu} CPU · {self.disk}GB Disk`\n"
                    f"**Node:** `{chosen_node}`\n\n"
                    "**Choose your operating system below to claim your VPS:**"
                ),
                color=0xFFD700, timestamp=datetime.now(),
            )
            dm_embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
            dm_embed.set_footer(text="You have 10 minutes to pick your OS · MoonNodes")
            await self.winner_obj.send(embed=dm_embed, view=os_view)
            await interaction.followup.send(
                embed=create_info_embed("OS Select Sent", f"DM sent to {self.winner_obj.mention}. Waiting for OS choice."),
                ephemeral=True)
        except discord.Forbidden:
            await interaction.followup.send(
                embed=create_error_embed("DM Failed", f"Could not DM {self.winner_obj}. Their DMs may be closed."), ephemeral=True)
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Error", str(e)[:1000]), ephemeral=True)


# ── Giveaway end task ─────────────────────────────────────────────────────────

async def _giveaway_task(g_id, duration_sec, winners_count, ram, cpu, disk,
                         message, view, invoker_user, storage_pool):
    await asyncio.sleep(duration_sec)
    if g_id not in active_giveaways:
        return
    del active_giveaways[g_id]

    if not view.entrants:
        try:
            await message.reply(embed=create_error_embed("Giveaway Ended", "Nobody entered. No VPS deployed."))
        except Exception:
            pass
        return

    pool  = list(view.entrants)
    drawn = random.sample(pool, min(winners_count, len(pool)))
    tags  = [f"<@{uid}>" for uid in drawn]

    congrats = create_success_embed(
        "🎉 Giveaway Winners!",
        f"**Winner(s):** {', '.join(tags)}\n\n"
        "Winners — check your DMs to select your OS and claim your VPS!"
    )
    try:
        await message.reply(content=", ".join(tags), embed=congrats)
    except Exception:
        pass

    for winner_uid in drawn:
        try:
            winner_user = await message._state.bot.fetch_user(winner_uid)
        except Exception:
            continue

        # Award giveaway coins
        try:
            from core.database import add_coins
            add_coins(str(winner_uid), 3)
        except Exception:
            pass

        # Build admin node select — send to the invoker admin ephemerally
        try:
            node_view = await AdminNodeSelectView.build(
                admin_id     = invoker_user.id,
                winner_id    = winner_uid,
                ram          = ram,
                cpu          = cpu,
                disk         = disk,
                storage_pool = storage_pool,
                winner_obj   = winner_user,
            )
            try:
                await invoker_user.send(
                    embed=create_info_embed(
                        "🎉 Giveaway Winner — Select Deployment Node",
                        f"**Winner:** {winner_user.mention} (`{winner_uid}`)\n"
                        f"**Specs:** `{ram}GB RAM · {cpu} CPU · {disk}GB Disk`\n\n"
                        "Select a node to deploy the winner's VPS, then they'll choose their OS via DM:"
                    ),
                    view=node_view,
                )
            except Exception:
                pass
        except Exception as e:
            pass


# ── /giveaway command ─────────────────────────────────────────────────────────

class GiveawayCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="giveaway", description="[ADMIN] Start or manage a VPS giveaway")
    @app_commands.choices(action=[
        app_commands.Choice(name="🎉 Create — Start a new VPS giveaway", value="create"),
        app_commands.Choice(name="❌ Cancel — Cancel an active giveaway", value="delete"),
        app_commands.Choice(name="📋 List — Show all active giveaways",   value="list"),
    ])
    @app_commands.describe(
        action           = "Action to perform",
        duration_minutes = "How long the giveaway runs (minutes)",
        ram  = "RAM in GB",
        cpu  = "CPU cores",
        disk = "Disk in GB",
        winners     = "Number of winners",
        description = "Giveaway announcement message",
        target_id   = "Giveaway ID to cancel",
    )
    @has_role("Owner", "Admin")
    async def giveaway_cmd(
        self, interaction: discord.Interaction,
        action: str,
        duration_minutes: int = None,
        ram:     int = None,
        cpu:     int = None,
        disk:    int = None,
        winners: int = None,
        description: str = None,
        target_id:   str = None,
    ):
        await interaction.response.defer(ephemeral=True)

        if action == "create":
            if not all([duration_minutes, ram, cpu, disk, winners]):
                return await interaction.followup.send(embed=create_error_embed(
                    "Missing Parameters",
                    "Provide: `duration_minutes`, `ram`, `cpu`, `disk`, `winners`."))

            g_id     = uuid.uuid4().hex[:6].upper()
            end_time = int(time.time() + duration_minutes * 60)

            embed = discord.Embed(
                title=f"🎉  VPS Giveaway  `[{g_id}]`",
                description=description or "React to enter the giveaway!",
                color=0xFFD700, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
            add_field(embed, "📦 Specs",
                f"```yaml\nRAM:  {ram}GB\nCPU:  {cpu} Cores\nDisk: {disk}GB\n```", False)
            add_field(embed, "🏆 Winners",   str(winners),                  True)
            add_field(embed, "⏳ Ends",      f"<t:{end_time}:R>",           True)
            add_field(embed, "📅 End Time",  f"<t:{end_time}:F>",           True)
            embed.set_footer(text="Click the button below to enter! • MoonNodes")

            view = GiveawayView(g_id)
            await interaction.followup.send(embed=create_success_embed("Giveaway Started 🎉", f"ID: `{g_id}`"))
            msg = await interaction.channel.send(embed=embed, view=view)

            task = asyncio.create_task(_giveaway_task(
                g_id, duration_minutes * 60, winners, ram, cpu, disk,
                msg, view, interaction.user, ACTIVE_STORAGE_POOL,
            ))
            active_giveaways[g_id] = {"task": task, "end": end_time, "msg": msg.jump_url}

        elif action == "delete":
            if not target_id or target_id not in active_giveaways:
                return await interaction.followup.send(embed=create_error_embed(
                    "Not Found", f"Giveaway `{target_id}` is not active. Use `/giveaway action:List` to see IDs."))
            active_giveaways[target_id]["task"].cancel()
            del active_giveaways[target_id]
            await interaction.followup.send(embed=create_success_embed("Cancelled", f"Giveaway `[{target_id}]` has been cancelled."))

        elif action == "list":
            if not active_giveaways:
                return await interaction.followup.send(embed=create_info_embed("No Active Giveaways", "Start one with `/giveaway action:Create`."))
            embed = discord.Embed(title="⏳ Active Giveaways", color=0xFFD700, timestamp=datetime.now())
            embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
            for gid, data in active_giveaways.items():
                add_field(embed, f"ID: `{gid}`",
                    f"Ends: <t:{data['end']}:R>\n[Jump to message]({data['msg']})", False)
            await interaction.followup.send(embed=embed)


async def setup(bot):
    await bot.add_cog(GiveawayCog(bot))
