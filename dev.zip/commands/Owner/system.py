import discord
from discord import app_commands
from discord.ext import commands
import core.config as cfg

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock, save_vps_data, get_db, set_setting, get_setting
from core.theme import create_success_embed, create_error_embed, create_info_embed, create_embed, add_field, Theme
from datetime import datetime

def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if uid == str(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure(f"Required role: {', '.join(roles)}")
    return app_commands.check(predicate)

# Extension registry: display name → config attribute
EXTENSIONS = {
    "Multi-Node Support":     "MULTI_NODE",
    "Scheduled Backups":      "SOSB",
    "Ticket System":          "ISTS",
    "Auto Expire & Suspend":  "AES",
    "Renewal Reminders":      "RR",
    "Admin 2FA":              "A2FA",
    "Multi-Server Tickets":   "MSTC",
    "Backup Limits":          "UBL_ENABLED",
    "Marketplace":            "MARKETPLACE",
    "Account & MoonCoin":     "ACCOUNT",
    "VPS Renewal":            "VPS_RENEWAL",
    "VPS Monitoring Alerts":  "VPS_MONITORING",
    "VPS Templates":          "VPS_TEMPLATES",
    "Multi-language":         "MULTILANG",
}

EXT_CHOICES = [app_commands.Choice(name=n, value=n) for n in EXTENSIONS]


class SystemAdminCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="system", description="[OWNER] System — extensions, maintenance, A2FA, and tools")
    @app_commands.choices(action=[
        app_commands.Choice(name="🔌 Extension Toggle",   value="extension"),
        app_commands.Choice(name="👁️ View Extensions",    value="view_ext"),
        app_commands.Choice(name="🚧 Maintenance Mode",   value="maintenance"),
        app_commands.Choice(name="🧹 Clean DB",            value="clean"),
        app_commands.Choice(name="🔐 A2FA Management",     value="a2fa"),
        app_commands.Choice(name="🌙 MoonCoin Earning",    value="mooncoin"),
    ])
    @app_commands.choices(extension=EXT_CHOICES)
    @app_commands.choices(ext_state=[
        app_commands.Choice(name="✅ Enable",  value="enable"),
        app_commands.Choice(name="❌ Disable", value="disable"),
    ])
    @app_commands.choices(a2fa_action=[
        app_commands.Choice(name="Set / Edit PIN", value="edit"),
        app_commands.Choice(name="Remove PIN",     value="remove"),
    ])
    @app_commands.choices(mooncoin_action=[
        app_commands.Choice(name="➕ Add Earning Rule",    value="add"),
        app_commands.Choice(name="✏️ Edit Earning Rule",   value="edit_earn"),
        app_commands.Choice(name="🗑️ Remove Earning Rule", value="remove_earn"),
        app_commands.Choice(name="📋 List Earning Rules",  value="list_earn"),
    ])
    @app_commands.describe(
        action         ="What action to perform",
        extension      ="Extension to toggle",
        ext_state      ="Enable or disable",
        a2fa_action    ="A2FA action",
        new_pin        ="New 4-digit PIN",
        mooncoin_action="MoonCoin earning rule action",
        earning_name   ="Earning rule name (e.g. invite, chat, event)",
        earning_amount ="Coin amount for this rule",
        earning_cooldown="Cooldown in seconds (0 = no cooldown)",
    )
    @has_role("Owner")
    async def system_admin(
        self, interaction: discord.Interaction,
        action: str,
        extension: str = None,
        ext_state: str = None,
        a2fa_action: str = None,
        new_pin: str = None,
        mooncoin_action: str = None,
        earning_name: str = None,
        earning_amount: int = None,
        earning_cooldown: int = None,
    ):
        await interaction.response.defer(ephemeral=True)

        # ── View Extensions ──────────────────────────────────────────────────
        if action == "view_ext":
            embed = discord.Embed(
                title="🔌  Extension Status",
                description=f"{Theme.DIVIDER}\nAll available extensions and their current state\n{Theme.DIVIDER}",
                color=Theme.PRIMARY, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes — System Admin", icon_url="https://imgur.com/6yfYDTP.png")
            lines_on, lines_off = [], []
            for name, attr in EXTENSIONS.items():
                val = getattr(cfg, attr, False)
                (lines_on if val else lines_off).append(f"{'🟢' if val else '🔴'} **{name}**")
            embed.add_field(name="✅ Enabled", value="\n".join(lines_on)  or "*None*", inline=True)
            embed.add_field(name="❌ Disabled",value="\n".join(lines_off) or "*None*", inline=True)
            return await interaction.followup.send(embed=embed)

        # ── Extension Toggle ─────────────────────────────────────────────────
        elif action == "extension":
            if not extension or not ext_state:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Select an extension and a state."))
            attr  = EXTENSIONS.get(extension)
            if not attr:
                return await interaction.followup.send(embed=create_error_embed("Unknown", f"Extension `{extension}` not found."))
            value = (ext_state == "enable")
            setattr(cfg, attr, value)
            set_setting(f"ext_{attr}", str(value))
            icon = "✅" if value else "❌"
            embed = create_success_embed(
                "Extension Updated",
                f"{icon} **{extension}** is now **{'Enabled' if value else 'Disabled'}**."
            )
            # Extension-specific notes
            notes = {
                "Ticket System":         "Users can now open support tickets with `/support`.",
                "Scheduled Backups":     "Configure the schedule with `/set setting:Scheduled Backups`.",
                "Backup Limits":         "Configure limits with `/set setting:Backup Limits`.",
                "Admin 2FA":             "Set your PIN with `/system-admin action:A2FA Management`.",
                "Multi-Node Support":    "Register nodes with `/node pick_one:Create`.",
                "Auto Expire & Suspend": "VPS will auto-suspend when their expiry date passes.",
                "Renewal Reminders":     "Users will receive DM reminders 3 days before expiry.",
                "VPS Monitoring Alerts": "Users will be DM'd when their VPS goes over resource thresholds.",
                "VPS Templates":         "Pre-configured OS templates become available in the OS selector.",
                "VPS Renewal":           "Users can extend VPS expiry with `/upgrade`.",
                "Marketplace":           "Users can buy/sell VPS with `/marketplace`.",
            }
            if extension in notes:
                add_field(embed, "ℹ️ Note", notes[extension], False)
            return await interaction.followup.send(embed=embed)

        # ── Maintenance ──────────────────────────────────────────────────────
        elif action == "maintenance":
            cfg.MAINTENANCE_MODE = not getattr(cfg, "MAINTENANCE_MODE", False)
            state = "ON 🚧" if cfg.MAINTENANCE_MODE else "OFF ✅"
            return await interaction.followup.send(
                embed=create_success_embed("Maintenance Mode", f"Maintenance mode is now **{state}**.")
            )

        # ── Clean DB ─────────────────────────────────────────────────────────
        elif action == "clean":
            removed = 0
            with data_lock:
                for uid in list(vps_data.keys()):
                    before = len(vps_data[uid])
                    vps_data[uid] = [v for v in vps_data[uid] if v.get("container_name")]
                    removed += before - len(vps_data[uid])
                    if not vps_data[uid]:
                        del vps_data[uid]
            save_vps_data()
            return await interaction.followup.send(
                embed=create_success_embed("DB Cleaned", f"Removed **{removed}** stale VPS entries.")
            )

        # ── A2FA ─────────────────────────────────────────────────────────────
        # ── MoonCoin Earning Rules ───────────────────────────────────────────────
        # ── MoonCoin Earning Rules ─────────────────────────────────────────────
        elif action == "mooncoin":
            if not mooncoin_action:
                return await interaction.followup.send(embed=create_error_embed(
                    "❌ Missing Action",
                    (
                        "Choose a `mooncoin_action` from the dropdown:\n"
                        "• **➕ Add Earning Rule** — Create a new rule\n"
                        "• **✏️ Edit Earning Rule** — Update amount or cooldown\n"
                        "• **🗑️ Remove Earning Rule** — Delete a rule\n"
                        "• **📋 List Earning Rules** — View all active rules"
                    )
                ))

            conn = get_db()
            cur  = conn.cursor()
            cur.execute(
                "CREATE TABLE IF NOT EXISTS mooncoin_rules "
                "(name TEXT PRIMARY KEY, amount INTEGER DEFAULT 1, cooldown INTEGER DEFAULT 0)"
            )
            conn.commit()

            if mooncoin_action == "list_earn":
                cur.execute("SELECT name, amount, cooldown FROM mooncoin_rules ORDER BY amount DESC")
                rows = cur.fetchall()
                conn.close()
                embed = create_embed("🌙  MoonCoin Earning Rules", "")
                embed.set_author(name="MoonNodes — System", icon_url="https://imgur.com/6yfYDTP.png")
                if not rows:
                    embed.description = (
                        "No custom rules yet.\n\n"
                        "**Built-in defaults:**\n"
                        "`invite → +5` · `chat → +1 (300s cd)` · `giveaway → +3` · `event → +7`\n\n"
                        "Use `mooncoin_action:➕ Add` to create custom rules."
                    )
                else:
                    parts = []
                    for r in rows:
                        cd = f" · ⏱️ {r[0]}s" if len(r) > 2 and r[2] > 0 else ""
                        parts.append(f"🔹 **{r[0]}** → **+{r[1]}** 🌙{cd}")
                    embed.description = "\n".join(parts)
                embed.set_footer(text=f"{len(rows)} custom rule(s) active")
                return await interaction.followup.send(embed=embed)

            elif mooncoin_action == "add":
                if not earning_name or earning_amount is None:
                    conn.close()
                    return await interaction.followup.send(embed=create_error_embed(
                        "❌ Missing Fields",
                        (
                            "Both `earning_name` and `earning_amount` are required.\n\n"
                            "**Example:** `earning_name:daily` `earning_amount:10` `earning_cooldown:86400`"
                        )
                    ))
                cur.execute(
                    "INSERT OR REPLACE INTO mooncoin_rules (name, amount, cooldown) VALUES (?,?,?)",
                    (earning_name.lower(), earning_amount, earning_cooldown or 0)
                )
                conn.commit(); conn.close()
                embed = create_success_embed(
                    "✅  Earning Rule Added",
                    f"Users now earn **+{earning_amount} 🌙** for `{earning_name}`."
                )
                add_field(embed, "Rule Name", earning_name,                                          True)
                add_field(embed, "Reward",    f"+{earning_amount} 🌙",                              True)
                add_field(embed, "Cooldown",  f"{earning_cooldown}s" if earning_cooldown else "None", True)
                return await interaction.followup.send(embed=embed)

            elif mooncoin_action == "edit_earn":
                if not earning_name:
                    conn.close()
                    return await interaction.followup.send(embed=create_error_embed(
                        "❌ Missing", "Provide the `earning_name` to edit."
                    ))
                changes = []
                if earning_amount is not None:
                    cur.execute("UPDATE mooncoin_rules SET amount=? WHERE name=?",
                                (earning_amount, earning_name.lower()))
                    changes.append(f"Reward → **+{earning_amount} 🌙**")
                if earning_cooldown is not None:
                    cur.execute("UPDATE mooncoin_rules SET cooldown=? WHERE name=?",
                                (earning_cooldown, earning_name.lower()))
                    changes.append(f"Cooldown → **{earning_cooldown}s**")
                conn.commit(); conn.close()
                desc = ("\n".join(f"• {c}" for c in changes)) if changes else "No changes specified."
                return await interaction.followup.send(embed=create_success_embed(
                    "✏️  Earning Rule Updated",
                    f"Rule **`{earning_name}`** updated:\n{desc}"
                ))

            elif mooncoin_action == "remove_earn":
                if not earning_name:
                    conn.close()
                    return await interaction.followup.send(embed=create_error_embed(
                        "❌ Missing", "Provide the `earning_name` to remove."
                    ))
                cur.execute("DELETE FROM mooncoin_rules WHERE name=?", (earning_name.lower(),))
                deleted = cur.rowcount
                conn.commit(); conn.close()
                if deleted == 0:
                    return await interaction.followup.send(embed=create_error_embed(
                        "❌ Not Found",
                        f"No rule named `{earning_name}`. Use `mooncoin_action:📋 List` to see active rules."
                    ))
                return await interaction.followup.send(embed=create_success_embed(
                    "🗑️  Earning Rule Removed",
                    f"**`{earning_name}`** rule deleted. Users no longer earn coins from this action."
                ))

            conn.close()

        # ── A2FA ─────────────────────────────────────────────────────────────
        elif action == "a2fa":
            if not a2fa_action:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Choose an A2FA action."))
            if not cfg.A2FA:
                return await interaction.followup.send(
                    embed=create_error_embed("Extension Off", "Enable Admin 2FA first via Extension Toggle.")
                )

            conn = get_db()
            cur  = conn.cursor()
            uid  = str(interaction.user.id)

            if a2fa_action == "edit":
                if not new_pin or not new_pin.isdigit() or len(new_pin) != 4:
                    conn.close()
                    return await interaction.followup.send(embed=create_error_embed("Invalid PIN", "PIN must be exactly 4 digits."))
                cur.execute("INSERT OR IGNORE INTO admins (user_id) VALUES (?)", (uid,))
                cur.execute("UPDATE admins SET pin=? WHERE user_id=?", (new_pin, uid))
                conn.commit()
                conn.close()
                return await interaction.followup.send(embed=create_success_embed("PIN Updated", "Your A2FA PIN has been set. Keep it private!"))

            elif a2fa_action == "remove":
                cur.execute("UPDATE admins SET pin='0000' WHERE user_id=?", (uid,))
                conn.commit()
                conn.close()
                return await interaction.followup.send(embed=create_success_embed("PIN Removed", "A2FA PIN reset to default (0000)."))

            conn.close()


async def setup(bot):
    await bot.add_cog(SystemAdminCog(bot))
