"""
/system — [OWNER] System administration.

Database action rework:
  - No text input needed — shows Install / Delete buttons in a UI
  - Install: bot sends system.db file to Discord DM
  - Delete: confirms then deletes with auto-backup
"""

import os
import asyncio
import shutil
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

import core.config as cfg
from core.config import MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock, async_save_vps_data, get_db, set_setting, get_setting
from core.theme import create_success_embed, create_error_embed, create_info_embed, create_embed, add_field, Theme
from core.af2f import require_af2f

BOT_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if int(uid) == int(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure(f"🚫 Required role: {', '.join(roles)}")
    return app_commands.check(predicate)


EXTENSIONS = {
    # Fully implemented — these flags actually gate real code
    "Scheduled Backups":       "SOSB",
    "Ticket System":           "ISTS",
    "Auto Expire & Suspend":   "AES",
    "Renewal Reminders":       "RR",
    "Bot 2FA (AF2F)":          "A2FA",
    "Multi-Server Tickets":    "MSTC",
    "Backup Limits":           "UBL_ENABLED",
    "Marketplace":             "MARKETPLACE",
    "Account & MoonCoin":      "ACCOUNT",
    "VPS Monitoring Alerts":   "VPS_MONITORING",
    "DM Commands":             "DM_COMMANDS",
}

EXT_CHOICES = [app_commands.Choice(name=n, value=n) for n in EXTENSIONS]


# ── Database UI View ──────────────────────────────────────────────────────────

class DatabaseView(discord.ui.View):
    """Shown when /system action:Database is run. No text input needed."""

    def __init__(self, user_id: str, bot):
        super().__init__(timeout=120)
        self.user_id = user_id
        self.bot     = bot

    async def _guard(self, inter: discord.Interaction) -> bool:
        if str(inter.user.id) != self.user_id:
            await inter.response.send_message("Permission denied.", ephemeral=True)
            return False
        return True

    # ── Show / Download ───────────────────────────────────────────────────────
    @discord.ui.button(label="📥 Show / Download DB", style=discord.ButtonStyle.primary, emoji="💾", row=0)
    async def show_btn(self, inter: discord.Interaction, btn: discord.ui.Button):
        if not await self._guard(inter): return
        await inter.response.defer(ephemeral=True)

        db_path = os.path.join(BOT_DIR, "system.db")
        if not os.path.exists(db_path):
            return await inter.followup.send(embed=create_error_embed(
                "Database Not Found", "`system.db` does not exist yet. Start fresh to create it."))

        size_kb = os.path.getsize(db_path) / 1024

        embed = discord.Embed(
            title="💾 system.db",
            description=(
                f"**Size:** `{size_kb:.1f} KB`\n\n"
                "The database file is attached below.\n"
                "Keep it safe — it contains all VPS data, users, and settings."
            ),
            color=Theme.PRIMARY, timestamp=datetime.now(),
        )
        embed.set_author(name="MoonNodes Database", icon_url="https://imgur.com/6yfYDTP.png")
        embed.set_footer(text="To restore: use /system action:Database → Install")

        try:
            await inter.followup.send(
                embed=embed,
                file=discord.File(db_path, filename="system.db"),
                ephemeral=True,
            )
        except Exception as e:
            await inter.followup.send(embed=create_error_embed("Send Failed", str(e)[:500]))

    # ── Install / Upload ──────────────────────────────────────────────────────
    @discord.ui.button(label="📤 Install (Upload DB)", style=discord.ButtonStyle.success, emoji="📤", row=0)
    async def install_btn(self, inter: discord.Interaction, btn: discord.ui.Button):
        if not await self._guard(inter): return
        for item in self.children: item.disabled = True
        await inter.response.edit_message(
            embed=discord.Embed(
                title="📤 Upload system.db",
                description=(
                    "**Attach `system.db` to your next DM message** and send it here.\n\n"
                    "⚠️ The current database will be backed up as `system.db.bak` first.\n\n"
                    "⏳ *You have 10 minutes to upload.*"
                ),
                color=0x5865F2, timestamp=datetime.now(),
            ).set_author(name="MoonNodes Database", icon_url="https://imgur.com/6yfYDTP.png"),
            view=self,
        )

        import urllib.request as _ur

        def _check(m):
            return (
                m.author.id == inter.user.id
                and isinstance(m.channel, discord.DMChannel)
                and m.attachments
                and m.attachments[0].filename == "system.db"
            )
        try:
            msg     = await self.bot.wait_for("message", check=_check, timeout=600)
            db_path = os.path.join(BOT_DIR, "system.db")
            if os.path.exists(db_path):
                shutil.copy2(db_path, db_path + ".bak")
            await msg.attachments[0].save(db_path)

            from core.database import init_db, load_vps_data, load_admin_data
            init_db(); load_vps_data(); load_admin_data()
            vps_count  = sum(len(v) for v in vps_data.values())
            user_count = len(vps_data)

            await msg.reply(embed=discord.Embed(
                title="✅ Database Installed",
                description=(
                    f"**{user_count}** users · **{vps_count}** VPS records loaded.\n\n"
                    "✅ Bot is using the restored database.\n"
                    "Restart recommended to reinitialise all caches."
                ),
                color=Theme.SUCCESS, timestamp=datetime.now(),
            ).set_author(name="MoonNodes Database", icon_url="https://imgur.com/6yfYDTP.png"))

        except asyncio.TimeoutError:
            await inter.followup.send(embed=create_error_embed(
                "⏰ Upload Timed Out", "No file received in 10 minutes."), ephemeral=True)
        except Exception as e:
            await inter.followup.send(embed=create_error_embed("Install Failed", str(e)[:500]), ephemeral=True)

    # ── Delete ────────────────────────────────────────────────────────────────
    @discord.ui.button(label="🗑️ Delete DB", style=discord.ButtonStyle.danger, emoji="⚠️", row=0)
    async def delete_btn(self, inter: discord.Interaction, btn: discord.ui.Button):
        if not await self._guard(inter): return
        # Show confirm sub-view
        confirm_view = _DeleteConfirmView(self.user_id)
        await inter.response.edit_message(
            embed=discord.Embed(
                title="⚠️ Delete Database — Confirm",
                description=(
                    "This will **permanently delete** `system.db`.\n\n"
                    "A backup will be saved as `system.db.bak` before deletion.\n\n"
                    "**Are you sure?**"
                ),
                color=Theme.ERROR, timestamp=datetime.now(),
            ).set_author(name="MoonNodes Database", icon_url="https://imgur.com/6yfYDTP.png"),
            view=confirm_view,
        )


class _DeleteConfirmView(discord.ui.View):
    def __init__(self, user_id: str):
        super().__init__(timeout=60)
        self.user_id = user_id

    @discord.ui.button(label="Yes, Delete", style=discord.ButtonStyle.danger, emoji="🗑️")
    async def confirm(self, inter: discord.Interaction, btn: discord.ui.Button):
        if str(inter.user.id) != self.user_id: return
        for item in self.children: item.disabled = True
        db_path = os.path.join(BOT_DIR, "system.db")
        try:
            if os.path.exists(db_path):
                shutil.copy2(db_path, db_path + ".bak")
                os.remove(db_path)
            await inter.response.edit_message(
                embed=discord.Embed(
                    title="✅ Database Deleted",
                    description=(
                        "`system.db` has been deleted.\n"
                        "Backup saved as `system.db.bak`.\n\n"
                        "Restart the bot to create a fresh database."
                    ),
                    color=Theme.SUCCESS, timestamp=datetime.now(),
                ).set_author(name="MoonNodes Database", icon_url="https://imgur.com/6yfYDTP.png"),
                view=self,
            )
        except Exception as e:
            await inter.response.edit_message(
                embed=create_error_embed("Delete Failed", str(e)[:500]), view=self)

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary, emoji="↩️")
    async def cancel(self, inter: discord.Interaction, btn: discord.ui.Button):
        if str(inter.user.id) != self.user_id: return
        await inter.response.edit_message(
            embed=discord.Embed(
                title="↩️ Cancelled",
                description="Database deletion cancelled. Nothing was changed.",
                color=Theme.PRIMARY,
            ), view=None)


# ── Cog ───────────────────────────────────────────────────────────────────────

class SystemAdminCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(
        name="system",
        description="[OWNER] System — extensions, maintenance, A2FA, containers, and tools",
    )
    @app_commands.choices(action=[
        app_commands.Choice(name="🔌 Extension Toggle",         value="extension"),
        app_commands.Choice(name="👁️ View Extensions",          value="view_ext"),
        app_commands.Choice(name="🚧 Maintenance Mode",         value="maintenance"),
        app_commands.Choice(name="🧹 Clean DB",                  value="clean"),
        app_commands.Choice(name="🔐 A2FA Management",           value="a2fa"),
        app_commands.Choice(name="🌙 MoonCoin Earning",          value="mooncoin"),
        app_commands.Choice(name="📋 List — All containers on node", value="list"),
        app_commands.Choice(name="🔄 Update Bot — Pull from GitHub", value="update"),
        app_commands.Choice(name="💾 Database",                  value="database"),
    ])
    @app_commands.choices(list_runtime=[
        app_commands.Choice(name="🐧 incus", value="incus"),
        app_commands.Choice(name="🔵 lxc",   value="lxc"),
    ])
    @app_commands.choices(extension=EXT_CHOICES)
    @app_commands.choices(ext_state=[
        app_commands.Choice(name="✅ Enable",  value="enable"),
        app_commands.Choice(name="❌ Disable", value="disable"),
    ])
    @app_commands.choices(a2fa_action=[
        app_commands.Choice(name="Set / Edit PIN", value="edit"),
        app_commands.Choice(name="Remove PIN",     value="remove"),
    ])
    @app_commands.choices(mooncoin_action=[
        app_commands.Choice(name="➕ Add Earning Rule",    value="add"),
        app_commands.Choice(name="✏️ Edit Earning Rule",   value="edit_earn"),
        app_commands.Choice(name="🗑️ Remove Earning Rule", value="remove_earn"),
        app_commands.Choice(name="📋 List Earning Rules",  value="list_earn"),
    ])
    @app_commands.describe(
        action          = "What action to perform",
        extension       = "Extension to toggle",
        ext_state       = "Enable or disable",
        a2fa_action     = "A2FA action",
        new_pin         = "New 4-digit PIN",
        mooncoin_action = "MoonCoin earning rule action",
        earning_name    = "Earning rule name",
        earning_amount  = "Coin amount for this rule",
        earning_cooldown= "Cooldown in seconds",
        list_runtime    = "Runtime to query",
        list_node_id    = "Node number (default: 1 = local)",
    )
    @has_role("Owner", "Admin", "Hard Admin", "Dev")
    async def system_admin(
        self, interaction: discord.Interaction,
        action:          str,
        extension:       str = None,
        ext_state:       str = None,
        a2fa_action:     str = None,
        new_pin:         str = None,
        mooncoin_action: str = None,
        earning_name:    str = None,
        earning_amount:  int = None,
        earning_cooldown:int = None,
        list_runtime:    str = None,
        list_node_id:    int = 1,
    ):
        uid      = str(interaction.user.id)
        is_owner = (str(uid) == str(MAIN_ADMIN_ID) or admin_data.get(uid) == "Owner")

        OWNER_ONLY = {"extension","maintenance","clean","a2fa","mooncoin","update","database"}
        if action in OWNER_ONLY and not is_owner:
            await interaction.response.defer(ephemeral=True)
            return await interaction.followup.send(embed=create_error_embed(
                "🚫 Owner Only",
                "This action is restricted to the **Bot Owner**.\n"
                "Use `/help` to see commands available to your role."))

        # AF2F gate for system command
        if not is_owner:
            if not await require_af2f(interaction, "system", self.bot):
                return

        if not interaction.response.is_done():
            await interaction.response.defer(ephemeral=True)

        # ── View Extensions ───────────────────────────────────────────────────
        if action == "view_ext":
            rows = "\n".join(
                f"{'✅' if getattr(cfg, attr, False) else '❌'}  {name}"
                for name, attr in EXTENSIONS.items()
            )
            embed = discord.Embed(
                title="🔌 Extension Status",
                description=f"```\n{rows}\n```",
                color=Theme.PRIMARY, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
            embed.set_footer(text=f"Requested by {interaction.user.display_name}")
            return await interaction.followup.send(embed=embed)

        # ── Extension Toggle ──────────────────────────────────────────────────
        elif action == "extension":
            if not extension or not ext_state:
                return await interaction.followup.send(embed=create_error_embed(
                    "Missing Fields", "Select both an `extension` and a `state`."))
            attr  = EXTENSIONS.get(extension)
            if not attr:
                return await interaction.followup.send(embed=create_error_embed(
                    "Unknown Extension", f"`{extension}` not found."))
            value  = (ext_state == "enable")
            setattr(cfg, attr, value)
            set_setting(f"ext_{attr}", str(value))
            icon   = "✅" if value else "❌"
            status = "Enabled" if value else "Disabled"
            embed  = discord.Embed(
                title=f"{icon} Extension {status}",
                description=f"**{extension}** is now **{status}** — takes effect immediately.",
                color=Theme.SUCCESS if value else Theme.ERROR, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
            embed.set_footer(text=f"Changed by {interaction.user.display_name}")
            return await interaction.followup.send(embed=embed)

        # ── Maintenance Mode ──────────────────────────────────────────────────
        elif action == "maintenance":
            cfg.MAINTENANCE_MODE = not getattr(cfg, "MAINTENANCE_MODE", False)
            is_on = cfg.MAINTENANCE_MODE
            asyncio.create_task(interaction.client.change_presence(
                status=discord.Status.dnd if is_on else discord.Status.online,
                activity=discord.Activity(
                    type=discord.ActivityType.watching,
                    name="🚧 Maintenance Mode" if is_on else "MoonNodes VPS Manager",
                )
            ))
            embed = discord.Embed(
                title="🚧 Maintenance Mode " + ("Enabled" if is_on else "Disabled"),
                description=(
                    "Bot is now in **maintenance mode**. Users see a maintenance message."
                    if is_on else
                    "Bot is back **Online**. All commands are fully operational."
                ),
                color=Theme.WARNING if is_on else Theme.SUCCESS, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
            embed.set_footer(text=f"Toggled by {interaction.user.display_name}")
            try:
                upd_ch_id = get_setting("update_channel")
                if upd_ch_id and upd_ch_id != "0":
                    ch = interaction.client.get_channel(int(upd_ch_id))
                    if ch:
                        upd = discord.Embed(
                            title="🚧 Maintenance Mode " + ("Started" if is_on else "Ended"),
                            description=(
                                "The bot is currently **under maintenance**. Some commands may be unavailable.\n"
                                "We'll post here when everything is back online."
                                if is_on else
                                "✅ Maintenance is **complete**! All systems are back online."
                            ),
                            color=Theme.WARNING if is_on else Theme.SUCCESS, timestamp=datetime.now(),
                        )
                        upd.set_author(name="MoonNodes System Update", icon_url="https://imgur.com/6yfYDTP.png")
                        await ch.send(embed=upd)
            except Exception: pass
            return await interaction.followup.send(embed=embed)

        # ── Clean DB ──────────────────────────────────────────────────────────
        elif action == "clean":
            removed = 0
            async with data_lock:
                for uid2 in list(vps_data.keys()):
                    before = len(vps_data[uid2])
                    vps_data[uid2] = [v for v in vps_data[uid2] if v.get("container_name")]
                    removed += before - len(vps_data[uid2])
                    if not vps_data[uid2]:
                        del vps_data[uid2]
            await async_save_vps_data()
            embed = discord.Embed(
                title="🧹 Database Cleaned",
                description=f"Removed **{removed}** stale VPS entries.",
                color=Theme.SUCCESS, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
            embed.set_footer(text=f"Cleaned by {interaction.user.display_name}")
            return await interaction.followup.send(embed=embed)

        # ── Database — Button UI ──────────────────────────────────────────────
        elif action == "database":
            db_path = os.path.join(BOT_DIR, "system.db")
            exists  = os.path.exists(db_path)
            size_kb = (os.path.getsize(db_path) / 1024) if exists else 0

            embed = discord.Embed(
                title="💾 Database Management",
                description=(
                    f"**Status:** {'✅ Found' if exists else '❌ Not found'}\n"
                    + (f"**Size:** `{size_kb:.1f} KB`\n" if exists else "")
                    + f"**Path:** `{db_path}`\n\n"
                    "Choose an action below:"
                ),
                color=Theme.PRIMARY, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes Database", icon_url="https://imgur.com/6yfYDTP.png")
            embed.add_field(
                name="📥 Show / Download",
                value="Send `system.db` to Discord DM as a file attachment.",
                inline=False,
            )
            embed.add_field(
                name="📤 Install (Upload)",
                value="Upload a `system.db` file here — restores all data.",
                inline=False,
            )
            embed.add_field(
                name="🗑️ Delete",
                value="Delete the current database (auto-backup to `.bak` first).",
                inline=False,
            )
            view = DatabaseView(uid, self.bot)
            return await interaction.followup.send(embed=embed, view=view)

        # ── List Containers ───────────────────────────────────────────────────
        elif action == "list":
            from core.lxc import RUNTIME
            rt = (list_runtime or RUNTIME).lower()
            bin_path = shutil.which("incus" if rt == "incus" else "lxc") or f"/usr/bin/{rt}"
            nodes_raw = get_setting("registered_nodes") or ""
            nodes     = ["local"] + [n.strip() for n in nodes_raw.split(",") if n.strip()]
            nid       = max(1, min(list_node_id, len(nodes)))
            node      = nodes[nid - 1]
            prefix    = f"{node}:" if node != "local" else ""
            try:
                import shlex
                proc = await asyncio.create_subprocess_exec(
                    *shlex.split(f"{bin_path} list {prefix}--format=csv"),
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=15)
                raw = stdout.decode().strip(); err = stderr.decode().strip()
                if proc.returncode != 0:
                    return await interaction.followup.send(embed=create_error_embed(
                        "List Failed", f"```{err[:1500]}```"))
                rows = []
                for line in (raw.splitlines() if raw else []):
                    p = line.split(",")
                    name   = p[0].strip() if len(p) > 0 else "?"
                    status = p[1].strip().upper() if len(p) > 1 else "?"
                    ipv4   = p[2].strip() if len(p) > 2 else "—"
                    icon   = "🟢" if status == "RUNNING" else ("⛔" if status == "STOPPED" else "🟡")
                    rows.append(f"{icon} `{name:<28}` {status:<8}  {ipv4}")
                text = "\n".join(rows[:25])
                if len(rows) > 25: text += f"\n*…and {len(rows)-25} more*"
                embed = discord.Embed(
                    title=f"📋 {rt.title()} Containers — Node `{node}`",
                    description=f"**{len(rows)}** container(s)\n\n{text or '*None*'}",
                    color=Theme.PRIMARY, timestamp=datetime.now(),
                )
                embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                return await interaction.followup.send(embed=embed)
            except asyncio.TimeoutError:
                return await interaction.followup.send(embed=create_error_embed(
                    "Timeout", f"`{rt}` timed out after 15 s."))
            except Exception as e:
                return await interaction.followup.send(embed=create_error_embed("Error", str(e)[:2000]))

        # ── GitHub Update ─────────────────────────────────────────────────────
        elif action == "update":
            import subprocess as _sp, glob as _glob
            loading_msg = await interaction.followup.send(embed=create_info_embed(
                "🔄 Updating Bot…", "Pulling latest code from GitHub…"), wait=True)
            try:
                _sp.run(["git", "-C", BOT_DIR, "stash"], capture_output=True, text=True, timeout=15)
                pull = _sp.run(
                    ["git", "-C", BOT_DIR, "pull", "origin", "main"],
                    capture_output=True, text=True, timeout=60,
                )
                pull_out = (pull.stdout + pull.stderr).strip()[:800]
                _sp.run(["git", "-C", BOT_DIR, "stash", "pop"], capture_output=True, text=True, timeout=15)

                unzip_out = ""
                for zf in _glob.glob(os.path.join(BOT_DIR, "*.zip")):
                    uz = _sp.run(
                        ["unzip", "-o", zf, "-d", BOT_DIR, "-x", "system.db", ".env", "*.json"],
                        capture_output=True, text=True, timeout=30,
                    )
                    unzip_out += f"\nUnzipped `{os.path.basename(zf)}`: " + (
                        "OK" if uz.returncode == 0 else uz.stderr.strip()[:200])

                embed = (create_success_embed if pull.returncode == 0 else create_error_embed)(
                    "✅ Update Complete" if pull.returncode == 0 else "❌ Update Failed",
                    f"```\n{pull_out or 'Already up to date.'}\n```"
                    + (f"\n{unzip_out}" if unzip_out else "")
                    + ("\n\n**Restart the bot to apply changes.**" if pull.returncode == 0 else ""),
                )
                await loading_msg.edit(embed=embed)
            except Exception as e:
                await loading_msg.edit(embed=create_error_embed("Error", str(e)[:1000]))

        # ── MoonCoin Rules ────────────────────────────────────────────────────
        elif action == "mooncoin":
            conn = get_db(); cur = conn.cursor()
            if mooncoin_action == "list_earn" or not mooncoin_action:
                cur.execute("SELECT name, amount, cooldown FROM mooncoin_rules ORDER BY amount DESC")
                rows = cur.fetchall()
                embed = discord.Embed(title="🌙 MoonCoin Earning Rules", color=Theme.PRIMARY, timestamp=datetime.now())
                embed.set_author(name="MoonNodes — System", icon_url="https://imgur.com/6yfYDTP.png")
                if not rows:
                    embed.description = "*No custom rules yet.*\n\nBuilt-in: `invite +5` · `chat +1` · `giveaway +3`"
                else:
                    parts = []
                    for r in rows:
                        cd = f" · ⏱️ {r['cooldown']}s" if r["cooldown"] > 0 else ""
                        parts.append(f"🔹 **{r['name']}** → **+{r['amount']} 🌙**{cd}")
                    embed.description = "\n".join(parts)
                embed.set_footer(text=f"{len(rows)} custom rule(s)")
                return await interaction.followup.send(embed=embed)

            elif mooncoin_action == "add":
                if not earning_name or earning_amount is None:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing Fields", "Provide `earning_name` and `earning_amount`."))
                cur.execute("INSERT OR REPLACE INTO mooncoin_rules (name,amount,cooldown) VALUES (?,?,?)",
                    (earning_name.lower(), earning_amount, earning_cooldown or 0))
                conn.commit()
                embed = discord.Embed(title="✅ Earning Rule Added",
                    description=f"**{earning_name}** → **+{earning_amount} 🌙**",
                    color=Theme.SUCCESS, timestamp=datetime.now())
                embed.add_field(name="Rule",     value=earning_name,                                           inline=True)
                embed.add_field(name="Reward",   value=f"+{earning_amount} 🌙",                               inline=True)
                embed.add_field(name="Cooldown", value=f"{earning_cooldown}s" if earning_cooldown else "None", inline=True)
                return await interaction.followup.send(embed=embed)

            elif mooncoin_action == "edit_earn":
                if not earning_name:
                    return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `earning_name`."))
                changes = []
                if earning_amount is not None:
                    cur.execute("UPDATE mooncoin_rules SET amount=? WHERE name=?", (earning_amount, earning_name.lower()))
                    changes.append(f"Reward → **+{earning_amount} 🌙**")
                if earning_cooldown is not None:
                    cur.execute("UPDATE mooncoin_rules SET cooldown=? WHERE name=?", (earning_cooldown, earning_name.lower()))
                    changes.append(f"Cooldown → **{earning_cooldown}s**")
                conn.commit()
                desc = "\n".join(f"• {c}" for c in changes) if changes else "No changes."
                return await interaction.followup.send(embed=create_success_embed(
                    f"✏️ Rule Updated", f"**`{earning_name}`**:\n{desc}"))

            elif mooncoin_action == "remove_earn":
                if not earning_name:
                    return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `earning_name`."))
                cur.execute("DELETE FROM mooncoin_rules WHERE name=?", (earning_name.lower(),))
                deleted = cur.rowcount; conn.commit()
                if not deleted:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Not Found", f"No rule named `{earning_name}`."))
                return await interaction.followup.send(embed=create_success_embed(
                    "🗑️ Rule Removed", f"`{earning_name}` deleted."))

        # ── A2FA ──────────────────────────────────────────────────────────────
        elif action == "a2fa":
            if not a2fa_action:
                # Show status embed instead of bare error
                conn = get_db(); cur = conn.cursor()
                uid2 = str(interaction.user.id)
                cur.execute("SELECT pin FROM admins WHERE user_id=?", (uid2,))
                row = cur.fetchone(); conn.close()
                has_pin = row and row["pin"] not in (None, "", "0000")
                ext_on  = getattr(cfg, "A2FA", False)
                ext_status = "✅ Enabled" if ext_on else "❌ Disabled"
                pin_status  = "✅ Set"     if has_pin else "❌ Not set"
                status_embed = discord.Embed(
                    title="🔐 A2FA Management",
                    description=(
                        f"**Extension:** {ext_status}\n"
                        f"**Your PIN:** {pin_status}\n\n"
                        "**Actions:**\n"
                        "› `a2fa_action:Set / Edit PIN  new_pin:<4 digits>` — set your PIN\n"
                        "› `a2fa_action:Remove PIN` — clear your PIN\n\n"
                        "Enable/disable via\n"
                        "`/system action:Extension Toggle extension:Bot 2FA (AF2F)`."
                    ),
                    color=0xEB459E,
                    timestamp=datetime.now(),
                )
                status_embed.set_author(name="MoonNodes A2FA", icon_url="https://imgur.com/6yfYDTP.png")
                return await interaction.followup.send(embed=status_embed)

            # PIN management always works regardless of whether extension is on
            # (you need to set PIN BEFORE enabling the extension)
            conn = get_db(); cur = conn.cursor()
            uid2 = str(interaction.user.id)

            if a2fa_action == "edit":
                if not new_pin or not new_pin.strip().isdigit() or len(new_pin.strip()) != 4:
                    conn.close()
                    return await interaction.followup.send(embed=create_error_embed(
                        "Invalid PIN",
                        "PIN must be exactly **4 digits** (e.g. `new_pin:1234`)."))
                pin = new_pin.strip()
                cur.execute("INSERT OR IGNORE INTO admins (user_id) VALUES (?)", (uid2,))
                cur.execute("UPDATE admins SET pin=? WHERE user_id=?", (pin, uid2))
                conn.commit(); conn.close()
                embed = create_success_embed(
                    "🔐 PIN Set",
                    "Your A2FA PIN has been saved.\n\n"
                    "**Next step:** Enable the extension with\n"
                    "`/system action:Extension Toggle  extension:Bot 2FA (AF2F)  ext_state:Enable`\n\n"
                    "Keep your PIN private — never share it."
                )
                return await interaction.followup.send(embed=embed)

            elif a2fa_action == "remove":
                cur.execute("INSERT OR IGNORE INTO admins (user_id) VALUES (?)", (uid2,))
                cur.execute("UPDATE admins SET pin='0000' WHERE user_id=?", (uid2,))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "🔓 PIN Removed",
                    "A2FA PIN has been cleared.\n"
                    "2FA is now disabled for your account until a new PIN is set."))


async def setup(bot):
    await bot.add_cog(SystemAdminCog(bot))
