import os
"""
/system — [OWNER] System administration: extensions, maintenance, A2FA, container list, MoonCoin rules.

Fixes:
  - /system action:list now correctly builds the rows list before joining (was empty in v1)
  - SSH renamed to SSH everywhere
  - data_lock usage updated to asyncio.Lock (async with)
  - Premium UI refresh throughout
"""

import asyncio
import re
import shutil
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

import core.config as cfg
from core.config import MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock, async_save_vps_data, get_db, set_setting, get_setting
from core.theme import create_success_embed, create_error_embed, create_info_embed, create_embed, add_field, Theme


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if int(uid) == int(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure(f"🚫 Required role: {', '.join(roles)}")
    return app_commands.check(predicate)


# Extension registry: display name → config attribute
EXTENSIONS = {
    "Multi-Node Support":      "MULTI_NODE",
    "Scheduled Backups":       "SOSB",
    "Ticket System":           "ISTS",
    "Auto Expire & Suspend":   "AES",
    "Renewal Reminders":       "RR",
    "Bot 2FA":                 "A2FA",          # Renamed from Admin 2FA
    "Multi-Server Tickets":    "MSTC",
    "Backup Limits":           "UBL_ENABLED",
    "Marketplace":             "MARKETPLACE",
    "Account & MoonCoin":      "ACCOUNT",
    "VPS Renewal":             "VPS_RENEWAL",
    "VPS Monitoring Alerts":   "VPS_MONITORING",
    # "VPS Templates" removed - not in use
    "Multi-language":          "MULTILANG",
    "User Can Use Command in DM": "DM_COMMANDS",
    "Block Terminal Commands": "BLOCK_TERMINAL",
}

EXT_CHOICES = [app_commands.Choice(name=n, value=n) for n in EXTENSIONS]


class SystemAdminCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="system", description="[OWNER] System — extensions, maintenance, A2FA, container list, and tools")
    @app_commands.choices(action=[
        app_commands.Choice(name="🔌 Extension Toggle",          value="extension"),
        app_commands.Choice(name="👁️ View Extensions",           value="view_ext"),
        app_commands.Choice(name="🚧 Maintenance Mode",          value="maintenance"),
        app_commands.Choice(name="🧹 Clean DB",                   value="clean"),
        app_commands.Choice(name="🔐 A2FA Management",            value="a2fa"),
        app_commands.Choice(name="🌙 MoonCoin Earning",           value="mooncoin"),
        app_commands.Choice(name="📋 List — Containers on node",  value="list"),
        app_commands.Choice(name="🔄 Update Bot — Pull latest from GitHub", value="update"),
        app_commands.Choice(name="💾 Database",                               value="database"),
    ])
    @app_commands.choices(list_runtime=[
        app_commands.Choice(name="🐧 incus — List incus containers", value="incus"),
        app_commands.Choice(name="🔵 lxc   — List LXD containers",   value="lxc"),
    ])
    @app_commands.choices(extension=EXT_CHOICES)
    @app_commands.choices(ext_state=[
        app_commands.Choice(name="✅ Enable",  value="enable"),
        app_commands.Choice(name="❌ Disable", value="disable"),
    ])
    @app_commands.choices(a2fa_action=[
        app_commands.Choice(name="Set / Edit PIN", value="edit"),
        app_commands.Choice(name="Remove PIN",     value="remove"),
    ])
    @app_commands.choices(mooncoin_action=[
        app_commands.Choice(name="➕ Add Earning Rule",    value="add"),
        app_commands.Choice(name="✏️ Edit Earning Rule",   value="edit_earn"),
        app_commands.Choice(name="🗑️ Remove Earning Rule", value="remove_earn"),
        app_commands.Choice(name="📋 List Earning Rules",  value="list_earn"),
    ])
    @app_commands.describe(
        action          = "What action to perform",
        extension       = "Extension to toggle",
        ext_state       = "Enable or disable",
        a2fa_action     = "A2FA action",
        database_action = "Database action: install or delete",
        new_pin         = "New 4-digit PIN",
        mooncoin_action = "MoonCoin earning rule action",
        earning_name    = "Earning rule name (e.g. invite, chat, event)",
        earning_amount  = "Coin amount for this rule",
        earning_cooldown= "Cooldown in seconds (0 = no cooldown)",
        list_runtime    = "Runtime to query (incus or lxc)",
        list_node_id    = "Node number from /node list (default: 1 = local)",
    )
    @has_role("Owner", "Admin", "Hard Admin", "Dev")
    async def system_admin(
        self, interaction: discord.Interaction,
        action: str,
        extension: str = None,
        ext_state: str = None,
        a2fa_action: str = None,
        new_pin: str = None,
        mooncoin_action: str = None,
        earning_name: str = None,
        earning_amount: int = None,
        earning_cooldown: int = None,
        list_runtime: str = None,
        list_node_id: int = 1,
    ):
        await interaction.response.defer(ephemeral=True)

        uid  = str(interaction.user.id)
        role = admin_data.get(uid, "")
        is_owner = (str(uid) == str(MAIN_ADMIN_ID) or role == "Owner")

        # Actions that ONLY the bot owner can use
        OWNER_ONLY = {"extension","maintenance","clean","a2fa","mooncoin","update","database","premium"}
        if action in OWNER_ONLY and not is_owner:
            return await interaction.followup.send(embed=create_error_embed(
                "🚫 No Permission",
                "This action is restricted to the **Bot Owner** only.\n\n"
                "Use `/help` to see commands available to your role."))

        # ── View Extensions ──────────────────────────────────────────────────
        if action == "view_ext":
            embed = discord.Embed(
                title="🔌  Extension Status",
                description=(
                    f"```\n{'Extension':<28} {'State':<8}\n"
                    + "─" * 38 + "\n"
                    + "\n".join(
                        f"{'✅' if getattr(cfg, attr, False) else '❌'}  {name:<26}"
                        for name, attr in EXTENSIONS.items()
                    )
                    + "\n```"
                ),
                color=Theme.PRIMARY,
                timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)
            embed.set_footer(text=f"Requested by {interaction.user.display_name}")
            return await interaction.followup.send(embed=embed)

        # ── Extension Toggle ─────────────────────────────────────────────────
        elif action == "extension":
            if not extension or not ext_state:
                return await interaction.followup.send(embed=create_error_embed(
                    "Missing Fields", "Select both an `extension` and a `state`."
                ))
            attr  = EXTENSIONS.get(extension)
            if not attr:
                return await interaction.followup.send(embed=create_error_embed(
                    "Unknown Extension", f"`{extension}` not found in the registry."
                ))
            value  = (ext_state == "enable")
            setattr(cfg, attr, value)
            set_setting(f"ext_{attr}", str(value))

            icon   = "✅" if value else "❌"
            status = "**Enabled**" if value else "**Disabled**"
            embed  = discord.Embed(
                title=f"{icon}  Extension {status.strip('*')}",
                description=f"**{extension}** is now {status} and takes effect immediately — no restart needed.",
                color=Theme.SUCCESS if value else Theme.ERROR,
                timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)

            notes = {
                "Ticket System":         "Users can now open support tickets with `/support`.",
                "Scheduled Backups":     "Configure the schedule with `/set setting:Scheduled Backups`.",
                "Backup Limits":         "Configure limits with `/set setting:Backup Limits`.",
                "Admin 2FA":             "Set your PIN with `/system action:A2FA Management`.",
                "Multi-Node Support":    "Register nodes with `/node pick_one:Create`.",
                "Auto Expire & Suspend": "VPS will auto-suspend when their expiry date passes.",
                "Renewal Reminders":     "Users receive DM reminders at 7, 3, and 1 day before expiry.",
                "VPS Monitoring Alerts": "Users are DM'd when their VPS exceeds resource thresholds.",
                "VPS Templates":         "Pre-configured OS templates appear in the OS selector.",
                "VPS Renewal":           "Users can extend VPS expiry with `/upgrade`.",
                "Marketplace":           "Users can buy/sell VPS with `/marketplace`.",
            }
            if extension in notes:
                embed.add_field(name="ℹ️ Note", value=notes[extension], inline=False)

            embed.set_footer(text=f"Changed by {interaction.user.display_name}")
            return await interaction.followup.send(embed=embed)

        # ── Maintenance Mode ─────────────────────────────────────────────────
        elif action == "maintenance":
            cfg.MAINTENANCE_MODE = not getattr(cfg, "MAINTENANCE_MODE", False)
            is_on = cfg.MAINTENANCE_MODE
            asyncio.create_task(interaction.client.change_presence(
                status=discord.Status.dnd if is_on else discord.Status.online,
                activity=discord.Activity(
                    type=discord.ActivityType.watching,
                    name="🚧 Maintenance Mode" if is_on else "MoonNodes VPS Manager"
                )
            ))
            embed = discord.Embed(
                title="🚧  Maintenance Mode " + ("Enabled" if is_on else "Disabled"),
                description=(
                    "Bot is now in **maintenance mode**. Users will see a maintenance message."
                    if is_on else
                    "Bot is back **Online**. All commands are fully operational."
                ),
                color=Theme.WARNING if is_on else Theme.SUCCESS,
                timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)
            embed.set_footer(text=f"Toggled by {interaction.user.display_name}")
            # Post to update channel
            try:
                upd_ch_id = get_setting("update_channel")
                if upd_ch_id and upd_ch_id != "0":
                    ch = interaction.client.get_channel(int(upd_ch_id))
                    if ch:
                        upd = discord.Embed(
                            title="🚧 Maintenance Mode " + ("Started" if is_on else "Ended"),
                            description=(
                                "The bot is currently **under maintenance**. Some commands may be unavailable.\n"
                                "We'll post here when everything is back online."
                                if is_on else
                                "✅ Maintenance is **complete**! All systems are back online."
                            ),
                            color=Theme.WARNING if is_on else Theme.SUCCESS,
                            timestamp=datetime.now(),
                        )
                        upd.set_author(name="MoonNodes System Update", icon_url=Theme.ICON_URL)
                        await ch.send(embed=upd)
            except Exception: pass
            return await interaction.followup.send(embed=embed)

        # ── Clean DB ─────────────────────────────────────────────────────────
        elif action == "clean":
            removed = 0
            async with data_lock:
                for uid in list(vps_data.keys()):
                    before = len(vps_data[uid])
                    vps_data[uid] = [v for v in vps_data[uid] if v.get("container_name")]
                    removed += before - len(vps_data[uid])
                    if not vps_data[uid]:
                        del vps_data[uid]
            await async_save_vps_data()
            embed = discord.Embed(
                title="🧹  Database Cleaned",
                description=f"Removed **{removed}** stale VPS entries from the database.",
                color=Theme.SUCCESS,
                timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)
            embed.set_footer(text=f"Cleaned by {interaction.user.display_name}")
            return await interaction.followup.send(embed=embed)

        # ── List Containers ──────────────────────────────────────────────────
        elif action == "list":
            from core.lxc import RUNTIME
            rt = (list_runtime or RUNTIME).lower()
            if rt == "incus":
                bin_path      = shutil.which("incus") or "/usr/bin/incus"
                runtime_label = "Incus"
            else:
                bin_path      = shutil.which("lxc") or "/usr/bin/lxc"
                runtime_label = "LXD"

            nodes_raw = get_setting("registered_nodes") or ""
            nodes     = ["local"] + [n.strip() for n in nodes_raw.split(",") if n.strip()]
            nid       = max(1, min(list_node_id, len(nodes)))
            node      = nodes[nid - 1]
            prefix    = f"{node}:" if node != "local" else ""

            try:
                import shlex
                cmd  = f"{bin_path} list {prefix}--format=csv"
                proc = await asyncio.create_subprocess_exec(
                    *shlex.split(cmd),
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=15)
                raw = stdout.decode().strip()
                err = stderr.decode().strip()

                if proc.returncode != 0:
                    return await interaction.followup.send(embed=create_error_embed(
                        "List Failed", f"```{err[:1500]}```"
                    ))

                lines = raw.splitlines() if raw else []
                rows  = []
                for line in lines:
                    p      = line.split(",")
                    name   = p[0].strip() if len(p) > 0 else "?"
                    status = p[1].strip().upper() if len(p) > 1 else "?"
                    ipv4   = p[2].strip() if len(p) > 2 else "—"
                    icon   = "🟢" if status == "RUNNING" else ("⛔" if status == "STOPPED" else "🟡")
                    rows.append(f"{icon} `{name:<28}` {status:<8}  {ipv4}")

                sep  = "\n"
                text = sep.join(rows[:25])
                if len(rows) > 25:
                    text += f"\n*…and {len(rows)-25} more containers*"

                embed = discord.Embed(
                    title=f"📋  {runtime_label} Containers — Node `{node}`",
                    description=f"**{len(rows)}** container(s) found\n\n{text or '*No containers found*'}",
                    color=Theme.PRIMARY,
                    timestamp=datetime.now(),
                )
                embed.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)
                embed.set_footer(text=f"Runtime: {rt}  ·  Binary: {bin_path}")
                return await interaction.followup.send(embed=embed)

            except asyncio.TimeoutError:
                return await interaction.followup.send(embed=create_error_embed(
                    "Timeout", f"The `{rt}` command timed out after 15 seconds."
                ))
            except Exception as e:
                return await interaction.followup.send(embed=create_error_embed("Error", str(e)[:2000]))

        # ── Database Install / Delete ─────────────────────────────────────────
        elif action == "database":
            sub = (database_action or option or "").lower()
            if sub in ("delete","delete data"):
                import shutil as _sh
                BOT_DIR2 = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
                db_path  = os.path.join(BOT_DIR2, "system.db")
                bak      = db_path + ".bak"
                try:
                    _sh.copy2(db_path, bak)
                    os.remove(db_path)
                    return await interaction.followup.send(embed=create_success_embed(
                        "💾 Database Deleted",
                        f"**system.db** has been deleted.\n"
                        f"A backup was saved as `system.db.bak`.\n"
                        "Restart the bot to create a fresh database."))
                except Exception as e:
                    return await interaction.followup.send(embed=create_error_embed("Failed", str(e)[:500]))
            else:
                # Install = show instructions for uploading system.db
                return await interaction.followup.send(embed=discord.Embed(
                    title="💾 Database — Install from Backup",
                    description=(
                        "To restore data from another bot or server:\n\n"
                        "**Step 1:** Stop the bot\n"
                        "```bash\nsystemctl stop moonbot\n```\n"
                        "**Step 2:** Upload your `system.db` to the bot folder\n"
                        "```bash\nscp system.db root@YOUR_SERVER:/root/MoonNode/system.db\n```\n"
                        "**Step 3:** Start the bot — data is loaded automatically\n"
                        "```bash\nsystemctl start moonbot\n```\n"
                        "> ⚠️ This will **replace** the current database. "
                        "Make a backup first with `/system action:Database option:delete` (which auto-backs up)."
                    ),
                    color=0x5865F2, timestamp=datetime.now(),
                ).set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png"))

        # ── GitHub Auto-Update ────────────────────────────────────────────────
        elif action == "update":
            import subprocess as _sp, glob as _glob
            BOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            # Send loading message and store it so we can edit it later
            loading_msg = await interaction.followup.send(embed=create_info_embed(
                "🔄 Updating Bot…",
                "Pulling latest code from `MoonLink-Team/MoonNode`…"), wait=True)
            try:
                # Step 1: stash any local changes so pull never fails
                _sp.run(
                    ["git", "-C", BOT_DIR, "stash"],
                    capture_output=True, text=True, timeout=15,
                )
                # Step 2: git pull
                pull = _sp.run(
                    ["git", "-C", BOT_DIR, "pull", "origin", "main"],
                    capture_output=True, text=True, timeout=60,
                )
                pull_out = (pull.stdout + pull.stderr).strip()[:800]
                # Step 3: pop stash (restore local tweaks)
                _sp.run(
                    ["git", "-C", BOT_DIR, "stash", "pop"],
                    capture_output=True, text=True, timeout=15,
                )

                # Step 2: if repo ships dev.zip, unzip it (overwrites .py files, keeps system.db + .env)
                zip_files = _glob.glob(os.path.join(BOT_DIR, "*.zip"))
                unzip_out = ""
                for zf in zip_files:
                    uz = _sp.run(
                        ["unzip", "-o", zf, "-d", BOT_DIR,
                         "-x", "system.db", ".env", "*.json"],
                        capture_output=True, text=True, timeout=30,
                    )
                    unzip_out += f"\nUnzipped `{os.path.basename(zf)}`: " + (
                        "OK" if uz.returncode == 0 else uz.stderr.strip()[:200]
                    )

                if pull.returncode == 0:
                    embed = create_success_embed(
                        "✅ Update Complete",
                        f"```\n{pull_out or 'Already up to date.'}\n```"
                        + (f"\n{unzip_out}" if unzip_out else "")
                        + "\n\n**Restart the bot to apply changes.**"
                    )
                else:
                    embed = create_error_embed("Update Failed", f"```\n{pull_out}\n```")
                await loading_msg.edit(embed=embed)
                return
            except Exception as e:
                await loading_msg.edit(embed=create_error_embed("Error", str(e)[:1000]))
                return

        # ── MoonCoin Earning Rules ────────────────────────────────────────────
        elif action == "mooncoin":
            if not mooncoin_action:
                embed = discord.Embed(
                    title="🌙  MoonCoin Earning Rules",
                    description=(
                        "Choose a `mooncoin_action` from the dropdown:\n\n"
                        "➕ **Add** — Create a new earning rule\n"
                        "✏️ **Edit** — Update amount or cooldown\n"
                        "🗑️ **Remove** — Delete a rule\n"
                        "📋 **List** — View all active rules"
                    ),
                    color=Theme.PRIMARY,
                )
                embed.set_author(name="MoonNodes — MoonCoin", icon_url=Theme.ICON_URL)
                return await interaction.followup.send(embed=embed)

            conn = get_db()
            cur  = conn.cursor()

            if mooncoin_action == "list_earn":
                cur.execute("SELECT name, amount, cooldown FROM mooncoin_rules ORDER BY amount DESC")
                rows = cur.fetchall()
                embed = discord.Embed(
                    title="🌙  MoonCoin Earning Rules",
                    color=Theme.PRIMARY,
                    timestamp=datetime.now(),
                )
                embed.set_author(name="MoonNodes — System", icon_url=Theme.ICON_URL)
                if not rows:
                    embed.description = (
                        "*No custom rules configured yet.*\n\n"
                        "**Built-in defaults:**\n"
                        "`invite → +5` · `chat → +1 (300s cd)` · `giveaway → +3` · `event → +7`\n\n"
                        "Use `mooncoin_action:➕ Add` to create custom rules."
                    )
                else:
                    parts = []
                    for r in rows:
                        cd = f" · ⏱️ {r['cooldown']}s cd" if r["cooldown"] > 0 else ""
                        parts.append(f"🔹 **{r['name']}** → **+{r['amount']} 🌙**{cd}")
                    embed.description = "\n".join(parts)
                embed.set_footer(text=f"{len(rows)} custom rule(s) active")
                return await interaction.followup.send(embed=embed)

            elif mooncoin_action == "add":
                if not earning_name or earning_amount is None:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing Fields",
                        "Provide both `earning_name` and `earning_amount`.\n\n"
                        "**Example:** `earning_name:daily` `earning_amount:10` `earning_cooldown:86400`"
                    ))
                cur.execute(
                    "INSERT OR REPLACE INTO mooncoin_rules (name, amount, cooldown) VALUES (?,?,?)",
                    (earning_name.lower(), earning_amount, earning_cooldown or 0)
                )
                conn.commit()
                embed = discord.Embed(
                    title="✅  Earning Rule Added",
                    description=f"Users now earn **+{earning_amount} 🌙** for `{earning_name}`.",
                    color=Theme.SUCCESS, timestamp=datetime.now(),
                )
                embed.add_field(name="Rule",     value=earning_name,                                          inline=True)
                embed.add_field(name="Reward",   value=f"+{earning_amount} 🌙",                              inline=True)
                embed.add_field(name="Cooldown", value=f"{earning_cooldown}s" if earning_cooldown else "None", inline=True)
                embed.set_author(name="MoonNodes — MoonCoin", icon_url=Theme.ICON_URL)
                return await interaction.followup.send(embed=embed)

            elif mooncoin_action == "edit_earn":
                if not earning_name:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing", "Provide the `earning_name` to edit."
                    ))
                changes = []
                if earning_amount is not None:
                    cur.execute("UPDATE mooncoin_rules SET amount=? WHERE name=?", (earning_amount, earning_name.lower()))
                    changes.append(f"Reward → **+{earning_amount} 🌙**")
                if earning_cooldown is not None:
                    cur.execute("UPDATE mooncoin_rules SET cooldown=? WHERE name=?", (earning_cooldown, earning_name.lower()))
                    changes.append(f"Cooldown → **{earning_cooldown}s**")
                conn.commit()
                desc = ("\n".join(f"• {c}" for c in changes)) if changes else "No changes specified."
                return await interaction.followup.send(embed=create_success_embed(
                    "✏️  Rule Updated", f"**`{earning_name}`** updated:\n{desc}"
                ))

            elif mooncoin_action == "remove_earn":
                if not earning_name:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing", "Provide the `earning_name` to remove."
                    ))
                cur.execute("DELETE FROM mooncoin_rules WHERE name=?", (earning_name.lower(),))
                deleted = cur.rowcount
                conn.commit()
                if deleted == 0:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Not Found",
                        f"No rule named `{earning_name}`. Use `mooncoin_action:📋 List` to see active rules."
                    ))
                return await interaction.followup.send(embed=create_success_embed(
                    "🗑️  Rule Removed",
                    f"**`{earning_name}`** deleted. Users no longer earn coins from this action."
                ))

        # ── A2FA ─────────────────────────────────────────────────────────────
        elif action == "a2fa":
            if not a2fa_action:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Choose an A2FA action."))
            if not cfg.A2FA:
                return await interaction.followup.send(embed=create_error_embed(
                    "Extension Off", "Enable **Admin 2FA** first via `/system action:Extension Toggle`."
                ))

            conn = get_db()
            cur  = conn.cursor()
            uid  = str(interaction.user.id)

            if a2fa_action == "edit":
                if not new_pin or not new_pin.isdigit() or len(new_pin) != 4:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Invalid PIN", "PIN must be exactly **4 digits**."
                    ))
                cur.execute("INSERT OR IGNORE INTO admins (user_id) VALUES (?)", (uid,))
                cur.execute("UPDATE admins SET pin=? WHERE user_id=?", (new_pin, uid))
                conn.commit()
                return await interaction.followup.send(embed=create_success_embed(
                    "🔐  PIN Updated", "Your A2FA PIN has been set. Keep it private — never share it!"
                ))

            elif a2fa_action == "remove":
                cur.execute("UPDATE admins SET pin='0000' WHERE user_id=?", (uid,))
                conn.commit()
                return await interaction.followup.send(embed=create_success_embed(
                    "🔓  PIN Removed", "A2FA PIN reset. Two-factor authentication is now disabled for your account."
                ))


async def setup(bot):
    await bot.add_cog(SystemAdminCog(bot))
