import discord
from discord import app_commands
from discord.ext import commands
import core.config as cfg

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock, save_vps_data, get_db, set_setting, get_setting
from core.theme import create_success_embed, create_error_embed, create_info_embed, create_embed, add_field, Theme
from datetime import datetime

def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if uid == str(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure(f"Required role: {', '.join(roles)}")
    return app_commands.check(predicate)

# Extension registry: display name → config attribute
EXTENSIONS = {
    "Multi-Node Support":     "MULTI_NODE",
    "Scheduled Backups":      "SOSB",
    "Ticket System":          "ISTS",
    "Auto Expire & Suspend":  "AES",
    "Renewal Reminders":      "RR",
    "Admin 2FA":              "A2FA",
    "Multi-Server Tickets":   "MSTC",
    "Backup Limits":          "UBL_ENABLED",
    "Marketplace":            "MARKETPLACE",
    "Account & MoonCoin":     "ACCOUNT",
    "VPS Renewal":            "VPS_RENEWAL",
    "VPS Monitoring Alerts":  "VPS_MONITORING",
    "VPS Templates":          "VPS_TEMPLATES",
    "Multi-language":         "MULTILANG",
}

EXT_CHOICES = [app_commands.Choice(name=n, value=n) for n in EXTENSIONS]


class SystemAdminCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="system-admin", description="[OWNER] Extensions, maintenance, A2FA, and system tools")
    @app_commands.choices(action=[
        app_commands.Choice(name="🔌 Extension Toggle", value="extension"),
        app_commands.Choice(name="👁️ View Extensions",  value="view_ext"),
        app_commands.Choice(name="🚧 Maintenance Mode", value="maintenance"),
        app_commands.Choice(name="🧹 Clean DB",          value="clean"),
        app_commands.Choice(name="🔐 A2FA Management",   value="a2fa"),
    ])
    @app_commands.choices(extension=EXT_CHOICES)
    @app_commands.choices(ext_state=[
        app_commands.Choice(name="✅ Enable",  value="enable"),
        app_commands.Choice(name="❌ Disable", value="disable"),
    ])
    @app_commands.choices(a2fa_action=[
        app_commands.Choice(name="Set / Edit PIN", value="edit"),
        app_commands.Choice(name="Remove PIN",     value="remove"),
    ])
    @app_commands.describe(
        action     ="What action to perform",
        extension  ="Extension to toggle",
        ext_state  ="Enable or disable",
        a2fa_action="A2FA action",
        new_pin    ="New 4-digit PIN",
    )
    @has_role("Owner")
    async def system_admin(
        self, interaction: discord.Interaction,
        action: str,
        extension: str = None,
        ext_state: str = None,
        a2fa_action: str = None,
        new_pin: str = None,
    ):
        await interaction.response.defer(ephemeral=True)

        # ── View Extensions ──────────────────────────────────────────────────
        if action == "view_ext":
            embed = discord.Embed(
                title="🔌  Extension Status",
                description=f"{Theme.DIVIDER}\nAll available extensions and their current state\n{Theme.DIVIDER}",
                color=Theme.PRIMARY, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes — System Admin", icon_url="https://imgur.com/6yfYDTP.png")
            lines_on, lines_off = [], []
            for name, attr in EXTENSIONS.items():
                val = getattr(cfg, attr, False)
                (lines_on if val else lines_off).append(f"{'🟢' if val else '🔴'} **{name}**")
            embed.add_field(name="✅ Enabled", value="\n".join(lines_on)  or "*None*", inline=True)
            embed.add_field(name="❌ Disabled",value="\n".join(lines_off) or "*None*", inline=True)
            return await interaction.followup.send(embed=embed)

        # ── Extension Toggle ─────────────────────────────────────────────────
        elif action == "extension":
            if not extension or not ext_state:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Select an extension and a state."))
            attr  = EXTENSIONS.get(extension)
            if not attr:
                return await interaction.followup.send(embed=create_error_embed("Unknown", f"Extension `{extension}` not found."))
            value = (ext_state == "enable")
            setattr(cfg, attr, value)
            set_setting(f"ext_{attr}", str(value))
            icon = "✅" if value else "❌"
            embed = create_success_embed(
                "Extension Updated",
                f"{icon} **{extension}** is now **{'Enabled' if value else 'Disabled'}**."
            )
            # Extension-specific notes
            notes = {
                "Ticket System":         "Users can now open support tickets with `/support`.",
                "Scheduled Backups":     "Configure the schedule with `/set setting:Scheduled Backups`.",
                "Backup Limits":         "Configure limits with `/set setting:Backup Limits`.",
                "Admin 2FA":             "Set your PIN with `/system-admin action:A2FA Management`.",
                "Multi-Node Support":    "Register nodes with `/node pick_one:Create`.",
                "Auto Expire & Suspend": "VPS will auto-suspend when their expiry date passes.",
                "Renewal Reminders":     "Users will receive DM reminders 3 days before expiry.",
                "VPS Monitoring Alerts": "Users will be DM'd when their VPS goes over resource thresholds.",
                "VPS Templates":         "Pre-configured OS templates become available in the OS selector.",
                "VPS Renewal":           "Users can extend VPS expiry with `/upgrade`.",
                "Marketplace":           "Users can buy/sell VPS with `/marketplace`.",
            }
            if extension in notes:
                add_field(embed, "ℹ️ Note", notes[extension], False)
            return await interaction.followup.send(embed=embed)

        # ── Maintenance ──────────────────────────────────────────────────────
        elif action == "maintenance":
            cfg.MAINTENANCE_MODE = not getattr(cfg, "MAINTENANCE_MODE", False)
            state = "ON 🚧" if cfg.MAINTENANCE_MODE else "OFF ✅"
            return await interaction.followup.send(
                embed=create_success_embed("Maintenance Mode", f"Maintenance mode is now **{state}**.")
            )

        # ── Clean DB ─────────────────────────────────────────────────────────
        elif action == "clean":
            removed = 0
            with data_lock:
                for uid in list(vps_data.keys()):
                    before = len(vps_data[uid])
                    vps_data[uid] = [v for v in vps_data[uid] if v.get("container_name")]
                    removed += before - len(vps_data[uid])
                    if not vps_data[uid]:
                        del vps_data[uid]
            save_vps_data()
            return await interaction.followup.send(
                embed=create_success_embed("DB Cleaned", f"Removed **{removed}** stale VPS entries.")
            )

        # ── A2FA ─────────────────────────────────────────────────────────────
        elif action == "a2fa":
            if not a2fa_action:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Choose an A2FA action."))

            if not cfg.A2FA:
                return await interaction.followup.send(
                    embed=create_error_embed("Extension Off", "Enable Admin 2FA first via Extension Toggle.")
                )

            conn = get_db()
            cur  = conn.cursor()
            uid  = str(interaction.user.id)

            if a2fa_action == "edit":
                if not new_pin or not new_pin.isdigit() or len(new_pin) != 4:
                    conn.close()
                    return await interaction.followup.send(embed=create_error_embed("Invalid PIN", "PIN must be exactly 4 digits."))
                cur.execute("INSERT OR IGNORE INTO admins (user_id) VALUES (?)", (uid,))
                cur.execute("UPDATE admins SET pin=? WHERE user_id=?", (new_pin, uid))
                conn.commit()
                conn.close()
                return await interaction.followup.send(embed=create_success_embed("PIN Updated", "Your A2FA PIN has been set. Keep it private!"))

            elif a2fa_action == "remove":
                cur.execute("UPDATE admins SET pin='0000' WHERE user_id=?", (uid,))
                conn.commit()
                conn.close()
                return await interaction.followup.send(embed=create_success_embed("PIN Removed", "A2FA PIN reset to default (0000)."))

            conn.close()


async def setup(bot):
    await bot.add_cog(SystemAdminCog(bot))
