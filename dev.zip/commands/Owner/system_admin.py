import discord
from discord import app_commands
from discord.ext import commands
import core.config as cfg

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock, save_vps_data, get_db, set_setting, get_setting
from core.theme import create_success_embed, create_error_embed, create_info_embed, create_embed, add_field


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if uid == str(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure(f"Required role: {', '.join(roles)}")
    return app_commands.check(predicate)


EXTENSIONS = [
    "Multi-Node Support",
    "Scheduled Backups",
    "Ticket System",
    "Auto Expire & Suspend",
    "Renewal Reminders",
    "Admin 2FA",
    "Multi-Server Tickets",
    "Backup Limits",
]

_EXT_MAP = {
    "Multi-Node Support":    "MULTI_NODE",
    "Scheduled Backups":     "SOSB",
    "Ticket System":         "ISTS",
    "Auto Expire & Suspend": "AES",
    "Renewal Reminders":     "RR",
    "Admin 2FA":             "A2FA",
    "Multi-Server Tickets":  "MSTC",
    "Backup Limits":         "UBL_ENABLED",
}

_EXT_KEY_MAP = {v: k for k, v in _EXT_MAP.items()}


class SystemAdminCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="system-admin", description="[OWNER] System toggles, maintenance, and A2FA tools")
    @app_commands.choices(action=[
        app_commands.Choice(name="Extension Toggle", value="extension"),
        app_commands.Choice(name="Maintenance Mode", value="maintenance"),
        app_commands.Choice(name="Clean DB",          value="clean"),
        app_commands.Choice(name="View Extensions",   value="view_ext"),
        app_commands.Choice(name="A2FA Management",   value="a2fa"),
    ])
    @app_commands.choices(extension=[app_commands.Choice(name=e, value=e) for e in EXTENSIONS])
    @app_commands.choices(ext_state=[
        app_commands.Choice(name="Enable",  value="enable"),
        app_commands.Choice(name="Disable", value="disable"),
    ])
    @app_commands.choices(a2fa_action=[
        app_commands.Choice(name="Edit PIN",   value="edit"),
        app_commands.Choice(name="Remove PIN", value="remove"),
    ])
    @app_commands.describe(
        new_pin="New 4-digit PIN for A2FA",
    )
    @has_role("Owner")
    async def system_admin(
        self, interaction: discord.Interaction,
        action: str,
        extension: str = None, ext_state: str = None,
        a2fa_action: str = None, new_pin: str = None,
    ):
        await interaction.response.defer(ephemeral=True)

        # ── View Extensions ──────────────────────────────────────────────────
        if action == "view_ext":
            lines = []
            for attr, friendly in _EXT_KEY_MAP.items():
                val  = getattr(cfg, attr, False)
                icon = "🟢" if val else "🔴"
                lines.append(f"{icon} **{friendly}** — {'Enabled' if val else 'Disabled'}")
            embed = create_embed("⚙️ Extension Status", "\n".join(lines))
            return await interaction.followup.send(embed=embed)

        # ── Maintenance toggle ───────────────────────────────────────────────
        elif action == "maintenance":
            cfg.MAINTENANCE_MODE = not cfg.MAINTENANCE_MODE
            state = "ON" if cfg.MAINTENANCE_MODE else "OFF"
            return await interaction.followup.send(embed=create_success_embed("Maintenance", f"Maintenance mode is now **{state}**."))

        # ── Extension toggle ─────────────────────────────────────────────────
        elif action == "extension":
            if not extension or not ext_state:
                return await interaction.followup.send(embed=create_error_embed("Error", "Provide an extension and state."))
            attr  = _EXT_MAP.get(extension)
            value = (ext_state == "enable")
            if attr:
                setattr(cfg, attr, value)
            set_setting(f"ext_{attr}", str(value))
            return await interaction.followup.send(
                embed=create_success_embed(
                    "Extension Updated",
                    f"**{extension}** → **{'✅ Enabled' if value else '❌ Disabled'}**"
                )
            )

        # ── Clean DB ─────────────────────────────────────────────────────────
        elif action == "clean":
            removed = 0
            with data_lock:
                for uid in list(vps_data.keys()):
                    before = len(vps_data[uid])
                    vps_data[uid] = [v for v in vps_data[uid] if v.get("container_name")]
                    removed += before - len(vps_data[uid])
                    if not vps_data[uid]:
                        del vps_data[uid]
            save_vps_data()
            return await interaction.followup.send(embed=create_success_embed("DB Cleaned", f"Removed {removed} stale entries."))

        # ── A2FA ─────────────────────────────────────────────────────────────
        elif action == "a2fa":
            if not a2fa_action:
                return await interaction.followup.send(embed=create_error_embed("Error", "Pick an A2FA action."))
            conn = get_db()
            cur  = conn.cursor()
            if a2fa_action == "edit":
                if not new_pin or not new_pin.isdigit() or len(new_pin) != 4:
                    conn.close()
                    return await interaction.followup.send(embed=create_error_embed("Error", "Provide a valid 4-digit PIN."))
                cur.execute("UPDATE admins SET pin=? WHERE user_id=?", (new_pin, str(interaction.user.id)))
                conn.commit()
                conn.close()
                return await interaction.followup.send(embed=create_success_embed("PIN Updated", "Your A2FA PIN has been changed."))
            elif a2fa_action == "remove":
                cur.execute("UPDATE admins SET pin='0000' WHERE user_id=?", (str(interaction.user.id),))
                conn.commit()
                conn.close()
                return await interaction.followup.send(embed=create_success_embed("PIN Removed", "A2FA PIN reset to default."))
            conn.close()


async def setup(bot):
    await bot.add_cog(SystemAdminCog(bot))
