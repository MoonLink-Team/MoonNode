"""
/role — Staff role management with promote/demote and DM notifications.

Role hierarchy (highest → lowest):
  Owner → Hard Admin → Admin → Manager → Hard Mod → Mod → Hard Staff → Staff → Trial Staff → Trial Mod → Partner
"""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.database import admin_data, save_admin_data, get_db
from core.config import MAIN_ADMIN_ID
from core.theme import create_success_embed, create_error_embed, create_embed, create_info_embed, add_field, Theme

# ── Role definitions ──────────────────────────────────────────────────────────

ROLE_HIERARCHY = [
    "Owner", "Hard Admin", "Admin", "Manager",
    "Hard Mod", "Mod", "Hard Staff", "Staff",
    "Trial Staff", "Trial Mod", "Partner",
]

ROLE_ICONS = {
    "Owner":       "👑",
    "Hard Admin":  "🔱",
    "Admin":       "🛡️",
    "Manager":     "💼",
    "Hard Mod":    "🔨",
    "Mod":         "⚒️",
    "Hard Staff":  "⭐",
    "Staff":       "🌟",
    "Trial Staff": "🔰",
    "Trial Mod":   "🎯",
    "Partner":     "🤝",
}

ROLE_COLORS = {
    "Owner":       0xFFD700,
    "Hard Admin":  0xFF4500,
    "Admin":       0x5865F2,
    "Manager":     0x9B59B6,
    "Hard Mod":    0xE74C3C,
    "Mod":         0x57F287,
    "Hard Staff":  0xF1C40F,
    "Staff":       0x3498DB,
    "Trial Staff": 0x95A5A6,
    "Trial Mod":   0x7F8C8D,
    "Partner":     0x1ABC9C,
}

ROLE_PERMISSIONS = {
    "Owner":       "Full control — all commands, extensions, nodes, staff management",
    "Hard Admin":  "All admin commands + can manage Admins and below",
    "Admin":       "VPS management, config, giveaways, node management",
    "Manager":     "Admin commands except node management and extensions",
    "Hard Mod":    "Mod commands + can warn, DM users, manage tickets",
    "Mod":         "Ticket management, user lookups, server stats",
    "Hard Staff":  "Support ticket handling + basic mod tools",
    "Staff":       "Support ticket handling only",
    "Trial Staff": "Handle support tickets in training — limited commands",
    "Trial Mod":   "Observe mod channels — no active permissions yet",
    "Partner":     "Partner badge + VIP perks — no mod permissions",
}

ROLE_DM_GRANT = {
    "Owner":       "## 👑  You've Been Granted Owner!\n\nYou now have **full control** over MoonNodes VPS Manager.\n\n**Permissions:**\n› All commands across every category\n› Toggle extensions on/off\n› Manage nodes, staff, and system\n\n*Use your power wisely — the community is counting on you!*",
    "Hard Admin":  "## 🔱  You're Now a Hard Admin!\n\nYou have elevated admin access with authority over the Admin tier.\n\n**Permissions:**\n› All admin and mod commands\n› Manage Admins, Mods, and Staff\n› VPS creation, deletion, suspension\n\n*Lead by example and keep things running smoothly!*",
    "Admin":       "## 🛡️  You've Been Promoted to Admin!\n\nYou now have admin access to MoonNodes.\n\n**Permissions:**\n› Create, delete, and manage VPS\n› Configure bot settings\n› Manage support tickets and giveaways\n\n*Welcome to the team — keep the servers online!*",
    "Manager":     "## 💼  You're Now a Manager!\n\nYou have management-level access to MoonNodes.\n\n**Permissions:**\n› All admin commands (except nodes and extensions)\n› Staff oversight and ticket management\n\n*Help coordinate the team and keep things organized!*",
    "Hard Mod":    "## 🔨  You're Now a Hard Mod!\n\nYou have elevated moderation access.\n\n**Permissions:**\n› All mod commands\n› Warn users, DM as staff, manage tickets\n\n*Keep the community and VPS environment clean!*",
    "Mod":         "## ⚒️  You've Been Made a Mod!\n\nYou can now moderate the MoonNodes community.\n\n**Permissions:**\n› User lookups, ticket management, server stats\n› Suspension logs and search tools\n\n*Help maintain a positive environment for all users!*",
    "Hard Staff":  "## ⭐  You're Now Hard Staff!\n\nYou have elevated staff access with mod tools.\n\n**Permissions:**\n› Support ticket handling\n› Basic moderation and user lookup tools\n\n*Support the community and help resolve issues!*",
    "Staff":       "## 🌟  You've Joined the Staff Team!\n\nWelcome to the MoonNodes support team.\n\n**Permissions:**\n› Handle and close support tickets\n› Basic member assistance\n\n*Be helpful, patient, and professional with every user!*",
    "Trial Staff": "## 🔰  You're a Trial Staff Member!\n\nYou are in your trial period for the MoonNodes team.\n\n**Permissions:**\n› Handle support tickets under supervision\n› No permanent permissions yet\n\n*Show us what you've got — this is your chance to prove yourself!*",
    "Trial Mod":   "## 🎯  You're a Trial Moderator!\n\nYou are observing the mod team in your trial period.\n\n**Permissions:**\n› View staff channels and observe\n› No active permissions during trial\n\n*Learn, observe, and prepare for full moderation duties!*",
    "Partner":     "## 🤝  You're Now a Partner!\n\nYou have been recognized as a valued MoonNodes Partner.\n\n**Perks:**\n› Partner badge and VIP role\n› Access to partner channels\n› Special discounts and early access\n\n*Thank you for supporting and partnering with MoonNodes!*",
}

ROLE_DM_REVOKE = {r: f"Your **{ROLE_ICONS.get(r,'')} {r}** role has been removed from MoonNodes." for r in ROLE_HIERARCHY}

ROLE_DM_PROMOTE = "## ⬆️  You've Been Promoted!\n\n**{old}** → **{new}**\n\nCongratulations on your promotion within MoonNodes!\n\n**New Permissions:**\n{perms}\n\n*Keep up the great work!*"
ROLE_DM_DEMOTE  = "## ⬇️  Role Change Notice\n\n**{old}** → **{new}**\n\nYour role in MoonNodes has been adjusted.\n\n*If you have questions, please contact the Owner.*"

# Roles that can use admin-style commands
ADMIN_ROLES     = {"Owner", "Hard Admin", "Admin", "Manager"}
MOD_ROLES       = {"Owner", "Hard Admin", "Admin", "Manager", "Hard Mod", "Mod", "Hard Staff"}
STAFF_ROLES     = {"Owner", "Hard Admin", "Admin", "Manager", "Hard Mod", "Mod", "Hard Staff", "Staff", "Trial Staff"}


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if int(uid) == int(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure(f"Required role: {', '.join(roles)}")
    return app_commands.check(predicate)


class AdminCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="role", description="[OWNER] Assign, remove, promote, or demote staff roles")
    @app_commands.choices(action=[
        app_commands.Choice(name="➕ Add — Grant a role",         value="add"),
        app_commands.Choice(name="➖ Remove — Revoke a role",     value="remove"),
        app_commands.Choice(name="⬆️ Promote — Move up one tier", value="promote"),
        app_commands.Choice(name="⬇️ Demote — Move down one tier",value="demote"),
        app_commands.Choice(name="📋 List — View all staff",      value="list"),
    ])
    @app_commands.choices(permission=[
        app_commands.Choice(name="👑 Owner",       value="Owner"),
        app_commands.Choice(name="🔱 Hard Admin",  value="Hard Admin"),
        app_commands.Choice(name="🛡️ Admin",       value="Admin"),
        app_commands.Choice(name="💼 Manager",     value="Manager"),
        app_commands.Choice(name="🔨 Hard Mod",    value="Hard Mod"),
        app_commands.Choice(name="⚒️ Mod",         value="Mod"),
        app_commands.Choice(name="⭐ Hard Staff",  value="Hard Staff"),
        app_commands.Choice(name="🌟 Staff",       value="Staff"),
        app_commands.Choice(name="🔰 Trial Staff", value="Trial Staff"),
        app_commands.Choice(name="🎯 Trial Mod",   value="Trial Mod"),
        app_commands.Choice(name="🤝 Partner",     value="Partner"),
    ])
    @app_commands.describe(
        action     ="Action to perform",
        user       ="Target Discord member",
        permission ="Role to assign (for Add action)",
    )
    @has_role("Owner", "Hard Admin")
    async def admin_action(
        self,
        interaction: discord.Interaction,
        action: str,
        user: discord.Member = None,
        permission: str = "Staff",
    ):
        await interaction.response.defer(ephemeral=True)

        # ── LIST ─────────────────────────────────────────────────────────────
        if action == "list":
            if not admin_data:
                return await interaction.followup.send(embed=create_error_embed("No Staff", "No staff members assigned yet."))

            grouped = {}
            for uid, role in admin_data.items():
                grouped.setdefault(role, []).append(uid)

            embed = discord.Embed(
                title="🌙  MoonNodes — Staff Directory",
                description=f"{Theme.DIVIDER}\n**{sum(len(v) for v in grouped.values())}** staff members\n{Theme.DIVIDER}",
                color=0x5865F2,
                timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")

            for role_name in ROLE_HIERARCHY:
                members = grouped.get(role_name, [])
                if not members:
                    continue
                icon  = ROLE_ICONS.get(role_name, "•")
                color_hex = f"#{ROLE_COLORS.get(role_name, 0):06X}"
                lines = []
                for uid in members:
                    member = interaction.guild.get_member(int(uid)) if interaction.guild else None
                    tag    = member.mention if member else f"<@{uid}>"
                    joined = f"<t:{int(member.joined_at.timestamp())}:R>" if (member and member.joined_at) else "?"
                    lines.append(f"**{tag}**\n╰ Joined: {joined}")
                embed.add_field(
                    name=f"{icon}  {role_name}  ({len(members)})",
                    value="\n\n".join(lines)[:1024],
                    inline=True,
                )

            embed.add_field(
                name="📖 Role Descriptions",
                value="\n".join(f"{ROLE_ICONS.get(r,'•')} **{r}** — {ROLE_PERMISSIONS[r]}" for r in ROLE_HIERARCHY)[:1024],
                inline=False,
            )
            embed.set_footer(text=f"Requested by {interaction.user.display_name}")
            return await interaction.followup.send(embed=embed)

        # ── Require user for all other actions ────────────────────────────────
        if not user:
            return await interaction.followup.send(embed=create_error_embed("Missing", "Specify a `user`."))

        uid       = str(user.id)
        cur_role  = admin_data.get(uid)

        # ── ADD ──────────────────────────────────────────────────────────────
        if action == "add":
            admin_data[uid] = permission
            save_admin_data()
            conn = get_db(); cur = conn.cursor()
            cur.execute("INSERT OR IGNORE INTO admins (user_id, role) VALUES (?,?)", (uid, permission))
            cur.execute("UPDATE admins SET role=? WHERE user_id=?", (permission, uid))
            conn.commit(); conn.close()

            icon  = ROLE_ICONS.get(permission, "•")
            color = ROLE_COLORS.get(permission, Theme.PRIMARY)

            embed = discord.Embed(
                title=f"{icon}  Role Assigned",
                description=f"{user.mention} is now **{permission}**.",
                color=color, timestamp=datetime.now(),
            )
            embed.set_thumbnail(url=user.display_avatar.url)
            embed.add_field(name="Permissions", value=ROLE_PERMISSIONS.get(permission,"—"), inline=False)
            embed.set_footer(text=f"Assigned by {interaction.user.display_name}")
            await interaction.followup.send(embed=embed)

            try:
                dm = discord.Embed(description=ROLE_DM_GRANT.get(permission, f"You have been granted **{permission}**."), color=color, timestamp=datetime.now())
                dm.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                dm.set_footer(text=f"Granted by {interaction.user.display_name}")
                await user.send(embed=dm)
            except discord.Forbidden:
                await interaction.followup.send(embed=create_info_embed("Note", f"{user.mention} has DMs disabled — they were not notified."))

        # ── REMOVE ───────────────────────────────────────────────────────────
        elif action == "remove":
            old_role = admin_data.pop(uid, None)
            save_admin_data()
            conn = get_db(); cur = conn.cursor()
            cur.execute("DELETE FROM admins WHERE user_id=?", (uid,))
            conn.commit(); conn.close()

            await interaction.followup.send(embed=create_success_embed("Role Removed", f"{user.mention}'s **{old_role or 'staff'}** role has been revoked."))
            if old_role:
                try:
                    dm = discord.Embed(
                        description=f"## ❌  Role Revoked\n\n{ROLE_DM_REVOKE.get(old_role, 'Your staff role has been removed.')}\n\n*Contact the Owner if you believe this is a mistake.*",
                        color=Theme.ERROR, timestamp=datetime.now(),
                    )
                    dm.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                    dm.set_footer(text=f"Removed by {interaction.user.display_name}")
                    await user.send(embed=dm)
                except discord.Forbidden:
                    pass

        # ── PROMOTE ──────────────────────────────────────────────────────────
        elif action == "promote":
            if not cur_role or cur_role not in ROLE_HIERARCHY:
                return await interaction.followup.send(embed=create_error_embed("No Role", f"{user.mention} has no staff role to promote from. Use `Add` first."))
            idx = ROLE_HIERARCHY.index(cur_role)
            if idx == 0:
                return await interaction.followup.send(embed=create_error_embed("At Top", f"{user.mention} is already at the highest role (**{cur_role}**)."))
            new_role = ROLE_HIERARCHY[idx - 1]
            admin_data[uid] = new_role
            save_admin_data()
            conn = get_db(); cur = conn.cursor()
            cur.execute("UPDATE admins SET role=? WHERE user_id=?", (new_role, uid))
            conn.commit(); conn.close()

            embed = discord.Embed(
                title="⬆️  Promoted!",
                description=f"{user.mention}\n`{cur_role}` → **`{new_role}`**",
                color=ROLE_COLORS.get(new_role, Theme.PRIMARY), timestamp=datetime.now(),
            )
            embed.set_thumbnail(url=user.display_avatar.url)
            embed.set_footer(text=f"Promoted by {interaction.user.display_name}")
            await interaction.followup.send(embed=embed)

            try:
                dm = discord.Embed(
                    description=ROLE_DM_PROMOTE.format(old=cur_role, new=new_role, perms=ROLE_PERMISSIONS.get(new_role,"—")),
                    color=ROLE_COLORS.get(new_role, Theme.PRIMARY), timestamp=datetime.now(),
                )
                dm.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                dm.set_footer(text=f"Promoted by {interaction.user.display_name}")
                await user.send(embed=dm)
            except discord.Forbidden:
                pass

        # ── DEMOTE ───────────────────────────────────────────────────────────
        elif action == "demote":
            if not cur_role or cur_role not in ROLE_HIERARCHY:
                return await interaction.followup.send(embed=create_error_embed("No Role", f"{user.mention} has no staff role to demote from."))
            idx = ROLE_HIERARCHY.index(cur_role)
            if idx >= len(ROLE_HIERARCHY) - 1:
                return await interaction.followup.send(embed=create_error_embed("At Bottom", f"{user.mention} is already at the lowest role (**{cur_role}**). Use `Remove` instead."))
            new_role = ROLE_HIERARCHY[idx + 1]
            admin_data[uid] = new_role
            save_admin_data()
            conn = get_db(); cur = conn.cursor()
            cur.execute("UPDATE admins SET role=? WHERE user_id=?", (new_role, uid))
            conn.commit(); conn.close()

            embed = discord.Embed(
                title="⬇️  Role Adjusted",
                description=f"{user.mention}\n`{cur_role}` → **`{new_role}`**",
                color=ROLE_COLORS.get(new_role, 0x7F8C8D), timestamp=datetime.now(),
            )
            embed.set_footer(text=f"Demoted by {interaction.user.display_name}")
            await interaction.followup.send(embed=embed)

            try:
                dm = discord.Embed(
                    description=ROLE_DM_DEMOTE.format(old=cur_role, new=new_role),
                    color=ROLE_COLORS.get(new_role, 0x7F8C8D), timestamp=datetime.now(),
                )
                dm.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                dm.set_footer(text=f"Adjusted by {interaction.user.display_name}")
                await user.send(embed=dm)
            except discord.Forbidden:
                pass


async def setup(bot):
    await bot.add_cog(AdminCog(bot))
