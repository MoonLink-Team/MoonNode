import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.database import admin_data, save_admin_data, get_db
from core.config import MAIN_ADMIN_ID
from core.theme import (
    create_success_embed, create_error_embed, create_embed,
    create_info_embed, add_field, Theme,
)

ROLE_ICONS = {
    "Owner": "👑",
    "Admin": "🛡️",
    "Mod":   "🔨",
    "Dev":   "💻",
}

ROLE_COLORS = {
    "Owner": 0xFFD700,   # gold
    "Admin": 0x5865F2,   # blurple
    "Mod":   0x57F287,   # green
    "Dev":   0xEB459E,   # pink
}

ROLE_DM_MSG = {
    "Owner": (
        "## 👑 You've been granted Owner access!\n\n"
        "You now have **full control** over the MoonNodes VPS Manager bot.\n\n"
        "**Your new permissions include:**\n"
        "› All admin & mod commands\n"
        "› Staff role management (`/role`)\n"
        "› System configuration & extensions (`/system-admin`)\n"
        "› Node cluster management (`/node`)\n\n"
        "*With great power comes great responsibility. Use it wisely!*"
    ),
    "Admin": (
        "## 🛡️ You've been promoted to Admin!\n\n"
        "You now have elevated access to the MoonNodes VPS Manager.\n\n"
        "**Your new permissions include:**\n"
        "› Create, delete, and manage VPS for all users (`/create`, `/delete`, `/manage`)\n"
        "› Suspend & unsuspend VPS (`/vps`)\n"
        "› Configure bot settings (`/set`, `/payment`)\n"
        "› Manage all nodes (`/node`)\n\n"
        "*Welcome to the team — keep the servers running smoothly!*"
    ),
    "Mod": (
        "## 🔨 You've been assigned as Moderator!\n\n"
        "You now have moderation access to the MoonNodes VPS Manager.\n\n"
        "**Your new permissions include:**\n"
        "› Manage support tickets\n"
        "› View user VPS info\n"
        "› Handle `/manage` for users\n\n"
        "*Help keep the community and VPS environment clean!*"
    ),
    "Dev": (
        "## 💻 You've been added as a Developer!\n\n"
        "You now have developer-level access to the MoonNodes VPS Manager.\n\n"
        "**Your new permissions include:**\n"
        "› All admin commands\n"
        "› Debug and diagnostic tools\n"
        "› Direct system configuration\n\n"
        "*Build things, break things (responsibly), and fix things faster!*"
    ),
}

REMOVE_DM_MSG = {
    "Owner": "Your **Owner** role in MoonNodes VPS Manager has been removed by a senior admin.",
    "Admin": "Your **Admin** role in MoonNodes VPS Manager has been revoked.",
    "Mod":   "Your **Moderator** role in MoonNodes VPS Manager has been removed.",
    "Dev":   "Your **Developer** role in MoonNodes VPS Manager has been removed.",
}


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if uid == str(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure(f"Required role: {', '.join(roles)}")
    return app_commands.check(predicate)


class AdminCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="role", description="[OWNER] Assign or remove staff roles")
    @app_commands.choices(action=[
        app_commands.Choice(name="Add",    value="add"),
        app_commands.Choice(name="Remove", value="remove"),
        app_commands.Choice(name="List",   value="list"),
    ])
    @app_commands.choices(permission=[
        app_commands.Choice(name="Owner Level", value="Owner"),
        app_commands.Choice(name="Admin Level", value="Admin"),
        app_commands.Choice(name="Mod Level",   value="Mod"),
        app_commands.Choice(name="Dev Level",   value="Dev"),
    ])
    @has_role("Owner")
    async def admin_action(
        self,
        interaction: discord.Interaction,
        action: str,
        user: discord.Member = None,
        permission: str = "Admin",
    ):
        await interaction.response.defer(ephemeral=True)

        # ── /role list ───────────────────────────────────────────────────────
        if action == "list":
            if not admin_data:
                return await interaction.followup.send(
                    embed=create_error_embed("No Staff", "No staff members have been assigned yet.")
                )

            # Group by role
            grouped = {}
            for uid, role in admin_data.items():
                grouped.setdefault(role, []).append(uid)

            embed = discord.Embed(
                title="🌙  MoonNodes — Staff Directory",
                description=(
                    f"{Theme.DIVIDER}\n"
                    f"**{sum(len(v) for v in grouped.values())}** staff members across "
                    f"**{len(grouped)}** role(s)\n"
                    f"{Theme.DIVIDER}"
                ),
                color=0x5865F2,
                timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")

            for role_name in ["Owner", "Admin", "Mod", "Dev"]:
                members = grouped.get(role_name, [])
                if not members:
                    continue
                icon  = ROLE_ICONS.get(role_name, "•")
                lines = []
                for uid in members:
                    member = interaction.guild.get_member(int(uid))
                    tag    = member.mention if member else f"<@{uid}>"
                    joined = (
                        f"<t:{int(member.joined_at.timestamp())}:R>"
                        if member and member.joined_at else "Unknown"
                    )
                    lines.append(f"**{tag}**\n╰ Joined: {joined}")
                embed.add_field(
                    name=f"{icon}  {role_name}  ({len(members)})",
                    value="\n\n".join(lines)[:1024],
                    inline=True,
                )

            embed.set_footer(text=f"Requested by {interaction.user.display_name}")
            return await interaction.followup.send(embed=embed)

        # ── /role add / remove ───────────────────────────────────────────────
        if not user:
            return await interaction.followup.send(
                embed=create_error_embed("Error", "You must specify a user.")
            )

        uid = str(user.id)

        if action == "add":
            admin_data[uid] = permission
            save_admin_data()

            db  = get_db()
            cur = db.cursor()
            cur.execute("INSERT OR IGNORE INTO admins (user_id, role) VALUES (?,?)", (uid, permission))
            cur.execute("UPDATE admins SET role=? WHERE user_id=?", (permission, uid))
            db.commit()
            db.close()

            icon  = ROLE_ICONS.get(permission, "•")
            color = ROLE_COLORS.get(permission, Theme.PRIMARY)

            # Confirm to admin
            embed = discord.Embed(
                title=f"{icon}  Role Assigned — {permission}",
                description=f"{user.mention} is now a **{permission}**.",
                color=color,
                timestamp=datetime.now(),
            )
            embed.set_thumbnail(url=user.display_avatar.url)
            embed.set_footer(text=f"Assigned by {interaction.user.display_name}")
            await interaction.followup.send(embed=embed)

            # DM the user
            try:
                dm_embed = discord.Embed(
                    description=ROLE_DM_MSG.get(permission, f"You have been assigned the **{permission}** role."),
                    color=color,
                    timestamp=datetime.now(),
                )
                dm_embed.set_author(
                    name="MoonNodes VPS Manager",
                    icon_url="https://imgur.com/6yfYDTP.png",
                )
                dm_embed.set_footer(text=f"Granted by {interaction.user.display_name}")
                await user.send(embed=dm_embed)
            except discord.Forbidden:
                await interaction.followup.send(
                    embed=create_info_embed("Note", f"Could not DM {user.mention} — they may have DMs disabled.")
                )

        elif action == "remove":
            old_role = admin_data.pop(uid, None)
            save_admin_data()

            db  = get_db()
            cur = db.cursor()
            cur.execute("DELETE FROM admins WHERE user_id=?", (uid,))
            db.commit()
            db.close()

            embed = create_success_embed(
                "Role Removed",
                f"{user.mention}'s **{old_role or 'staff'}** role has been revoked.",
            )
            await interaction.followup.send(embed=embed)

            if old_role:
                try:
                    dm_embed = discord.Embed(
                        description=(
                            f"## ❌  Staff Role Revoked\n\n"
                            f"{REMOVE_DM_MSG.get(old_role, 'Your staff role has been removed.')}\n\n"
                            f"*If you believe this is a mistake, contact the server owner.*"
                        ),
                        color=Theme.ERROR,
                        timestamp=datetime.now(),
                    )
                    dm_embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
                    dm_embed.set_footer(text=f"Removed by {interaction.user.display_name}")
                    await user.send(embed=dm_embed)
                except discord.Forbidden:
                    pass


async def setup(bot):
    await bot.add_cog(AdminCog(bot))
