"""
/create — [ADMIN] Deploy a VPS for any user.
Flow: slash command → NodeSelectView → OSSelectView → deploy
"""
import discord
from discord import app_commands
from discord.ext import commands

from core.config import MAIN_ADMIN_ID, ENFORCE_RESOURCE_LIMITS, MAX_RAM_LIMIT, MAX_CPU_LIMIT
from core.database import admin_data
from core.theme import create_error_embed, create_info_embed
from feature.plans import PLANS
from ui.node_select import NodeSelectView
from core import ACTIVE_STORAGE_POOL


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if int(uid) == int(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure("🚫 no_permission")
    return app_commands.check(predicate)


class CreateCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="create", description="[ADMIN] Deploy a VPS for a user — pick node then OS")
    @app_commands.describe(
        user          = "Target Discord user @mention",
        user_id       = "Paste User ID if @mention doesn't work",
        plan_name     = "Plan name (e.g. basic, starter) — overrides manual specs",
        plan_type     = "Plan type: Free or Premium",
        ram_gb        = "RAM in GB",
        cpu_cores     = "CPU cores",
        disk_gb       = "Disk in GB",
        validity_days = "Expiry in days (0 = permanent)",
        vm_mode       = "Virtualisation type: LXC container (default) or KVM/QEMU VM",
    )
    @app_commands.choices(plan_type=[
        app_commands.Choice(name="Free",    value="free"),
        app_commands.Choice(name="Premium", value="premium"),
    ])
    @app_commands.choices(vm_mode=[
        app_commands.Choice(name="📦 LXC Container (default, fast)",  value="lxc"),
        app_commands.Choice(name="🖥️ KVM/QEMU VM (full virtualisation)", value="kvm"),
    ])
    @has_role("Owner", "Admin", "Dev")
    async def create_cmd(
        self,
        interaction: discord.Interaction,
        user:          discord.Member = None,
        plan_name:     str            = None,
        plan_type:     str            = None,
        ram_gb:        int            = None,
        cpu_cores:     int            = None,
        disk_gb:       int            = None,
        validity_days: int            = 0,
        user_id:       str            = None,
        vm_mode:       str            = "lxc",
    ):
        await interaction.response.defer(ephemeral=True)

        # ── Rate limit ────────────────────────────────────────────────────────
        try:
            import bot as _bot_module
            wait = _bot_module._check_rate_limit("create", interaction.user.id)
            if wait > 0:
                return await interaction.followup.send(
                    embed=create_error_embed("⏳ Slow Down", f"Wait **{wait:.0f}s** before using this command again."),
                    ephemeral=True,
                )
        except Exception:
            pass

        # ── Resolve target user ───────────────────────────────────────────────
        if not user and not user_id:
            return await interaction.followup.send(
                embed=create_error_embed("Missing User", "Provide a `user` @mention or `user_id`."), ephemeral=True)
        if not user and user_id:
            try:
                user = await interaction.client.fetch_user(int(user_id))
            except Exception:
                return await interaction.followup.send(
                    embed=create_error_embed("User Not Found", f"No user with ID `{user_id}`."), ephemeral=True)

        # ── Resolve specs ─────────────────────────────────────────────────────
        if plan_name:
            pn     = plan_name.lower()
            search = [plan_type] if plan_type else ["premium", "free"]
            plan   = None
            for pt in search:
                plan = PLANS.get(pt, {}).get(pn)
                if plan: break
            if not plan:
                return await interaction.followup.send(
                    embed=create_error_embed("Invalid Plan", f"`{plan_name}` not found. Check `/plans`."), ephemeral=True)
            final_ram  = plan["ram"]
            final_cpu  = plan["cpu"]
            final_disk = plan["disk"]
            label      = f"{plan_name.title()} ({(plan_type or 'Free').title()})"
        else:
            if not all([ram_gb, cpu_cores, disk_gb]):
                return await interaction.followup.send(
                    embed=create_error_embed("Missing Specs", "Provide a `plan_name` OR `ram_gb`, `cpu_cores`, and `disk_gb`."),
                    ephemeral=True)
            final_ram  = ram_gb
            final_cpu  = cpu_cores
            final_disk = disk_gb
            label      = "Custom"

        # ── Enforce limits ────────────────────────────────────────────────────
        if ENFORCE_RESOURCE_LIMITS:
            if final_ram > MAX_RAM_LIMIT:
                return await interaction.followup.send(
                    embed=create_error_embed("Limit Exceeded", f"RAM **{final_ram}GB** exceeds server max **{MAX_RAM_LIMIT}GB**."),
                    ephemeral=True)
            if final_cpu > MAX_CPU_LIMIT:
                return await interaction.followup.send(
                    embed=create_error_embed("Limit Exceeded", f"CPU **{final_cpu}** cores exceeds server max **{MAX_CPU_LIMIT}**."),
                    ephemeral=True)

        validity = validity_days if validity_days and validity_days > 0 else None

        use_vm = (vm_mode == "kvm")

        embed = create_info_embed(
            "Step 1 — Select Node",
            f"**User:** {user.mention} | **Plan:** `{label}`\n"
            f"**Specs:** `{final_ram}GB RAM / {final_cpu} CPU / {final_disk}GB Disk`\n"
            f"**Type:** {'🖥️ KVM/QEMU VM' if use_vm else '📦 LXC Container'}\n\n"
            "Choose which node to deploy this VPS on:",
        )

        view = await NodeSelectView.create(
            invoker_id    = str(interaction.user.id),
            ram           = final_ram,
            cpu           = final_cpu,
            disk          = final_disk,
            target_user   = user,
            plan_name     = label,
            validity_days = validity,
            storage_pool  = ACTIVE_STORAGE_POOL,
            vm_mode       = use_vm,
        )
        await interaction.followup.send(embed=embed, view=view)


async def setup(bot):
    await bot.add_cog(CreateCog(bot))
