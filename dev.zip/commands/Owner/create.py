"""
/create — [ADMIN] Deploy a VPS for any user.
Flow: slash command → NodeSelectView → OSSelectView → deploy
"""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config   import MAIN_ADMIN_ID, ENFORCE_RESOURCE_LIMITS, MAX_RAM_LIMIT, MAX_CPU_LIMIT
from core.database import admin_data, vps_data, data_lock, get_db
from core.theme    import Theme, create_error_embed, create_info_embed, create_embed, add_field
from feature.plans import PLANS
from ui.node_select import NodeSelectView
from core import ACTIVE_STORAGE_POOL


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if int(uid) == int(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure("🚫 no_permission")
    return app_commands.check(predicate)


class CreateCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(
        name="create",
        description="[ADMIN] Deploy a new VPS for a user"
    )
    @app_commands.describe(
        user          = "Target user (@mention)",
        user_id       = "User ID — use if @mention fails",
        plan_name     = "Plan name from /plans (e.g. starter, pro)",
        plan_type     = "Plan type — Free or Premium",
        ram_gb        = "RAM in GB (ignored if plan_name given)",
        cpu_cores     = "CPU cores (ignored if plan_name given)",
        disk_gb       = "Disk in GB (ignored if plan_name given)",
        validity_days = "Expiry in days — 0 means no expiry",
        vm_mode       = "Container type — LXC (fast) or KVM (full VM)",
    )
    @app_commands.choices(plan_type=[
        app_commands.Choice(name="🆓 Free",    value="free"),
        app_commands.Choice(name="💎 Premium", value="premium"),
    ])
    @app_commands.choices(vm_mode=[
        app_commands.Choice(name="📦 LXC Container — fast, lightweight (default)", value="lxc"),
        app_commands.Choice(name="🖥️ KVM/QEMU VM — full virtualisation",           value="kvm"),
    ])
    @has_role("Owner", "Admin", "Dev")
    async def create_cmd(
        self,
        interaction:   discord.Interaction,
        user:          discord.Member = None,
        user_id:       str            = None,
        plan_name:     str            = None,
        plan_type:     str            = None,
        ram_gb:        int            = None,
        cpu_cores:     int            = None,
        disk_gb:       int            = None,
        validity_days: int            = 0,
        vm_mode:       str            = "lxc",
    ):
        await interaction.response.defer(ephemeral=True)

        # ── Resolve target user ───────────────────────────────────────────────
        if not user and not user_id:
            return await interaction.followup.send(embed=create_error_embed(
                "Missing User",
                "Provide a `user` @mention **or** a `user_id`.\n"
                "› Right-click the user → Copy ID for their user ID."
            ), ephemeral=True)

        if not user and user_id:
            try:
                user = await interaction.client.fetch_user(int(user_id))
            except Exception:
                return await interaction.followup.send(embed=create_error_embed(
                    "User Not Found",
                    f"No Discord user found with ID `{user_id}`.\n"
                    "Check the ID is correct and belongs to a real account."
                ), ephemeral=True)

        # ── Resolve specs ─────────────────────────────────────────────────────
        if plan_name:
            pn     = plan_name.strip().lower()
            search = [plan_type] if plan_type else ["premium", "free"]
            plan   = None
            for pt in search:
                plan = PLANS.get(pt, {}).get(pn)
                if plan: break
            if not plan:
                avail = ", ".join(f"`{k}`" for pt in PLANS for k in PLANS[pt])
                return await interaction.followup.send(embed=create_error_embed(
                    "Plan Not Found",
                    f"No plan named `{plan_name}`.\n\n"
                    f"**Available plans:** {avail or 'none configured'}\n"
                    "Use `/plans` to browse all plans."
                ), ephemeral=True)
            final_ram  = plan["ram"]
            final_cpu  = plan["cpu"]
            final_disk = plan["disk"]
            label      = f"{plan_name.title()} ({(plan_type or 'Free').title()})"
            plan_type  = plan_type or "free"
        else:
            missing = [n for n, v in [("ram_gb", ram_gb), ("cpu_cores", cpu_cores), ("disk_gb", disk_gb)] if not v]
            if missing:
                return await interaction.followup.send(embed=create_error_embed(
                    "Missing Specs",
                    f"Provide either a `plan_name` **or** all three custom specs.\n\n"
                    f"Missing: {', '.join(f'`{m}`' for m in missing)}"
                ), ephemeral=True)
            final_ram  = ram_gb
            final_cpu  = cpu_cores
            final_disk = disk_gb
            label      = "Custom"
            plan_type  = plan_type or "custom"

        # ── Enforce resource limits ───────────────────────────────────────────
        if ENFORCE_RESOURCE_LIMITS:
            if final_ram > MAX_RAM_LIMIT:
                return await interaction.followup.send(embed=create_error_embed(
                    "RAM Limit Exceeded",
                    f"Requested `{final_ram}GB` RAM exceeds the server limit of `{MAX_RAM_LIMIT}GB`.\n"
                    "Lower the RAM or raise the limit in `.env` (`MAX_RAM_LIMIT`)."
                ), ephemeral=True)
            if final_cpu > MAX_CPU_LIMIT:
                return await interaction.followup.send(embed=create_error_embed(
                    "CPU Limit Exceeded",
                    f"Requested `{final_cpu}` cores exceeds the server limit of `{MAX_CPU_LIMIT}`.\n"
                    "Lower the core count or raise the limit in `.env` (`MAX_CPU_LIMIT`)."
                ), ephemeral=True)

        validity = validity_days if validity_days and validity_days > 0 else None
        use_vm   = (vm_mode == "kvm")

        # ── Show existing VPS count for this user ─────────────────────────────
        async with data_lock:
            existing = len(vps_data.get(str(user.id), []))

        # ── Build step 1 embed ────────────────────────────────────────────────
        type_icon = "🖥️ KVM/QEMU VM" if use_vm else "📦 LXC Container"
        exp_text  = f"`{validity}` days" if validity else "No expiry"

        embed = discord.Embed(
            title="🚀 Deploy VPS — Step 1 of 2: Select Node",
            description=(
                "Choose which **node** (server) to deploy this VPS on.\n"
                "The node determines the physical location and available resources."
            ),
            color=Theme.PRIMARY,
            timestamp=datetime.now(),
        )
        embed.set_author(name="MoonNodes — VPS Deployment", icon_url="https://imgur.com/6yfYDTP.png")
        embed.add_field(name="👤 Owner",   value=user.mention,                  inline=True)
        embed.add_field(name="📋 Plan",    value=f"`{label}`",                  inline=True)
        embed.add_field(name="🏷️ Type",   value=type_icon,                     inline=True)
        embed.add_field(name="🧬 RAM",    value=f"`{final_ram}GB`",            inline=True)
        embed.add_field(name="💠 CPU",    value=f"`{final_cpu}` core(s)",      inline=True)
        embed.add_field(name="💾 Disk",   value=f"`{final_disk}GB`",           inline=True)
        embed.add_field(name="⏳ Expiry", value=exp_text,                       inline=True)
        embed.add_field(name="📦 Existing VPS", value=f"`{existing}` on record", inline=True)
        embed.set_footer(text="MoonNodes · Step 1 of 2 — Select a node to continue")

        view = await NodeSelectView.create(
            invoker_id    = str(interaction.user.id),
            ram           = final_ram,
            cpu           = final_cpu,
            disk          = final_disk,
            target_user   = user,
            plan_name     = label,
            validity_days = validity,
            storage_pool  = ACTIVE_STORAGE_POOL,
            vm_mode       = use_vm,
        )
        await interaction.followup.send(embed=embed, view=view)

        # ── Audit ─────────────────────────────────────────────────────────────
        try:
            from core.audit import audit
            await audit(
                interaction,
                action  = "VPS Created",
                target  = f"{user} (`{user.id}`)",
                details = f"Plan: {label} · {final_ram}GB RAM / {final_cpu} CPU / {final_disk}GB · Expiry: {exp_text}",
                color   = Theme.SUCCESS,
            )
        except Exception:
            pass


async def setup(bot):
    await bot.add_cog(CreateCog(bot))
