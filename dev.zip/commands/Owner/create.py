"""
/create  –  [OWNER/ADMIN] Force-create a VPS for a user.

NEW FLOW:
  1. Admin fills out the slash command (user, plan/specs, validity).
  2. A NodeSelectView dropdown appears — pick which node to deploy on.
  3. An OSSelectView dropdown appears — pick the OS.
  4. Deployment begins.
"""

import re
import discord
from discord import app_commands
from discord.ext import commands
from typing import Optional

from core.config import MAIN_ADMIN_ID, ENFORCE_RESOURCE_LIMITS, MAX_RAM_LIMIT, MAX_CPU_LIMIT
from core.database import admin_data
from core.theme import create_embed, create_error_embed, create_info_embed
from feature.plans import PLANS
from ui.node_select import NodeSelectView

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
from core import ACTIVE_STORAGE_POOL


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if uid == str(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure(f"Required role: {', '.join(roles)}")
    return app_commands.check(predicate)


class CreateCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="create", description="[ADMIN] Deploy a VPS for a user – choose node then OS")
    @app_commands.describe(
        user           = "Discord user — @mention them in the server",
        user_id        = "Paste their Discord User ID if @mention doesn't work",
        plan_name      = "Plan name (e.g. basic, starter) — overrides manual specs",
        ram_gb         = "RAM in GB",
        cpu_cores      = "CPU cores",
        disk_gb        = "Disk size in GB",
        validity_days  = "Expiry in days (0 = permanent)",
    )
    @has_role("Owner", "Admin", "Dev")
    async def create_cmd(
        self,
        interaction: discord.Interaction,
        user: discord.Member = None,
        plan_name: str = None,
        ram_gb: int = None,
        cpu_cores: int = None,
        disk_gb: int = None,
        validity_days: int = 0,
        user_id: str = None,
    ):
        await interaction.response.defer(ephemeral=True)

        # Resolve user — try @mention first, then user_id fallback
        if not user and not user_id:
            return await interaction.followup.send(
                embed=create_error_embed("Missing User", "Provide a `user` @mention or `user_id` (Discord numeric ID)."),
                ephemeral=True,
            )
        if not user and user_id:
            try:
                user = await interaction.client.fetch_user(int(user_id))
                # Wrap as pseudo-member for display
                user.display_name = user.name
            except Exception:
                return await interaction.followup.send(
                    embed=create_error_embed("User Not Found", f"Could not find user with ID `{user_id}`."),
                    ephemeral=True,
                )

        # Resolve specs from plan or manual input
        if plan_name:
            p_name = plan_name.lower()
            plan   = PLANS.get("premium", {}).get(p_name) or PLANS.get("free", {}).get(p_name)
            if not plan:
                return await interaction.followup.send(
                    embed=create_error_embed("Invalid Plan", f"Plan `{plan_name}` not found. Check `/plans`."),
                    ephemeral=True,
                )
            final_ram  = plan["ram"]
            final_cpu  = plan["cpu"]
            final_disk = plan["disk"]
            label      = plan_name.title()
        else:
            if not all([ram_gb, cpu_cores, disk_gb]):
                return await interaction.followup.send(
                    embed=create_error_embed("Error", "Provide either a `plan_name` OR manual `ram_gb`, `cpu_cores`, `disk_gb`."),
                    ephemeral=True,
                )
            final_ram  = ram_gb
            final_cpu  = cpu_cores
            final_disk = disk_gb
            label      = "Custom"

        # Enforce limits
        if ENFORCE_RESOURCE_LIMITS:
            if final_ram > MAX_RAM_LIMIT:
                return await interaction.followup.send(
                    embed=create_error_embed("Limit Exceeded", f"RAM {final_ram}GB exceeds server max {MAX_RAM_LIMIT}GB."),
                    ephemeral=True,
                )
            if final_cpu > MAX_CPU_LIMIT:
                return await interaction.followup.send(
                    embed=create_error_embed("Limit Exceeded", f"CPU {final_cpu} cores exceeds server max {MAX_CPU_LIMIT}."),
                    ephemeral=True,
                )

        validity = validity_days if validity_days and validity_days > 0 else None

        embed = create_info_embed(
            "Step 1 – Select Node",
            f"**User:** {user.mention} | **Plan:** {label}\n"
            f"**Specs:** `{final_ram}GB RAM / {final_cpu} CPU / {final_disk}GB Disk`\n\n"
            f"Choose which node to deploy this VPS on:",
        )

        # Build NodeSelectView (async, fetches live node stats)
        view = await NodeSelectView.create(
            invoker_id   = str(interaction.user.id),
            ram          = final_ram,
            cpu          = final_cpu,
            disk         = final_disk,
            target_user  = user,
            plan_name    = label,
            validity_days= validity,
            storage_pool = ACTIVE_STORAGE_POOL,
        )

        await interaction.followup.send(embed=embed, view=view)


async def setup(bot):
    await bot.add_cog(CreateCog(bot))
