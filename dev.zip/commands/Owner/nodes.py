"""
/node  —  [ADMIN] Node management command group.

Subcommands:
  /node list                     — List all configured nodes
  /node status [node_id]         — Live resource stats for a node
  /node create                   — Register a new LXD remote node
  /node edit <node_id>           — Edit a node's connection details
  /node delete <node_id>         — Remove a node from the cluster
  /node migrate <vps> <to_node>  — Migrate a VPS to another node
  /lxc-list [node_id]            — List raw LXC containers on a node
"""

import discord
from discord import app_commands
from discord.ext import commands

from core.config import MULTI_NODE, MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock, save_vps_data, get_db, set_setting, get_setting
from core.lxc import list_lxd_remotes, get_node_stats, execute_lxc
from core.theme import (
    create_embed, create_success_embed, create_error_embed,
    create_info_embed, create_warning_embed, add_field, Theme,
)


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if uid == str(MAIN_ADMIN_ID):
            return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles:
            return True
        raise app_commands.CheckFailure(f"Required role: {', '.join(roles)}")
    return app_commands.check(predicate)


def _get_node_list() -> list:
    raw = get_setting("registered_nodes") or ""
    extras = [n.strip() for n in raw.split(",") if n.strip()]
    return ["local"] + extras


def _save_node_list(nodes: list):
    extras = [n for n in nodes if n != "local"]
    set_setting("registered_nodes", ",".join(extras))


class NodeCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    node_group = app_commands.Group(
        name="node",
        description="[ADMIN] Node cluster management",
    )

    # /node list
    @node_group.command(name="list", description="[ADMIN] List all registered nodes in the cluster")
    @has_role("Owner", "Admin")
    async def node_list(self, interaction: discord.Interaction):
        await interaction.response.defer()
        nodes = _get_node_list()
        embed = create_embed("🌐 Registered Nodes", f"**{len(nodes)}** node(s) in your cluster.")
        for i, node in enumerate(nodes):
            icon = "🏠" if node == "local" else "🌐"
            host = get_setting(f"node_host_{node}") or "localhost"
            port = get_setting(f"node_port_{node}") or "—"
            add_field(embed, f"{icon} #{i+1} — `{node}`",
                      f"Host: `{host}`\nPort: `{port}`" if node != "local" else "Local host machine",
                      inline=True)
        embed.set_footer(text="Use /node status to check live stats · /node create to add a node")
        await interaction.followup.send(embed=embed)

    # /node status
    @node_group.command(name="status", description="[ADMIN] View live resource stats for a node (leave blank for all)")
    @app_commands.describe(node_id="Node number from /node list (leave blank for all)")
    @has_role("Owner", "Admin")
    async def node_status(self, interaction: discord.Interaction, node_id: int = None):
        await interaction.response.defer()
        all_nodes = _get_node_list()

        if node_id is not None:
            if node_id < 1 or node_id > len(all_nodes):
                return await interaction.followup.send(
                    embed=create_error_embed("Invalid Node", f"Node #{node_id} not found. Use `/node list`."),
                    ephemeral=True,
                )
            nodes_to_check = [all_nodes[node_id - 1]]
            title = f"📡 Node #{node_id} — `{nodes_to_check[0]}`"
        else:
            nodes_to_check = all_nodes
            title = f"🌐 Cluster Overview — {len(nodes_to_check)} node(s)"

        embed = create_embed(title, "")
        for node in nodes_to_check:
            stats = await get_node_stats(node)
            ram_pct   = stats["ram_pct"]
            cpu_pct   = stats["cpu_pct"]
            disk_pct  = stats["disk_pct"]
            cpu_cores = stats["cpu_cores"]
            ram_used  = stats["used_ram_mb"]
            ram_total = stats["total_ram_mb"]
            disk_used = stats["used_disk_gb"]
            disk_total= stats["total_disk_gb"]
            vps_total = stats["vps_count"]
            vps_run   = stats["vps_running"]

            ram_bar  = Theme.progress_bar(ram_pct,  size=10)
            cpu_bar  = Theme.progress_bar(cpu_pct,  size=10)
            disk_bar = Theme.progress_bar(disk_pct, size=10)
            ram_line  = f"{ram_bar}\n`{ram_used} MB / {ram_total} MB`" if ram_total  > 0 else "`N/A`"
            disk_line = f"{disk_bar}\n`{disk_used} GB / {disk_total} GB`" if disk_total > 0 else "`N/A`"

            icon = "🏠" if node == "local" else "🌐"
            value = (
                f"**Status:** 🟢 Online\n"
                f"\n{Theme.CPU} **CPU** ({cpu_cores} cores)\n{cpu_bar} `{cpu_pct:.1f}%`\n"
                f"\n{Theme.RAM} **RAM**\n{ram_line}\n"
                f"\n{Theme.DISK} **Disk**\n{disk_line}\n"
                f"\n🖥️ **VPS:** `{vps_run} running / {vps_total} total`"
            )
            add_field(embed, f"{icon} Node: `{node}`", value, inline=False)

        await interaction.followup.send(embed=embed)

    # /node create
    @node_group.command(name="create", description="[OWNER] Register a new LXD remote node")
    @app_commands.describe(
        name="Unique name for this node (e.g. node-us-1)",
        host="Node hostname or IP address",
        port="LXD API port (default: 8443)",
    )
    @has_role("Owner")
    async def node_create(self, interaction: discord.Interaction, name: str, host: str, port: int = 8443):
        await interaction.response.defer(ephemeral=True)
        nodes = _get_node_list()
        if name in nodes:
            return await interaction.followup.send(embed=create_error_embed("Duplicate", f"A node named `{name}` already exists."))
        if name == "local":
            return await interaction.followup.send(embed=create_error_embed("Reserved", "`local` is reserved for the host machine."))

        set_setting(f"node_host_{name}", host)
        set_setting(f"node_port_{name}", str(port))
        nodes.append(name)
        _save_node_list(nodes)

        try:
            await execute_lxc(f"lxc remote add {name} https://{host}:{port} --accept-certificate --auth-type tls")
            lxd_status = "✅ LXD remote configured successfully"
        except Exception as e:
            lxd_status = f"⚠️ Registered, but LXD remote setup failed:\n`{str(e)[:300]}`\nRun manually:\n`lxc remote add {name} https://{host}:{port} --accept-certificate`"

        embed = create_success_embed("Node Created", f"Node **{name}** registered as Node #{len(nodes)}.")
        add_field(embed, "Host",   host,      True)
        add_field(embed, "Port",   str(port), True)
        add_field(embed, "LXD Remote Setup", lxd_status, False)
        await interaction.followup.send(embed=embed)

    # /node edit
    @node_group.command(name="edit", description="[OWNER] Edit a node's connection details")
    @app_commands.describe(
        node_id="Node number from /node list",
        new_name="New name (leave blank to keep current)",
        new_host="New hostname or IP",
        new_port="New LXD API port",
    )
    @has_role("Owner")
    async def node_edit(self, interaction: discord.Interaction, node_id: int, new_name: str = None, new_host: str = None, new_port: int = None):
        await interaction.response.defer(ephemeral=True)
        nodes = _get_node_list()
        if node_id < 1 or node_id > len(nodes):
            return await interaction.followup.send(embed=create_error_embed("Invalid Node", f"Node #{node_id} not found."))
        current = nodes[node_id - 1]
        if current == "local":
            return await interaction.followup.send(embed=create_error_embed("Protected", "The local node cannot be edited."))

        host = new_host or (get_setting(f"node_host_{current}") or "unknown")
        port = new_port or int(get_setting(f"node_port_{current}") or "8443")

        if new_name and new_name != current:
            set_setting(f"node_host_{new_name}", host)
            set_setting(f"node_port_{new_name}", str(port))
            nodes[node_id - 1] = new_name
            _save_node_list(nodes)
            display = new_name
        else:
            set_setting(f"node_host_{current}", host)
            set_setting(f"node_port_{current}", str(port))
            display = current

        embed = create_success_embed("Node Updated", f"Node **{display}** updated.")
        add_field(embed, "Host", host,      True)
        add_field(embed, "Port", str(port), True)
        await interaction.followup.send(embed=embed)

    # /node delete
    @node_group.command(name="delete", description="[OWNER] Remove a node from the cluster")
    @app_commands.describe(node_id="Node number from /node list")
    @has_role("Owner")
    async def node_delete(self, interaction: discord.Interaction, node_id: int):
        await interaction.response.defer(ephemeral=True)
        nodes = _get_node_list()
        if node_id < 1 or node_id > len(nodes):
            return await interaction.followup.send(embed=create_error_embed("Invalid Node", f"Node #{node_id} not found."))
        target = nodes[node_id - 1]
        if target == "local":
            return await interaction.followup.send(embed=create_error_embed("Protected", "The local node cannot be deleted."))

        vps_on_node = []
        with data_lock:
            for uid, lst in vps_data.items():
                for v in lst:
                    if v.get("node") == target:
                        vps_on_node.append(v["container_name"])
        if vps_on_node:
            return await interaction.followup.send(
                embed=create_error_embed("Node In Use",
                    f"Cannot delete `{target}` — it still hosts **{len(vps_on_node)}** VPS: " +
                    ", ".join(f"`{n}`" for n in vps_on_node[:10]))
            )

        nodes.remove(target)
        _save_node_list(nodes)
        try:
            await execute_lxc(f"lxc remote remove {target}")
        except Exception:
            pass

        await interaction.followup.send(embed=create_success_embed("Node Deleted", f"Node **{target}** removed from the cluster."))

    # /node migrate
    @node_group.command(name="migrate", description="[ADMIN] Migrate a VPS container to another node")
    @app_commands.describe(vps_name="Container name to migrate", to_node="Destination node name")
    @has_role("Owner", "Admin")
    async def node_migrate(self, interaction: discord.Interaction, vps_name: str, to_node: str):
        await interaction.response.defer(ephemeral=True)
        nodes = _get_node_list()
        if to_node not in nodes:
            return await interaction.followup.send(embed=create_error_embed("Unknown Node", f"`{to_node}` is not registered. Use `/node list`."))

        found_vps = None
        with data_lock:
            for uid, lst in vps_data.items():
                for v in lst:
                    if v["container_name"] == vps_name:
                        found_vps = v
                        break

        if not found_vps:
            return await interaction.followup.send(embed=create_error_embed("Not Found", f"No VPS named `{vps_name}` in the database."))

        from_node   = found_vps.get("node", "local")
        prefix_from = f"{from_node}:" if from_node != "local" else ""
        full_from   = f"{prefix_from}{vps_name}"
        full_to     = f"{to_node}:{vps_name}"

        await interaction.followup.send(embed=create_info_embed("Migrating…", f"Moving `{vps_name}` from `{from_node}` → `{to_node}`. This may take several minutes."))

        try:
            await execute_lxc(f"lxc stop {full_from}", timeout=60)
            await execute_lxc(f"lxc move {full_from} {full_to}", timeout=600)
            await execute_lxc(f"lxc start {full_to}", timeout=60)
            with data_lock:
                found_vps["node"]   = to_node
                found_vps["status"] = "running"
            save_vps_data()
            embed = create_success_embed("Migration Complete", f"`{vps_name}` is now on **{to_node}**.")
            add_field(embed, "From", from_node, True)
            add_field(embed, "To",   to_node,   True)
            await interaction.followup.send(embed=embed)
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Migration Failed", str(e)[:4000]))

    # /lxc-list (standalone, not a subcommand of /node)
    @app_commands.command(name="lxc-list", description="[ADMIN] List raw LXC containers on a node")
    @app_commands.describe(node_id="Node number from /node list (default: 1 = local)")
    @has_role("Owner", "Admin")
    async def lxc_list(self, interaction: discord.Interaction, node_id: int = 1):
        await interaction.response.defer(ephemeral=True)
        nodes = _get_node_list()
        if node_id < 1 or node_id > len(nodes):
            return await interaction.followup.send(embed=create_error_embed("Invalid Node", f"Node #{node_id} not found. Use `/node list`."))
        target = nodes[node_id - 1]
        prefix = f"{target}:" if target != "local" else ""

        try:
            raw = await execute_lxc(f"lxc list {prefix}--format=csv")
            if not raw:
                return await interaction.followup.send(embed=create_info_embed(f"Node: `{target}`", "No containers found."))
            lines = raw.strip().splitlines()
            rows  = []
            for line in lines:
                parts  = line.split(",")
                name   = parts[0] if len(parts) > 0 else "?"
                status = parts[1] if len(parts) > 1 else "?"
                ipv4   = parts[2] if len(parts) > 2 else "—"
                rows.append(f"`{name}` — **{status.upper()}** — `{ipv4}`")
            text = "\n".join(rows[:30])
            if len(rows) > 30:
                text += f"\n…and {len(rows) - 30} more"
            embed = create_embed(f"🖥️ LXC Containers on `{target}`", f"**{len(rows)}** container(s)\n\n{text}")
            await interaction.followup.send(embed=embed)
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Error", str(e)[:4000]))


async def setup(bot):
    cog = NodeCog(bot)
    await bot.add_cog(cog)
    bot.tree.add_command(cog.node_group)
