"""
/node pick_one: [option: node_id: name: host: port: vps_name: to_node:]

Single slash command for all node management operations.
"""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock, save_vps_data, set_setting, get_setting
from core.lxc import list_lxd_remotes, get_node_stats, execute_lxc
from core.theme import Theme, add_field, create_embed, create_error_embed, create_info_embed, create_loading_embed, create_success_embed, create_warning_embed


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if uid == str(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure(f"Required: {', '.join(roles)}")
    return app_commands.check(predicate)


def _get_nodes() -> list:
    raw    = get_setting("registered_nodes") or ""
    extras = [n.strip() for n in raw.split(",") if n.strip()]
    return ["local"] + extras


def _save_nodes(nodes: list):
    set_setting("registered_nodes", ",".join(n for n in nodes if n != "local"))


# ── Modals ────────────────────────────────────────────────────────────────────

class NodeCreateModal(discord.ui.Modal, title="➕  Register New Node"):
    n_name = discord.ui.TextInput(label="Node Name",       placeholder="e.g. node-us-1", max_length=32)
    n_host = discord.ui.TextInput(label="Host / IP",       placeholder="e.g. 192.168.1.10")
    n_port = discord.ui.TextInput(label="LXD/Incus Port",  default="8443", max_length=6)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        name = self.n_name.value.strip()
        host = self.n_host.value.strip()
        port = int(self.n_port.value.strip()) if self.n_port.value.strip().isdigit() else 8443

        nodes = _get_nodes()
        if name in nodes:
            return await interaction.followup.send(embed=create_error_embed("Duplicate", f"`{name}` already registered."))
        if name == "local":
            return await interaction.followup.send(embed=create_error_embed("Reserved", "`local` is reserved."))

        set_setting(f"node_host_{name}", host)
        set_setting(f"node_port_{name}", str(port))
        nodes.append(name)
        _save_nodes(nodes)

        try:
            await execute_lxc(f"lxc remote add {name} https://{host}:{port} --accept-certificate --auth-type tls")
            lxd_msg = "✅ Remote configured automatically"
        except Exception as e:
            lxd_msg = (f"⚠️ Registered, but auto-setup failed.\nRun manually:\n"
                       f"`lxc remote add {name} https://{host}:{port} --accept-certificate`\n"
                       f"`{str(e)[:200]}`")

        embed = create_success_embed(f"Node Created — #{len(nodes)}", f"**{name}** added to the cluster.")
        add_field(embed, "🌐 Host", host,      True)
        add_field(embed, "🔌 Port", str(port), True)
        add_field(embed, "🔗 LXD Remote", lxd_msg, False)
        await interaction.followup.send(embed=embed)


class NodeEditModal(discord.ui.Modal, title="✏️  Edit Node"):
    new_name = discord.ui.TextInput(label="New Name (blank = keep)",  required=False, max_length=32)
    new_host = discord.ui.TextInput(label="New Host (blank = keep)",  required=False)
    new_port = discord.ui.TextInput(label="New Port (blank = keep)",  required=False, max_length=6)

    def __init__(self, node_id: int, current: str):
        super().__init__()
        self.node_id = node_id
        self.current = current

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        nodes    = _get_nodes()
        old_host = get_setting(f"node_host_{self.current}") or ""
        old_port = get_setting(f"node_port_{self.current}") or "8443"
        n_name   = self.new_name.value.strip() or self.current
        n_host   = self.new_host.value.strip() or old_host
        n_port   = self.new_port.value.strip() or old_port

        set_setting(f"node_host_{n_name}", n_host)
        set_setting(f"node_port_{n_name}", n_port)
        if n_name != self.current:
            nodes[self.node_id - 1] = n_name
            _save_nodes(nodes)

        embed = create_success_embed("Node Updated ✅", f"Node **{n_name}** saved.")
        add_field(embed, "Host", n_host, True)
        add_field(embed, "Port", n_port, True)
        await interaction.followup.send(embed=embed)


class NodeMigrateModal(discord.ui.Modal, title="🚀  Migrate VPS"):
    vps_name = discord.ui.TextInput(label="Container Name",     placeholder="vps-12345-1")
    to_node  = discord.ui.TextInput(label="Destination Node",   placeholder="node-us-1")

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        vps  = self.vps_name.value.strip()
        dest = self.to_node.value.strip()
        nodes = _get_nodes()
        if dest not in nodes:
            return await interaction.followup.send(
                embed=create_error_embed("Unknown Node", f"`{dest}` not registered. Use `/node pick_one:List`."))

        found = None
        with data_lock:
            for uid, lst in vps_data.items():
                for v in lst:
                    if v["container_name"] == vps:
                        found = v; break

        if not found:
            return await interaction.followup.send(
                embed=create_error_embed("Not Found", f"No VPS `{vps}` in the database."))

        src    = found.get("node", "local")
        f_from = f"{src}:{vps}" if src != "local" else vps
        f_to   = f"{dest}:{vps}"

        await interaction.followup.send(
            embed=create_info_embed("Migrating…", f"`{vps}` → **{dest}**. This may take several minutes."))
        try:
            await execute_lxc(f"lxc stop {f_from}", timeout=60)
            await execute_lxc(f"lxc move {f_from} {f_to}", timeout=600)
            await execute_lxc(f"lxc start {f_to}", timeout=60)
            with data_lock:
                found["node"]   = dest
                found["status"] = "running"
            save_vps_data()
            embed = create_success_embed("Migration Complete 🎉", f"`{vps}` is now live on **{dest}**.")
            add_field(embed, "From", src,  True)
            add_field(embed, "To",   dest, True)
            await interaction.followup.send(embed=embed)
        except Exception as e:
            await interaction.followup.send(
                embed=create_error_embed("Migration Failed", str(e)[:2000]))


# ── Main /node command ────────────────────────────────────────────────────────

class NodeCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="node", description="[ADMIN] Manage the LXD/Incus node cluster")
    @app_commands.choices(pick_one=[
        app_commands.Choice(name="📋 List — Show all registered nodes",           value="list"),
        app_commands.Choice(name="📡 Status — Live CPU, RAM and Disk per node",   value="status"),
        app_commands.Choice(name="➕ Create — Register a new LXD/Incus node",    value="create"),
        app_commands.Choice(name="✏️ Edit — Change a node's host or port",        value="edit"),
        app_commands.Choice(name="🗑️ Delete — Remove a node from the cluster",    value="delete"),
        app_commands.Choice(name="🚀 Migrate — Move a VPS between nodes",        value="migrate"),
    ])
    @app_commands.describe(
        pick_one = "Action to perform",
        option   = "Node ID (for Status/Edit/Delete) or leave blank for all",
        name     = "Node name (Create only)",
        host     = "Host/IP address (Create only)",
        port     = "LXD/Incus API port (Create only, default 8443)",
        vps_name = "Container name to migrate (Migrate only)",
        to_node  = "Destination node name (Migrate only)",
    )
    @has_role("Owner", "Admin")
    async def node_cmd(
        self, interaction: discord.Interaction,
        pick_one: str,
        option: int   = None,    # node_id for status/edit/delete
        name: str     = None,
        host: str     = None,
        port: int     = 8443,
        vps_name: str = None,
        to_node: str  = None,
    ):
        uid = str(interaction.user.id)
        is_owner = (uid == str(MAIN_ADMIN_ID) or admin_data.get(uid) == "Owner")

        # ── LIST ─────────────────────────────────────────────────────────────
        if pick_one == "list":
            await interaction.response.defer()
            nodes = _get_nodes()
            embed = discord.Embed(
                title="🌐  Node Cluster",
                description=(
                    f"{Theme.DIVIDER}\n"
                    f"**{len(nodes)}** registered node(s)\n"
                    f"{Theme.DIVIDER}"
                ),
                color=Theme.PRIMARY, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
            for i, node in enumerate(nodes):
                icon = "🏠" if node == "local" else "🌐"
                h    = get_setting(f"node_host_{node}") or "localhost"
                p    = get_setting(f"node_port_{node}") or "—"
                info = "Local host machine" if node == "local" else f"`{h}:{p}`"
                embed.add_field(name=f"{icon}  #{i+1} — `{node}`", value=info, inline=True)
            embed.set_footer(text="Use /node pick_one:Status to see live stats")
            return await interaction.followup.send(embed=embed)

        # ── STATUS ───────────────────────────────────────────────────────────
        elif pick_one == "status":
            await interaction.response.defer()
            all_nodes = _get_nodes()
            targets   = [all_nodes[option - 1]] if option and 1 <= option <= len(all_nodes) else all_nodes

            embed = discord.Embed(
                title="📡  Cluster Status" if not option else f"📡  Node #{option}",
                description=f"{Theme.DIVIDER}\nLive resource snapshot\n{Theme.DIVIDER}",
                color=Theme.PRIMARY, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")

            for node in targets:
                s    = await get_node_stats(node)
                c_b  = Theme.progress_bar(s["cpu_pct"])
                r_b  = Theme.progress_bar(s["ram_pct"])
                d_b  = Theme.progress_bar(s["disk_pct"])
                icon = "🏠" if node == "local" else "🌐"
                val  = (
                    f"🟢 **Online**\n\n"
                    f"{Theme.CPU} **CPU** ({s['cpu_cores']} cores)\n{c_b}\n\n"
                    f"{Theme.RAM} **RAM** — `{s['used_ram_mb']} / {s['total_ram_mb']} MB`\n{r_b}\n\n"
                    f"{Theme.DISK} **Disk** — `{s['used_disk_gb']} / {s['total_disk_gb']} GB`\n{d_b}\n\n"
                    f"🖥️ **VPS** `{s['vps_running']} running / {s['vps_count']} total`"
                )
                embed.add_field(name=f"{icon}  `{node}`", value=val, inline=True)
            return await interaction.followup.send(embed=embed)

        # ── CREATE ───────────────────────────────────────────────────────────
        elif pick_one == "create":
            if not is_owner:
                return await interaction.response.send_message(
                    embed=create_error_embed("Owner Only", "Only Owners can register new nodes."), ephemeral=True)
            # If name+host provided directly, skip modal
            if name and host:
                await interaction.response.defer(ephemeral=True)
                nodes = _get_nodes()
                if name in nodes:
                    return await interaction.followup.send(embed=create_error_embed("Duplicate", f"`{name}` already exists."))
                set_setting(f"node_host_{name}", host)
                set_setting(f"node_port_{name}", str(port))
                nodes.append(name)
                _save_nodes(nodes)
                try:
                    await execute_lxc(f"lxc remote add {name} https://{host}:{port} --accept-certificate --auth-type tls")
                    lxd_msg = "✅ Remote configured"
                except Exception as e:
                    lxd_msg = f"⚠️ Registered. Run manually:\n`lxc remote add {name} https://{host}:{port} --accept-certificate`"
                embed = create_success_embed(f"Node Created — #{len(nodes)}", f"**{name}** added.")
                add_field(embed, "Host", host, True)
                add_field(embed, "Port", str(port), True)
                add_field(embed, "Remote", lxd_msg, False)
                return await interaction.followup.send(embed=embed)
            # Open modal if no params
            return await interaction.response.send_modal(NodeCreateModal())

        # ── EDIT ─────────────────────────────────────────────────────────────
        elif pick_one == "edit":
            if not is_owner:
                return await interaction.response.send_message(
                    embed=create_error_embed("Owner Only", "Only Owners can edit nodes."), ephemeral=True)
            nodes = _get_nodes()
            nid   = option or 0
            if not nid or nid < 1 or nid > len(nodes):
                return await interaction.response.send_message(
                    embed=create_error_embed("Missing", "Provide `option` = node ID (from `/node pick_one:List`)."), ephemeral=True)
            current = nodes[nid - 1]
            if current == "local":
                return await interaction.response.send_message(
                    embed=create_error_embed("Protected", "The local node cannot be edited."), ephemeral=True)
            return await interaction.response.send_modal(NodeEditModal(nid, current))

        # ── DELETE ───────────────────────────────────────────────────────────
        elif pick_one == "delete":
            if not is_owner:
                return await interaction.response.send_message(
                    embed=create_error_embed("Owner Only", "Only Owners can delete nodes."), ephemeral=True)
            await interaction.response.defer(ephemeral=True)
            nodes = _get_nodes()
            nid   = option or 0
            if not nid or nid < 1 or nid > len(nodes):
                return await interaction.followup.send(
                    embed=create_error_embed("Missing", "Provide `option` = node ID (from `/node pick_one:List`)."))
            target = nodes[nid - 1]
            if target == "local":
                return await interaction.followup.send(embed=create_error_embed("Protected", "Cannot delete the local node."))

            # Check no VPS on this node
            in_use = []
            with data_lock:
                for uid2, lst in vps_data.items():
                    for v in lst:
                        if v.get("node") == target:
                            in_use.append(v["container_name"])
            if in_use:
                return await interaction.followup.send(
                    embed=create_error_embed("In Use",
                        f"`{target}` still hosts **{len(in_use)}** VPS.\nMigrate them first with `/node pick_one:Migrate`."))

            nodes.remove(target)
            _save_nodes(nodes)
            try:
                await execute_lxc(f"lxc remote remove {target}")
            except Exception:
                pass
            return await interaction.followup.send(
                embed=create_success_embed("Node Deleted", f"**{target}** removed from the cluster."))

        # ── MIGRATE ──────────────────────────────────────────────────────────
        elif pick_one == "migrate":
            # If both params provided, skip modal
            if vps_name and to_node:
                await interaction.response.defer(ephemeral=True)
                nodes = _get_nodes()
                if to_node not in nodes:
                    return await interaction.followup.send(
                        embed=create_error_embed("Unknown Node", f"`{to_node}` not registered."))
                found = None
                with data_lock:
                    for uid2, lst in vps_data.items():
                        for v in lst:
                            if v["container_name"] == vps_name:
                                found = v; break
                if not found:
                    return await interaction.followup.send(
                        embed=create_error_embed("Not Found", f"No VPS `{vps_name}` in DB."))
                src    = found.get("node", "local")
                f_from = f"{src}:{vps_name}" if src != "local" else vps_name
                f_to   = f"{to_node}:{vps_name}"
                await interaction.followup.send(
                    embed=create_info_embed("Migrating…", f"`{vps_name}` → **{to_node}**"))
                try:
                    await execute_lxc(f"lxc stop {f_from}", timeout=60)
                    await execute_lxc(f"lxc move {f_from} {f_to}", timeout=600)
                    await execute_lxc(f"lxc start {f_to}", timeout=60)
                    with data_lock:
                        found["node"]   = to_node
                        found["status"] = "running"
                    save_vps_data()
                    embed = create_success_embed("Migration Complete 🎉", f"`{vps_name}` → **{to_node}**")
                    add_field(embed, "From", src,     True)
                    add_field(embed, "To",   to_node, True)
                    return await interaction.followup.send(embed=embed)
                except Exception as e:
                    return await interaction.followup.send(
                        embed=create_error_embed("Failed", str(e)[:2000]))
            # Open modal
            return await interaction.response.send_modal(NodeMigrateModal())


async def setup(bot):
    await bot.add_cog(NodeCog(bot))