"""
/node — Manage the LXD/Incus node cluster.

Multi-Node connection uses API keys (tokens) — no IP needed separately.

How to get your API key:
  Incus:  incus config trust add --name moonbot   (outputs a full token URL)
  LXD:    lxc config trust add --name moonbot     (outputs a token)

Then register the node:
  /node pick_one:Create  runtime:incus  name:node2  api_key:<token>
"""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MAIN_ADMIN_ID
from core.database import (
    admin_data, vps_data, data_lock,
    async_save_vps_data, set_setting, get_setting,
)
from core.lxc import list_lxd_remotes, get_node_stats, execute_lxc, RUNTIME
from core.theme import (
    Theme, add_field, create_embed, create_error_embed,
    create_info_embed, create_success_embed, create_warning_embed,
)


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if int(uid) == int(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure("🚫 no_permission")
    return app_commands.check(predicate)


def _get_nodes() -> list:
    raw    = get_setting("registered_nodes") or ""
    extras = [n.strip() for n in raw.split(",") if n.strip()]
    return ["local"] + extras


def _save_nodes(nodes: list):
    set_setting("registered_nodes", ",".join(n for n in nodes if n != "local"))


async def _add_remote(name: str, api_key: str, runtime: str = None) -> str:
    """
    Register a remote node using an API key token.

    Incus token URL:  incus remote add NAME TOKEN_URL
    LXD token:        lxc remote add NAME TOKEN
    Both accept the token directly — no separate IP needed.
    """
    rt = runtime or RUNTIME
    try:
        cmd = f"lxc remote add {name} {api_key} --accept-certificate"
        await execute_lxc(cmd)
        return "✅ Remote registered successfully via API key"
    except Exception as e:
        return (
            f"⚠️ Could not auto-register. Run manually:\n"
            f"```bash\n{rt} remote add {name} {api_key}\n```\n"
            f"Error: `{str(e)[:200]}`"
        )


# ── Modals ─────────────────────────────────────────────────────────────────────

class NodeCreateModal(discord.ui.Modal, title="➕  Register New Node"):
    n_name    = discord.ui.TextInput(label="Node Name",      placeholder="e.g. node-us-1", max_length=32)
    n_api_key = discord.ui.TextInput(label="API Key / Token", placeholder="Token from: incus config trust add --name moonbot", max_length=512)
    n_runtime = discord.ui.TextInput(label="Runtime (incus or lxc)", default="incus", max_length=8)
    n_section = discord.ui.TextInput(
        label="Section (all / free / premium)",
        placeholder="all = everyone | free = MoonCoin/Invite | premium = Premium users",
        default="all", max_length=16, required=False,
    )

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        name    = self.n_name.value.strip().lower().replace(" ", "-")
        api_key = self.n_api_key.value.strip()
        runtime = self.n_runtime.value.strip().lower() or RUNTIME
        section = (self.n_section.value.strip().lower() or "all")
        if section not in ("all","free","premium"):
            section = "all"

        nodes = _get_nodes()
        if name in nodes:
            return await interaction.followup.send(embed=create_error_embed("Duplicate", f"`{name}` is already registered."))
        if name == "local":
            return await interaction.followup.send(embed=create_error_embed("Reserved", "`local` is a reserved name."))

        set_setting(f"node_api_key_{name}", api_key)
        set_setting(f"node_runtime_{name}", runtime)
        set_setting(f"node_section_{name}", section)
        nodes.append(name)
        _save_nodes(nodes)

        result = await _add_remote(name, api_key, runtime)

        section_icons = {"all": "🌐 All Users", "free": "🌙 MoonCoin & Invite & Giveaway", "premium": "💎 Premium Users Only"}
        embed = create_success_embed(f"✅ Node Registered — `{name}`", f"**{name}** added to the cluster.")
        add_field(embed, "🔑 API Key", f"`{api_key[:40]}…`" if len(api_key) > 40 else f"`{api_key}`", False)
        add_field(embed, "⚙️ Runtime", runtime.upper(), True)
        add_field(embed, "🔒 Section", section_icons.get(section, section), True)
        add_field(embed, "🔗 Remote Status", result, False)
        add_field(embed, "📋 How to get the token",
            f"Run on the **remote node**:\n```bash\n{runtime} config trust add --name moonbot\n```\nPaste the output token here.",
            False)
        await interaction.followup.send(embed=embed)


class NodeEditModal(discord.ui.Modal, title="✏️  Edit Node"):
    new_name    = discord.ui.TextInput(label="New Name (blank = keep)",    required=False, max_length=32)
    new_api_key = discord.ui.TextInput(label="New API Key (blank = keep)", required=False, max_length=512)

    def __init__(self, node_id: int, current: str):
        super().__init__()
        self.node_id = node_id
        self.current = current

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        nodes    = _get_nodes()
        old_key  = get_setting(f"node_api_key_{self.current}") or ""
        n_name   = self.new_name.value.strip() or self.current
        n_key    = self.new_api_key.value.strip() or old_key

        set_setting(f"node_api_key_{n_name}", n_key)
        if n_name != self.current:
            nodes[self.node_id - 1] = n_name
            _save_nodes(nodes)

        embed = create_success_embed("Node Updated ✅", f"**{n_name}** saved.")
        add_field(embed, "API Key", f"`{n_key[:40]}…`" if len(n_key) > 40 else f"`{n_key}`", False)
        await interaction.followup.send(embed=embed)


class NodeMigrateModal(discord.ui.Modal, title="🚀  Migrate VPS"):
    vps_name = discord.ui.TextInput(label="Container Name",   placeholder="vps-username-1")
    to_node  = discord.ui.TextInput(label="Destination Node", placeholder="node-us-1")

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        vps  = self.vps_name.value.strip()
        dest = self.to_node.value.strip()
        nodes = _get_nodes()
        if dest not in nodes:
            return await interaction.followup.send(
                embed=create_error_embed("Unknown Node", f"`{dest}` is not registered. Use `/node pick_one:List`."))

        found = None
        async with data_lock:
            for uid, lst in vps_data.items():
                for v in lst:
                    if v["container_name"] == vps:
                        found = v; break

        if not found:
            return await interaction.followup.send(
                embed=create_error_embed("Not Found", f"No VPS `{vps}` in the database."))

        src    = found.get("node", "local")
        f_from = f"{src}:{vps}" if src != "local" else vps
        f_to   = f"{dest}:{vps}"

        await interaction.followup.send(
            embed=create_info_embed("Migrating…", f"`{vps}` → **{dest}**. This may take several minutes."))
        try:
            await execute_lxc(f"lxc stop {f_from}", timeout=60)
            await execute_lxc(f"lxc move {f_from} {f_to}", timeout=600)
            await execute_lxc(f"lxc start {f_to}", timeout=60)
            async with data_lock:
                found["node"]   = dest
                found["status"] = "running"
            await async_save_vps_data()
            embed = create_success_embed("Migration Complete 🎉", f"`{vps}` is now live on **{dest}**.")
            add_field(embed, "From", src,  True)
            add_field(embed, "To",   dest, True)
            await interaction.followup.send(embed=embed)
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Migration Failed", str(e)[:2000]))


# ── Main /node command ─────────────────────────────────────────────────────────

class NodeCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="node", description="[ADMIN] Manage the LXD/Incus node cluster")
    @app_commands.choices(pick_one=[
        app_commands.Choice(name="📋 List — Show all registered nodes",         value="list"),
        app_commands.Choice(name="📡 Status — Live CPU, RAM, Disk per node",    value="status"),
        app_commands.Choice(name="➕ Create — Register a new node",              value="create"),
        app_commands.Choice(name="✏️ Edit — Change a node's API key or name",   value="edit"),
        app_commands.Choice(name="🗑️ Delete — Remove a node from the cluster",  value="delete"),
        app_commands.Choice(name="🚀 Migrate — Move a VPS between nodes",       value="migrate"),
    ])
    @app_commands.describe(
        pick_one = "Action to perform",
        option   = "Node ID (for Status/Edit/Delete) or leave blank for all",
        name     = "Node name (Create only)",
        api_key  = "API key token from: incus config trust add --name moonbot  (Create only)",
        runtime  = "Runtime on the remote node: incus or lxc  (Create only)",
        section  = "Who can deploy here: MoonCoin+Invite, Premium, or All (Create only)",
        vps_name = "Container name to migrate (Migrate only)",
        to_node  = "Destination node name (Migrate only)",
    )
    @app_commands.choices(section=[
        app_commands.Choice(name="🌙 MoonCoin & Invite & Giveaway — Free plans only", value="free"),
        app_commands.Choice(name="💎 Premium Users Only",                              value="premium"),
        app_commands.Choice(name="🌐 All Users",                                       value="all"),
    ])
    @app_commands.choices(runtime=[
        app_commands.Choice(name="Incus", value="incus"),
        app_commands.Choice(name="LXC",   value="lxc"),
    ])
    @has_role("Owner", "Admin")
    async def node_cmd(
        self, interaction: discord.Interaction,
        pick_one: str,
        option:   int   = None,
        name:     str   = None,
        api_key:  str   = None,
        runtime:  str   = None,
        section:  str   = None,
        vps_name: str   = None,
        to_node:  str   = None,
    ):
        uid      = str(interaction.user.id)
        is_owner = (int(uid) == int(MAIN_ADMIN_ID) or admin_data.get(uid) == "Owner")

        # ── LIST ─────────────────────────────────────────────────────────────
        if pick_one == "list":
            await interaction.response.defer()
            nodes = _get_nodes()
            embed = discord.Embed(
                title="🌐  Node Cluster",
                description=f"{Theme.DIVIDER}\n**{len(nodes)}** registered node(s)\n{Theme.DIVIDER}",
                color=Theme.PRIMARY, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
            for i, node in enumerate(nodes):
                icon = "🏠" if node == "local" else "🌐"
                rt   = get_setting(f"node_runtime_{node}") or RUNTIME
                key  = get_setting(f"node_api_key_{node}") or "—"
                sec  = get_setting(f"node_section_{node}") or "all"
                sec_icons = {"free":"🌙","premium":"💎","all":"🌐"}
                sec_icon  = sec_icons.get(sec,"🌐")
                info = "Local host machine" if node == "local" else f"Runtime: `{rt.upper()}` · Section: {sec_icon} `{sec.title()}` · Key: `{key[:20]}…`"
                embed.add_field(name=f"{icon}  #{i+1} — `{node}`", value=info, inline=False)
            embed.set_footer(text="Use /node pick_one:Status to see live stats")
            return await interaction.followup.send(embed=embed)

        # ── STATUS ────────────────────────────────────────────────────────────
        elif pick_one == "status":
            await interaction.response.defer()
            all_nodes = _get_nodes()
            targets   = [all_nodes[option - 1]] if option and 1 <= option <= len(all_nodes) else all_nodes

            embed = discord.Embed(
                title="📡  Cluster Status" if not option else f"📡  Node #{option}",
                description=f"{Theme.DIVIDER}\nLive resource snapshot\n{Theme.DIVIDER}",
                color=Theme.PRIMARY, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")

            for node in targets:
                s    = await get_node_stats(node)
                c_b  = Theme.progress_bar(s["cpu_pct"])
                r_b  = Theme.progress_bar(s["ram_pct"])
                d_b  = Theme.progress_bar(s["disk_pct"])
                icon = "🏠" if node == "local" else "🌐"
                val  = (
                    f"🟢 **Online**\n\n"
                    f"{Theme.CPU} **CPU** ({s['cpu_cores']} cores)\n{c_b}\n\n"
                    f"{Theme.RAM} **RAM** — `{s['used_ram_mb']} / {s['total_ram_mb']} MB`\n{r_b}\n\n"
                    f"{Theme.DISK} **Disk** — `{s['used_disk_gb']} / {s['total_disk_gb']} GB`\n{d_b}\n\n"
                    f"🖥️ **VPS** `{s['vps_running']} running / {s['vps_count']} total`"
                )
                embed.add_field(name=f"{icon}  `{node}`", value=val, inline=True)
            return await interaction.followup.send(embed=embed)

        # ── CREATE ────────────────────────────────────────────────────────────
        elif pick_one == "create":
            if not is_owner:
                return await interaction.response.send_message(
                    embed=create_error_embed("Owner Only", "Only the Owner can register new nodes."), ephemeral=True)

            # If name+api_key provided inline, skip modal
            if name and api_key:
                await interaction.response.defer(ephemeral=True)
                nodes = _get_nodes()
                node_name = name.strip().lower().replace(" ", "-")
                if node_name in nodes:
                    return await interaction.followup.send(embed=create_error_embed("Duplicate", f"`{node_name}` already registered."))
                rt = (runtime or RUNTIME).lower()
                set_setting(f"node_api_key_{node_name}", api_key.strip())
                set_setting(f"node_runtime_{node_name}", rt)
                set_setting(f"node_section_{node_name}", (section or "all").lower())
                nodes.append(node_name)
                _save_nodes(nodes)
                result = await _add_remote(node_name, api_key.strip(), rt)
                embed = create_success_embed(f"Node Registered — #{len(nodes)}", f"**{node_name}** added.")
                sec_label = {"free":"🌙 Free (MoonCoin/Invite/Giveaway)","premium":"💎 Premium Only","all":"🌐 All Users"}.get(section or "all", "All Users")
                add_field(embed, "Runtime", rt.upper(), True)
                add_field(embed, "Section", sec_label, True)
                add_field(embed, "Remote", result, False)
                return await interaction.followup.send(embed=embed)

            return await interaction.response.send_modal(NodeCreateModal())

        # ── EDIT ──────────────────────────────────────────────────────────────
        elif pick_one == "edit":
            if not is_owner:
                return await interaction.response.send_message(
                    embed=create_error_embed("Owner Only", "Only the Owner can edit nodes."), ephemeral=True)
            nodes = _get_nodes()
            nid   = option or 0
            if not nid or nid < 1 or nid > len(nodes):
                return await interaction.response.send_message(
                    embed=create_error_embed("Missing", "Provide `option` = node ID from `/node pick_one:List`."), ephemeral=True)
            current = nodes[nid - 1]
            if current == "local":
                return await interaction.response.send_message(
                    embed=create_error_embed("Protected", "The local node cannot be edited."), ephemeral=True)
            return await interaction.response.send_modal(NodeEditModal(nid, current))

        # ── DELETE ────────────────────────────────────────────────────────────
        elif pick_one == "delete":
            if not is_owner:
                return await interaction.response.send_message(
                    embed=create_error_embed("Owner Only", "Only the Owner can delete nodes."), ephemeral=True)
            await interaction.response.defer(ephemeral=True)
            nodes = _get_nodes()
            nid   = option or 0
            if not nid or nid < 1 or nid > len(nodes):
                return await interaction.followup.send(
                    embed=create_error_embed("Missing", "Provide `option` = node ID from `/node pick_one:List`."))
            target = nodes[nid - 1]
            if target == "local":
                return await interaction.followup.send(embed=create_error_embed("Protected", "Cannot delete the local node."))

            in_use = []
            async with data_lock:
                for uid2, lst in vps_data.items():
                    for v in lst:
                        if v.get("node") == target:
                            in_use.append(v["container_name"])
            if in_use:
                return await interaction.followup.send(embed=create_error_embed(
                    "In Use",
                    f"`{target}` still hosts **{len(in_use)}** VPS.\nMigrate them first with `/node pick_one:Migrate`."))

            nodes.remove(target)
            _save_nodes(nodes)
            try:
                await execute_lxc(f"lxc remote remove {target}")
            except Exception:
                pass
            return await interaction.followup.send(
                embed=create_success_embed("Node Deleted", f"**{target}** removed from the cluster."))

        # ── MIGRATE ───────────────────────────────────────────────────────────
        elif pick_one == "migrate":
            if vps_name and to_node:
                await interaction.response.defer(ephemeral=True)
                nodes = _get_nodes()
                if to_node not in nodes:
                    return await interaction.followup.send(
                        embed=create_error_embed("Unknown Node", f"`{to_node}` is not registered."))
                found = None
                async with data_lock:
                    for uid2, lst in vps_data.items():
                        for v in lst:
                            if v["container_name"] == vps_name:
                                found = v; break
                if not found:
                    return await interaction.followup.send(
                        embed=create_error_embed("Not Found", f"No VPS `{vps_name}` in the database."))
                src    = found.get("node", "local")
                f_from = f"{src}:{vps_name}" if src != "local" else vps_name
                f_to   = f"{to_node}:{vps_name}"
                await interaction.followup.send(
                    embed=create_info_embed("Migrating…", f"`{vps_name}` → **{to_node}**"))
                try:
                    await execute_lxc(f"lxc stop {f_from}", timeout=60)
                    await execute_lxc(f"lxc move {f_from} {f_to}", timeout=600)
                    await execute_lxc(f"lxc start {f_to}", timeout=60)
                    async with data_lock:
                        found["node"]   = to_node
                        found["status"] = "running"
                    await async_save_vps_data()
                    embed = create_success_embed("Migration Complete 🎉", f"`{vps_name}` → **{to_node}**")
                    add_field(embed, "From", src,     True)
                    add_field(embed, "To",   to_node, True)
                    return await interaction.followup.send(embed=embed)
                except Exception as e:
                    return await interaction.followup.send(embed=create_error_embed("Failed", str(e)[:2000]))
            return await interaction.response.send_modal(NodeMigrateModal())


async def setup(bot):
    await bot.add_cog(NodeCog(bot))
