"""
/af2f — Submit AF2F 6-digit code to authorise a pending action.

After running /af2f code:<CODE>, the user's session is marked verified.
They then re-run the original command, which proceeds immediately.
"""

import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.af2f import verify_code, is_owner
from core.database import get_db, admin_data
from core.config import MAIN_ADMIN_ID
from core.theme import Theme


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if int(uid) == int(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure("🚫 no_permission")
    return app_commands.check(predicate)


class AF2FCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(
        name="af2f",
        description="🔐 Submit your 6-digit AF2F code, then re-run the original command",
    )
    @app_commands.describe(code="The 6-digit code from the AF2F channel")
    @has_role("Owner", "Admin", "Hard Admin", "Hard Mod", "Dev")
    async def af2f_cmd(self, interaction: discord.Interaction, code: str):
        await interaction.response.defer(ephemeral=True)
        uid = str(interaction.user.id)

        # Owner never needs AF2F
        if is_owner(uid):
            embed = discord.Embed(
                title="ℹ️ AF2F Not Required",
                description=(
                    "You are the **bot owner** — you are permanently exempt from AF2F.\n\n"
                    "AF2F is only required for non-owner staff members."
                ),
                color=Theme.WARNING, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes AF2F", icon_url="https://imgur.com/6yfYDTP.png")
            return await interaction.followup.send(embed=embed)

        result = verify_code(uid, code.strip())

        if result is None:
            embed = discord.Embed(
                title="❌ AF2F Failed — Invalid or Expired Code",
                description=(
                    "The code you entered is **incorrect or has expired**.\n\n"
                    "**What to do:**\n"
                    "• Re-run the original command to receive a fresh code\n"
                    "• Codes expire after **5 minutes**\n"
                    "• Make sure you copied the code exactly"
                ),
                color=Theme.ERROR, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes AF2F", icon_url="https://imgur.com/6yfYDTP.png")
            return await interaction.followup.send(embed=embed)

        cmd = result.get("cmd", "unknown")

        # Mark as verified so the next run of this command passes through
        conn = get_db()
        conn.execute(
            "INSERT OR REPLACE INTO af2f_pending "
            "(user_id, code, cmd, args, created_at, expires_at) "
            "VALUES (?, 'VERIFIED', ?, '{}', datetime('now'), datetime('now', '+10 minutes'))",
            (uid, cmd),
        )
        conn.commit()

        embed = discord.Embed(
            title="✅ AF2F Verified",
            description=(
                "Your identity has been **confirmed**.\n\n"
                f"**Authorised command:** `/{cmd}`\n\n"
                "**Next step:** Re-run the original command — it will execute immediately.\n\n"
                "⏳ Your verified session expires in **10 minutes**."
            ),
            color=Theme.SUCCESS, timestamp=datetime.now(),
        )
        embed.set_author(name="MoonNodes AF2F", icon_url="https://imgur.com/6yfYDTP.png")
        embed.set_footer(text="Each command action requires its own verification.")
        await interaction.followup.send(embed=embed)


async def setup(bot):
    await bot.add_cog(AF2FCog(bot))
