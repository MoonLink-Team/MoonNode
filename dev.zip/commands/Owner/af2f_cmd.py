"""
/af2f — Admin 2-Factor verification command.

Usage:
    /af2f code:<4-digit-code>

The bot owner is always exempt from AF2F — this command is for staff only.
When a protected command is run by a non-owner, the bot:
  1. Generates a 4-digit code and posts it to the AF2F channel (owner sees it)
  2. DMs the user to run this command with that code

Protected commands:
  /create  /delete  /set  /system  /node  /role
  /mod role::trident:  action:Expire | Suspend | Unsuspend
"""

import discord
from discord import app_commands
from discord.ext import commands

from core.af2f import verify_code, is_owner
from core.theme import create_success_embed, create_error_embed, create_warning_embed
from core.config import MAIN_ADMIN_ID
from core.database import admin_data

def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if int(uid) == int(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure("🚫 no_permission")
    return app_commands.check(predicate)


class AF2FCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(
        name="af2f",
        description="Submit your AF2F 2-factor code to authorise a pending action"
    )
    @app_commands.describe(
        code="The 4-digit code from the AF2F channel"
    )
    @has_role("Owner", "Admin", "Hard Mod", "Dev")
    async def af2f_cmd(
        self,
        interaction: discord.Interaction,
        code: str,
    ):
        await interaction.response.defer(ephemeral=True)
        uid = str(interaction.user.id)

        # Owner never needs AF2F
        if is_owner(uid):
            return await interaction.followup.send(embed=create_warning_embed(
                "ℹ️ Not Required",
                "You are the **bot owner** — AF2F verification is never required for you."))

        result = verify_code(uid, code.strip())

        if result is None:
            return await interaction.followup.send(embed=create_error_embed(
                "🔐 AF2F Failed",
                "The code you entered is **invalid or expired**.\n\n"
                "Re-run the original command to receive a fresh code.\n"
                "Codes expire after **5 minutes**."))

        cmd  = result.get("cmd", "unknown")
        import json
        args = json.loads(result.get("args", "{}"))

        embed = create_success_embed(
            "✅ AF2F Verified",
            f"Your identity has been confirmed.\n\n"
            f"**Authorised command:** `{cmd}`\n\n"
            f"Now re-run the original command — it will execute immediately without prompting for a code again.\n\n"
            f"*(The verified session is consumed. Each action requires its own code.)*"
        )
        embed.set_author(name="MoonNodes AF2F", icon_url="https://imgur.com/6yfYDTP.png")
        await interaction.followup.send(embed=embed)


async def setup(bot):
    await bot.add_cog(AF2FCog(bot))
