import discord
from discord import app_commands
from discord.ext import commands

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock
from core.theme import create_embed, create_error_embed, add_field


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if uid == str(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure(f"Required role: {', '.join(roles)}")
    return app_commands.check(predicate)


class ListAllCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="list-all", description="[ADMIN] View all VPS instances across the network")
    @has_role("Owner", "Admin", "Dev")
    async def list_all(self, interaction: discord.Interaction):
        await interaction.response.defer()
        with data_lock:
            snapshot = dict(vps_data)

        if not snapshot:
            return await interaction.followup.send(embed=create_error_embed("Empty", "No VPS instances found."))

        embed = create_embed("📋 All VPS Instances", f"Total users with VPS: **{len(snapshot)}**")
        count = 0
        for uid, vps_list in snapshot.items():
            member = interaction.guild.get_member(int(uid))
            name   = member.display_name if member else f"<@{uid}>"
            lines  = []
            for vps in vps_list:
                status    = vps.get("status", "?")
                suspended = vps.get("suspended", False)
                icon = "⛔" if suspended else ("🟢" if status == "running" else "🔴")
                node = vps.get("node", "local")
                lines.append(f"{icon} `{vps['container_name']}` — {vps.get('config','?')} — node: **{node}**")
            add_field(embed, name, "\n".join(lines) or "No VPS", False)
            count += 1
            if count >= 20:
                embed.set_footer(text="Showing first 20 users. More exist.")
                break

        await interaction.followup.send(embed=embed)


async def setup(bot):
    await bot.add_cog(ListAllCog(bot))
