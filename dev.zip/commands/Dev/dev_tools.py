"""Dev-only commands: debug, diagnostics, live config viewing."""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

import core.config as cfg
from core.config import MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock, get_db
from core.lxc import RUNTIME, execute_lxc
from core.theme import create_embed, create_success_embed, create_error_embed, create_info_embed, add_field, Theme


def is_dev(uid):
    return str(uid) == str(MAIN_ADMIN_ID) or admin_data.get(str(uid)) in ("Owner", "Dev")


class DevCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="dev", description="[DEV] Developer tools and diagnostics")
    @app_commands.choices(action=[
        app_commands.Choice(name="🔍 Config Dump — Show all runtime config values",          value="config"),
        app_commands.Choice(name="🗃️ DB Stats — Row counts per table",                        value="db_stats"),
        app_commands.Choice(name="🔧 Runtime — Show container runtime and version",           value="runtime"),
        app_commands.Choice(name="📡 Test LXC — Run a safe lxc list and show output",         value="test_lxc"),
        app_commands.Choice(name="🌡️ Host Stats — Live CPU/RAM/Disk of the host",             value="host_stats"),
        app_commands.Choice(name="📝 Error Log — Show last 20 lines of bot.log",              value="log"),
        app_commands.Choice(name="🔄 Reload Cog — Reload a specific cog without restarting", value="reload"),
        app_commands.Choice(name="🔔 Test DM — Send a test DM to yourself",                  value="test_dm"),
        app_commands.Choice(name="🌐 Extension State — Show all extension flags",             value="ext_state"),
        app_commands.Choice(name="🧹 Purge Cache — Clear any in-memory caches",              value="purge_cache"),
    ])
    @app_commands.describe(action="Dev action to perform", option="Optional argument (cog name for reload, etc.)")
    async def dev_cmd(self, interaction: discord.Interaction, action: str, option: str = None):
        await interaction.response.defer(ephemeral=True)
        if not is_dev(interaction.user.id):
            return await interaction.followup.send(embed=create_error_embed("Denied", "Developer only."))

        # Config dump
        if action == "config":
            attrs = ["DISCORD_TOKEN","MAIN_ADMIN_ID","VPS_PREFIX","DEFAULT_STORAGE_POOL",
                     "MULTI_NODE","SOSB","ISTS","AES","RR","A2FA","MSTC","UBL_ENABLED",
                     "MARKETPLACE","ACCOUNT","VPS_MONITORING","VPS_RENEWAL"]
            lines = []
            for a in attrs:
                val = getattr(cfg, a, "N/A")
                if a == "DISCORD_TOKEN":
                    val = f"{str(val)[:6]}…" if val else "NOT SET"
                lines.append(f"`{a}` = `{val}`")
            embed = create_embed("⚙️ Runtime Config", "\n".join(lines))
            return await interaction.followup.send(embed=embed)

        # DB stats
        elif action == "db_stats":
            conn = get_db(); cur = conn.cursor()
            tables = ["settings", "users", "admins", "payments", "marketplace"]
            lines  = []
            for t in tables:
                try:
                    cur.execute(f"SELECT COUNT(*) FROM {t}"); count = cur.fetchone()[0]
                    lines.append(f"• `{t}` — **{count}** rows")
                except Exception:
                    lines.append(f"• `{t}` — *missing*")
            conn.close()
            with data_lock:
                vps_rows = sum(len(v) for v in vps_data.values())
            lines.append(f"• `vps (memory)` — **{vps_rows}** entries")
            return await interaction.followup.send(embed=create_info_embed("🗃️ DB Stats", "\n".join(lines)))

        # Runtime info
        elif action == "runtime":
            import shutil, subprocess
            rt_path = shutil.which(RUNTIME) or "not found"
            try:
                v = subprocess.run([RUNTIME, "version"], capture_output=True, text=True, timeout=5)
                ver = v.stdout.strip() or v.stderr.strip()
            except Exception as e:
                ver = str(e)
            return await interaction.followup.send(embed=create_info_embed("🔧 Runtime", f"Binary: `{RUNTIME}`\nPath: `{rt_path}`\nVersion:\n```{ver[:500]}```"))

        # Test LXC
        elif action == "test_lxc":
            try:
                out = await execute_lxc("lxc list --format=csv")
                text = str(out)[:1500] if out and out is not True else "(no containers)"
                return await interaction.followup.send(embed=create_success_embed("✅ LXC Works", f"```{text}```"))
            except Exception as e:
                return await interaction.followup.send(embed=create_error_embed("LXC Failed", str(e)[:2000]))

        # Host stats
        elif action == "host_stats":
            from core.lxc import _host_cpu_pct, _host_cpu_cores, _host_ram, _host_disk
            cpu   = _host_cpu_pct()
            cores = _host_cpu_cores()
            ur, tr = _host_ram()
            ud, td = _host_disk()
            embed = create_embed("🌡️ Host Stats", "")
            add_field(embed, "CPU",  f"{Theme.progress_bar(cpu)}\n`{cpu:.1f}%` ({cores} cores)", False)
            add_field(embed, "RAM",  f"{Theme.progress_bar(ur/tr*100 if tr else 0)}\n`{ur}/{tr} MB`", False)
            add_field(embed, "Disk", f"{Theme.progress_bar(ud/td*100 if td else 0)}\n`{ud}/{td} GB`", False)
            return await interaction.followup.send(embed=embed)

        # Log tail
        elif action == "log":
            import os
            log_path = "bot.log"
            if not os.path.exists(log_path):
                return await interaction.followup.send(embed=create_error_embed("Not Found", "bot.log not found."))
            with open(log_path, "r") as f:
                lines = f.readlines()
            tail = "".join(lines[-20:])[:1800]
            return await interaction.followup.send(embed=create_info_embed("📝 Last 20 Log Lines", f"```{tail}```"))

        # Reload cog
        elif action == "reload":
            if not option:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Provide cog name in `option` (e.g. `commands.User.help`)."))
            try:
                await interaction.client.reload_extension(option)
                return await interaction.followup.send(embed=create_success_embed("Reloaded", f"Cog `{option}` reloaded."))
            except Exception as e:
                return await interaction.followup.send(embed=create_error_embed("Failed", str(e)[:2000]))

        # Test DM
        elif action == "test_dm":
            dm = discord.Embed(title="🔔 Test DM", description="If you see this, the bot's DM system is working correctly.", color=Theme.SUCCESS)
            try:
                await interaction.user.send(embed=dm)
                return await interaction.followup.send(embed=create_success_embed("DM Sent", "Check your DMs!"))
            except discord.Forbidden:
                return await interaction.followup.send(embed=create_error_embed("DM Failed", "You have DMs disabled."))

        # Extension states
        elif action == "ext_state":
            ext_attrs = ["MULTI_NODE","SOSB","ISTS","AES","RR","A2FA","MSTC",
                         "UBL_ENABLED","MARKETPLACE","ACCOUNT","VPS_MONITORING",
                         "VPS_RENEWAL","VPS_TEMPLATES","MULTILANG"]
            lines = [f"{'🟢' if getattr(cfg, a, False) else '🔴'} `{a}`" for a in ext_attrs]
            return await interaction.followup.send(embed=create_info_embed("🌐 Extension States", "\n".join(lines)))

        # Purge cache
        elif action == "purge_cache":
            from core.database import load_vps_data, load_admin_data
            load_vps_data()
            load_admin_data()
            return await interaction.followup.send(embed=create_success_embed("Cache Purged", "VPS and admin data reloaded from disk."))


async def setup(bot):
    await bot.add_cog(DevCog(bot))
