"""
commands/Admin/vps.py — REMOVED

The /vps command has been removed.
VPS suspend/unsuspend is handled via /account admin_action:VPS
"""
# This file is intentionally empty — the cog is no longer loaded.
