import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock, save_vps_data
from core.lxc import execute_lxc
from core.theme import create_success_embed, create_error_embed, create_warning_embed


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if uid == str(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure(f"Required role: {', '.join(roles)}")
    return app_commands.check(predicate)


class VPSAdminCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="vps", description="[ADMIN] Suspend or unsuspend a VPS")
    @app_commands.choices(action=[
        app_commands.Choice(name="Suspend VPS",   value="suspend"),
        app_commands.Choice(name="Unsuspend VPS", value="unsuspend"),
    ])
    @app_commands.describe(container_name="Exact container name", reason="Reason for suspension")
    @has_role("Owner", "Admin", "Dev")
    async def vps_action(self, interaction: discord.Interaction, action: str, container_name: str, reason: str = "Violated Rules"):
        await interaction.response.defer()

        target_vps = None
        target_uid = None
        with data_lock:
            for uid, lst in vps_data.items():
                for vps in lst:
                    if vps["container_name"] == container_name:
                        target_vps = vps
                        target_uid = uid
                        break
                if target_vps:
                    break

        if not target_vps:
            return await interaction.followup.send(embed=create_error_embed("Not Found", f"No VPS named `{container_name}`."), ephemeral=True)

        node   = target_vps.get("node", "local")
        prefix = f"{node}:" if node != "local" else ""
        full   = f"{prefix}{container_name}"

        if action == "suspend":
            try:
                await execute_lxc(f"lxc stop {full}")
                with data_lock:
                    target_vps["status"]    = "stopped"
                    target_vps["suspended"] = True
                    target_vps.setdefault("suspension_history", []).append({
                        "time": datetime.now().isoformat(), "reason": reason, "by": interaction.user.name
                    })
                save_vps_data()
                await interaction.followup.send(embed=create_warning_embed("Suspended", f"`{container_name}` suspended.\nReason: {reason}"))
            except Exception as e:
                await interaction.followup.send(embed=create_error_embed("Failed", str(e)[:4000]), ephemeral=True)

        elif action == "unsuspend":
            try:
                await execute_lxc(f"lxc start {full}")
                with data_lock:
                    target_vps["suspended"] = False
                    target_vps["status"]    = "running"
                save_vps_data()
                await interaction.followup.send(embed=create_success_embed("Unsuspended", f"`{container_name}` is active again."))
            except Exception as e:
                await interaction.followup.send(embed=create_error_embed("Failed", str(e)[:4000]), ephemeral=True)


async def setup(bot):
    await bot.add_cog(VPSAdminCog(bot))
