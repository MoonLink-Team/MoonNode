"""
/set — [ADMIN] Configure bot settings.

Channel setting rework:
  - setting:Channel → shows all channels in one clean UI
  - Each channel has a Set button; user sends ID in DM
  - DM Commands: added "All" action to allow/block all commands at once
"""

import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime
import asyncio

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, set_setting, get_setting, get_db
from core.theme import create_success_embed, create_error_embed, create_embed, add_field, Theme
from core.af2f import require_af2f


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if int(uid) == int(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure("🚫 no_permission")
    return app_commands.check(predicate)


# ── Channel Setup View ────────────────────────────────────────────────────────

CHANNEL_SETTINGS = [
    ("log_channel",     "📋 Log Channel",        "Where bot activity is logged"),
    ("payment_channel", "💳 Payment Channel",    "Where payment proofs are posted"),
    ("ticket_channel",  "🎫 Ticket Category",    "Discord category for support tickets"),
    ("update_channel",  "📢 Update Channel",     "For maintenance/update announcements"),
    ("main_chat_id",    "💬 Main Chat Channel",  "For MoonCoin chat rewards"),
    ("af2f_channel_id", "🔐 AF2F Channel",       "Where admin 2FA codes are posted"),
    ("claim_channel",   "🎟️ Claim Channel",      "Where users claim free VPS"),
]


def _channels_embed() -> discord.Embed:
    embed = discord.Embed(
        title="📡 Channel Configuration",
        description=(
            "Configure all bot channels from one place.\n\n"
            "Click a button to set that channel.\n"
            "You'll be prompted to **send the channel ID** in DM.\n\n"
            "**Current values:**"
        ),
        color=Theme.PRIMARY,
        timestamp=datetime.now(),
    )
    embed.set_author(name="MoonNodes — Channel Setup", icon_url="https://imgur.com/6yfYDTP.png")
    for key, label, desc in CHANNEL_SETTINGS:
        val = get_setting(key) or "Not set"
        mention = f"<#{val}>" if val != "Not set" else "*(not set)*"
        embed.add_field(name=label, value=f"{mention}\n`{val}`\n*{desc}*", inline=True)
    embed.set_footer(text="Click a button below to update a channel")
    return embed


class ChannelSetupView(discord.ui.View):
    def __init__(self, user_id: str, bot):
        super().__init__(timeout=300)
        self.user_id = user_id
        self.bot     = bot
        # Add one button per channel
        for key, label, desc in CHANNEL_SETTINGS:
            btn = discord.ui.Button(
                label=label,
                style=discord.ButtonStyle.secondary,
                custom_id=f"chset_{key}",
            )
            btn.callback = self._make_callback(key, label)
            self.add_item(btn)

    def _make_callback(self, key: str, label: str):
        async def callback(inter: discord.Interaction):
            if str(inter.user.id) != self.user_id:
                return await inter.response.send_message("Permission denied.", ephemeral=True)

            await inter.response.defer(ephemeral=True)
            await inter.followup.send(embed=discord.Embed(
                title=f"Setting {label}",
                description=(
                    f"**Send the channel ID for {label} in this DM.**\n\n"
                    "Right-click the channel in Discord → **Copy ID**\n"
                    "Then send just the number here.\n\n"
                    "⏳ *You have 2 minutes.*"
                ),
                color=0x5865F2,
            ), ephemeral=True)

            def _check(m):
                return (
                    m.author.id == inter.user.id
                    and isinstance(m.channel, discord.DMChannel)
                    and m.content.strip().isdigit()
                )
            try:
                msg = await self.bot.wait_for("message", check=_check, timeout=120)
                channel_id = msg.content.strip()
                set_setting(key, channel_id)
                # Apply runtime updates
                import core.config as _cfg
                if key == "main_chat_id":
                    try: _cfg.MAIN_CHAT_ID = int(channel_id)
                    except Exception: pass

                await msg.reply(embed=discord.Embed(
                    description=f"✅ **{label}** set to <#{channel_id}> (`{channel_id}`)",
                    color=Theme.SUCCESS,
                ))
                # Refresh the main embed
                try:
                    await inter.edit_original_response(embed=_channels_embed(), view=self)
                except Exception:
                    pass
            except asyncio.TimeoutError:
                await inter.followup.send(embed=discord.Embed(
                    description="⏰ Timed out — no channel ID received.", color=Theme.ERROR), ephemeral=True)
        return callback


# ── Cog ───────────────────────────────────────────────────────────────────────

class SetCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="set", description="[ADMIN] Configure bot settings, channels, and thresholds")
    @app_commands.choices(setting=[
        app_commands.Choice(name="📡 Channel — Configure all channels in one UI",   value="channel"),
        app_commands.Choice(name="📋 Log Channel",              value="log_channel"),
        app_commands.Choice(name="💳 Payment Channel",          value="payment_channel"),
        app_commands.Choice(name="🎫 Ticket Category",          value="ticket_channel"),
        app_commands.Choice(name="📢 Update Channel",           value="update_channel"),
        app_commands.Choice(name="💬 Main Chat Channel",        value="main_chat_id"),
        app_commands.Choice(name="📊 CPU Threshold %",          value="cpu_threshold"),
        app_commands.Choice(name="📊 RAM Threshold %",          value="ram_threshold"),
        app_commands.Choice(name="💾 Backup Limits",            value="backup_limits"),
        app_commands.Choice(name="🕐 Scheduled Backups",        value="scheduled_backups"),
        app_commands.Choice(name="🎟️ Claim Channel",           value="claim_channel"),
        app_commands.Choice(name="💬 DM Commands",             value="user_dm"),
        app_commands.Choice(name="🌙 MoonCoin — Manage earn rules", value="mooncoin"),
        app_commands.Choice(name="🔐 AF2F Channel",            value="af2f_channel"),
    ])
    @app_commands.choices(command_dm_action=[
        app_commands.Choice(name="PREFIX — Set DM command prefix",      value="prefix"),
        app_commands.Choice(name="📋 List — Show current DM settings",  value="list"),
    ])
    @app_commands.choices(block_action=[
        app_commands.Choice(name="➕ Add — Block a command",      value="add"),
        app_commands.Choice(name="🗑️ Delete — Unblock a command", value="delete"),
        app_commands.Choice(name="📋 List — View blocked",        value="list"),
    ])
    @app_commands.choices(mooncoin_action=[
        app_commands.Choice(name="➕ Add — Create/update a rule",  value="add"),
        app_commands.Choice(name="🗑️ Remove — Delete a rule",     value="remove"),
        app_commands.Choice(name="📋 View — List all rules",       value="view"),
        app_commands.Choice(name="🎁 Grant — Give coins to user",  value="grant"),
        app_commands.Choice(name="➖ Deduct — Remove coins",       value="deduct"),
    ])
    @app_commands.describe(
        setting           = "Which setting to configure",
        value             = "New value (channel ID, number, command name, role ID, or amount)",
        command_dm_action = "For DM Commands: all | none | prefix | add | remove | list",
        role_action       = "For Role setting: add | remove | list",
        permission        = "Staff role name (for Role setting)",
        option            = "Option modifier",
        date              = "Schedule date e.g. 2025-12-01",
        time              = "Schedule time e.g. 12:00",
        mooncoin_action   = "MoonCoin action",
        target_user       = "Target user for MoonCoin grant/deduct",
    )
    @has_role("Owner", "Admin")
    async def set_cmd(
        self, interaction: discord.Interaction,
        setting:           str,
        value:             str = None,
        option:            str = None,
        date:              str = None,
        time:              str = None,
        command_dm_action: str = None,
        role_action:       str = None,
        permission:        str = None,
        mooncoin_action:   str = None,
        target_user:       discord.Member = None,
    ):
        uid      = str(interaction.user.id)
        is_owner = (uid == str(MAIN_ADMIN_ID))

        # AF2F gate
        if not is_owner:
            if not await require_af2f(interaction, "set", self.bot):
                return

        await interaction.response.defer(ephemeral=True)

        # ── Channel — All-in-one UI ───────────────────────────────────────────
        if setting == "channel":
            view = ChannelSetupView(uid, self.bot)
            return await interaction.followup.send(
                embed=_channels_embed(), view=view)

        # ── Block Terminal Command ────────────────────────────────────────────
        # ── Backup Limits ─────────────────────────────────────────────────────
        if setting == "backup_limits":
            if not value:
                cur_val = get_setting("backup_limits_value") or "1"
                return await interaction.followup.send(embed=create_embed(
                    "💾 Backup Limits", f"**Current limit:** `{cur_val}` snapshots per VPS\n\nProvide `value:<number>` to update."))
            set_setting("backup_limits_value", value)
            return await interaction.followup.send(embed=create_success_embed(
                "✅ Backup Limits Updated", f"Max **{value}** snapshot(s) per VPS.\nMake sure the **Backup Limits** extension is enabled."))

        # ── Scheduled Backups ─────────────────────────────────────────────────
        if setting == "scheduled_backups":
            if not time:
                cur_time = get_setting("scheduled_backups_time") or "02:00AM"
                return await interaction.followup.send(embed=create_embed(
                    "🕐 Scheduled Backups",
                    f"**Current run time:** `{cur_time}`\n\nProvide `time:<HH:MMam/pm>` to update, e.g. `time:02:00AM`.\n"
                    "Enable/disable via `/system action:Extension Toggle extension:Scheduled Backups`."))
            set_setting("scheduled_backups_time", time)
            return await interaction.followup.send(embed=create_success_embed(
                "✅ Scheduled Backups Updated", f"Backups will run daily at **{time}**.\nMake sure the **Scheduled Backups** extension is enabled."))

        # ── AF2F Channel ──────────────────────────────────────────────────────
        if setting == "af2f_channel":
            if not is_owner:
                return await interaction.followup.send(embed=create_error_embed(
                    "🚫 Owner Only", "Only the **bot owner** can configure the AF2F channel."))
            if not value:
                cur_val = get_setting("af2f_channel_id") or "Not set"
                return await interaction.followup.send(embed=create_embed(
                    "🔐 AF2F Channel",
                    f"**Current:** `{cur_val}`\n\nProvide `value:<channel_id>` to update."))
            set_setting("af2f_channel_id", value.strip())
            return await interaction.followup.send(embed=create_success_embed(
                "✅ AF2F Channel Set",
                f"AF2F codes will be sent to <#{value.strip()}>.\n"
                "Only visible in that channel."))

        # ── MoonCoin Rules ────────────────────────────────────────────────────
        if setting == "mooncoin":
            conn = get_db(); cur = conn.cursor()
            mc_action = (mooncoin_action or "view").lower()

            if mc_action == "view":
                cur.execute("SELECT name, amount, cooldown FROM mooncoin_rules ORDER BY name")
                rows = cur.fetchall()
                embed = create_embed("🌙 MoonCoin Rules", f"**{len(rows)}** rule(s)")
                for r in rows:
                    cd = f"{r['cooldown']}s cooldown" if r['cooldown'] else "no cooldown"
                    add_field(embed, r['name'], f"`+{r['amount']} coins` · {cd}", True)
                if not rows: embed.description = "No rules defined yet."
                conn.close()
                return await interaction.followup.send(embed=embed)

            elif mc_action == "add":
                if not value: conn.close(); return await interaction.followup.send(
                    embed=create_error_embed("Missing", "Provide `value:<rule_name>`."))
                rule_name = value.strip().lower()
                amount    = int(option) if option and str(option).isdigit() else 1
                cur.execute("INSERT OR REPLACE INTO mooncoin_rules (name,amount,cooldown) VALUES (?,?,?)",
                    (rule_name, amount, 0))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ Rule Added", f"`{rule_name}` → **+{amount} coins**."))

            elif mc_action == "remove":
                if not value: conn.close(); return await interaction.followup.send(
                    embed=create_error_embed("Missing", "Provide `value:<rule_name>`."))
                cur.execute("DELETE FROM mooncoin_rules WHERE name=?", (value.strip().lower(),))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ Rule Removed", f"`{value.strip()}` deleted."))

            elif mc_action == "grant":
                if not target_user or not value: conn.close(); return await interaction.followup.send(
                    embed=create_error_embed("Missing", "Provide `target_user` and `value:<amount>`."))
                try: amt = int(value)
                except ValueError: conn.close(); return await interaction.followup.send(
                    embed=create_error_embed("Invalid", "`value` must be a number."))
                from core.database import add_coins
                add_coins(str(target_user.id), amt); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ Coins Granted", f"**+{amt:,} 🌙** granted to {target_user.mention}."))

            elif mc_action == "deduct":
                if not target_user or not value: conn.close(); return await interaction.followup.send(
                    embed=create_error_embed("Missing", "Provide `target_user` and `value:<amount>`."))
                try: amt = int(value)
                except ValueError: conn.close(); return await interaction.followup.send(
                    embed=create_error_embed("Invalid", "`value` must be a number."))
                from core.database import add_coins
                add_coins(str(target_user.id), -amt); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ Coins Deducted", f"**-{amt:,} 🌙** removed from {target_user.mention}."))

            conn.close(); return

        # ── User DM Commands ──────────────────────────────────────────────────
        if setting == "user_dm":
            conn = get_db(); cur = conn.cursor()
            cur.execute("""CREATE TABLE IF NOT EXISTS dm_settings
                (key TEXT PRIMARY KEY, value TEXT)""")
            conn.commit()
            action_dm = (command_dm_action or "list").lower()

            if action_dm == "prefix":
                prefix_val = (value or "!").strip()
                cur.execute("INSERT OR REPLACE INTO dm_settings (key,value) VALUES (?,?)",
                    ("dm_prefix", prefix_val))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "DM Prefix Set",
                    f"Users can now use `{prefix_val}<command>` in DMs."))

            else:  # list
                cur.execute("SELECT key,value FROM dm_settings")
                rows       = [dict(r) for r in cur.fetchall()]; conn.close()
                mode       = get_setting("dm_commands_mode") or "custom"
                prefix_row = next((r for r in rows if r["key"] == "dm_prefix"), None)
                allowed    = [r["key"].replace("dm_allow_","") for r in rows if r["key"].startswith("dm_allow_")]
                embed      = create_embed("💬 DM Command Settings", "")
                add_field(embed, "Mode",    f"`{mode}`",                                                         True)
                add_field(embed, "Prefix",  f"`{prefix_row['value']}`" if prefix_row else "`!` (default)",       True)
                add_field(embed, "Allowed", ", ".join(f"`{c}`" for c in allowed) or "All (if mode=all)",         False)
                return await interaction.followup.send(embed=embed)

        # ── Standard channel / threshold settings ─────────────────────────────
        if not value:
            return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `value`."))

        set_setting(setting, value)

        if setting == "main_chat_id":
            try:
                import core.config as _cfg2
                _cfg2.MAIN_CHAT_ID = int(value)
            except Exception: pass

        LABELS = {
            "claim_channel":   "🎟️ Claim Channel",
            "log_channel":     "📋 Log Channel",
            "payment_channel": "💳 Payment Channel",
            "ticket_channel":  "🎫 Ticket Category",
            "update_channel":  "📢 Update Channel",
            "main_chat_id":    "💬 Main Chat Channel",
            "cpu_threshold":   "📊 CPU Threshold",
            "ram_threshold":   "📊 RAM Threshold",
        }
        label = LABELS.get(setting, setting)

        embed = create_success_embed(
            "✅ Setting Updated",
            f"**{label}** → `{value}`"
        )
        embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
        embed.set_footer(text=f"Updated by {interaction.user.display_name} · MoonNodes")

        if setting == "ticket_channel":
            embed.description += "\n\n> This is a **category ID**. New tickets open inside this category."

        await interaction.followup.send(embed=embed)


async def setup(bot):
    await bot.add_cog(SetCog(bot))
