"""
/set — [ADMIN] Configure bot channels, thresholds, and schedules.
/payment — [ADMIN] Manage payment methods.
"""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, set_setting, get_setting, get_db
from core.theme import create_success_embed, create_error_embed, create_embed, add_field, Theme


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if int(uid) == int(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure("no_permission")
    return app_commands.check(predicate)


class SetCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="set", description="[ADMIN] Configure bot settings, channels, and thresholds")
    @app_commands.choices(setting=[
        app_commands.Choice(name="📋 Log Channel",               value="log_channel"),
        app_commands.Choice(name="💳 Payment Channel",           value="payment_channel"),
        app_commands.Choice(name="🎫 Ticket Category",           value="ticket_channel"),
        app_commands.Choice(name="📢 Update Channel",            value="update_channel"),
        app_commands.Choice(name="💬 Main Chat Channel",         value="main_chat_id"),
        app_commands.Choice(name="📊 CPU Threshold %",           value="cpu_threshold"),
        app_commands.Choice(name="📊 RAM Threshold %",           value="ram_threshold"),
        app_commands.Choice(name="💾 Backup Limits",             value="backup_limits"),
        app_commands.Choice(name="🕐 Scheduled Backups",         value="scheduled_backups"),
        app_commands.Choice(name="🚫 Block Terminal Command",    value="block_terminal"),
    ])
    @app_commands.choices(block_action=[
        app_commands.Choice(name="➕ Add — Block a command",     value="add"),
        app_commands.Choice(name="🗑️ Delete — Unblock a command", value="delete"),
        app_commands.Choice(name="📋 List — View blocked commands", value="list"),
    ])
    @app_commands.describe(
        setting      = "Which setting to configure",
        value        = "New value (channel ID, number, or on/off)",
        option       = "Option modifier",
        date         = "Schedule date e.g. 2025-12-01",
        time         = "Schedule time e.g. 12:00",
        block_action = "Add / Delete / List a blocked terminal command",
    )
    @has_role("Owner", "Admin")
    async def set_cmd(
        self, interaction: discord.Interaction,
        setting:      str,
        value:        str = None,
        option:       str = None,
        date:         str = None,
        time:         str = None,
        block_action: str = None,
    ):
        await interaction.response.defer(ephemeral=True)

        # ── Block Terminal Command ────────────────────────────────────────────
        if setting == "block_terminal":
            conn = get_db(); cur = conn.cursor()
            cur.execute("""CREATE TABLE IF NOT EXISTS blocked_commands
                (cmd TEXT PRIMARY KEY, added_by TEXT, added_at TEXT)""")
            conn.commit()

            if block_action == "list" or (not block_action and not value):
                cur.execute("SELECT cmd FROM blocked_commands ORDER BY cmd")
                rows = cur.fetchall()
                conn.close()
                if not rows:
                    return await interaction.followup.send(embed=create_embed(
                        "🚫 Blocked Terminal Commands", "No commands blocked yet."))
                cmds = "\n".join(f"› `{r['cmd']}`" for r in rows)
                return await interaction.followup.send(embed=create_embed(
                    f"🚫 Blocked Commands ({len(rows)})", cmds))

            if not value:
                conn.close()
                return await interaction.followup.send(embed=create_error_embed(
                    "Missing", "Provide `value` = the command to block/unblock."))

            if block_action == "add" or not block_action:
                cur.execute("INSERT OR IGNORE INTO blocked_commands (cmd,added_by,added_at) VALUES (?,?,?)",
                    (value.strip(), str(interaction.user.id), datetime.now().isoformat()))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "Command Blocked", f"`{value}` is now blocked in VPS terminals."))

            elif block_action == "delete":
                cur.execute("DELETE FROM blocked_commands WHERE cmd=?", (value.strip(),))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "Command Unblocked", f"`{value}` is no longer blocked."))

        # ── Backup Limits ────────────────────────────────────────────────────
        if setting == "backup_limits":
            if not value:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `value`."))
            set_setting("backup_limits_enabled", value)
            if option: set_setting("backup_limits_option", option)
            embed = create_success_embed("Backup Limits Updated")
            add_field(embed, "Enabled/Value", value, True)
            if option: add_field(embed, "Option", option, True)
            return await interaction.followup.send(embed=embed)

        # ── Scheduled Backups ────────────────────────────────────────────────
        if setting == "scheduled_backups":
            if not value:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `value`."))
            set_setting("scheduled_backups_enabled", value)
            if option: set_setting("scheduled_backups_option", option)
            if date:   set_setting("scheduled_backups_date", date)
            if time:   set_setting("scheduled_backups_time", time)
            embed = create_success_embed("Scheduled Backups Updated")
            add_field(embed, "Status", value, True)
            if option: add_field(embed, "Frequency", option, True)
            if date:   add_field(embed, "Start Date", date, True)
            if time:   add_field(embed, "Run Time", time, True)
            return await interaction.followup.send(embed=embed)

        # ── Standard channel/threshold settings ──────────────────────────────
        if not value:
            return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `value`."))

        set_setting(setting, value)

        # Apply main_chat_id at runtime
        if setting == "main_chat_id":
            try:
                import core.config as cfg
                cfg.MAIN_CHAT_ID = int(value)
            except Exception: pass

        labels = {
            "log_channel":     "📋 Log Channel",
            "payment_channel": "💳 Payment Channel",
            "ticket_channel":  "🎫 Ticket Category",
            "update_channel":  "📢 Update Channel",
            "main_chat_id":    "💬 Main Chat Channel",
            "cpu_threshold":   "📊 CPU Threshold",
            "ram_threshold":   "📊 RAM Threshold",
        }
        label = labels.get(setting, setting)

        embed = create_success_embed(
            "✅ Setting Updated",
            f"**{label}** has been set to `{value}`."
        )
        embed.set_author(name="MoonNodes — Admin Settings", icon_url="https://imgur.com/6yfYDTP.png")
        embed.set_footer(text=f"Updated by {interaction.user.display_name} · MoonNodes")

        # Extra note for ticket category
        if setting == "ticket_channel":
            embed.description += (
                "\n\n> This is a **category ID**. New tickets will create channels inside this category."
            )

        await interaction.followup.send(embed=embed)

    # ── /payment ─────────────────────────────────────────────────────────────
    @app_commands.command(name="payment", description="[ADMIN] Manage payment methods shown in /plans")
    @app_commands.choices(action=[
        app_commands.Choice(name="➕ Add / Edit", value="add"),
        app_commands.Choice(name="🗑️ Remove",    value="remove"),
        app_commands.Choice(name="📋 List",       value="list"),
    ])
    @app_commands.describe(
        payment_name = "Name of the payment method (e.g. GCash)",
        image        = "QR code or payment image",
    )
    @has_role("Owner", "Admin")
    async def payment_cmd(
        self, interaction: discord.Interaction,
        action: str,
        payment_name: str = None,
        image: discord.Attachment = None,
    ):
        await interaction.response.defer(ephemeral=True)
        conn = get_db(); cur = conn.cursor()

        if action == "list":
            cur.execute("SELECT * FROM payments")
            rows = [dict(r) for r in cur.fetchall()]; conn.close()
            if not rows:
                return await interaction.followup.send(embed=create_error_embed("Empty", "No payment methods saved yet."))
            embed = create_embed("💳 Payment Methods", f"**{len(rows)}** method(s) configured.")
            for r in rows:
                add_field(embed, r["name"], r["image_url"][:200], True)
            return await interaction.followup.send(embed=embed)

        if not payment_name:
            conn.close()
            return await interaction.followup.send(embed=create_error_embed("Missing", "Provide a `payment_name`."))

        if action == "add":
            if not image or not image.content_type.startswith("image/"):
                conn.close()
                return await interaction.followup.send(embed=create_error_embed("Missing Image", "Attach a valid image file (JPG/PNG)."))
            cur.execute("INSERT OR REPLACE INTO payments (name, image_url) VALUES (?,?)", (payment_name, image.url))
            conn.commit(); conn.close()
            return await interaction.followup.send(embed=create_success_embed(
                "Payment Method Saved", f"**{payment_name}** is now available in `/plans`."))

        elif action == "remove":
            cur.execute("DELETE FROM payments WHERE name=?", (payment_name,))
            conn.commit(); conn.close()
            return await interaction.followup.send(embed=create_success_embed(
                "Removed", f"Payment method **{payment_name}** has been removed."))

        conn.close()


async def setup(bot):
    await bot.add_cog(SetCog(bot))
