import discord
from discord import app_commands
from discord.ext import commands

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, set_setting, get_setting
from core.theme import create_success_embed, create_error_embed, create_embed, add_field


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if int(uid) == int(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure(f"Required role: {', '.join(roles)}")
    return app_commands.check(predicate)


class SetCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="set", description="[ADMIN] Configure bot settings, channels, thresholds, and schedules")
    @app_commands.choices(setting=[
        app_commands.Choice(name="Log Channel",        value="log_channel"),
        app_commands.Choice(name="Payment Channel",    value="payment_channel"),
        app_commands.Choice(name="Ticket Channel",     value="ticket_channel"),
        app_commands.Choice(name="CPU Threshold %",    value="cpu_threshold"),
        app_commands.Choice(name="RAM Threshold %",    value="ram_threshold"),
        app_commands.Choice(name="Backup Limits",      value="backup_limits"),
        app_commands.Choice(name="Scheduled Backups",  value="scheduled_backups"),
    ])
    @app_commands.describe(
        setting="Which setting to configure",
        value="New value (channel ID, number, or enable/disable)",
        option="Option modifier (e.g. per-plan limit, backup frequency)",
        date="Schedule date  e.g. 1/12/2025",
        time="Schedule time  e.g. 12:00AM",
    )
    @has_role("Owner", "Admin")
    async def set_cmd(
        self,
        interaction: discord.Interaction,
        setting: str,
        value: str,
        option: str = None,
        date: str = None,
        time: str = None,
    ):
        await interaction.response.defer(ephemeral=True)

        # ── Backup Limits ────────────────────────────────────────────────────
        if setting == "backup_limits":
            set_setting("backup_limits_enabled", value)           # enable / disable / a number
            if option:
                set_setting("backup_limits_option", option)
            if date:
                set_setting("backup_limits_date", date)
            if time:
                set_setting("backup_limits_time", time)

            embed = create_success_embed("Backup Limits Updated")
            add_field(embed, "Enabled/Value", value, True)
            if option: add_field(embed, "Option",    option, True)
            if date:   add_field(embed, "Date",      date,   True)
            if time:   add_field(embed, "Time",      time,   True)
            add_field(embed, "Note",
                "This controls the maximum number of backups per VPS. "
                "Requires the **Backup Limits** extension to be enabled via `/system-admin`.",
                False)
            return await interaction.followup.send(embed=embed)

        # ── Scheduled Backups ────────────────────────────────────────────────
        if setting == "scheduled_backups":
            set_setting("scheduled_backups_enabled", value)       # enable / disable
            if option:
                set_setting("scheduled_backups_option", option)   # e.g. daily / weekly
            if date:
                set_setting("scheduled_backups_date", date)       # start date
            if time:
                set_setting("scheduled_backups_time", time)       # run time

            embed = create_success_embed("Scheduled Backups Updated")
            add_field(embed, "Status",    value,              True)
            if option: add_field(embed, "Frequency", option, True)
            if date:   add_field(embed, "Start Date", date,  True)
            if time:   add_field(embed, "Run Time",   time,  True)
            add_field(embed, "Note",
                "Requires the **Scheduled Backups** extension to be enabled via `/system-admin`. "
                "The bot will auto-snapshot all running VPS at the specified time.",
                False)
            return await interaction.followup.send(embed=embed)

        # ── Standard settings ────────────────────────────────────────────────
        set_setting(setting, value)
        labels = {
            "log_channel":     "Log Channel",
            "payment_channel": "Payment Channel",
            "ticket_channel":  "Ticket Channel",
            "cpu_threshold":   "CPU Threshold",
            "ram_threshold":   "RAM Threshold",
        }
        embed = create_success_embed("Setting Updated", f"**{labels.get(setting, setting)}** has been set to `{value}`.")
        await interaction.followup.send(embed=embed)

    # ── /payment ─────────────────────────────────────────────────────────────
    @app_commands.command(name="payment", description="[ADMIN] Manage payment methods shown in /plans")
    @app_commands.choices(action=[
        app_commands.Choice(name="Add/Edit", value="add"),
        app_commands.Choice(name="Remove",   value="remove"),
        app_commands.Choice(name="List",     value="list"),
    ])
    @app_commands.describe(payment_name="Name of the payment method (e.g. GCash)", image="QR code or payment image")
    @has_role("Owner", "Admin")
    async def payment_cmd(
        self,
        interaction: discord.Interaction,
        action: str,
        payment_name: str = None,
        image: discord.Attachment = None,
    ):
        await interaction.response.defer(ephemeral=True)
        from core.database import get_db, get_payments
        conn = get_db()
        cur  = conn.cursor()

        if action == "list":
            rows = get_payments()
            if not rows:
                conn.close()
                return await interaction.followup.send(embed=create_error_embed("Empty", "No payment methods saved."))
            embed = create_embed("💳 Payment Methods", f"{len(rows)} method(s) configured.")
            for r in rows:
                add_field(embed, r["name"], r["image_url"][:200], True)
            conn.close()
            return await interaction.followup.send(embed=embed)

        if not payment_name:
            conn.close()
            return await interaction.followup.send(embed=create_error_embed("Error", "Provide a `payment_name`."))

        if action == "add":
            if not image or not image.content_type.startswith("image/"):
                conn.close()
                return await interaction.followup.send(embed=create_error_embed("Error", "Attach a valid image file (JPG/PNG)."))
            cur.execute("INSERT OR REPLACE INTO payments (name, image_url) VALUES (?,?)", (payment_name, image.url))
            conn.commit()
            conn.close()
            return await interaction.followup.send(embed=create_success_embed("Saved", f"Payment method **{payment_name}** saved."))

        elif action == "remove":
            cur.execute("DELETE FROM payments WHERE name=?", (payment_name,))
            conn.commit()
            conn.close()
            return await interaction.followup.send(embed=create_success_embed("Removed", f"Payment method **{payment_name}** removed."))

        conn.close()


async def setup(bot):
    await bot.add_cog(SetCog(bot))
