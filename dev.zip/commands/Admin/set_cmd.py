"""
/set — [ADMIN] Configure bot channels, thresholds, and schedules.
/payment — [ADMIN] Manage payment methods.
"""
import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, set_setting, get_setting, get_db
from core.theme import create_success_embed, create_error_embed, create_embed, add_field, Theme


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if int(uid) == int(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure("🚫 no_permission")
    return app_commands.check(predicate)


class SetCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="set", description="[ADMIN] Configure bot settings, channels, and thresholds")
    @app_commands.choices(setting=[
        app_commands.Choice(name="📋 Log Channel",               value="log_channel"),
        app_commands.Choice(name="💳 Payment Channel",           value="payment_channel"),
        app_commands.Choice(name="🎫 Ticket Category",           value="ticket_channel"),
        app_commands.Choice(name="📢 Update Channel",            value="update_channel"),
        app_commands.Choice(name="💬 Main Chat Channel",         value="main_chat_id"),
        app_commands.Choice(name="📊 CPU Threshold %",           value="cpu_threshold"),
        app_commands.Choice(name="📊 RAM Threshold %",           value="ram_threshold"),
        app_commands.Choice(name="💾 Backup Limits",             value="backup_limits"),
        app_commands.Choice(name="🕐 Scheduled Backups",         value="scheduled_backups"),
        app_commands.Choice(name="🎟️ Claim Channel",            value="claim_channel"),
        app_commands.Choice(name="💳 Payment Method",           value="payment"),
        app_commands.Choice(name="🚫 Block Terminal Command",    value="block_terminal"),
        app_commands.Choice(name="💬 DM Commands",              value="user_dm"),
        app_commands.Choice(name="🎭 Role — Set Discord role ID", value="role_id"),
        app_commands.Choice(name="🌙 MoonCoin — Manage earn rules", value="mooncoin"),
        app_commands.Choice(name="🔐 AF2F Channel — Bot AF2F log channel", value="af2f_channel"),
    ])
    @app_commands.choices(command_dm_action=[
        app_commands.Choice(name="PREFIX — Set command prefix for DMs", value="prefix"),
        app_commands.Choice(name="➕ Add — Allow a specific command in DMs", value="add"),
        app_commands.Choice(name="🗑️ Remove — Block a specific command in DMs", value="remove"),
        app_commands.Choice(name="📋 List — Show DM command settings", value="list"),
    ])
    @app_commands.choices(block_action=[
        app_commands.Choice(name="➕ Add — Block a command",     value="add"),
        app_commands.Choice(name="🗑️ Delete — Unblock a command", value="delete"),
        app_commands.Choice(name="📋 List — View blocked commands", value="list"),
    ])
    @app_commands.choices(mooncoin_action=[
        app_commands.Choice(name="➕ Add — Create/update a MoonCoin rule",  value="add"),
        app_commands.Choice(name="🗑️ Remove — Delete a MoonCoin rule",      value="remove"),
        app_commands.Choice(name="📋 View — List all MoonCoin rules",       value="view"),
        app_commands.Choice(name="🎁 Grant — Give coins to a user",         value="grant"),
        app_commands.Choice(name="➖ Deduct — Remove coins from a user",    value="deduct"),
    ])
    @app_commands.describe(
        setting           = "Which setting to configure",
        value             = "New value (channel ID, number, command name, role ID, or coin amount)",
        command_dm_action = "For DM Commands setting: prefix | add | remove | list",
        role_action       = "For Role setting: add | remove | list",
        permission        = "Staff role name (for Role setting)",
        option            = "Option modifier (e.g. cooldown seconds for MoonCoin rules)",
        date              = "Schedule date e.g. 2025-12-01",
        time              = "Schedule time e.g. 12:00",
        block_action      = "Add / Delete / List a blocked terminal command",
        mooncoin_action   = "For MoonCoin setting: add | remove | view | grant | deduct",
        target_user       = "Target user for MoonCoin grant/deduct",
    )
    @has_role("Owner", "Admin")
    async def set_cmd(
        self, interaction: discord.Interaction,
        setting:      str,
        value:        str = None,
        option:       str = None,
        date:         str = None,
        time:         str = None,
        block_action:      str = None,
        payment_name:      str = None,
        image:             discord.Attachment = None,
        command_dm_action: str = None,
        role_action:       str = None,
        permission:        str = None,
        mooncoin_action:   str = None,
        target_user:       discord.Member = None,
    ):
        await interaction.response.defer(ephemeral=True)

        # ── Block Terminal Command ────────────────────────────────────────────
        if setting == "block_terminal":
            conn = get_db(); cur = conn.cursor()
            cur.execute("""CREATE TABLE IF NOT EXISTS blocked_commands
                (cmd TEXT PRIMARY KEY, added_by TEXT, added_at TEXT)""")
            conn.commit()

            if block_action == "list" or (not block_action and not value):
                cur.execute("SELECT cmd FROM blocked_commands ORDER BY cmd")
                rows = cur.fetchall()
                conn.close()
                if not rows:
                    return await interaction.followup.send(embed=create_embed(
                        "🚫 Blocked Terminal Commands", "No commands blocked yet."))
                cmds = "\n".join(f"› `{r['cmd']}`" for r in rows)
                return await interaction.followup.send(embed=create_embed(
                    f"🚫 Blocked Commands ({len(rows)})", cmds))

            if not value:
                conn.close()
                return await interaction.followup.send(embed=create_error_embed(
                    "Missing", "Provide `value` = the command to block/unblock."))

            if block_action == "add" or not block_action:
                cur.execute("INSERT OR IGNORE INTO blocked_commands (cmd,added_by,added_at) VALUES (?,?,?)",
                    (value.strip(), str(interaction.user.id), datetime.now().isoformat()))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "Command Blocked", f"`{value}` is now blocked in VPS terminals."))

            elif block_action == "delete":
                cur.execute("DELETE FROM blocked_commands WHERE cmd=?", (value.strip(),))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "Command Unblocked", f"`{value}` is no longer blocked."))

        # ── Backup Limits ────────────────────────────────────────────────────
        if setting == "backup_limits":
            if not value:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `value`."))
            set_setting("backup_limits_enabled", value)
            if option: set_setting("backup_limits_option", option)
            embed = create_success_embed("Backup Limits Updated")
            add_field(embed, "Enabled/Value", value, True)
            if option: add_field(embed, "Option", option, True)
            return await interaction.followup.send(embed=embed)

        # ── Scheduled Backups ────────────────────────────────────────────────
        if setting == "scheduled_backups":
            if not value:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `value`."))
            set_setting("scheduled_backups_enabled", value)
            if option: set_setting("scheduled_backups_option", option)
            if date:   set_setting("scheduled_backups_date", date)
            if time:   set_setting("scheduled_backups_time", time)
            embed = create_success_embed("Scheduled Backups Updated")
            add_field(embed, "Status", value, True)
            if option: add_field(embed, "Frequency", option, True)
            if date:   add_field(embed, "Start Date", date, True)
            if time:   add_field(embed, "Run Time", time, True)
            return await interaction.followup.send(embed=embed)

        # ── AF2F Channel ─────────────────────────────────────────────────────
        if setting == "af2f_channel":
            if str(interaction.user.id) != str(MAIN_ADMIN_ID):
                return await interaction.followup.send(embed=create_error_embed(
                    "🚫 Owner Only",
                    "Only the **bot owner** can configure the AF2F channel."))
            if not value:
                cur_val = get_setting("af2f_channel_id") or "Not set"
                return await interaction.followup.send(embed=create_embed(
                    "🔐 AF2F Channel", f"Current: `{cur_val}`\n\nProvide `value:<channel_id>` to update."))
            set_setting("af2f_channel_id", value.strip())
            return await interaction.followup.send(embed=create_success_embed(
                "✅ AF2F Channel Set",
                f"AF2F codes will be sent to <#{value.strip()}>.\n"
                "Only the bot owner can see and use these codes."))

        # ── MoonCoin Rules ───────────────────────────────────────────────────
        if setting == "mooncoin":
            conn = get_db(); cur = conn.cursor()
            mc_action = (mooncoin_action or "view").lower()

            if mc_action == "view":
                cur.execute("SELECT name, amount, cooldown FROM mooncoin_rules ORDER BY name")
                rows = cur.fetchall()
                embed = create_embed("🌙 MoonCoin Rules", f"**{len(rows)}** rule(s) active")
                for r in rows:
                    cd = f"{r['cooldown']}s cooldown" if r['cooldown'] else "no cooldown"
                    add_field(embed, r['name'], f"`+{r['amount']} coins` · {cd}", True)
                if not rows:
                    embed.description = "No rules defined yet."
                conn.close()
                return await interaction.followup.send(embed=embed)

            elif mc_action == "add":
                if not value:
                    conn.close()
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing", "Provide `value:<rule_name>` and optionally `option:<amount>`."))
                rule_name = value.strip().lower()
                amount    = int(option) if option and str(option).isdigit() else 1
                cur.execute(
                    "INSERT OR REPLACE INTO mooncoin_rules (name, amount, cooldown) VALUES (?,?,?)",
                    (rule_name, amount, 0))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ MoonCoin Rule Added",
                    f"Rule `{rule_name}` → **+{amount} coins**."))

            elif mc_action == "remove":
                if not value:
                    conn.close()
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing", "Provide `value:<rule_name>` to remove."))
                cur.execute("DELETE FROM mooncoin_rules WHERE name=?", (value.strip().lower(),))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ MoonCoin Rule Removed", f"Rule `{value.strip()}` deleted."))

            elif mc_action == "grant":
                if not target_user or not value:
                    conn.close()
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing", "Provide `target_user` and `value:<amount>`."))
                try: amt = int(value)
                except ValueError:
                    conn.close()
                    return await interaction.followup.send(embed=create_error_embed("Invalid", "`value` must be a number."))
                from core.database import add_coins
                add_coins(str(target_user.id), amt)
                conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ Coins Granted", f"**+{amt:,} 🌙** granted to {target_user.mention}."))

            elif mc_action == "deduct":
                if not target_user or not value:
                    conn.close()
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing", "Provide `target_user` and `value:<amount>`."))
                try: amt = int(value)
                except ValueError:
                    conn.close()
                    return await interaction.followup.send(embed=create_error_embed("Invalid", "`value` must be a number."))
                from core.database import add_coins
                add_coins(str(target_user.id), -amt)
                conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ Coins Deducted", f"**-{amt:,} 🌙** removed from {target_user.mention}."))

            conn.close()
            return

        # ── Standard channel/threshold settings ──────────────────────────────
        if not value:
            return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `value`."))

        set_setting(setting, value)

        # Apply main_chat_id at runtime
        if setting == "main_chat_id":
            try:
                import core.config as cfg
                cfg.MAIN_CHAT_ID = int(value)
            except Exception: pass

        labels = {
            "claim_channel":   "🎟️ Claim Channel",
            "log_channel":     "📋 Log Channel",
            "payment_channel": "💳 Payment Channel",
            "ticket_channel":  "🎫 Ticket Category",
            "update_channel":  "📢 Update Channel",
            "main_chat_id":    "💬 Main Chat Channel",
            "cpu_threshold":   "📊 CPU Threshold",
            "ram_threshold":   "📊 RAM Threshold",
        }
        label = labels.get(setting, setting)

        embed = create_success_embed(
            "✅ Setting Updated",
            f"**{label}** has been set to `{value}`."
        )
        embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
        embed.set_footer(text=f"Updated by {interaction.user.display_name} · MoonNodes")

        # Extra note for ticket category
        if setting == "ticket_channel":
            embed.description += (
                "\n\n> This is a **category ID**. New tickets will create channels inside this category."
            )

        await interaction.followup.send(embed=embed)


        # ── User DM Commands ─────────────────────────────────────────────────
        if setting == "user_dm":
            conn = get_db(); cur = conn.cursor()
            cur.execute("""CREATE TABLE IF NOT EXISTS dm_settings
                (key TEXT PRIMARY KEY, value TEXT)""")
            conn.commit()
            action_dm = (command_dm_action or block_action or "list").lower()

            if action_dm == "prefix":
                prefix_val = (value or "!").strip()
                cur.execute("INSERT OR REPLACE INTO dm_settings (key,value) VALUES (?,?)",
                            ("dm_prefix", prefix_val))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "DM Prefix Set",
                    f"Users can now use `{prefix_val}<command>` in DMs.\n"
                    "Make sure **DM Commands** extension is enabled."))

            elif action_dm == "add":
                if not value:
                    conn.close()
                    return await interaction.followup.send(embed=create_error_embed("Missing","Provide `value` = command name."))
                cur.execute("INSERT OR IGNORE INTO dm_settings (key,value) VALUES (?,?)",
                            (f"dm_allow_{value.strip()}", "1"))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "DM Command Allowed", f"`{value}` can now be used in DMs."))

            elif action_dm == "remove":
                if not value:
                    conn.close()
                    return await interaction.followup.send(embed=create_error_embed("Missing","Provide `value` = command name."))
                cur.execute("DELETE FROM dm_settings WHERE key=?", (f"dm_allow_{value.strip()}",))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "DM Command Blocked", f"`{value}` is now blocked in DMs."))

            else:  # list
                cur.execute("SELECT key,value FROM dm_settings")
                rows = [dict(r) for r in cur.fetchall()]; conn.close()
                prefix_row = next((r for r in rows if r["key"]=="dm_prefix"), None)
                allowed    = [r["key"].replace("dm_allow_","") for r in rows if r["key"].startswith("dm_allow_")]
                embed = create_embed("💬 User DM Command Settings","")
                add_field(embed, "Prefix", f"`{prefix_row['value']}`" if prefix_row else "`!` (default)", True)
                add_field(embed, "Allowed Commands", ", ".join(f"`{c}`" for c in allowed) or "All (if extension on)", False)
                return await interaction.followup.send(embed=embed)

        # ── Role ID Setting ──────────────────────────────────────────────────
        if setting == "role_id":
            conn = get_db(); cur = conn.cursor()
            cur.execute("""CREATE TABLE IF NOT EXISTS role_ids
                (role_name TEXT PRIMARY KEY, discord_role_id TEXT)""")
            conn.commit()
            r_action = (role_action or block_action or "list").lower()
            perm = (permission or "").strip()

            if r_action == "add":
                if not perm or not value:
                    conn.close()
                    return await interaction.followup.send(embed=create_error_embed("Missing","Provide `permission` (role name) and `value` (Discord role ID)."))
                cur.execute("INSERT OR REPLACE INTO role_ids (role_name,discord_role_id) VALUES (?,?)", (perm, value.strip()))
                conn.commit()
                # Apply to config at runtime
                from core import config as _cfg
                role_map = {
                    "Owner":"OWNER_ROLE_ID","Hard Admin":"HARD_ADMIN_ROLE_ID",
                    "Admin":"ADMIN_ROLE_ID","Manager":"MANAGER_ROLE_ID",
                    "Hard Mod":"HARD_MOD_ROLE_ID","Mod":"MOD_ROLE_ID",
                    "Hard Staff":"HARD_STAFF_ROLE_ID","Staff":"STAFF_ROLE_ID",
                    "Trial Staff":"TRIAL_STAFF_ROLE_ID","Trial Mod":"TRIAL_MOD_ROLE_ID",
                    "Partner":"PARTNER_ROLE_ID","VIP":"VIP_ROLE_ID",
                }
                if perm in role_map:
                    setattr(_cfg, role_map[perm], int(value.strip()))
                conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ Role ID Set",
                    f"**{perm}** role → Discord role `{value}`\n"
                    "This takes effect immediately — no restart needed."))

            elif r_action == "remove":
                if not perm:
                    conn.close()
                    return await interaction.followup.send(embed=create_error_embed("Missing","Provide `permission` (role name) to remove."))
                cur.execute("DELETE FROM role_ids WHERE role_name=?", (perm,))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed("Role ID Removed",f"**{perm}** role mapping removed."))

            else:  # list
                cur.execute("SELECT * FROM role_ids")
                rows = [dict(r) for r in cur.fetchall()]; conn.close()
                embed = create_embed("🎭 Role ID Mappings",f"**{len(rows)}** role(s) configured")
                for r in rows:
                    add_field(embed, r["role_name"], f"<@&{r['discord_role_id']}> (`{r['discord_role_id']}`)", True)
                if not rows:
                    embed.description = "No role IDs set. Use `permission:RoleName value:DiscordRoleID` to add."
                return await interaction.followup.send(embed=embed)

        # ── Standard channel/threshold settings ──────────────────────────────
        if not value:
            return await interaction.followup.send(embed=create_error_embed("Missing","Provide `value`."))


async def setup(bot):
    await bot.add_cog(SetCog(bot))
