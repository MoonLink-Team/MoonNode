"""
/set — [ADMIN] Configure bot settings.

Fixes & Improvements:
  - command_dm_action: added enable, disable, allow, block actions
  - Removed all conn.close() on thread-local connections (causes pool corruption)
  - mooncoin: fixed conn leak in early-return branches
  - All embed messages reworded for clarity and consistency
  - /set mooncoin now supports set_cooldown action
"""

import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime
import asyncio

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, set_setting, get_setting, get_db
from core.theme import create_success_embed, create_error_embed, create_embed, add_field, Theme
from core.af2f import require_af2f


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if int(uid) == int(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure("🚫 no_permission")
    return app_commands.check(predicate)


# ── Channel Setup View ────────────────────────────────────────────────────────

CHANNEL_SETTINGS = [
    ("log_channel",     "📋 Log Channel",       "Where bot activity is logged"),
    ("payment_channel", "💳 Payment Channel",   "Where payment proof images are posted"),
    ("ticket_channel",  "🎫 Ticket Category",   "Discord category for support tickets"),
    ("update_channel",  "📢 Update Channel",    "For maintenance and update announcements"),
    ("main_chat_id",    "💬 Main Chat Channel", "Chat channel that awards MoonCoins"),
    ("af2f_channel_id", "🔐 AF2F Channel",      "Where admin 2FA verification codes appear"),
    ("claim_channel",   "🎟️ Claim Channel",     "Where users submit free VPS claims"),
]


def _channels_embed() -> discord.Embed:
    embed = discord.Embed(
        title="📡 Channel Configuration",
        description=(
            "Manage all bot channels from one place.\n\n"
            "Press a button to update that channel — you'll be asked to "
            "**send the channel ID** in DM.\n\n"
            "**Current configuration:**"
        ),
        color=Theme.PRIMARY,
        timestamp=datetime.now(),
    )
    embed.set_author(name="MoonNodes — Channel Setup", icon_url="https://imgur.com/6yfYDTP.png")
    for key, label, desc in CHANNEL_SETTINGS:
        val     = get_setting(key) or "Not set"
        mention = f"<#{val}>" if val != "Not set" else "*(not configured)*"
        embed.add_field(name=label, value=f"{mention}\n`{val}`\n*{desc}*", inline=True)
    embed.set_footer(text="Press any button below to update a channel")
    return embed


class ChannelSetupView(discord.ui.View):
    def __init__(self, user_id: str, bot):
        super().__init__(timeout=300)
        self.user_id = user_id
        self.bot     = bot
        for key, label, desc in CHANNEL_SETTINGS:
            btn          = discord.ui.Button(
                label=label,
                style=discord.ButtonStyle.secondary,
                custom_id=f"chset_{key}",
            )
            btn.callback = self._make_callback(key, label)
            self.add_item(btn)

    def _make_callback(self, key: str, label: str):
        async def callback(inter: discord.Interaction):
            if str(inter.user.id) != self.user_id:
                return await inter.response.send_message(
                    embed=create_error_embed("🚫 Access Denied", "Only the person who opened this panel can use these buttons."),
                    ephemeral=True,
                )
            await inter.response.defer(ephemeral=True)
            await inter.followup.send(embed=discord.Embed(
                title=f"📋 Set {label}",
                description=(
                    f"**Send the channel ID for {label} in this DM.**\n\n"
                    "**How to find a channel ID:**\n"
                    "Right-click the channel → **Copy Channel ID**\n"
                    "Then paste just the number here.\n\n"
                    "⏳ *You have 2 minutes.*"
                ),
                color=0x5865F2,
            ), ephemeral=True)

            def _check(m):
                return (
                    m.author.id == inter.user.id
                    and isinstance(m.channel, discord.DMChannel)
                    and m.content.strip().isdigit()
                )
            try:
                msg        = await self.bot.wait_for("message", check=_check, timeout=120)
                channel_id = msg.content.strip()
                set_setting(key, channel_id)
                import core.config as _cfg
                if key == "main_chat_id":
                    try: _cfg.MAIN_CHAT_ID = int(channel_id)
                    except Exception: pass
                await msg.reply(embed=discord.Embed(
                    description=f"✅ **{label}** updated to <#{channel_id}> (`{channel_id}`)",
                    color=Theme.SUCCESS,
                ))
                try:
                    await inter.edit_original_response(embed=_channels_embed(), view=self)
                except Exception:
                    pass
            except asyncio.TimeoutError:
                await inter.followup.send(embed=discord.Embed(
                    description="⏰ Timed out — no channel ID was received.", color=Theme.ERROR), ephemeral=True)
        return callback


# ── Cog ───────────────────────────────────────────────────────────────────────

class SetCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="set", description="[ADMIN] Configure bot settings, channels, MoonCoin rules, and DM permissions")
    @app_commands.choices(setting=[
        app_commands.Choice(name="📡 Channel — Configure all channels in one UI",   value="channel"),
        app_commands.Choice(name="📋 Log Channel",              value="log_channel"),
        app_commands.Choice(name="💳 Payment Channel",          value="payment_channel"),
        app_commands.Choice(name="🎫 Ticket Category",          value="ticket_channel"),
        app_commands.Choice(name="📢 Update Channel",           value="update_channel"),
        app_commands.Choice(name="💬 Main Chat Channel",        value="main_chat_id"),
        app_commands.Choice(name="📊 CPU Alert Threshold %",    value="cpu_threshold"),
        app_commands.Choice(name="📊 RAM Alert Threshold %",    value="ram_threshold"),
        app_commands.Choice(name="💾 Backup Snapshot Limit",    value="backup_limits"),
        app_commands.Choice(name="🕐 Scheduled Backup Time",    value="scheduled_backups"),
        app_commands.Choice(name="🎟️ Claim Channel",            value="claim_channel"),
        app_commands.Choice(name="💬 DM Commands — Manage DM permissions", value="user_dm"),
        app_commands.Choice(name="🌙 MoonCoin — Manage earn rules",        value="mooncoin"),
        app_commands.Choice(name="🔐 AF2F Channel",             value="af2f_channel"),
    ])
    @app_commands.choices(command_dm_action=[
        app_commands.Choice(name="✅ Enable — Allow DM commands globally",        value="enable"),
        app_commands.Choice(name="🚫 Disable — Block all DM commands",            value="disable"),
        app_commands.Choice(name="📋 List — Show current DM settings",            value="list"),
        app_commands.Choice(name="🔑 Set Prefix — Change the DM command prefix",  value="prefix"),
        app_commands.Choice(name="➕ Allow Command — Permit a specific command",  value="allow"),
        app_commands.Choice(name="➖ Block Command — Restrict a specific command", value="block"),
        app_commands.Choice(name="🗑️ Clear — Reset all DM command rules",         value="clear"),
    ])
    @app_commands.choices(mooncoin_action=[
        app_commands.Choice(name="➕ Add — Create or update an earn rule",     value="add"),
        app_commands.Choice(name="⏱️ Set Cooldown — Update a rule's cooldown", value="set_cooldown"),
        app_commands.Choice(name="🗑️ Remove — Delete an earn rule",           value="remove"),
        app_commands.Choice(name="📋 View — List all earn rules",              value="view"),
        app_commands.Choice(name="🎁 Grant — Give MoonCoins to a user",       value="grant"),
        app_commands.Choice(name="➖ Deduct — Remove MoonCoins from a user",  value="deduct"),
    ])
    @app_commands.describe(
        setting           = "Which setting category to configure",
        value             = "New value (channel ID, number, command name, or coin amount)",
        command_dm_action = "DM Commands action to perform",
        option            = "Secondary modifier (e.g. coin amount or cooldown seconds)",
        date              = "Schedule date — e.g. 2025-12-01",
        time              = "Schedule time — e.g. 14:00 or 02:00AM",
        mooncoin_action   = "MoonCoin management action",
        target_user       = "Target user for MoonCoin grant or deduct",
    )
    @has_role("Owner", "Admin")
    async def set_cmd(
        self, interaction: discord.Interaction,
        setting:           str,
        value:             str = None,
        option:            str = None,
        date:              str = None,
        time:              str = None,
        command_dm_action: str = None,
        mooncoin_action:   str = None,
        target_user:       discord.Member = None,
    ):
        uid      = str(interaction.user.id)
        is_owner = (uid == str(MAIN_ADMIN_ID))

        if not is_owner:
            if not await require_af2f(interaction, "set", self.bot):
                return

        await interaction.response.defer(ephemeral=True)

        # ── Channel — All-in-one UI ───────────────────────────────────────────
        if setting == "channel":
            view = ChannelSetupView(uid, self.bot)
            return await interaction.followup.send(embed=_channels_embed(), view=view)

        # ── Backup Snapshot Limit ─────────────────────────────────────────────
        if setting == "backup_limits":
            if not value:
                cur_val = get_setting("backup_limits_value") or "1"
                return await interaction.followup.send(embed=create_embed(
                    "💾 Backup Snapshot Limit",
                    f"**Current limit:** `{cur_val}` snapshot(s) per VPS\n\n"
                    "Provide `value:<number>` to change the limit.\n"
                    "*The **Backup Limits** extension must be enabled for this to take effect.*"
                ))
            set_setting("backup_limits_value", value)
            return await interaction.followup.send(embed=create_success_embed(
                "✅ Backup Limit Updated",
                f"Each VPS is now limited to **{value}** snapshot(s).\n"
                "*Ensure the **Backup Limits** extension is enabled via `/system`.*"
            ))

        # ── Scheduled Backup Time ─────────────────────────────────────────────
        if setting == "scheduled_backups":
            if not time:
                cur_time = get_setting("scheduled_backups_time") or "02:00AM"
                return await interaction.followup.send(embed=create_embed(
                    "🕐 Scheduled Backup Time",
                    f"**Current run time:** `{cur_time}`\n\n"
                    "Provide `time:<HH:MMam/pm>` to update — e.g. `time:02:00AM`.\n"
                    "*Toggle the feature via `/system action:Extension Toggle extension:Scheduled Backups`.*"
                ))
            set_setting("scheduled_backups_time", time)
            return await interaction.followup.send(embed=create_success_embed(
                "✅ Scheduled Backup Time Updated",
                f"Automatic backups will run daily at **{time}**.\n"
                "*Make sure the **Scheduled Backups** extension is enabled.*"
            ))

        # ── AF2F Channel ──────────────────────────────────────────────────────
        if setting == "af2f_channel":
            if not is_owner:
                return await interaction.followup.send(embed=create_error_embed(
                    "🚫 Owner Only",
                    "Only the **bot owner** can configure the AF2F verification channel."
                ))
            if not value:
                cur_val = get_setting("af2f_channel_id") or "Not set"
                return await interaction.followup.send(embed=create_embed(
                    "🔐 AF2F Verification Channel",
                    f"**Current channel:** `{cur_val}`\n\n"
                    "Provide `value:<channel_id>` to update."
                ))
            set_setting("af2f_channel_id", value.strip())
            return await interaction.followup.send(embed=create_success_embed(
                "✅ AF2F Channel Updated",
                f"Admin 2FA codes will now be sent to <#{value.strip()}>.\n"
                "*Only visible to admins with access to that channel.*"
            ))

        # ── MoonCoin Rules ────────────────────────────────────────────────────
        if setting == "mooncoin":
            conn = get_db(); cur = conn.cursor()
            mc_action = (mooncoin_action or "view").lower()

            if mc_action == "view":
                cur.execute("SELECT name, amount, cooldown FROM mooncoin_rules ORDER BY name")
                rows  = cur.fetchall()
                embed = create_embed(
                    "🌙 MoonCoin Earn Rules",
                    f"**{len(rows)}** active rule(s) — users earn coins by triggering these actions."
                )
                for r in rows:
                    cd_text = f"`{r['cooldown']}s` cooldown" if r['cooldown'] else "no cooldown"
                    add_field(embed, r['name'].capitalize(), f"**+{r['amount']} 🌙** · {cd_text}", True)
                if not rows:
                    embed.description = "No earn rules defined yet.\nUse `mooncoin_action: Add` to create one."
                embed.set_footer(text="Use /set setting:MoonCoin mooncoin_action:Add to create a rule")
                return await interaction.followup.send(embed=embed)

            elif mc_action == "add":
                if not value:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing Rule Name", "Provide `value:<rule_name>` — e.g. `value:daily_bonus`."))
                rule_name = value.strip().lower()
                amount    = int(option) if option and str(option).isdigit() else 1
                cur.execute(
                    "INSERT OR REPLACE INTO mooncoin_rules (name,amount,cooldown) VALUES (?,?,?)",
                    (rule_name, amount, 0)
                )
                conn.commit()
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ Earn Rule Saved",
                    f"Rule **`{rule_name}`** now awards **+{amount} 🌙** per trigger.\n"
                    f"*Set a cooldown with `mooncoin_action: Set Cooldown`.*"
                ))

            elif mc_action == "set_cooldown":
                if not value:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing Rule Name", "Provide `value:<rule_name>` and `option:<seconds>`."))
                rule_name = value.strip().lower()
                cooldown  = int(option) if option and str(option).isdigit() else 0
                cur.execute("UPDATE mooncoin_rules SET cooldown=? WHERE name=?", (cooldown, rule_name))
                if cur.rowcount == 0:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Rule Not Found", f"No rule named `{rule_name}` exists. Use `Add` to create it first."))
                conn.commit()
                cd_text = f"**{cooldown}s**" if cooldown else "**no cooldown**"
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ Cooldown Updated",
                    f"Rule **`{rule_name}`** cooldown set to {cd_text}."
                ))

            elif mc_action == "remove":
                if not value:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing Rule Name", "Provide `value:<rule_name>` to delete."))
                cur.execute("DELETE FROM mooncoin_rules WHERE name=?", (value.strip().lower(),))
                conn.commit()
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ Earn Rule Deleted", f"Rule **`{value.strip()}`** has been removed."))

            elif mc_action == "grant":
                if not target_user or not value:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing Parameters", "Provide both `target_user` and `value:<amount>`."))
                try:
                    amt = int(value)
                except ValueError:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Invalid Amount", "`value` must be a whole number — e.g. `value:50`."))
                from core.database import add_coins
                add_coins(str(target_user.id), amt)
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ MoonCoins Granted",
                    f"**+{amt:,} 🌙** have been added to {target_user.mention}'s balance."
                ))

            elif mc_action == "deduct":
                if not target_user or not value:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing Parameters", "Provide both `target_user` and `value:<amount>`."))
                try:
                    amt = int(value)
                except ValueError:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Invalid Amount", "`value` must be a whole number — e.g. `value:25`."))
                from core.database import add_coins
                add_coins(str(target_user.id), -amt)
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ MoonCoins Deducted",
                    f"**-{amt:,} 🌙** have been removed from {target_user.mention}'s balance."
                ))

            return

        # ── User DM Commands ──────────────────────────────────────────────────
        if setting == "user_dm":
            conn    = get_db(); cur = conn.cursor()
            action  = (command_dm_action or "list").lower()

            if action == "enable":
                set_setting("dm_commands_mode", "all")
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ DM Commands Enabled",
                    "Users can now run bot commands in Direct Messages.\n"
                    "*Use `block` to restrict specific commands if needed.*"
                ))

            elif action == "disable":
                set_setting("dm_commands_mode", "disabled")
                return await interaction.followup.send(embed=create_success_embed(
                    "🚫 DM Commands Disabled",
                    "All bot commands in Direct Messages have been blocked.\n"
                    "*Use `enable` to restore DM access.*"
                ))

            elif action == "prefix":
                prefix_val = (value or "!").strip()
                cur.execute(
                    "INSERT OR REPLACE INTO dm_settings (key,value) VALUES (?,?)",
                    ("dm_prefix", prefix_val)
                )
                conn.commit()
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ DM Prefix Updated",
                    f"Users must now use `{prefix_val}<command>` in Direct Messages."
                ))

            elif action == "allow":
                if not value:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing Command Name", "Provide `value:<command_name>` — e.g. `value:status`."))
                cmd_name = value.strip().lower().lstrip("!/")
                cur.execute(
                    "INSERT OR REPLACE INTO dm_settings (key,value) VALUES (?,?)",
                    (f"dm_allow_{cmd_name}", "true")
                )
                conn.commit()
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ Command Allowed in DMs",
                    f"The `{cmd_name}` command is now permitted in Direct Messages."
                ))

            elif action == "block":
                if not value:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing Command Name", "Provide `value:<command_name>` — e.g. `value:create`."))
                cmd_name = value.strip().lower().lstrip("!/")
                cur.execute("DELETE FROM dm_settings WHERE key=?", (f"dm_allow_{cmd_name}",))
                cur.execute(
                    "INSERT OR REPLACE INTO dm_settings (key,value) VALUES (?,?)",
                    (f"dm_block_{cmd_name}", "true")
                )
                conn.commit()
                return await interaction.followup.send(embed=create_success_embed(
                    "🚫 Command Blocked in DMs",
                    f"The `{cmd_name}` command is now blocked in Direct Messages."
                ))

            elif action == "clear":
                cur.execute("DELETE FROM dm_settings WHERE key LIKE 'dm_allow_%' OR key LIKE 'dm_block_%'")
                conn.commit()
                return await interaction.followup.send(embed=create_success_embed(
                    "🗑️ DM Rules Cleared",
                    "All per-command allow/block rules have been removed.\n"
                    "*Global enable/disable and prefix settings are unchanged.*"
                ))

            else:  # list
                mode       = get_setting("dm_commands_mode") or "custom"
                cur.execute("SELECT key, value FROM dm_settings")
                rows       = [dict(r) for r in cur.fetchall()]
                prefix_row = next((r for r in rows if r["key"] == "dm_prefix"), None)
                allowed    = [r["key"].replace("dm_allow_","") for r in rows if r["key"].startswith("dm_allow_")]
                blocked    = [r["key"].replace("dm_block_","") for r in rows if r["key"].startswith("dm_block_")]
                embed      = create_embed("💬 DM Command Settings", "Current Direct Message command configuration:")
                add_field(embed, "Global Mode",       f"`{mode}`",                                                 True)
                add_field(embed, "Command Prefix",    f"`{prefix_row['value']}`" if prefix_row else "`!` (default)", True)
                add_field(embed, "Allowed Commands",  ", ".join(f"`{c}`" for c in allowed) or "*none set*",        False)
                add_field(embed, "Blocked Commands",  ", ".join(f"`{c}`" for c in blocked) or "*none set*",        False)
                embed.set_footer(text="Use command_dm_action options to modify these settings")
                return await interaction.followup.send(embed=embed)

        # ── Standard channel / threshold settings ─────────────────────────────
        if not value:
            return await interaction.followup.send(embed=create_error_embed(
                "Missing Value", "Please provide a `value` for this setting."))

        set_setting(setting, value)

        if setting == "main_chat_id":
            try:
                import core.config as _cfg2
                _cfg2.MAIN_CHAT_ID = int(value)
            except Exception: pass

        LABELS = {
            "claim_channel":   "🎟️ Claim Channel",
            "log_channel":     "📋 Log Channel",
            "payment_channel": "💳 Payment Channel",
            "ticket_channel":  "🎫 Ticket Category",
            "update_channel":  "📢 Update Channel",
            "main_chat_id":    "💬 Main Chat Channel",
            "cpu_threshold":   "📊 CPU Alert Threshold",
            "ram_threshold":   "📊 RAM Alert Threshold",
        }
        label = LABELS.get(setting, setting.replace("_", " ").title())

        embed = create_success_embed(
            "✅ Setting Updated",
            f"**{label}** has been set to `{value}`"
        )
        embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
        embed.set_footer(text=f"Updated by {interaction.user.display_name} · MoonNodes")

        if setting == "ticket_channel":
            embed.description += (
                "\n\n> ⚠️ This is a **category ID**, not a channel ID.\n"
                "> New support tickets will be created inside this category."
            )

        await interaction.followup.send(embed=embed)


async def setup(bot):
    await bot.add_cog(SetCog(bot))
