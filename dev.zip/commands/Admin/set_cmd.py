"""
/set — [ADMIN] Configure bot settings.

Channel setting rework:
  - setting:Channel → shows all channels in one clean UI
  - Each channel has a Set button; user sends ID in DM
  - DM Commands: added "All" action to allow/block all commands at once
"""

import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime
import asyncio

from core.config import MAIN_ADMIN_ID
from core.database import admin_data, set_setting, get_setting, get_db
from core.theme import create_success_embed, create_error_embed, create_embed, add_field, Theme
from core.af2f import require_af2f


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if int(uid) == int(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure("🚫 no_permission")
    return app_commands.check(predicate)


# ── Channel Setup View ────────────────────────────────────────────────────────

CHANNEL_SETTINGS = [
    ("log_channel",     "📋 Log Channel",        "Where bot activity is logged"),
    ("payment_channel", "💳 Payment Channel",    "Where payment proofs are posted"),
    ("ticket_channel",  "🎫 Ticket Category",    "Discord category for support tickets"),
    ("update_channel",  "📢 Update Channel",     "For maintenance/update announcements"),
    ("main_chat_id",    "💬 Main Chat Channel",  "For MoonCoin chat rewards"),
    ("af2f_channel_id", "🔐 AF2F Channel",       "Where admin 2FA codes are posted"),
    ("claim_channel",   "🎟️ Claim Channel",      "Where users claim free VPS"),
]


def _channels_embed() -> discord.Embed:
    embed = discord.Embed(
        title="📡 Channel Configuration",
        description=(
            "Configure all bot channels from one place.\n\n"
            "Click a button to set that channel.\n"
            "You'll be prompted to **send the channel ID** in DM.\n\n"
            "**Current values:**"
        ),
        color=Theme.PRIMARY,
        timestamp=datetime.now(),
    )
    embed.set_author(name="MoonNodes — Channel Setup", icon_url="https://imgur.com/6yfYDTP.png")
    for key, label, desc in CHANNEL_SETTINGS:
        val = get_setting(key) or "Not set"
        mention = f"<#{val}>" if val != "Not set" else "*(not set)*"
        embed.add_field(name=label, value=f"{mention}\n`{val}`\n*{desc}*", inline=True)
    embed.set_footer(text="Click a button below to update a channel")
    return embed


class ChannelSetupView(discord.ui.View):
    def __init__(self, user_id: str, bot):
        super().__init__(timeout=300)
        self.user_id = user_id
        self.bot     = bot
        # Add one button per channel
        for key, label, desc in CHANNEL_SETTINGS:
            btn = discord.ui.Button(
                label=label,
                style=discord.ButtonStyle.secondary,
                custom_id=f"chset_{key}",
            )
            btn.callback = self._make_callback(key, label)
            self.add_item(btn)

    def _make_callback(self, key: str, label: str):
        async def callback(inter: discord.Interaction):
            if str(inter.user.id) != self.user_id:
                return await inter.response.send_message("Permission denied.", ephemeral=True)

            await inter.response.defer(ephemeral=True)
            await inter.followup.send(embed=discord.Embed(
                title=f"Setting {label}",
                description=(
                    f"**Send the channel ID for {label} in this DM.**\n\n"
                    "Right-click the channel in Discord → **Copy ID**\n"
                    "Then send just the number here.\n\n"
                    "⏳ *You have 2 minutes.*"
                ),
                color=0x5865F2,
            ), ephemeral=True)

            def _check(m):
                return (
                    m.author.id == inter.user.id
                    and isinstance(m.channel, discord.DMChannel)
                    and m.content.strip().isdigit()
                )
            try:
                msg = await self.bot.wait_for("message", check=_check, timeout=120)
                channel_id = msg.content.strip()
                set_setting(key, channel_id)
                # Apply runtime updates
                import core.config as _cfg
                if key == "main_chat_id":
                    try: _cfg.MAIN_CHAT_ID = int(channel_id)
                    except Exception: pass

                await msg.reply(embed=discord.Embed(
                    description=f"✅ **{label}** set to <#{channel_id}> (`{channel_id}`)",
                    color=Theme.SUCCESS,
                ))
                # Refresh the main embed
                try:
                    await inter.edit_original_response(embed=_channels_embed(), view=self)
                except Exception:
                    pass
            except asyncio.TimeoutError:
                await inter.followup.send(embed=discord.Embed(
                    description="⏰ Timed out — no channel ID received.", color=Theme.ERROR), ephemeral=True)
        return callback


# ── Cog ───────────────────────────────────────────────────────────────────────

class SetCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="set", description="[ADMIN] Configure bot settings, channels, and thresholds")
    @app_commands.choices(setting=[
        app_commands.Choice(name="📡 Channel — Configure all channels in one UI",   value="channel"),
        app_commands.Choice(name="📋 Log Channel",              value="log_channel"),
        app_commands.Choice(name="💳 Payment Channel",          value="payment_channel"),
        app_commands.Choice(name="🎫 Ticket Category",          value="ticket_channel"),
        app_commands.Choice(name="📢 Update Channel",           value="update_channel"),
        app_commands.Choice(name="💬 Main Chat Channel",        value="main_chat_id"),
        app_commands.Choice(name="📊 CPU Threshold %",          value="cpu_threshold"),
        app_commands.Choice(name="📊 RAM Threshold %",          value="ram_threshold"),
        app_commands.Choice(name="💾 Backup Limits",            value="backup_limits"),
        app_commands.Choice(name="🕐 Scheduled Backups",        value="scheduled_backups"),
        app_commands.Choice(name="🎟️ Claim Channel",           value="claim_channel"),
        app_commands.Choice(name="🚫 Block Terminal Command",   value="block_terminal"),
        app_commands.Choice(name="💬 DM Commands",             value="user_dm"),
        app_commands.Choice(name="🎭 Role — Set Discord role ID", value="role_id"),
        app_commands.Choice(name="🌙 MoonCoin — Manage earn rules", value="mooncoin"),
        app_commands.Choice(name="🔐 AF2F Channel",            value="af2f_channel"),
    ])
    @app_commands.choices(command_dm_action=[
        app_commands.Choice(name="✅ All — Allow all commands in DMs",   value="all"),
        app_commands.Choice(name="🚫 None — Block all commands in DMs", value="none"),
        app_commands.Choice(name="PREFIX — Set DM command prefix",      value="prefix"),
        app_commands.Choice(name="➕ Add — Allow a specific command",    value="add"),
        app_commands.Choice(name="🗑️ Remove — Block a specific command", value="remove"),
        app_commands.Choice(name="📋 List — Show DM settings",          value="list"),
    ])
    @app_commands.choices(block_action=[
        app_commands.Choice(name="➕ Add — Block a command",      value="add"),
        app_commands.Choice(name="🗑️ Delete — Unblock a command", value="delete"),
        app_commands.Choice(name="📋 List — View blocked",        value="list"),
    ])
    @app_commands.choices(mooncoin_action=[
        app_commands.Choice(name="➕ Add — Create/update a rule",  value="add"),
        app_commands.Choice(name="🗑️ Remove — Delete a rule",     value="remove"),
        app_commands.Choice(name="📋 View — List all rules",       value="view"),
        app_commands.Choice(name="🎁 Grant — Give coins to user",  value="grant"),
        app_commands.Choice(name="➖ Deduct — Remove coins",       value="deduct"),
    ])
    @app_commands.describe(
        setting           = "Which setting to configure",
        value             = "New value (channel ID, number, command name, role ID, or amount)",
        command_dm_action = "For DM Commands: all | none | prefix | add | remove | list",
        role_action       = "For Role setting: add | remove | list",
        permission        = "Staff role name (for Role setting)",
        option            = "Option modifier",
        date              = "Schedule date e.g. 2025-12-01",
        time              = "Schedule time e.g. 12:00",
        block_action      = "Add / Delete / List a blocked terminal command",
        mooncoin_action   = "MoonCoin action",
        target_user       = "Target user for MoonCoin grant/deduct",
    )
    @has_role("Owner", "Admin")
    async def set_cmd(
        self, interaction: discord.Interaction,
        setting:           str,
        value:             str = None,
        option:            str = None,
        date:              str = None,
        time:              str = None,
        block_action:      str = None,
        command_dm_action: str = None,
        role_action:       str = None,
        permission:        str = None,
        mooncoin_action:   str = None,
        target_user:       discord.Member = None,
    ):
        uid      = str(interaction.user.id)
        is_owner = (uid == str(MAIN_ADMIN_ID))

        # AF2F gate
        if not is_owner:
            if not await require_af2f(interaction, "set", self.bot):
                return

        await interaction.response.defer(ephemeral=True)

        # ── Channel — All-in-one UI ───────────────────────────────────────────
        if setting == "channel":
            view = ChannelSetupView(uid, self.bot)
            return await interaction.followup.send(
                embed=_channels_embed(), view=view)

        # ── Block Terminal Command ────────────────────────────────────────────
        if setting == "block_terminal":
            conn = get_db(); cur = conn.cursor()
            cur.execute("""CREATE TABLE IF NOT EXISTS blocked_commands
                (cmd TEXT PRIMARY KEY, added_by TEXT, added_at TEXT)""")
            conn.commit()

            if block_action == "list" or (not block_action and not value):
                cur.execute("SELECT cmd FROM blocked_commands ORDER BY cmd")
                rows = cur.fetchall(); conn.close()
                cmds = "\n".join(f"› `{r['cmd']}`" for r in rows) or "*None blocked*"
                return await interaction.followup.send(embed=create_embed(
                    f"🚫 Blocked Commands ({len(rows)})", cmds))

            if not value:
                conn.close()
                return await interaction.followup.send(embed=create_error_embed(
                    "Missing", "Provide `value` = the command to block/unblock."))

            if block_action == "add" or not block_action:
                cur.execute("INSERT OR IGNORE INTO blocked_commands (cmd,added_by,added_at) VALUES (?,?,?)",
                    (value.strip(), uid, datetime.now().isoformat()))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "Command Blocked", f"`{value}` is now blocked in VPS terminals."))

            elif block_action == "delete":
                cur.execute("DELETE FROM blocked_commands WHERE cmd=?", (value.strip(),))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "Command Unblocked", f"`{value}` is no longer blocked."))

        # ── Backup Limits ─────────────────────────────────────────────────────
        if setting == "backup_limits":
            if not value:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `value`."))
            set_setting("backup_limits_enabled", value)
            if option: set_setting("backup_limits_option", option)
            embed = create_success_embed("Backup Limits Updated")
            add_field(embed, "Value", value, True)
            if option: add_field(embed, "Option", option, True)
            return await interaction.followup.send(embed=embed)

        # ── Scheduled Backups ─────────────────────────────────────────────────
        if setting == "scheduled_backups":
            if not value:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `value`."))
            set_setting("scheduled_backups_enabled", value)
            if option: set_setting("scheduled_backups_option", option)
            if date:   set_setting("scheduled_backups_date", date)
            if time:   set_setting("scheduled_backups_time", time)
            embed = create_success_embed("Scheduled Backups Updated")
            add_field(embed, "Status", value, True)
            if option: add_field(embed, "Frequency", option, True)
            if date:   add_field(embed, "Start Date", date, True)
            if time:   add_field(embed, "Run Time", time, True)
            return await interaction.followup.send(embed=embed)

        # ── AF2F Channel ──────────────────────────────────────────────────────
        if setting == "af2f_channel":
            if not is_owner:
                return await interaction.followup.send(embed=create_error_embed(
                    "🚫 Owner Only", "Only the **bot owner** can configure the AF2F channel."))
            if not value:
                cur_val = get_setting("af2f_channel_id") or "Not set"
                return await interaction.followup.send(embed=create_embed(
                    "🔐 AF2F Channel",
                    f"**Current:** `{cur_val}`\n\nProvide `value:<channel_id>` to update."))
            set_setting("af2f_channel_id", value.strip())
            return await interaction.followup.send(embed=create_success_embed(
                "✅ AF2F Channel Set",
                f"AF2F codes will be sent to <#{value.strip()}>.\n"
                "Only visible in that channel."))

        # ── MoonCoin Rules ────────────────────────────────────────────────────
        if setting == "mooncoin":
            conn = get_db(); cur = conn.cursor()
            mc_action = (mooncoin_action or "view").lower()

            if mc_action == "view":
                cur.execute("SELECT name, amount, cooldown FROM mooncoin_rules ORDER BY name")
                rows = cur.fetchall()
                embed = create_embed("🌙 MoonCoin Rules", f"**{len(rows)}** rule(s)")
                for r in rows:
                    cd = f"{r['cooldown']}s cooldown" if r['cooldown'] else "no cooldown"
                    add_field(embed, r['name'], f"`+{r['amount']} coins` · {cd}", True)
                if not rows: embed.description = "No rules defined yet."
                conn.close()
                return await interaction.followup.send(embed=embed)

            elif mc_action == "add":
                if not value: conn.close(); return await interaction.followup.send(
                    embed=create_error_embed("Missing", "Provide `value:<rule_name>`."))
                rule_name = value.strip().lower()
                amount    = int(option) if option and str(option).isdigit() else 1
                cur.execute("INSERT OR REPLACE INTO mooncoin_rules (name,amount,cooldown) VALUES (?,?,?)",
                    (rule_name, amount, 0))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ Rule Added", f"`{rule_name}` → **+{amount} coins**."))

            elif mc_action == "remove":
                if not value: conn.close(); return await interaction.followup.send(
                    embed=create_error_embed("Missing", "Provide `value:<rule_name>`."))
                cur.execute("DELETE FROM mooncoin_rules WHERE name=?", (value.strip().lower(),))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ Rule Removed", f"`{value.strip()}` deleted."))

            elif mc_action == "grant":
                if not target_user or not value: conn.close(); return await interaction.followup.send(
                    embed=create_error_embed("Missing", "Provide `target_user` and `value:<amount>`."))
                try: amt = int(value)
                except ValueError: conn.close(); return await interaction.followup.send(
                    embed=create_error_embed("Invalid", "`value` must be a number."))
                from core.database import add_coins
                add_coins(str(target_user.id), amt); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ Coins Granted", f"**+{amt:,} 🌙** granted to {target_user.mention}."))

            elif mc_action == "deduct":
                if not target_user or not value: conn.close(); return await interaction.followup.send(
                    embed=create_error_embed("Missing", "Provide `target_user` and `value:<amount>`."))
                try: amt = int(value)
                except ValueError: conn.close(); return await interaction.followup.send(
                    embed=create_error_embed("Invalid", "`value` must be a number."))
                from core.database import add_coins
                add_coins(str(target_user.id), -amt); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ Coins Deducted", f"**-{amt:,} 🌙** removed from {target_user.mention}."))

            conn.close(); return

        # ── User DM Commands ──────────────────────────────────────────────────
        if setting == "user_dm":
            conn = get_db(); cur = conn.cursor()
            cur.execute("""CREATE TABLE IF NOT EXISTS dm_settings
                (key TEXT PRIMARY KEY, value TEXT)""")
            conn.commit()
            action_dm = (command_dm_action or "list").lower()

            if action_dm == "all":
                # Allow ALL commands in DMs
                set_setting("dm_commands_mode", "all")
                conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ DM Commands — All Allowed",
                    "All commands are now allowed in DMs.\n"
                    "Make sure the **DM Commands** extension is enabled."))

            elif action_dm == "none":
                # Block ALL commands in DMs
                set_setting("dm_commands_mode", "none")
                conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "🚫 DM Commands — All Blocked",
                    "All commands are now blocked in DMs."))

            elif action_dm == "prefix":
                prefix_val = (value or "!").strip()
                cur.execute("INSERT OR REPLACE INTO dm_settings (key,value) VALUES (?,?)",
                    ("dm_prefix", prefix_val))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "DM Prefix Set",
                    f"Users can now use `{prefix_val}<command>` in DMs."))

            elif action_dm == "add":
                if not value: conn.close(); return await interaction.followup.send(
                    embed=create_error_embed("Missing", "Provide `value` = command name."))
                cur.execute("INSERT OR IGNORE INTO dm_settings (key,value) VALUES (?,?)",
                    (f"dm_allow_{value.strip()}", "1"))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "DM Command Allowed", f"`{value}` can now be used in DMs."))

            elif action_dm == "remove":
                if not value: conn.close(); return await interaction.followup.send(
                    embed=create_error_embed("Missing", "Provide `value` = command name."))
                cur.execute("DELETE FROM dm_settings WHERE key=?", (f"dm_allow_{value.strip()}",))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "DM Command Blocked", f"`{value}` is now blocked in DMs."))

            else:  # list
                cur.execute("SELECT key,value FROM dm_settings")
                rows       = [dict(r) for r in cur.fetchall()]; conn.close()
                mode       = get_setting("dm_commands_mode") or "custom"
                prefix_row = next((r for r in rows if r["key"] == "dm_prefix"), None)
                allowed    = [r["key"].replace("dm_allow_","") for r in rows if r["key"].startswith("dm_allow_")]
                embed      = create_embed("💬 DM Command Settings", "")
                add_field(embed, "Mode",    f"`{mode}`",                                                         True)
                add_field(embed, "Prefix",  f"`{prefix_row['value']}`" if prefix_row else "`!` (default)",       True)
                add_field(embed, "Allowed", ", ".join(f"`{c}`" for c in allowed) or "All (if mode=all)",         False)
                return await interaction.followup.send(embed=embed)

        # ── Role ID Setting ───────────────────────────────────────────────────
        if setting == "role_id":
            conn = get_db(); cur = conn.cursor()
            cur.execute("""CREATE TABLE IF NOT EXISTS role_ids
                (role_name TEXT PRIMARY KEY, discord_role_id TEXT)""")
            conn.commit()
            r_action = (role_action or "list").lower()
            perm     = (permission or "").strip()

            if r_action == "add":
                if not perm or not value: conn.close(); return await interaction.followup.send(
                    embed=create_error_embed("Missing", "Provide `permission` and `value` (Discord role ID)."))
                cur.execute("INSERT OR REPLACE INTO role_ids (role_name,discord_role_id) VALUES (?,?)", (perm, value.strip()))
                conn.commit()
                import core.config as _cfg
                ROLE_MAP = {
                    "Owner":"OWNER_ROLE_ID","Hard Admin":"HARD_ADMIN_ROLE_ID",
                    "Admin":"ADMIN_ROLE_ID","Manager":"MANAGER_ROLE_ID",
                    "Hard Mod":"HARD_MOD_ROLE_ID","Mod":"MOD_ROLE_ID",
                    "Hard Staff":"HARD_STAFF_ROLE_ID","Staff":"STAFF_ROLE_ID",
                    "Trial Staff":"TRIAL_STAFF_ROLE_ID","Trial Mod":"TRIAL_MOD_ROLE_ID",
                    "Partner":"PARTNER_ROLE_ID","VIP":"VIP_ROLE_ID",
                }
                if perm in ROLE_MAP:
                    setattr(_cfg, ROLE_MAP[perm], int(value.strip()))
                conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ Role ID Set",
                    f"**{perm}** → <@&{value.strip()}>\nTakes effect immediately."))

            elif r_action == "remove":
                if not perm: conn.close(); return await interaction.followup.send(
                    embed=create_error_embed("Missing", "Provide `permission` to remove."))
                cur.execute("DELETE FROM role_ids WHERE role_name=?", (perm,))
                conn.commit(); conn.close()
                return await interaction.followup.send(embed=create_success_embed(
                    "Role Removed", f"**{perm}** mapping removed."))

            else:  # list
                cur.execute("SELECT * FROM role_ids")
                rows = [dict(r) for r in cur.fetchall()]; conn.close()
                embed = create_embed("🎭 Role ID Mappings", f"**{len(rows)}** role(s) configured")
                for r in rows:
                    add_field(embed, r["role_name"], f"<@&{r['discord_role_id']}> (`{r['discord_role_id']}`)", True)
                if not rows: embed.description = "No role IDs set yet."
                return await interaction.followup.send(embed=embed)

        # ── Standard channel / threshold settings ─────────────────────────────
        if not value:
            return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `value`."))

        set_setting(setting, value)

        if setting == "main_chat_id":
            try:
                import core.config as _cfg2
                _cfg2.MAIN_CHAT_ID = int(value)
            except Exception: pass

        LABELS = {
            "claim_channel":   "🎟️ Claim Channel",
            "log_channel":     "📋 Log Channel",
            "payment_channel": "💳 Payment Channel",
            "ticket_channel":  "🎫 Ticket Category",
            "update_channel":  "📢 Update Channel",
            "main_chat_id":    "💬 Main Chat Channel",
            "cpu_threshold":   "📊 CPU Threshold",
            "ram_threshold":   "📊 RAM Threshold",
        }
        label = LABELS.get(setting, setting)

        embed = create_success_embed(
            "✅ Setting Updated",
            f"**{label}** → `{value}`"
        )
        embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
        embed.set_footer(text=f"Updated by {interaction.user.display_name} · MoonNodes")

        if setting == "ticket_channel":
            embed.description += "\n\n> This is a **category ID**. New tickets open inside this category."

        await interaction.followup.send(embed=embed)


async def setup(bot):
    await bot.add_cog(SetCog(bot))
