"""
/set — [ADMIN] Bot settings.

Channel flow:
  /set setting:Channel
    → Select which channel to configure (dropdown)
    → Pick the Discord channel using the native channel picker
    → Done — no IDs needed

All individual channel choices removed from setting list.
"""

import discord
from discord import app_commands
from discord.ext import commands
from datetime import datetime

from core.config   import MAIN_ADMIN_ID
from core.database import admin_data, set_setting, get_setting, get_db, add_coins
from core.theme    import create_success_embed, create_error_embed, create_embed, add_field, Theme
from core.af2f     import require_af2f


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if int(uid) == int(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure("🚫 no_permission")
    return app_commands.check(predicate)


# ── Channel definitions ────────────────────────────────────────────────────────

CHANNEL_DEFS = [
    ("log_channel",     "📋 Log Channel",       "Bot activity, audit events, and admin actions",  discord.ChannelType.text),
    ("payment_channel", "💳 Payment Channel",   "Where payment proof images are posted",           discord.ChannelType.text),
    ("ticket_channel",  "🎫 Ticket Category",   "Category where support ticket channels are created", discord.ChannelType.category),
    ("update_channel",  "📢 Update Channel",    "Maintenance notices and bot announcements",       discord.ChannelType.text),
    ("main_chat_id",    "💬 Main Chat Channel", "Chat channel that awards MoonCoins per message", discord.ChannelType.text),
    ("claim_channel",   "🎟️ Claim Channel",     "Where free VPS claim requests are posted",        discord.ChannelType.text),
    ("af2f_channel_id", "🔐 AF2F Channel",      "Where admin 2FA codes are sent (owner-visible)",  discord.ChannelType.text),
]


def _channels_overview_embed() -> discord.Embed:
    """Build the overview embed showing all current channel configs."""
    embed = discord.Embed(
        title="📡 Channel Configuration",
        description=(
            "Pick which channel to configure from the dropdown below.\n"
            "You'll then select the Discord channel directly — no IDs needed.\n\n"
            "**Current configuration:**"
        ),
        color=Theme.PRIMARY,
        timestamp=datetime.now(),
    )
    embed.set_author(name="MoonNodes · Channels", icon_url="https://imgur.com/6yfYDTP.png")
    for key, label, desc, _ in CHANNEL_DEFS:
        val     = get_setting(key)
        mention = f"<#{val}>" if val else "*(not set)*"
        embed.add_field(
            name=label,
            value=f"{mention}\n*{desc}*",
            inline=True,
        )
    embed.set_footer(text="Pick type → select channel")
    return embed


# ── Step 1: channel type select ────────────────────────────────────────────────

class ChannelTypeSelect(discord.ui.Select):
    def __init__(self, admin_id: str):
        self.admin_id = admin_id
        options = [
            discord.SelectOption(
                label=label,
                value=key,
                description=desc[:100],
            )
            for key, label, desc, _ in CHANNEL_DEFS
        ]
        super().__init__(
            placeholder="▼  Which channel do you want to configure?",
            options=options,
            min_values=1,
            max_values=1,
        )

    async def callback(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.admin_id:
            return await interaction.response.send_message(
                embed=create_error_embed("Access Denied", "Only the admin who opened this panel can use it."),
                ephemeral=True,
            )

        key   = self.values[0]
        entry = next(d for d in CHANNEL_DEFS if d[0] == key)
        _, label, desc, ch_type = entry

        # Step 2: show a ChannelSelect for the chosen type
        view = ChannelPickView(self.admin_id, key, label, ch_type)
        embed = discord.Embed(
            title=f"📡 Set {label}",
            description=(
                f"**{desc}**\n\n"
                f"Select the {'category' if ch_type == discord.ChannelType.category else 'channel'} "
                f"below to use as the **{label}**.\n\n"
                f"Current: {f'<#{get_setting(key)}>' if get_setting(key) else '*(not set)*'}"
            ),
            color=0x5865F2,
            timestamp=datetime.now(),
        )
        embed.set_author(name="MoonNodes · Channels", icon_url="https://imgur.com/6yfYDTP.png")
        embed.set_footer(text="Select a channel below · Click ← Back to return to the overview")
        await interaction.response.edit_message(embed=embed, view=view)


class ChannelTypeView(discord.ui.View):
    def __init__(self, admin_id: str):
        super().__init__(timeout=300)
        self.add_item(ChannelTypeSelect(admin_id))


# ── Step 2: Discord channel picker ────────────────────────────────────────────

class ChannelPickView(discord.ui.View):
    def __init__(self, admin_id: str, key: str, label: str, ch_type: discord.ChannelType):
        super().__init__(timeout=300)
        self.admin_id = admin_id
        self.key      = key
        self.label    = label

        # Native Discord channel select — users see a proper channel list, no typing IDs
        channel_types = [ch_type] if ch_type == discord.ChannelType.category else [
            discord.ChannelType.text,
            discord.ChannelType.news,
        ]
        picker = discord.ui.ChannelSelect(
            placeholder=f"▼  Select the {label}",
            channel_types=channel_types,
        )
        picker.callback = self._on_pick
        self.add_item(picker)

    @discord.ui.button(label="← Back", style=discord.ButtonStyle.secondary, row=1)
    async def back_btn(self, inter: discord.Interaction, _: discord.ui.Button):
        if str(inter.user.id) != self.admin_id:
            return await inter.response.send_message(
                embed=create_error_embed("Access Denied", "Only the admin who opened this panel can use it."),
                ephemeral=True,
            )
        view = ChannelTypeView(self.admin_id)
        await inter.response.edit_message(embed=_channels_overview_embed(), view=view)

    async def _on_pick(self, interaction: discord.Interaction):
        if str(interaction.user.id) != self.admin_id:
            return await interaction.response.send_message(
                embed=create_error_embed("Access Denied", "Only the admin who opened this panel can use it."),
                ephemeral=True,
            )

        channel    = interaction.data["resolved"]["channels"]
        channel_id = list(channel.keys())[0]
        ch_mention = f"<#{channel_id}>"

        set_setting(self.key, channel_id)

        # Live-update MAIN_CHAT_ID so MoonCoin earning works immediately
        if self.key == "main_chat_id":
            try:
                import core.config as _cfg
                _cfg.MAIN_CHAT_ID = int(channel_id)
            except Exception:
                pass

        # Audit log
        try:
            from core.audit import audit
            await audit(
                interaction,
                action  = "Setting Changed",
                target  = self.label,
                details = f"Set to {ch_mention} (`{channel_id}`)",
                color   = Theme.SUCCESS,
            )
        except Exception:
            pass

        # Rebuild overview with updated values
        done_embed = _channels_overview_embed()
        done_embed.description = (
            f"✅ **{self.label}** updated to {ch_mention}\n\n"
            "Pick another channel to configure, or dismiss this panel.\n\n"
            "**Current configuration:**"
        )
        # Go back to type picker so they can configure more channels
        view = ChannelTypeView(self.admin_id)
        await interaction.response.edit_message(embed=done_embed, view=view)


# ── Cog ───────────────────────────────────────────────────────────────────────

class SetCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(
        name="set",
        description="[ADMIN] Bot settings: channels · coins · DMs",
    )
    @app_commands.choices(setting=[
        app_commands.Choice(name="📡 Channel       — Configure bot channels",              value="channel"),
        app_commands.Choice(name="📊 CPU Threshold — Alert % for CPU usage",              value="cpu_threshold"),
        app_commands.Choice(name="📊 RAM Threshold — Alert % for RAM usage",              value="ram_threshold"),
        app_commands.Choice(name="💾 Backup Limit  — Max snapshots per VPS",             value="backup_limits"),
        app_commands.Choice(name="🕐 Backup Time   — Daily scheduled backup time",        value="scheduled_backups"),
        app_commands.Choice(name="💬 DM Commands   — Manage DM command permissions",      value="user_dm"),
        app_commands.Choice(name="🌙 MoonCoin      — Manage earn rules and balances",     value="mooncoin"),
    ])
    @app_commands.choices(command_dm_action=[
        app_commands.Choice(name="✅ Enable  — Allow DM commands globally",        value="enable"),
        app_commands.Choice(name="🚫 Disable — Block all DM commands",             value="disable"),
        app_commands.Choice(name="📋 List    — Show current DM settings",          value="list"),
        app_commands.Choice(name="🔑 Prefix  — Change the DM command prefix",      value="prefix"),
        app_commands.Choice(name="➕ Allow   — Permit a specific command in DMs",  value="allow"),
        app_commands.Choice(name="➖ Block   — Restrict a specific command in DMs",value="block"),
        app_commands.Choice(name="🗑️ Clear   — Reset all DM command rules",        value="clear"),
    ])
    @app_commands.choices(mooncoin_action=[
        app_commands.Choice(name="📋 View        — List all earn rules",              value="view"),
        app_commands.Choice(name="➕ Add         — Create or update an earn rule",   value="add"),
        app_commands.Choice(name="⏱️ Set Cooldown — Update a rule's cooldown",       value="set_cooldown"),
        app_commands.Choice(name="🗑️ Remove      — Delete an earn rule",             value="remove"),
        app_commands.Choice(name="🎁 Grant       — Give MoonCoins to a user",        value="grant"),
        app_commands.Choice(name="➖ Deduct      — Remove MoonCoins from a user",   value="deduct"),
    ])
    @app_commands.describe(
        setting           = "Which setting to configure",
        value             = "New value — number, command name, or coin amount",
        option            = "Secondary value — e.g. coin amount or cooldown in seconds",
        time              = "Time for scheduled backups — e.g. 02:00AM",
        command_dm_action = "DM Commands action",
        mooncoin_action   = "MoonCoin action",
        target_user       = "Target user for MoonCoin grant or deduct",
    )
    @has_role("Owner", "Admin")
    async def set_cmd(
        self, interaction: discord.Interaction,
        setting:           str,
        value:             str            = None,
        option:            str            = None,
        time:              str            = None,
        command_dm_action: str            = None,
        mooncoin_action:   str            = None,
        target_user:       discord.Member = None,
    ):
        uid      = str(interaction.user.id)
        is_owner = (uid == str(MAIN_ADMIN_ID))

        if not is_owner:
            if not await require_af2f(interaction, "set", self.bot):
                return

        await interaction.response.defer(ephemeral=True)

        # ── 📡 CHANNEL ────────────────────────────────────────────────────────
        if setting == "channel":
            view = ChannelTypeView(uid)
            return await interaction.followup.send(
                embed=_channels_overview_embed(), view=view, ephemeral=True,
            )

        # ── 💾 BACKUP LIMIT ───────────────────────────────────────────────────
        if setting == "backup_limits":
            cur_val = get_setting("backup_limits_value") or "1"
            if not value:
                return await interaction.followup.send(embed=create_embed(
                    "💾 Backup Snapshot Limit",
                    f"**Current limit:** `{cur_val}` snapshot(s) per VPS\n\n"
                    "Provide `value:<number>` to change.\n"
                    "*Enable the **Backup Limits** extension via `/system`.*"
                ))
            set_setting("backup_limits_value", value)
            return await interaction.followup.send(embed=create_success_embed(
                "✅ Backup Limit Updated",
                f"Each VPS is now limited to **{value}** snapshot(s).\n"
                "*Make sure the **Backup Limits** extension is enabled.*"
            ))

        # ── 🕐 SCHEDULED BACKUP TIME ──────────────────────────────────────────
        if setting == "scheduled_backups":
            cur_time = get_setting("scheduled_backups_time") or "02:00AM"
            if not time:
                return await interaction.followup.send(embed=create_embed(
                    "🕐 Scheduled Backup Time",
                    f"**Current run time:** `{cur_time}`\n\n"
                    "Provide `time:<HH:MMam/pm>` to update — e.g. `02:00AM`.\n"
                    "*Toggle via `/system action:Extension Toggle extension:Scheduled Backups`.*"
                ))
            set_setting("scheduled_backups_time", time)
            return await interaction.followup.send(embed=create_success_embed(
                "✅ Scheduled Backup Time Updated",
                f"Automatic backups will run daily at **{time}**.\n"
                "*Make sure the Scheduled Backups extension is enabled.*"
            ))

        # ── 📊 CPU / RAM THRESHOLD ────────────────────────────────────────────
        if setting in ("cpu_threshold", "ram_threshold"):
            kind    = "CPU" if setting == "cpu_threshold" else "RAM"
            cur_val = get_setting(setting) or ("90" if setting == "cpu_threshold" else "90")
            if not value:
                return await interaction.followup.send(embed=create_embed(
                    f"📊 {kind} Alert Threshold",
                    f"**Current threshold:** `{cur_val}%`\n\n"
                    f"Provide `value:<0–100>` to change the alert threshold.\n"
                    f"Users are DM'd when their VPS {kind} exceeds this percentage.\n"
                    f"*Enable **VPS Monitoring** via `/system` for alerts to work.*"
                ))
            try:
                pct = int(value)
                if not 1 <= pct <= 100:
                    raise ValueError
            except ValueError:
                return await interaction.followup.send(embed=create_error_embed(
                    "Invalid Value", "`value` must be a whole number between `1` and `100`."
                ))
            set_setting(setting, str(pct))
            import core.config as _cfg
            if setting == "cpu_threshold":
                _cfg.CPU_THRESHOLD = float(pct)
            else:
                _cfg.RAM_THRESHOLD = float(pct)
            return await interaction.followup.send(embed=create_success_embed(
                f"✅ {kind} Threshold Updated",
                f"VPS {kind} alerts will now fire when usage exceeds **{pct}%**."
            ))

        # ── 🌙 MOONCOIN ───────────────────────────────────────────────────────
        if setting == "mooncoin":
            conn      = get_db()
            cur       = conn.cursor()
            mc_action = (mooncoin_action or "view").lower()

            if mc_action == "view":
                cur.execute("SELECT name, amount, cooldown FROM mooncoin_rules ORDER BY name")
                rows  = cur.fetchall()
                embed = create_embed(
                    "🌙 MoonCoin Earn Rules",
                    f"**{len(rows)}** active rule(s)." if rows else
                    "No earn rules yet.\nUse `mooncoin_action:Add` to create one."
                )
                for r in rows:
                    cd = f"`{r['cooldown']}s` cooldown" if r["cooldown"] else "no cooldown"
                    add_field(embed, r["name"].capitalize(), f"**+{r['amount']} 🌙** · {cd}", True)
                embed.set_footer(text="/set setting:MoonCoin mooncoin_action:Add to create a rule")
                return await interaction.followup.send(embed=embed)

            elif mc_action == "add":
                if not value:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing Rule Name",
                        "Provide `value:<rule_name>` — e.g. `value:daily_bonus`.\n"
                        "Optionally set `option:<amount>` (default: 1 coin)."
                    ))
                rule_name = value.strip().lower()
                amount    = int(option) if option and option.isdigit() else 1
                cur.execute(
                    "INSERT OR REPLACE INTO mooncoin_rules (name,amount,cooldown) VALUES (?,?,?)",
                    (rule_name, amount, 0),
                )
                conn.commit()
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ Earn Rule Saved",
                    f"Rule **`{rule_name}`** awards **+{amount} 🌙** per trigger.\n"
                    "Set a cooldown with `mooncoin_action:Set Cooldown`."
                ))

            elif mc_action == "set_cooldown":
                if not value:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing Rule Name",
                        "Provide `value:<rule_name>` and `option:<seconds>`."
                    ))
                rule_name = value.strip().lower()
                cooldown  = int(option) if option and option.isdigit() else 0
                cur.execute("UPDATE mooncoin_rules SET cooldown=? WHERE name=?", (cooldown, rule_name))
                if cur.rowcount == 0:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Rule Not Found",
                        f"No rule named `{rule_name}`. Use `mooncoin_action:Add` to create it."
                    ))
                conn.commit()
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ Cooldown Updated",
                    f"Rule **`{rule_name}`** cooldown → **{cooldown}s**" if cooldown
                    else f"Rule **`{rule_name}`** — no cooldown (unlimited)."
                ))

            elif mc_action == "remove":
                if not value:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing Rule Name", "Provide `value:<rule_name>` to delete."
                    ))
                cur.execute("DELETE FROM mooncoin_rules WHERE name=?", (value.strip().lower(),))
                conn.commit()
                return await interaction.followup.send(embed=create_success_embed(
                    "🗑️ Earn Rule Deleted", f"Rule **`{value.strip()}`** removed."
                ))

            elif mc_action == "grant":
                if not target_user or not value:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing Parameters",
                        "Provide `target_user` and `value:<amount>`.\n"
                        "Example: `target_user:@Alice value:100`"
                    ))
                try:
                    amt = int(value)
                    if amt <= 0: raise ValueError
                except ValueError:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Invalid Amount", "`value` must be a positive whole number."
                    ))
                add_coins(str(target_user.id), amt,
                          reason="admin grant", by_id=uid)
                # DM the user
                try:
                    dm = discord.Embed(
                        title="🌙 MoonCoins Received!",
                        description=(
                            f"An admin has granted you **+{amt:,} 🌙 MoonCoins**!\n\n"
                            "Check your balance with `/account`."
                        ),
                        color=0xFFD700, timestamp=datetime.now(),
                    )
                    dm.set_author(name="MoonNodes", icon_url="https://imgur.com/6yfYDTP.png")
                    await target_user.send(embed=dm)
                except discord.Forbidden:
                    pass
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ MoonCoins Granted",
                    f"**+{amt:,} 🌙** added to {target_user.mention}'s balance."
                ))

            elif mc_action == "deduct":
                if not target_user or not value:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing Parameters",
                        "Provide `target_user` and `value:<amount>`."
                    ))
                try:
                    amt = int(value)
                    if amt <= 0: raise ValueError
                except ValueError:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Invalid Amount", "`value` must be a positive whole number."
                    ))
                add_coins(str(target_user.id), -amt,
                          reason="admin deduct", by_id=uid)
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ MoonCoins Deducted",
                    f"**-{amt:,} 🌙** removed from {target_user.mention}'s balance."
                ))

            return await interaction.followup.send(embed=create_error_embed(
                "Unknown Action",
                f"Unknown mooncoin action `{mc_action}`. Pick one from the dropdown."
            ))

        # ── 💬 DM COMMANDS ────────────────────────────────────────────────────
        if setting == "user_dm":
            conn   = get_db()
            cur    = conn.cursor()
            action = (command_dm_action or "list").lower()

            if action == "enable":
                set_setting("dm_commands_mode", "all")
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ DM Commands Enabled",
                    "Users can now run bot commands in Direct Messages.\n"
                    "*Use `Block` to restrict specific commands if needed.*"
                ))

            elif action == "disable":
                set_setting("dm_commands_mode", "disabled")
                return await interaction.followup.send(embed=create_success_embed(
                    "🚫 DM Commands Disabled",
                    "All bot commands in Direct Messages are now blocked.\n"
                    "*Use `Enable` to restore DM access.*"
                ))

            elif action == "prefix":
                prefix_val = (value or "!").strip()
                cur.execute(
                    "INSERT OR REPLACE INTO dm_settings (key,value) VALUES (?,?)",
                    ("dm_prefix", prefix_val),
                )
                conn.commit()
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ DM Prefix Updated",
                    f"Users must now prefix DM commands with `{prefix_val}`."
                ))

            elif action == "allow":
                if not value:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing Command Name",
                        "Provide `value:<command_name>` — e.g. `value:status`."
                    ))
                cmd = value.strip().lower().lstrip("!/")
                cur.execute(
                    "INSERT OR REPLACE INTO dm_settings (key,value) VALUES (?,?)",
                    (f"dm_allow_{cmd}", "true"),
                )
                conn.commit()
                return await interaction.followup.send(embed=create_success_embed(
                    "✅ Command Allowed in DMs",
                    f"`{cmd}` is now permitted in Direct Messages."
                ))

            elif action == "block":
                if not value:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing Command Name",
                        "Provide `value:<command_name>` — e.g. `value:create`."
                    ))
                cmd = value.strip().lower().lstrip("!/")
                cur.execute("DELETE FROM dm_settings WHERE key=?", (f"dm_allow_{cmd}",))
                cur.execute(
                    "INSERT OR REPLACE INTO dm_settings (key,value) VALUES (?,?)",
                    (f"dm_block_{cmd}", "true"),
                )
                conn.commit()
                return await interaction.followup.send(embed=create_success_embed(
                    "🚫 Command Blocked in DMs",
                    f"`{cmd}` is now blocked in Direct Messages."
                ))

            elif action == "clear":
                cur.execute(
                    "DELETE FROM dm_settings WHERE key LIKE 'dm_allow_%' OR key LIKE 'dm_block_%'"
                )
                conn.commit()
                return await interaction.followup.send(embed=create_success_embed(
                    "🗑️ DM Rules Cleared",
                    "All per-command allow/block rules have been removed.\n"
                    "*Global mode and prefix are unchanged.*"
                ))

            else:  # list
                mode       = get_setting("dm_commands_mode") or "custom"
                cur.execute("SELECT key, value FROM dm_settings")
                rows       = [dict(r) for r in cur.fetchall()]
                prefix_row = next((r for r in rows if r["key"] == "dm_prefix"), None)
                allowed    = [r["key"].replace("dm_allow_", "") for r in rows if r["key"].startswith("dm_allow_")]
                blocked    = [r["key"].replace("dm_block_", "") for r in rows if r["key"].startswith("dm_block_")]
                embed      = create_embed("💬 DM Command Settings", "Current Direct Message command configuration:")
                add_field(embed, "Global Mode",      f"`{mode}`",                                                  True)
                add_field(embed, "Command Prefix",   f"`{prefix_row['value']}`" if prefix_row else "`!` (default)", True)
                add_field(embed, "Allowed Commands", ", ".join(f"`{c}`" for c in allowed) or "*none*",              False)
                add_field(embed, "Blocked Commands", ", ".join(f"`{c}`" for c in blocked) or "*none*",              False)
                embed.set_footer(text="Use command_dm_action options to modify")
                return await interaction.followup.send(embed=embed)


async def setup(bot):
    await bot.add_cog(SetCog(bot))
