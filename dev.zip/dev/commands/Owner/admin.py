import discord
from discord import app_commands
from discord.ext import commands

from core.database import admin_data, save_admin_data, get_db
from core.config import MAIN_ADMIN_ID
from core.theme import create_success_embed, create_error_embed, create_embed, add_field


def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if uid == str(MAIN_ADMIN_ID): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure(f"Required role: {', '.join(roles)}")
    return app_commands.check(predicate)


class AdminCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="admin", description="[OWNER] Assign or remove staff roles")
    @app_commands.choices(action=[
        app_commands.Choice(name="Add",    value="add"),
        app_commands.Choice(name="Remove", value="remove"),
        app_commands.Choice(name="List",   value="list"),
    ])
    @app_commands.choices(permission=[
        app_commands.Choice(name="Owner Level", value="Owner"),
        app_commands.Choice(name="Admin Level", value="Admin"),
        app_commands.Choice(name="Mod Level",   value="Mod"),
        app_commands.Choice(name="Dev Level",   value="Dev"),
    ])
    @has_role("Owner")
    async def admin_action(
        self,
        interaction: discord.Interaction,
        action: str,
        user: discord.Member = None,
        permission: str = "Admin",
    ):
        await interaction.response.defer(ephemeral=True)

        if action == "list":
            if not admin_data:
                return await interaction.followup.send(embed=create_error_embed("Empty", "No admins assigned."))
            embed = create_embed("👥 Staff List")
            for uid, role in admin_data.items():
                member = interaction.guild.get_member(int(uid))
                name   = member.mention if member else f"<@{uid}>"
                add_field(embed, role, name, True)
            return await interaction.followup.send(embed=embed)

        if not user:
            return await interaction.followup.send(embed=create_error_embed("Error", "You must provide a user."))

        if action == "add":
            admin_data[str(user.id)] = permission
            save_admin_data()

            conn = self.bot.get_cog  # just for type hint clarity
            db   = get_db()
            cur  = db.cursor()
            cur.execute("INSERT OR IGNORE INTO admins (user_id, role) VALUES (?, ?)", (str(user.id), permission))
            cur.execute("UPDATE admins SET role=? WHERE user_id=?", (permission, str(user.id)))
            db.commit()
            db.close()

            await interaction.followup.send(embed=create_success_embed("Role Assigned", f"{user.mention} → **{permission}**"))

        elif action == "remove":
            admin_data.pop(str(user.id), None)
            save_admin_data()

            db  = get_db()
            cur = db.cursor()
            cur.execute("DELETE FROM admins WHERE user_id=?", (str(user.id),))
            db.commit()
            db.close()

            await interaction.followup.send(embed=create_success_embed("Role Removed", f"{user.mention} removed from staff."))


async def setup(bot):
    await bot.add_cog(AdminCog(bot))
