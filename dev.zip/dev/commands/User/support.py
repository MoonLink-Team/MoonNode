import discord
from discord import app_commands
from discord.ext import commands

from core.config import ISTS, MAIN_ADMIN_ID
from core.database import admin_data, vps_data, data_lock, get_setting
from core.theme import create_success_embed, create_error_embed, create_info_embed, create_warning_embed, add_field


def is_admin_check(user_id):
    role = admin_data.get(str(user_id))
    return role in ["Owner", "Admin", "Dev", "Mod"] or str(user_id) == str(MAIN_ADMIN_ID)


class SupportCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="support", description="Open a support ticket for a specific VPS")
    @app_commands.choices(ticket_action=[
        app_commands.Choice(name="Close Ticket", value="close"),
        app_commands.Choice(name="Claim Ticket", value="claim"),
    ])
    @app_commands.describe(
        vps_number    = "Your VPS number (1, 2…)",
        issue         = "Describe your issue",
        ticket_action = "Manage this ticket (staff only, run inside the thread)",
    )
    async def support_cmd(
        self, interaction: discord.Interaction,
        vps_number: int,
        issue: str = None,
        ticket_action: str = None,
    ):
        if not ISTS:
            return await interaction.response.send_message(embed=create_error_embed("Disabled", "Support tickets are disabled."), ephemeral=True)

        await interaction.response.defer(ephemeral=True)

        # ── Staff actions inside a thread ────────────────────────────────────
        if ticket_action in ("close", "claim"):
            if not isinstance(interaction.channel, discord.Thread):
                return await interaction.followup.send(embed=create_error_embed("Error", "Use ticket actions inside a support thread."))
            if not is_admin_check(interaction.user.id):
                return await interaction.followup.send(embed=create_error_embed("Denied", "Staff only."))
            if ticket_action == "close":
                await interaction.followup.send(embed=create_info_embed("Ticket Closed", "This ticket has been resolved."))
                await interaction.channel.edit(archived=True, locked=True)
            elif ticket_action == "claim":
                await interaction.followup.send(embed=create_success_embed("Ticket Claimed", f"{interaction.user.mention} is handling this ticket."))
            return

        # ── Create a new ticket ──────────────────────────────────────────────
        uid = str(interaction.user.id)
        with data_lock:
            user_list = vps_data.get(uid, [])
            if not user_list or vps_number < 1 or vps_number > len(user_list):
                return await interaction.followup.send(embed=create_error_embed("Error", "Invalid VPS number."))
            vps = user_list[vps_number - 1]

        ticket_ch_id = get_setting("ticket_channel")
        if not ticket_ch_id or ticket_ch_id == "0":
            return await interaction.followup.send(embed=create_error_embed("Error", "No ticket channel configured. Ask an admin to use `/set`."))

        channel = interaction.guild.get_channel(int(ticket_ch_id))
        if not channel:
            return await interaction.followup.send(embed=create_error_embed("Error", "Ticket channel not found."))

        thread_name = f"ticket-{interaction.user.name}-{vps['container_name']}"[:100]
        embed = create_warning_embed(
            f"🎫 Support Ticket — {interaction.user}",
            f"**VPS:** `{vps['container_name']}`\n**Issue:** {issue or 'Not specified'}"
        )
        add_field(embed, "Specs",  vps.get("config", "Custom"), True)
        add_field(embed, "Status", vps.get("status", "?"),      True)
        add_field(embed, "Node",   vps.get("node", "local"),    True)
        embed.set_footer(text=f"User ID: {uid}")

        try:
            thread = await channel.create_thread(
                name=thread_name,
                type=discord.ChannelType.private_thread,
                invitable=False,
            )
            await thread.send(content=f"<@{MAIN_ADMIN_ID}> {interaction.user.mention}", embed=embed)
            await thread.add_user(interaction.user)
            await interaction.followup.send(
                embed=create_success_embed("Ticket Created", f"Your support thread has been opened: {thread.mention}")
            )
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Error", f"Could not create thread: {str(e)[:2000]}"))


async def setup(bot):
    await bot.add_cog(SupportCog(bot))
