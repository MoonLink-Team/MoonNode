import os
import logging
import sys
import shutil
from dotenv import load_dotenv

load_dotenv()

# --- Discord ---
DISCORD_TOKEN       = os.getenv("DISCORD_TOKEN")
MAIN_ADMIN_ID       = int(os.getenv("BOT_OWNER_ID", "0"))
VPS_USER_ROLE_ID    = int(os.getenv("VPS_USER_ROLE_ID", "0"))

# --- Bot Color ---
_raw_color = os.getenv("BOT_COLOR", "5865F2").replace("#", "")
try:
    CUSTOM_BOT_COLOR = int(_raw_color, 16)
except ValueError:
    CUSTOM_BOT_COLOR = 0x5865F2

# --- LXC ---
DEFAULT_STORAGE_POOL = os.getenv("DEFAULT_STORAGE_POOL", None)
VPS_PREFIX           = os.getenv("VPS_PREFIX", "vps")

# --- Features ---
ENABLE_PLANS = os.getenv("PLANS", "True").lower() == "true"
CLAIM_PREMIUM = os.getenv("CLAIM_PREMIUM", "True").lower() == "true"
CLAIM_FREE    = os.getenv("CLAIM_FREE",    "True").lower() == "true"

# --- Security ---
ENFORCE_RESOURCE_LIMITS = os.getenv("ENFORCE_RESOURCE_LIMITS", "True").lower() == "true"
MAX_RAM_LIMIT  = int(os.getenv("MAX_RAM_GB",    "16"))
MAX_CPU_LIMIT  = int(os.getenv("MAX_CPU_CORES", "8"))
CPU_THRESHOLD  = float(os.getenv("CPU_THRESHOLD", "90"))
RAM_THRESHOLD  = float(os.getenv("RAM_THRESHOLD", "90"))

# --- Extensions ---
ASM        = os.getenv("ASM",        "False").lower() == "true"
MULTI_NODE = os.getenv("Multi-Node", "False").lower() == "true"
SOSB       = os.getenv("SOSB",       "False").lower() == "true"
ABEI       = os.getenv("ABEI",       "False").lower() == "true"
ISTS       = os.getenv("ISTS",       "False").lower() == "true"
AES        = os.getenv("AES",        "False").lower() == "true"
RR         = os.getenv("RR",         "False").lower() == "true"
RA         = os.getenv("RA",         "False").lower() == "true"
A2FA       = os.getenv("A2FA",       "False").lower() == "true"
CPCS       = os.getenv("CPCS",       "False").lower() == "true"
MSTC       = os.getenv("MSTC",       "False").lower() == "true"
PUDC       = os.getenv("PUDC",       "False").lower() == "true"
UBL_ENABLED = os.getenv("UBL_ENABLED", "False").lower() == "true"
UBL_LIMIT   = int(os.getenv("BACKUP_LIMIT", "1"))

# --- Cloudflare ---
CF_API_TOKEN   = os.getenv("CF_API_TOKEN")
CF_ZONE_ID     = os.getenv("CF_ZONE_ID")
CF_DOMAIN      = os.getenv("CF_DOMAIN", "moonlink.qzz.io")
HOST_PUBLIC_IP = os.getenv("HOST_PUBLIC_IP")

# --- OS Options ---
OS_OPTIONS = [
    {"label": "Ubuntu 20.04 LTS",    "value": "ubuntu:20.04",       "emoji": "🐧", "desc": "Stable, widely supported"},
    {"label": "Ubuntu 22.04 LTS",    "value": "ubuntu:22.04",       "emoji": "🐧", "desc": "Standard recommendation"},
    {"label": "Ubuntu 24.04 LTS",    "value": "ubuntu:24.04",       "emoji": "🐧", "desc": "Latest LTS release"},
    {"label": "Debian 10 (Buster)",  "value": "images:debian/10",   "emoji": "🍥", "desc": "Legacy stable"},
    {"label": "Debian 11 (Bullseye)","value": "images:debian/11",   "emoji": "🍥", "desc": "Old stable"},
    {"label": "Debian 12 (Bookworm)","value": "images:debian/12",   "emoji": "🍥", "desc": "Current stable"},
    {"label": "Debian 13 (Trixie)",  "value": "images:debian/13",   "emoji": "🍥", "desc": "Testing/Next stable"},
]

# --- Software Installer ---
SOFTWARE_SCRIPTS = {
    "docker":    {"name": "Docker",              "cmd": "curl -fsSL https://get.docker.com | sh",                                                                                           "check": "docker --version"},
    "nodejs":    {"name": "Node.js (LTS)",       "cmd": "curl -fsSL https://deb.nodesource.com/setup_lts.x | bash - && apt-get install -y nodejs",                                        "check": "node --version"},
    "nginx":     {"name": "Nginx Web Server",    "cmd": "apt-get update && apt-get install -y nginx",                                                                                      "check": "nginx -v"},
    "python":    {"name": "Python 3 & Pip",      "cmd": "apt-get update && apt-get install -y python3 python3-pip",                                                                        "check": "python3 --version"},
    "java":      {"name": "Java (OpenJDK 17)",   "cmd": "apt-get update && apt-get install -y openjdk-17-jre-headless",                                                                    "check": "java -version"},
    "security":  {"name": "UFW Firewall",        "cmd": "apt-get update && apt-get install -y ufw fail2ban && ufw default deny incoming && ufw default allow outgoing && ufw allow ssh && ufw --force enable && systemctl enable fail2ban && systemctl start fail2ban", "check": "ufw status"},
    "minecraft": {"name": "Minecraft Java",      "cmd": "dpkg --add-architecture i386 && apt update && apt install default-jre curl wget file tar bzip2 gzip unzip bsdmainutils python3 util-linux ca-certificates binutils bc jq tmux netcat-openbsd -y && adduser --disabled-password --gecos '' mcserver && su - mcserver -c 'curl -Lo linuxgsm.sh https://linuxgsm.sh && chmod +x linuxgsm.sh && bash linuxgsm.sh mcserver && ./mcserver install'", "check": "ls /home/mcserver"},
    "rust":      {"name": "Rust Server (LGSM)",  "cmd": "dpkg --add-architecture i386 && apt update && apt install curl wget file tar bzip2 gzip unzip bsdmainutils python3 util-linux ca-certificates binutils bc jq tmux netcat-openbsd lib32gcc-s1 lib32stdc++6 -y && adduser --disabled-password --gecos '' rustserver && su - rustserver -c 'curl -Lo linuxgsm.sh https://linuxgsm.sh && chmod +x linuxgsm.sh && bash linuxgsm.sh rustserver && ./rustserver install'", "check": "ls /home/rustserver"},
    "cs2":       {"name": "CS2 Server (LGSM)",   "cmd": "dpkg --add-architecture i386 && apt update && apt install curl wget file tar bzip2 gzip unzip bsdmainutils python3 util-linux ca-certificates binutils bc jq tmux netcat-openbsd lib32gcc-s1 lib32stdc++6 -y && adduser --disabled-password --gecos '' cs2server && su - cs2server -c 'curl -Lo linuxgsm.sh https://linuxgsm.sh && chmod +x linuxgsm.sh && bash linuxgsm.sh cs2server && ./cs2server install'", "check": "ls /home/cs2server"},
    "fivem":     {"name": "FiveM Server",        "cmd": "apt update && apt install xz-utils git -y && mkdir -p /home/fivem && cd /home/fivem && wget https://runtime.fivem.net/artifacts/fivem/build_proot_linux/master/6683-10d7a040b1029da2d8d8ee4c7d0d0cc151e39a51/fx.tar.xz && tar xf fx.tar.xz && rm fx.tar.xz", "check": "ls /home/fivem/run.sh"},
}

# --- Logging ---
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("bot.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("moonnodes_vps_bot")

# --- Sanity Checks ---
if not shutil.which("lxc"):
    logger.critical("LXC/LXD is not installed or not in PATH. Please install it first.")
    sys.exit(1)

# --- Maintenance Mode (runtime flag) ---
MAINTENANCE_MODE = False
