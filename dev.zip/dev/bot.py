"""
MoonNodes VPS Manager — bot.py
Entry point: loads all cogs and starts background tasks.
"""

import asyncio
import logging
import random
import sys
import os

import discord
from discord.ext import commands, tasks

# ── Bootstrap: ensure project root is on sys.path ───────────────────────────
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# ── Core imports (order matters — __init__ detects the storage pool) ─────────
import core                                   # noqa: F401  (sets ACTIVE_STORAGE_POOL)
from core.config import (
    DISCORD_TOKEN, MAIN_ADMIN_ID,
    SOSB, AES, RR,
    CPU_THRESHOLD, RAM_THRESHOLD,
    MAINTENANCE_MODE,
)
from core.database import (
    init_db, load_vps_data, load_admin_data,
    vps_data, data_lock, save_vps_data,
    get_setting, admin_data,
    get_db,
)
from core.lxc import execute_lxc
from core.monitoring import start_resource_monitor
from core.theme import (
    create_embed, create_success_embed,
    create_error_embed, create_warning_embed,
    add_field,
)

logger = logging.getLogger("moonnodes_vps_bot")


# ── Bot class ────────────────────────────────────────────────────────────────

class MoonNodesBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members         = True
        super().__init__(command_prefix="!", intents=intents)

    async def setup_hook(self):
        """Load all cog extensions."""
        cogs = [
            # Owner
            "commands.Owner.admin",
            "commands.Owner.create",
            "commands.Owner.delete",
            "commands.Owner.giveaway",
            "commands.Owner.list_all",
            "commands.Owner.nodes",
            "commands.Owner.system_admin",
            # Admin
            "commands.Admin.vps",
            "commands.Admin.set_cmd",
            # User
            "commands.User.list_cmd",
            "commands.User.manage",
            "commands.User.plans",
            "commands.User.claim",
            "commands.User.backup",
            "commands.User.share",
            "commands.User.affiliate",
            "commands.User.support",
            "commands.User.status",
            "commands.User.transfer",
            "commands.User.upgrade",
            "commands.User.help",
        ]
        for cog in cogs:
            try:
                await self.load_extension(cog)
                logger.info(f"Loaded cog: {cog}")
            except Exception as e:
                logger.error(f"Failed to load cog {cog}: {e}")

        try:
            synced = await self.tree.sync()
            logger.info(f"Synced {len(synced)} slash command(s) globally.")
        except Exception as e:
            logger.error(f"Failed to sync slash commands: {e}")

    async def on_ready(self):
        logger.info(f"Bot ready — logged in as {self.user} ({self.user.id})")

        # Load persistent data
        load_vps_data()
        load_admin_data()

        # Restore admin data from DB into memory dict
        try:
            conn = get_db()
            cur  = conn.cursor()
            cur.execute("SELECT user_id, role FROM admins")
            for row in cur.fetchall():
                admin_data[row["user_id"]] = row["role"]
            conn.close()
        except Exception as e:
            logger.error(f"Failed to load admin data from DB: {e}")

        # Start background tasks
        update_status_task.start()
        if SOSB:
            automated_backups.start()
        if AES or RR:
            expiration_monitor.start()

        # Start resource monitor thread
        start_resource_monitor(
            bot_loop      = self.loop,
            cpu_threshold = CPU_THRESHOLD,
            ram_threshold = RAM_THRESHOLD,
            vps_data_ref  = vps_data,
            data_lock_ref = data_lock,
            save_fn       = save_vps_data,
            send_log_fn   = _send_log,
        )

        logger.info("Bot is ready!")

    async def on_app_command_error(self, interaction: discord.Interaction, error):
        if isinstance(error, discord.app_commands.CheckFailure):
            embed = create_error_embed("Access Denied", str(error))
            try:
                if interaction.response.is_done():
                    await interaction.followup.send(embed=embed, ephemeral=True)
                else:
                    await interaction.response.send_message(embed=embed, ephemeral=True)
            except Exception:
                pass
            return

        import traceback
        msg = str(error.original) if isinstance(error, discord.app_commands.CommandInvokeError) else str(error)
        logger.error(f"Command error: {msg}")
        traceback.print_exc()
        try:
            embed = create_error_embed("System Error", f"An unexpected error occurred:\n`{msg[:3900]}`")
            if interaction.response.is_done():
                await interaction.followup.send(embed=embed, ephemeral=True)
            else:
                await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception:
            pass

    # ── !sync command (owner only) ───────────────────────────────────────────
    @commands.command(name="sync")
    async def sync_commands(self, ctx: commands.Context):
        if ctx.author.id != MAIN_ADMIN_ID:
            return
        synced = await self.tree.sync()
        await ctx.send(f"✅ Synced **{len(synced)}** slash commands globally.")


# ── Helpers ──────────────────────────────────────────────────────────────────

async def _send_log(embed: discord.Embed):
    log_ch_id = get_setting("log_channel")
    if log_ch_id and log_ch_id != "0":
        try:
            channel = bot.get_channel(int(log_ch_id))
            if channel:
                await channel.send(embed=embed)
        except Exception as e:
            logger.error(f"Log send failed: {e}")


# ── Background tasks ─────────────────────────────────────────────────────────

bot = MoonNodesBot()


@tasks.loop(seconds=60)
async def update_status_task():
    try:
        import core.config as _cfg
        if _cfg.MAINTENANCE_MODE:
            await bot.change_presence(
                status=discord.Status.dnd,
                activity=discord.Activity(type=discord.ActivityType.watching, name="System Maintenance"),
            )
            return
        total = sum(len(v) for v in vps_data.values())
        statuses = [
            "System Status: Online",
            f"Managing {total} VPS Nodes",
            "MoonNodes System",
            "Type /help for commands",
        ]
        await bot.change_presence(
            activity=discord.Activity(type=discord.ActivityType.watching, name=random.choice(statuses))
        )
    except Exception:
        pass


@tasks.loop(hours=24)
async def automated_backups():
    if not SOSB:
        return
    from datetime import datetime
    logger.info("[SOSB] Running scheduled automated backups…")
    with data_lock:
        snapshot = dict(vps_data)
    for uid, vps_list in snapshot.items():
        for vps in vps_list:
            name       = vps["container_name"]
            node       = vps.get("node", "local")
            prefix     = f"{node}:" if node != "local" else ""
            snap_name  = f"auto-backup-{datetime.now().strftime('%Y%m%d')}"
            try:
                info = await execute_lxc(f"lxc info {prefix}{name}")
                if snap_name in info:
                    continue
                await execute_lxc(f"lxc snapshot {prefix}{name} {snap_name}")
                logger.info(f"[SOSB] Backup created: {name}/{snap_name}")
            except Exception as e:
                logger.error(f"[SOSB] Backup failed for {name}: {e}")


@tasks.loop(hours=12)
async def expiration_monitor():
    if not AES and not RR:
        return
    from datetime import datetime, timedelta
    logger.info("[AES/RR] Running expiration checks…")
    now = datetime.now()
    with data_lock:
        snapshot = dict(vps_data)
    for uid, vps_list in snapshot.items():
        for vps in vps_list:
            exp_str = vps.get("expires_at")
            if not exp_str:
                continue
            try:
                exp_date  = datetime.fromisoformat(exp_str)
            except ValueError:
                continue
            days_left = (exp_date - now).days
            node      = vps.get("node", "local")
            prefix    = f"{node}:" if node != "local" else ""
            name      = vps["container_name"]

            if days_left <= 0 and AES and not vps.get("suspended", False):
                try:
                    await execute_lxc(f"lxc stop {prefix}{name}")
                    with data_lock:
                        vps["suspended"] = True
                        vps["status"]    = "stopped"
                        vps.setdefault("suspension_history", []).append({
                            "time":   datetime.now().isoformat(),
                            "reason": "Automated Expiration",
                            "by":     "System",
                        })
                    save_vps_data()
                    user = bot.get_user(int(uid))
                    if user:
                        await user.send(embed=create_error_embed(
                            "VPS Expired",
                            f"Your VPS `{name}` has expired and been suspended.\n"
                            "Please open a ticket or renew via `/plans`.",
                        ))
                except Exception as e:
                    logger.error(f"[AES] Auto-suspend failed for {name}: {e}")

            elif days_left == 3 and RR:
                user = bot.get_user(int(uid))
                if user:
                    try:
                        await user.send(embed=create_warning_embed(
                            "Renewal Reminder",
                            f"Your VPS `{name}` expires in **3 days**!\n"
                            "Use `/plans` to renew and avoid downtime.",
                        ))
                    except Exception:
                        pass


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    init_db()
    if not DISCORD_TOKEN:
        logger.error("DISCORD_TOKEN not set in .env file. Exiting.")
        sys.exit(1)
    try:
        bot.run(DISCORD_TOKEN)
    except KeyboardInterrupt:
        logger.info("Bot stopped by user.")
