"""
commands.py — All MoonNodes slash commands in a single file.

This consolidates every cog that was previously split across:
  commands/Owner/*, commands/Admin/*, commands/Dev/*,
  commands/Mod/*, commands/Staff/*, commands/User/*

Premium UI, all bug fixes, and new features are included.
"""

# ═══════════════════════════════════════════════════════════════════════════════
#  IMPORTS
# ═══════════════════════════════════════════════════════════════════════════════

import asyncio
import shutil
import time
import uuid
import random
import logging

from datetime import datetime


import discord
from discord import app_commands
from discord.ext import commands

import core.config as cfg
from core.config import (
    MAIN_ADMIN_ID, ENFORCE_RESOURCE_LIMITS, MAX_RAM_LIMIT, MAX_CPU_LIMIT
)
from core.database import (
    admin_data, vps_data, data_lock, get_db, get_setting, set_setting,
    async_save_vps_data, load_vps_data, load_admin_data, get_payments,
    active_giveaways
)
from core.lxc import execute_lxc, deploy_container, get_best_node, RUNTIME, normalize_os
from core.theme import (
    Theme, add_field, create_embed, create_success_embed, create_error_embed,
    create_info_embed, create_warning_embed
)

from feature.plans.plans_manager import PLANS
from ui.node_select import NodeSelectView


from ui.confirm_view import ConfirmView
from ui.plans_view import GiveawayView

logger = logging.getLogger("moonnodes_vps_bot")

# ═══════════════════════════════════════════════════════════════════════════════
#  SHARED HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

def _uid(interaction: discord.Interaction) -> str:
    return str(interaction.user.id)

def _is_owner(uid) -> bool:
    return int(uid) == int(MAIN_ADMIN_ID)

def _role(uid) -> str:
    if _is_owner(uid): return "Owner"
    return admin_data.get(str(uid), "")

def has_role(*roles):
    async def predicate(interaction: discord.Interaction):
        uid = str(interaction.user.id)
        if _is_owner(uid): return True
        role = admin_data.get(uid)
        if role == "Owner" or role in roles: return True
        raise app_commands.CheckFailure(f"🚫 Required role: {', '.join(roles)}")
    return app_commands.check(predicate)

def _is_admin(uid) -> bool:
    return _is_owner(uid) or admin_data.get(str(uid)) in ("Owner", "Hard Admin", "Admin", "Manager", "Dev")

def _is_mod(uid) -> bool:
    return _is_owner(uid) or admin_data.get(str(uid)) in ("Owner", "Hard Admin", "Admin", "Manager", "Hard Mod", "Mod")

def _is_staff(uid) -> bool:
    return _is_mod(uid) or admin_data.get(str(uid)) in ("Hard Staff", "Staff", "Trial Staff")

# ═══════════════════════════════════════════════════════════════════════════════
#  ROLE SYSTEM
# ═══════════════════════════════════════════════════════════════════════════════

ROLE_HIERARCHY = [
    "Owner", "Hard Admin", "Admin", "Manager",
    "Hard Mod", "Mod", "Hard Staff", "Staff",
    "Trial Staff", "Trial Mod", "Partner",
]
ROLE_ICONS = {
    "Owner": "👑", "Hard Admin": "🔱", "Admin": "🛡️", "Manager": "💼",
    "Hard Mod": "🔨", "Mod": "⚒️", "Hard Staff": "⭐", "Staff": "🌟",
    "Trial Staff": "🔰", "Trial Mod": "🎯", "Partner": "🤝",
}
ROLE_COLORS = {
    "Owner": 0xFFD700, "Hard Admin": 0xFF4500, "Admin": 0x5865F2, "Manager": 0x9B59B6,
    "Hard Mod": 0xE74C3C, "Mod": 0x57F287, "Hard Staff": 0xF1C40F, "Staff": 0x3498DB,
    "Trial Staff": 0x95A5A6, "Trial Mod": 0x7F8C8D, "Partner": 0x1ABC9C,
}
ROLE_PERMISSIONS = {
    "Owner":       "Full control — all commands, extensions, nodes, staff management",
    "Hard Admin":  "All admin commands + can manage Admins and below",
    "Admin":       "VPS management, config, giveaways, node management",
    "Manager":     "Admin commands except node management and extensions",
    "Hard Mod":    "Mod commands + warn, DM users, manage tickets",
    "Mod":         "Ticket management, user lookups, server stats",
    "Hard Staff":  "Support ticket handling + basic mod tools",
    "Staff":       "Support ticket handling only",
    "Trial Staff": "Handle support tickets in training — limited commands",
    "Trial Mod":   "Observe mod channels — no active permissions yet",
    "Partner":     "Partner badge + VIP perks — no mod permissions",
}
ADMIN_ROLES = {"Owner", "Hard Admin", "Admin", "Manager"}
MOD_ROLES   = {"Owner", "Hard Admin", "Admin", "Manager", "Hard Mod", "Mod", "Hard Staff"}
STAFF_ROLES = {"Owner", "Hard Admin", "Admin", "Manager", "Hard Mod", "Mod", "Hard Staff", "Staff", "Trial Staff"}

# ═══════════════════════════════════════════════════════════════════════════════
#  PREMIUM TIER SYSTEM
# ═══════════════════════════════════════════════════════════════════════════════

PREMIUM_TIERS = {
    "basic":    {"label": "⭐ Basic",    "color": 0x5865F2, "icon": "⭐"},
    "standard": {"label": "🌟 Standard", "color": 0x57F287, "icon": "🌟"},
    "pro":      {"label": "💎 Pro",      "color": 0xFFD700, "icon": "💎"},
    "elite":    {"label": "🔱 Elite",    "color": 0xFF4500, "icon": "🔱"},
}

def _get_user_tier(uid: str) -> dict:
    """Get a user's premium tier from DB. Returns None if not premium."""
    try:
        conn = get_db()
        cur  = conn.cursor()
        cur.execute("SELECT tier FROM users WHERE user_id=?", (uid,))
        row = cur.fetchone()
        tier_key = row["tier"] if row and "tier" in row.keys() else None
        return PREMIUM_TIERS.get(tier_key)
    except Exception:
        return None

def _premium_badge(uid: str) -> str:
    tier = _get_user_tier(uid)
    return f" {tier['icon']}" if tier else ""

# ═══════════════════════════════════════════════════════════════════════════════
#  EXTENSION REGISTRY
# ═══════════════════════════════════════════════════════════════════════════════

EXTENSIONS = {
    "Scheduled Backups":     "SOSB",
    "Ticket System":         "ISTS",
    "Auto Expire & Suspend": "AES",
    "Renewal Reminders":     "RR",
    "Admin 2FA (AF2F)":      "A2FA",
    "Multi-Server Tickets":  "MSTC",
    "Backup Limits":         "UBL_ENABLED",
    "Marketplace":           "MARKETPLACE",
    "Account & MoonCoin":    "ACCOUNT",
    "VPS Monitoring Alerts": "VPS_MONITORING",
    "DM Commands":           "DM_COMMANDS",
}
EXT_CHOICES = [app_commands.Choice(name=n, value=n) for n in EXTENSIONS]

# ═══════════════════════════════════════════════════════════════════════════════
#  COG: OWNER — /role
# ═══════════════════════════════════════════════════════════════════════════════

class RoleCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="role", description="[OWNER] Assign, remove, promote, or demote staff roles")
    @app_commands.choices(action=[
        app_commands.Choice(name="➕ Add — Grant a role",          value="add"),
        app_commands.Choice(name="➖ Remove — Revoke a role",      value="remove"),
        app_commands.Choice(name="⬆️ Promote — Move up one tier",  value="promote"),
        app_commands.Choice(name="⬇️ Demote — Move down one tier", value="demote"),
        app_commands.Choice(name="📋 List — View all staff",       value="list"),
    ])
    @app_commands.choices(permission=[
        app_commands.Choice(name=f"{ROLE_ICONS[r]}  {r}", value=r) for r in ROLE_HIERARCHY
    ])
    @app_commands.describe(action="Action", user="Target member", permission="Role to assign")
    @has_role("Owner", "Hard Admin")
    async def admin_action(self, interaction: discord.Interaction, action: str,
                           user: discord.Member = None, permission: str = "Staff"):
        await interaction.response.defer(ephemeral=True)

        if action == "list":
            grouped = {}
            for uid, role in admin_data.items():
                grouped.setdefault(role, []).append(uid)
            embed = discord.Embed(
                title="🌙  MoonNodes — Staff Directory",
                description=f"**{sum(len(v) for v in grouped.values())}** staff members across {len(grouped)} roles",
                color=0x5865F2, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)
            for rn in ROLE_HIERARCHY:
                members = grouped.get(rn, [])
                if not members: continue
                lines = []
                for uid in members:
                    m = interaction.guild.get_member(int(uid)) if interaction.guild else None
                    lines.append(m.mention if m else f"<@{uid}>")
                embed.add_field(name=f"{ROLE_ICONS.get(rn,'•')} {rn} ({len(members)})",
                                value=", ".join(lines)[:1024], inline=True)
            embed.set_footer(text=f"Requested by {interaction.user.display_name}")
            return await interaction.followup.send(embed=embed)

        if not user:
            return await interaction.followup.send(embed=create_error_embed("Missing", "Specify a `user`."))

        uid      = str(user.id)
        cur_role = admin_data.get(uid)

        if action == "add":
            from core.database import save_admin_data
            admin_data[uid] = permission
            save_admin_data()
            conn = get_db(); cur = conn.cursor()
            cur.execute("INSERT OR IGNORE INTO admins (user_id, role) VALUES (?,?)", (uid, permission))
            cur.execute("UPDATE admins SET role=? WHERE user_id=?", (permission, uid))
            conn.commit()
            embed = discord.Embed(
                title=f"{ROLE_ICONS.get(permission,'•')}  Role Assigned",
                description=f"{user.mention} is now **{permission}**.",
                color=ROLE_COLORS.get(permission, Theme.PRIMARY), timestamp=datetime.now(),
            )
            embed.set_thumbnail(url=user.display_avatar.url)
            embed.add_field(name="Permissions", value=ROLE_PERMISSIONS.get(permission, "—"), inline=False)
            embed.set_footer(text=f"Assigned by {interaction.user.display_name}")
            await interaction.followup.send(embed=embed)
            try:
                dm = discord.Embed(
                    title=f"{ROLE_ICONS.get(permission,'•')}  You've Been Granted {permission}!",
                    description=f"**Permissions:** {ROLE_PERMISSIONS.get(permission,'—')}",
                    color=ROLE_COLORS.get(permission, Theme.PRIMARY), timestamp=datetime.now(),
                )
                dm.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)
                dm.set_footer(text=f"Granted by {interaction.user.display_name}")
                await user.send(embed=dm)
            except discord.Forbidden:
                pass

        elif action == "remove":
            from core.database import save_admin_data
            old = admin_data.pop(uid, None)
            save_admin_data()
            conn = get_db(); cur = conn.cursor()
            cur.execute("DELETE FROM admins WHERE user_id=?", (uid,))
            conn.commit()
            await interaction.followup.send(embed=create_success_embed(
                "Role Removed", f"{user.mention}'s **{old or 'staff'}** role has been revoked."
            ))

        elif action in ("promote", "demote"):
            from core.database import save_admin_data
            if not cur_role or cur_role not in ROLE_HIERARCHY:
                return await interaction.followup.send(embed=create_error_embed(
                    "No Role", f"{user.mention} has no staff role. Use `Add` first."
                ))
            idx = ROLE_HIERARCHY.index(cur_role)
            if action == "promote":
                if idx == 0:
                    return await interaction.followup.send(embed=create_error_embed("At Top", "Already at the highest role."))
                new_role = ROLE_HIERARCHY[idx - 1]
                title = "⬆️  Promoted!"
            else:
                if idx >= len(ROLE_HIERARCHY) - 1:
                    return await interaction.followup.send(embed=create_error_embed("At Bottom", "Use `Remove` instead."))
                new_role = ROLE_HIERARCHY[idx + 1]
                title = "⬇️  Role Adjusted"

            admin_data[uid] = new_role
            save_admin_data()
            conn = get_db(); cur = conn.cursor()
            cur.execute("UPDATE admins SET role=? WHERE user_id=?", (new_role, uid))
            conn.commit()
            embed = discord.Embed(
                title=title,
                description=f"{user.mention}\n`{cur_role}` → **`{new_role}`**",
                color=ROLE_COLORS.get(new_role, Theme.PRIMARY), timestamp=datetime.now(),
            )
            embed.set_thumbnail(url=user.display_avatar.url)
            embed.set_footer(text=f"By {interaction.user.display_name}")
            await interaction.followup.send(embed=embed)

# ═══════════════════════════════════════════════════════════════════════════════
#  COG: OWNER — /system
# ═══════════════════════════════════════════════════════════════════════════════

class SystemCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="system", description="[OWNER] System — extensions, maintenance, A2FA, containers, MoonCoin rules")
    @app_commands.choices(action=[
        app_commands.Choice(name="🔌 Extension Toggle",         value="extension"),
        app_commands.Choice(name="👁️ View Extensions",          value="view_ext"),
        app_commands.Choice(name="🚧 Maintenance Mode",         value="maintenance"),
        app_commands.Choice(name="🧹 Clean DB",                  value="clean"),
        app_commands.Choice(name="🔐 A2FA Management",           value="a2fa"),
        app_commands.Choice(name="🌙 MoonCoin Earning",          value="mooncoin"),
        app_commands.Choice(name="📋 List — Containers on node", value="list"),
        app_commands.Choice(name="💎 Premium — Manage user tiers", value="premium"),
    ])
    @app_commands.choices(list_runtime=[
        app_commands.Choice(name="🐧 incus — List incus containers", value="incus"),
        app_commands.Choice(name="🔵 lxc   — List LXD containers",   value="lxc"),
    ])
    @app_commands.choices(extension=EXT_CHOICES)
    @app_commands.choices(ext_state=[
        app_commands.Choice(name="✅ Enable",  value="enable"),
        app_commands.Choice(name="❌ Disable", value="disable"),
    ])
    @app_commands.choices(a2fa_action=[
        app_commands.Choice(name="Set / Edit PIN", value="edit"),
        app_commands.Choice(name="Remove PIN",     value="remove"),
    ])
    @app_commands.choices(mooncoin_action=[
        app_commands.Choice(name="➕ Add Earning Rule",    value="add"),
        app_commands.Choice(name="✏️ Edit Earning Rule",   value="edit_earn"),
        app_commands.Choice(name="🗑️ Remove Earning Rule", value="remove_earn"),
        app_commands.Choice(name="📋 List Earning Rules",  value="list_earn"),
    ])
    @app_commands.choices(premium_action=[
        app_commands.Choice(name="💎 Set Tier",    value="set"),
        app_commands.Choice(name="🗑️ Remove Tier", value="remove"),
        app_commands.Choice(name="📋 View Tier",   value="view"),
    ])
    @app_commands.choices(premium_tier=[
        app_commands.Choice(name=t["label"], value=k) for k, t in PREMIUM_TIERS.items()
    ])
    @app_commands.describe(
        action="Action to perform", extension="Extension to toggle", ext_state="Enable or disable",
        a2fa_action="A2FA action", new_pin="New 4-digit PIN",
        mooncoin_action="MoonCoin earning rule action", earning_name="Rule name (e.g. invite)",
        earning_amount="Coin amount", earning_cooldown="Cooldown in seconds",
        list_runtime="Runtime (incus or lxc)", list_node_id="Node number (default: 1 = local)",
        premium_action="Premium tier action", premium_tier="Tier to assign",
        premium_user="User to set/view/remove premium tier",
    )
    @has_role("Owner")
    async def system_cmd(
        self, interaction: discord.Interaction,
        action: str,
        extension: str = None, ext_state: str = None,
        a2fa_action: str = None, new_pin: str = None,
        mooncoin_action: str = None, earning_name: str = None,
        earning_amount: int = None, earning_cooldown: int = None,
        list_runtime: str = None, list_node_id: int = 1,
        premium_action: str = None, premium_tier: str = None,
        premium_user: discord.Member = None,
    ):
        await interaction.response.defer(ephemeral=True)

        # ── View Extensions ──────────────────────────────────────────────────
        if action == "view_ext":
            lines_on, lines_off = [], []
            for name, attr in EXTENSIONS.items():
                val = getattr(cfg, attr, False)
                (lines_on if val else lines_off).append(
                    f"{'🟢' if val else '🔴'} **{name}**"
                )
            embed = discord.Embed(
                title="🔌  Extension Status",
                color=Theme.PRIMARY, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)
            embed.add_field(name=f"✅ Enabled ({len(lines_on)})",  value="\n".join(lines_on)  or "*None*", inline=True)
            embed.add_field(name=f"❌ Disabled ({len(lines_off)})", value="\n".join(lines_off) or "*None*", inline=True)
            embed.set_footer(text=f"Requested by {interaction.user.display_name}")
            return await interaction.followup.send(embed=embed)

        # ── Extension Toggle ─────────────────────────────────────────────────
        elif action == "extension":
            if not extension or not ext_state:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Select both an extension and a state."))
            attr  = EXTENSIONS.get(extension)
            value = (ext_state == "enable")
            setattr(cfg, attr, value)
            set_setting(f"ext_{attr}", str(value))
            embed = discord.Embed(
                title=f"{'✅' if value else '❌'}  Extension {'Enabled' if value else 'Disabled'}",
                description=f"**{extension}** is now {'**enabled**' if value else '**disabled**'} — takes effect immediately.",
                color=Theme.SUCCESS if value else Theme.ERROR, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)
            embed.set_footer(text=f"Changed by {interaction.user.display_name}")
            return await interaction.followup.send(embed=embed)

        # ── Maintenance Mode ─────────────────────────────────────────────────
        elif action == "maintenance":
            cfg.MAINTENANCE_MODE = not getattr(cfg, "MAINTENANCE_MODE", False)
            is_on = cfg.MAINTENANCE_MODE
            asyncio.create_task(interaction.client.change_presence(
                status=discord.Status.dnd if is_on else discord.Status.online,
                activity=discord.Activity(type=discord.ActivityType.watching,
                    name="🚧 Maintenance" if is_on else "MoonNodes VPS Manager")
            ))
            embed = discord.Embed(
                title="🚧  Maintenance " + ("Enabled" if is_on else "Disabled"),
                description="Bot is now in maintenance mode." if is_on else "Bot is back online.",
                color=Theme.WARNING if is_on else Theme.SUCCESS, timestamp=datetime.now(),
            )
            embed.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)
            return await interaction.followup.send(embed=embed)

        # ── Clean DB ─────────────────────────────────────────────────────────
        elif action == "clean":
            removed = 0
            async with data_lock:
                for uid in list(vps_data.keys()):
                    before = len(vps_data[uid])
                    vps_data[uid] = [v for v in vps_data[uid] if v.get("container_name")]
                    removed += before - len(vps_data[uid])
                    if not vps_data[uid]:
                        del vps_data[uid]
            await async_save_vps_data()
            return await interaction.followup.send(embed=create_success_embed(
                "🧹  Database Cleaned", f"Removed **{removed}** stale VPS entries."
            ))

        # ── List Containers ──────────────────────────────────────────────────
        elif action == "list":
            rt = (list_runtime or RUNTIME).lower()
            bin_path      = shutil.which("incus" if rt == "incus" else "lxc") or f"/usr/bin/{rt}"
            runtime_label = "Incus" if rt == "incus" else "LXD"

            nodes = ["local"] + [n.strip() for n in (get_setting("registered_nodes") or "").split(",") if n.strip()]
            nid   = max(1, min(list_node_id, len(nodes)))
            node  = nodes[nid - 1]
            prefix = f"{node}:" if node != "local" else ""

            try:
                import shlex
                proc = await asyncio.create_subprocess_exec(
                    *shlex.split(f"{bin_path} list {prefix}--format=csv"),
                    stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
                )
                stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=15)
                if proc.returncode != 0:
                    return await interaction.followup.send(embed=create_error_embed(
                        "List Failed", f"```{stderr.decode()[:1500]}```"
                    ))
                rows = []
                for line in stdout.decode().strip().splitlines():
                    p      = line.split(",")
                    name   = p[0].strip() if p else "?"
                    status = p[1].strip().upper() if len(p) > 1 else "?"
                    ipv4   = p[2].strip() if len(p) > 2 else "—"
                    icon   = "🟢" if status == "RUNNING" else "🔴"
                    rows.append(f"{icon} `{name:<30}` `{status:<8}` `{ipv4}`")

                text  = "\n".join(rows[:25]) or "*No containers found*"
                if len(rows) > 25:
                    text += f"\n*…and {len(rows)-25} more*"
                embed = discord.Embed(
                    title=f"📋  {runtime_label} Containers — Node `{node}`",
                    description=f"**{len(rows)}** container(s) found\n\n{text}",
                    color=Theme.PRIMARY, timestamp=datetime.now(),
                )
                embed.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)
                embed.set_footer(text=f"Runtime: {rt}  ·  Binary: {bin_path}")
                return await interaction.followup.send(embed=embed)
            except asyncio.TimeoutError:
                return await interaction.followup.send(embed=create_error_embed("Timeout", f"`{rt}` timed out after 15s."))
            except Exception as e:
                return await interaction.followup.send(embed=create_error_embed("Error", str(e)[:2000]))

        # ── Premium Tier Management ──────────────────────────────────────────
        elif action == "premium":
            if not premium_action:
                tiers_desc = "\n".join(f"{t['icon']} **{k.title()}** — `{k}`" for k, t in PREMIUM_TIERS.items())
                embed = discord.Embed(
                    title="💎  Premium Tier Management",
                    description=(
                        "Manage premium tiers for users.\n\n"
                        f"**Available Tiers:**\n{tiers_desc}\n\n"
                        "Use `premium_action` to set, remove, or view a user's tier."
                    ),
                    color=0xFFD700, timestamp=datetime.now(),
                )
                embed.set_author(name="MoonNodes — Premium", icon_url=Theme.ICON_URL)
                return await interaction.followup.send(embed=embed)

            # Ensure tier column exists
            try:
                conn = get_db(); cur = conn.cursor()
                cur.execute("ALTER TABLE users ADD COLUMN tier TEXT DEFAULT NULL")
                conn.commit()
            except Exception:
                pass

            if premium_action == "set":
                if not premium_user or not premium_tier:
                    return await interaction.followup.send(embed=create_error_embed(
                        "Missing", "Provide both `premium_user` and `premium_tier`."
                    ))
                conn = get_db(); cur = conn.cursor()
                cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (str(premium_user.id),))
                cur.execute("UPDATE users SET tier=? WHERE user_id=?", (premium_tier, str(premium_user.id)))
                conn.commit()
                tier = PREMIUM_TIERS[premium_tier]
                embed = discord.Embed(
                    title=f"{tier['icon']}  Premium Tier Assigned",
                    description=f"{premium_user.mention} is now **{tier['label']}**.",
                    color=tier["color"], timestamp=datetime.now(),
                )
                embed.set_thumbnail(url=premium_user.display_avatar.url)
                embed.set_author(name="MoonNodes — Premium", icon_url=Theme.ICON_URL)
                embed.set_footer(text=f"Set by {interaction.user.display_name}")
                await interaction.followup.send(embed=embed)
                try:
                    dm = discord.Embed(
                        title=f"{tier['icon']}  You're Now {tier['label']}!",
                        description=(
                            f"Your MoonNodes account has been upgraded to **{tier['label']}**.\n\n"
                            f"Enjoy your premium benefits!"
                        ),
                        color=tier["color"], timestamp=datetime.now(),
                    )
                    dm.set_author(name="MoonNodes Premium", icon_url=Theme.ICON_URL)
                    await premium_user.send(embed=dm)
                except discord.Forbidden:
                    pass

            elif premium_action == "remove":
                if not premium_user:
                    return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `premium_user`."))
                conn = get_db(); cur = conn.cursor()
                cur.execute("UPDATE users SET tier=NULL WHERE user_id=?", (str(premium_user.id),))
                conn.commit()
                return await interaction.followup.send(embed=create_success_embed(
                    "Tier Removed", f"Premium tier removed from {premium_user.mention}."
                ))

            elif premium_action == "view":
                if not premium_user:
                    return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `premium_user`."))
                tier = _get_user_tier(str(premium_user.id))
                if not tier:
                    return await interaction.followup.send(embed=create_info_embed(
                        "No Tier", f"{premium_user.mention} has no premium tier."
                    ))
                embed = discord.Embed(
                    title=f"{tier['icon']}  {tier['label']}",
                    description=f"{premium_user.mention} holds the **{tier['label']}** tier.",
                    color=tier["color"], timestamp=datetime.now(),
                )
                embed.set_thumbnail(url=premium_user.display_avatar.url)
                return await interaction.followup.send(embed=embed)

        # ── MoonCoin Earning Rules ────────────────────────────────────────────
        elif action == "mooncoin":
            conn = get_db(); cur = conn.cursor()
            if mooncoin_action == "list_earn" or not mooncoin_action:
                cur.execute("SELECT name, amount, cooldown FROM mooncoin_rules ORDER BY amount DESC")
                rows = cur.fetchall()
                embed = discord.Embed(title="🌙  MoonCoin Earning Rules", color=Theme.PRIMARY, timestamp=datetime.now())
                embed.set_author(name="MoonNodes — MoonCoin", icon_url=Theme.ICON_URL)
                if not rows:
                    embed.description = "*No custom rules yet.*\n\n**Defaults:** `invite +5` · `chat +1 (300s)` · `giveaway +3` · `event +7`"
                else:
                    embed.description = "\n".join(
                        f"🔹 **{r['name']}** → **+{r['amount']} 🌙**" + (f" · ⏱️ {r['cooldown']}s" if r["cooldown"] else "")
                        for r in rows
                    )
                embed.set_footer(text=f"{len(rows)} custom rule(s)")
                return await interaction.followup.send(embed=embed)
            elif mooncoin_action == "add":
                if not earning_name or earning_amount is None:
                    return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `earning_name` and `earning_amount`."))
                cur.execute("INSERT OR REPLACE INTO mooncoin_rules (name, amount, cooldown) VALUES (?,?,?)",
                            (earning_name.lower(), earning_amount, earning_cooldown or 0))
                conn.commit()
                return await interaction.followup.send(embed=create_success_embed(
                    "Rule Added", f"**{earning_name}** → **+{earning_amount} 🌙**"
                ))
            elif mooncoin_action == "remove_earn":
                if not earning_name:
                    return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `earning_name`."))
                cur.execute("DELETE FROM mooncoin_rules WHERE name=?", (earning_name.lower(),))
                conn.commit()
                return await interaction.followup.send(embed=create_success_embed("Rule Removed", f"`{earning_name}` deleted."))

        # ── A2FA ─────────────────────────────────────────────────────────────
        elif action == "a2fa":
            if not a2fa_action:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Choose an A2FA action."))
            if not cfg.A2FA:
                return await interaction.followup.send(embed=create_error_embed(
                    "Extension Off", "Enable **Admin 2FA** first via Extension Toggle."
                ))
            conn = get_db(); cur = conn.cursor()
            uid  = str(interaction.user.id)
            if a2fa_action == "edit":
                if not new_pin or not new_pin.isdigit() or len(new_pin) != 4:
                    return await interaction.followup.send(embed=create_error_embed("Invalid PIN", "PIN must be exactly 4 digits."))
                cur.execute("INSERT OR IGNORE INTO admins (user_id) VALUES (?)", (uid,))
                cur.execute("UPDATE admins SET pin=? WHERE user_id=?", (new_pin, uid))
                conn.commit()
                return await interaction.followup.send(embed=create_success_embed("🔐 PIN Updated", "Keep it private!"))
            elif a2fa_action == "remove":
                cur.execute("UPDATE admins SET pin='0000' WHERE user_id=?", (uid,))
                conn.commit()
                return await interaction.followup.send(embed=create_success_embed("🔓 PIN Removed", "A2FA disabled for your account."))


# ═══════════════════════════════════════════════════════════════════════════════
#  COG: ADMIN — /vps  /set  /payment
# ═══════════════════════════════════════════════════════════════════════════════

class AdminCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="vps", description="[ADMIN] Suspend or unsuspend a VPS")
    @app_commands.choices(action=[
        app_commands.Choice(name="⛔ Suspend VPS",   value="suspend"),
        app_commands.Choice(name="✅ Unsuspend VPS", value="unsuspend"),
    ])
    @app_commands.describe(container_name="Exact container name", reason="Reason for action")
    @has_role("Owner", "Hard Admin", "Admin", "Dev")
    async def vps_action(self, interaction: discord.Interaction, action: str, container_name: str, reason: str = "Violated Rules"):
        await interaction.response.defer()
        target_vps = None
        _owner_uid = None
        async with data_lock:
            for uid, lst in vps_data.items():
                for vps in lst:
                    if vps["container_name"] == container_name:
                        target_vps = vps
                        _owner_uid = uid
                        break
                if target_vps:
                    break

        if not target_vps:
            return await interaction.followup.send(embed=create_error_embed("Not Found", f"No VPS named `{container_name}`."), ephemeral=True)

        node   = target_vps.get("node", "local")
        prefix = f"{node}:" if node != "local" else ""
        full   = f"{prefix}{container_name}"

        async def _notify_owner(dm_embed: discord.Embed):
            """DM the VPS owner if we know who they are."""
            if _owner_uid:
                try:
                    owner = await interaction.client.fetch_user(int(_owner_uid))
                    await owner.send(embed=dm_embed)
                except Exception:
                    pass

        if action == "suspend":
            try:
                await execute_lxc(f"lxc stop {full}")
                async with data_lock:
                    target_vps["status"]    = "stopped"
                    target_vps["suspended"] = True
                    target_vps.setdefault("suspension_history", []).append({
                        "time": datetime.now().isoformat(), "reason": reason, "by": interaction.user.name
                    })
                await async_save_vps_data()
                embed = discord.Embed(
                    title="⛔ VPS Suspended",
                    description=f"Container **`{container_name}`** has been suspended.\n\n**Reason:** {reason}",
                    color=Theme.ERROR, timestamp=datetime.now(),
                )
                embed.set_author(name="MoonNodes — Admin", icon_url=Theme.ICON_URL)
                embed.set_footer(text=f"By {interaction.user.display_name}")
                await interaction.followup.send(embed=embed)
                dm = discord.Embed(
                    title="⛔ Your VPS Has Been Suspended",
                    description=f"**`{container_name}`** has been suspended by a staff member.\n\n**Reason:** {reason}\n\nContact support if you believe this is a mistake.",
                    color=Theme.ERROR, timestamp=datetime.now(),
                )
                dm.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)
                await _notify_owner(dm)
            except Exception as e:
                await interaction.followup.send(embed=create_error_embed("Failed", str(e)[:4000]), ephemeral=True)

        elif action == "unsuspend":
            try:
                await execute_lxc(f"lxc start {full}")
                async with data_lock:
                    target_vps["suspended"] = False
                    target_vps["status"]    = "running"
                await async_save_vps_data()
                embed = discord.Embed(
                    title="✅ VPS Unsuspended",
                    description=f"Container **`{container_name}`** is now active again.",
                    color=Theme.SUCCESS, timestamp=datetime.now(),
                )
                embed.set_author(name="MoonNodes — Admin", icon_url=Theme.ICON_URL)
                await interaction.followup.send(embed=embed)
                dm = discord.Embed(
                    title="✅ Your VPS Has Been Reactivated",
                    description=f"**`{container_name}`** has been unsuspended and is now running again.",
                    color=Theme.SUCCESS, timestamp=datetime.now(),
                )
                dm.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)
                await _notify_owner(dm)
            except Exception as e:
                await interaction.followup.send(embed=create_error_embed("Failed", str(e)[:4000]), ephemeral=True)

    @app_commands.command(name="set", description="[ADMIN] Configure bot settings, channels, thresholds, and schedules")
    @app_commands.choices(setting=[
        app_commands.Choice(name="Log Channel",       value="log_channel"),
        app_commands.Choice(name="Payment Channel",   value="payment_channel"),
        app_commands.Choice(name="Ticket Channel",    value="ticket_channel"),
        app_commands.Choice(name="CPU Threshold %",   value="cpu_threshold"),
        app_commands.Choice(name="RAM Threshold %",   value="ram_threshold"),
        app_commands.Choice(name="Backup Limits",     value="backup_limits"),
        app_commands.Choice(name="Scheduled Backups", value="scheduled_backups"),
    ])
    @app_commands.describe(setting="Setting to configure", value="New value", option="Modifier", date="Date e.g. 1/12/2025", time="Time e.g. 02:00AM")
    @has_role("Owner", "Hard Admin", "Admin")
    async def set_cmd(self, interaction: discord.Interaction, setting: str, value: str,
                      option: str = None, date: str = None, time: str = None):
        await interaction.response.defer(ephemeral=True)
        if setting in ("backup_limits", "scheduled_backups"):
            set_setting(f"{setting}_enabled", value)
            if option: set_setting(f"{setting}_option", option)
            if date:   set_setting(f"{setting}_date", date)
            if time:   set_setting(f"{setting}_time", time)
            embed = create_success_embed(f"{'Backup Limits' if setting == 'backup_limits' else 'Scheduled Backups'} Updated")
            add_field(embed, "Status", value, True)
            if option: add_field(embed, "Option", option, True)
            if date:   add_field(embed, "Date",   date,   True)
            if time:   add_field(embed, "Time",   time,   True)
        else:
            set_setting(setting, value)
            labels = {"log_channel": "Log Channel", "payment_channel": "Payment Channel",
                      "ticket_channel": "Ticket Channel", "cpu_threshold": "CPU Threshold", "ram_threshold": "RAM Threshold"}
            embed = create_success_embed("Setting Updated", f"**{labels.get(setting, setting)}** → `{value}`")
        await interaction.followup.send(embed=embed)

    @app_commands.command(name="payment", description="[ADMIN] Manage payment methods shown in /plans")
    @app_commands.choices(action=[
        app_commands.Choice(name="Add/Edit", value="add"),
        app_commands.Choice(name="Remove",   value="remove"),
        app_commands.Choice(name="List",     value="list"),
    ])
    @app_commands.describe(payment_name="Payment method name (e.g. GCash)", image="QR code or payment image")
    @has_role("Owner", "Hard Admin", "Admin")
    async def payment_cmd(self, interaction: discord.Interaction, action: str,
                          payment_name: str = None, image: discord.Attachment = None):
        await interaction.response.defer(ephemeral=True)
        conn = get_db(); cur = conn.cursor()
        if action == "list":
            rows = get_payments()
            if not rows:
                return await interaction.followup.send(embed=create_error_embed("Empty", "No payment methods saved."))
            embed = create_embed("💳  Payment Methods", f"{len(rows)} method(s) configured.")
            for r in rows:
                add_field(embed, r["name"], r["image_url"][:200], True)
            return await interaction.followup.send(embed=embed)
        if not payment_name:
            return await interaction.followup.send(embed=create_error_embed("Missing", "Provide `payment_name`."))
        if action == "add":
            if not image or not image.content_type.startswith("image/"):
                return await interaction.followup.send(embed=create_error_embed("Missing Image", "Attach a valid image file."))
            cur.execute("INSERT OR REPLACE INTO payments (name, image_url) VALUES (?,?)", (payment_name, image.url))
            conn.commit()
            return await interaction.followup.send(embed=create_success_embed("Saved", f"Payment method **{payment_name}** saved."))
        elif action == "remove":
            cur.execute("DELETE FROM payments WHERE name=?", (payment_name,))
            conn.commit()
            return await interaction.followup.send(embed=create_success_embed("Removed", f"**{payment_name}** removed."))


# ═══════════════════════════════════════════════════════════════════════════════
#  COG: OWNER — /create  /delete  /giveaway
# ═══════════════════════════════════════════════════════════════════════════════

class DeployCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="create", description="[ADMIN] Deploy a VPS for a user — choose node then OS")
    @app_commands.describe(
        user="Discord user @mention", user_id="Fallback: paste Discord User ID",
        plan_name="Plan name (e.g. basic) — overrides manual specs",
        ram_gb="RAM in GB", cpu_cores="CPU cores", disk_gb="Disk in GB",
        validity_days="Expiry in days (0 = permanent)",
    )
    @has_role("Owner", "Hard Admin", "Admin", "Dev")
    async def create_cmd(self, interaction: discord.Interaction,
                         user: discord.Member = None, user_id: str = None,
                         plan_name: str = None, ram_gb: int = None,
                         cpu_cores: int = None, disk_gb: int = None, validity_days: int = 0):
        await interaction.response.defer(ephemeral=True)
        if not user and not user_id:
            return await interaction.followup.send(embed=create_error_embed("Missing User", "Provide a `user` mention or `user_id`."))
        if not user and user_id:
            try:
                user = await interaction.client.fetch_user(int(user_id))
                user.display_name = user.name
            except Exception:
                return await interaction.followup.send(embed=create_error_embed("Not Found", f"Could not find user with ID `{user_id}`."))

        if plan_name:
            pn   = plan_name.lower()
            plan = PLANS.get("premium", {}).get(pn) or PLANS.get("free", {}).get(pn)
            if not plan:
                return await interaction.followup.send(embed=create_error_embed("Invalid Plan", f"`{plan_name}` not found. Check `/plans`."))
            final_ram, final_cpu, final_disk, label = plan["ram"], plan["cpu"], plan["disk"], plan_name.title()
        else:
            if not all([ram_gb, cpu_cores, disk_gb]):
                return await interaction.followup.send(embed=create_error_embed("Missing Specs", "Provide `plan_name` OR `ram_gb`, `cpu_cores`, `disk_gb`."))
            final_ram, final_cpu, final_disk, label = ram_gb, cpu_cores, disk_gb, "Custom"

        if ENFORCE_RESOURCE_LIMITS:
            if final_ram > MAX_RAM_LIMIT:
                return await interaction.followup.send(embed=create_error_embed("Limit Exceeded", f"RAM {final_ram}GB > max {MAX_RAM_LIMIT}GB."))
            if final_cpu > MAX_CPU_LIMIT:
                return await interaction.followup.send(embed=create_error_embed("Limit Exceeded", f"CPU {final_cpu} cores > max {MAX_CPU_LIMIT}."))

        from core import ACTIVE_STORAGE_POOL
        view = await NodeSelectView.create(
            invoker_id=str(interaction.user.id), ram=final_ram, cpu=final_cpu, disk=final_disk,
            target_user=user, plan_name=label, validity_days=validity_days or None,
            storage_pool=ACTIVE_STORAGE_POOL,
        )
        embed = discord.Embed(
            title="🌐  Step 1 — Select Deployment Node",
            description=(
                f"**User:** {user.mention}  ·  **Plan:** {label}\n"
                f"**Specs:** `{final_ram}GB RAM / {final_cpu} CPU / {final_disk}GB Disk`\n\n"
                "Select the node to deploy this VPS on:"
            ),
            color=Theme.PRIMARY, timestamp=datetime.now(),
        )
        embed.set_author(name="MoonNodes — Deploy VPS", icon_url=Theme.ICON_URL)
        await interaction.followup.send(embed=embed, view=view)

    @app_commands.command(name="delete", description="[ADMIN] Permanently delete a user's VPS")
    @app_commands.describe(user="Target user", vps_number="VPS number (1, 2…)", reason="Reason")
    @has_role("Owner", "Hard Admin", "Admin", "Mod", "Dev")
    async def delete_vps(self, interaction: discord.Interaction, user: discord.Member, vps_number: int, reason: str = "Violated Rules"):
        uid = str(user.id)
        async with data_lock:
            if uid not in vps_data or vps_number < 1 or vps_number > len(vps_data[uid]):
                return await interaction.response.send_message(embed=create_error_embed("Error", "Invalid user or VPS number."), ephemeral=True)
            vps  = vps_data[uid][vps_number - 1]
            cname, node = vps["container_name"], vps.get("node", "local")
            prefix = f"{node}:" if node != "local" else ""

        view = ConfirmView(str(interaction.user.id), requires_2fa=True)
        await interaction.response.send_message(
            embed=create_warning_embed("⚠️ Delete VPS?", f"Delete `{cname}`? **All data will be lost permanently.**"),
            view=view,
        )
        await view.wait()
        if not view.value:
            return await interaction.edit_original_response(embed=create_info_embed("Cancelled", "Deletion cancelled."), view=None)

        await interaction.edit_original_response(embed=create_info_embed("⏳ Deleting…", f"Removing `{cname}`…"), view=None)
        try:
            await execute_lxc(f"lxc delete {prefix}{cname} --force")
        except Exception:
            pass
        async with data_lock:
            if uid in vps_data and len(vps_data[uid]) >= vps_number:
                del vps_data[uid][vps_number - 1]
                if not vps_data[uid]:
                    del vps_data[uid]
        await async_save_vps_data()

        embed = discord.Embed(
            title="🗑️  VPS Deleted",
            description=f"Container **`{cname}`** has been permanently removed.\n\n**Reason:** {reason}",
            color=Theme.SUCCESS, timestamp=datetime.now(),
        )
        embed.set_author(name="MoonNodes — Admin", icon_url=Theme.ICON_URL)
        embed.set_footer(text=f"Deleted by {interaction.user.display_name}")
        await interaction.edit_original_response(embed=embed)

        try:
            owner_user = await interaction.client.fetch_user(int(uid))
            dm = discord.Embed(
                title="🗑️  Your VPS Was Deleted",
                description=f"Your VPS **`{cname}`** has been removed by a staff member.\n\n**Reason:** {reason}\n\nIf this was a mistake, open a ticket with `/support`.",
                color=Theme.ERROR,
            )
            dm.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)
            await owner_user.send(embed=dm)
        except Exception:
            pass

    @app_commands.command(name="giveaway", description="[ADMIN] Start, cancel, or list VPS giveaways")
    @app_commands.choices(action=[
        app_commands.Choice(name="🎉 Create", value="create"),
        app_commands.Choice(name="❌ Cancel", value="delete"),
        app_commands.Choice(name="📋 List",   value="list"),
    ])
    @app_commands.describe(
        duration_minutes="Duration in minutes", ram="RAM in GB", cpu="CPU cores", disk="Disk in GB",
        winners="Number of winners", description="Giveaway message", target_id="Giveaway ID to cancel",
    )
    @has_role("Owner", "Hard Admin", "Admin")
    async def giveaway_cmd(self, interaction: discord.Interaction, action: str,
                           duration_minutes: int = None, ram: int = None, cpu: int = None,
                           disk: int = None, winners: int = None, description: str = None, target_id: str = None):
        await interaction.response.defer(ephemeral=True)
        if action == "create":
            if not all([duration_minutes, ram, cpu, disk, winners]):
                return await interaction.followup.send(embed=create_error_embed("Missing", "Provide duration, ram, cpu, disk, and winners."))
            g_id     = uuid.uuid4().hex[:6].upper()
            end_time = int(time.time() + duration_minutes * 60)
            embed = discord.Embed(
                title=f"🎉  VPS Giveaway  `[{g_id}]`",
                description=description or "React below to enter!",
                color=0xFFD700, timestamp=datetime.now(),
            )
            embed.add_field(name="📦 Specs",    value=f"`{ram}GB RAM / {cpu} CPU / {disk}GB Disk`", inline=True)
            embed.add_field(name="🏆 Winners",  value=str(winners), inline=True)
            embed.add_field(name="⏰ Ends",     value=f"<t:{end_time}:R>", inline=True)
            embed.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)
            embed.set_footer(text="Click Enter Giveaway to participate!")

            view = GiveawayView(g_id)
            await interaction.followup.send(embed=create_success_embed("Giveaway Started", f"ID: `[{g_id}]`"))
            msg  = await interaction.channel.send(embed=embed, view=view)

            async def _giveaway_task():
                await asyncio.sleep(duration_minutes * 60)
                if g_id not in active_giveaways: return
                del active_giveaways[g_id]
                if not view.entrants:
                    try: await msg.reply(embed=create_error_embed("Giveaway Ended", "Nobody entered."))
                    except: pass
                    return
                drawn = random.sample(list(view.entrants), min(winners, len(view.entrants)))
                tags  = [f"<@{uid}>" for uid in drawn]
                await msg.reply(content=", ".join(tags),
                                embed=create_success_embed("🎉 Winners!", ", ".join(tags) + " — check your DMs!"))
                from core import ACTIVE_STORAGE_POOL
                for uid in drawn:
                    try:
                        member = interaction.guild.get_member(uid) or await interaction.guild.fetch_member(uid)
                        node_prefix = await get_best_node()
                        vps_entry   = await deploy_container(
                            user_id=str(uid), username=member.name, ram=ram, cpu=cpu, disk=disk,
                            os_version=normalize_os("ubuntu:22.04"), validity_days=None,
                            target_node=node_prefix, storage_pool=ACTIVE_STORAGE_POOL,
                        )
                        dm = discord.Embed(
                            title="🎉  You Won a VPS!",
                            description=f"Container: `{vps_entry.get('container_name','—')}`\nSpecs: `{ram}GB RAM / {cpu} CPU / {disk}GB`\n\nUse `/manage` to start your VPS.",
                            color=0xFFD700,
                        )
                        dm.set_author(name="MoonNodes VPS Manager", icon_url=Theme.ICON_URL)
                        await member.send(embed=dm)
                    except Exception as e:
                        logger.warning(f"Giveaway VPS deploy failed for {uid}: {e}")

            task = asyncio.create_task(_giveaway_task())
            active_giveaways[g_id] = {"task": task, "end": end_time, "msg": msg.jump_url}

        elif action == "delete":
            if not target_id or target_id not in active_giveaways:
                return await interaction.followup.send(embed=create_error_embed("Not Found", f"Giveaway `{target_id}` not found."))
            active_giveaways[target_id]["task"].cancel()
            del active_giveaways[target_id]
            await interaction.followup.send(embed=create_success_embed("Cancelled", f"Giveaway `[{target_id}]` cancelled."))

        elif action == "list":
            if not active_giveaways:
                return await interaction.followup.send(embed=create_info_embed("No Giveaways", "No active giveaways right now."))
            embed = create_embed("🎉  Active Giveaways", f"{len(active_giveaways)} running")
            for gid, data in active_giveaways.items():
                embed.add_field(name=f"`{gid}`", value=f"Ends <t:{data['end']}:R> · [View]({data['msg']})", inline=True)
            await interaction.followup.send(embed=embed)


# ═══════════════════════════════════════════════════════════════════════════════
#  COG: MOD — /mod
# ═══════════════════════════════════════════════════════════════════════════════

class ModCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="mod", description="[MOD] Moderation tools — user info, VPS info, warnings, stats")
    @app_commands.choices(action=[
        app_commands.Choice(name="👤 User Info",        value="user_info"),
        app_commands.Choice(name="🖥️ VPS Info",         value="vps_info"),
        app_commands.Choice(name="📋 List VPS",         value="list_vps"),
        app_commands.Choice(name="🔍 Search",           value="search"),
        app_commands.Choice(name="📊 Server Stats",     value="server_stats"),
        app_commands.Choice(name="🎫 Open Tickets",     value="tickets"),
        app_commands.Choice(name="📝 Suspension Logs",  value="susp_logs"),
        app_commands.Choice(name="💬 DM User",          value="dm_user"),
        app_commands.Choice(name="⚠️ Warn User",        value="warn"),
        app_commands.Choice(name="📜 Warn Log",         value="warn_log"),
    ])
    @app_commands.describe(action="Mod action", target_user="Target user",
                           container_name="Container name", message="Message/reason")
    async def mod_cmd(self, interaction: discord.Interaction, action: str,
                      target_user: discord.Member = None, container_name: str = None, message: str = None):
        await interaction.response.defer(ephemeral=True)
        if not _is_mod(interaction.user.id):
            return await interaction.followup.send(embed=create_error_embed("Access Denied", "Mod or above required."))

        if action == "user_info":
            if not target_user:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Specify `target_user`."))
            uid = str(target_user.id)
            conn = get_db(); cur = conn.cursor()
            cur.execute("SELECT mooncoin FROM users WHERE user_id=?", (uid,))
            row = cur.fetchone()
            coins = row["mooncoin"] if row else 0
            async with data_lock:
                vps_count = len(vps_data.get(uid, []))
            tier = _get_user_tier(uid)
            embed = discord.Embed(
                title=f"👤  {target_user.display_name}{_premium_badge(uid)}",
                color=tier["color"] if tier else Theme.PRIMARY, timestamp=datetime.now(),
            )
            embed.set_thumbnail(url=target_user.display_avatar.url)
            embed.set_author(name="MoonNodes — Mod", icon_url=Theme.ICON_URL)
            embed.add_field(name="ID",        value=f"`{target_user.id}`", inline=True)
            embed.add_field(name="Joined",    value=f"<t:{int(target_user.joined_at.timestamp())}:R>" if target_user.joined_at else "?", inline=True)
            embed.add_field(name="VPS",       value=str(vps_count), inline=True)
            embed.add_field(name="🌙 Coins",  value=f"{coins:,}", inline=True)
            embed.add_field(name="Staff",     value=admin_data.get(uid, "User"), inline=True)
            if tier: embed.add_field(name="Tier", value=tier["label"], inline=True)
            return await interaction.followup.send(embed=embed)

        elif action == "vps_info":
            if not container_name:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Specify `container_name`."))
            found = owner = None
            async with data_lock:
                for uid, lst in vps_data.items():
                    for v in lst:
                        if v["container_name"] == container_name:
                            found = v; owner = uid; break
            if not found:
                return await interaction.followup.send(embed=create_error_embed("Not Found", f"`{container_name}` not in database."))
            m = interaction.guild.get_member(int(owner)) if interaction.guild else None
            embed = discord.Embed(title=f"🖥️  `{container_name}`", color=Theme.PRIMARY, timestamp=datetime.now())
            embed.set_author(name="MoonNodes — Mod", icon_url=Theme.ICON_URL)
            embed.add_field(name="Owner",  value=m.mention if m else f"<@{owner}>", inline=True)
            embed.add_field(name="Status", value=("SUSPENDED" if found.get("suspended") else found.get("status", "?")).upper(), inline=True)
            embed.add_field(name="Node",   value=found.get("node", "local"), inline=True)
            embed.add_field(name="Specs",  value=found.get("config", "?"), inline=True)
            embed.add_field(name="OS",     value=found.get("os_version", "?"), inline=True)
            return await interaction.followup.send(embed=embed)

        elif action == "list_vps":
            if not target_user:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Specify `target_user`."))
            uid = str(target_user.id)
            async with data_lock:
                lst = list(vps_data.get(uid, []))
            if not lst:
                return await interaction.followup.send(embed=create_info_embed("No VPS", f"{target_user.mention} has no VPS."))
            embed = create_embed(f"🖥️  VPS for {target_user.display_name}", f"{len(lst)} instance(s)")
            for i, v in enumerate(lst, 1):
                icon = "⛔" if v.get("suspended") else ("🟢" if v.get("status") == "running" else "🔴")
                embed.add_field(name=f"{icon} #{i} `{v['container_name']}`",
                                value=f"{v.get('config','?')} · {v.get('node','local')}", inline=True)
            return await interaction.followup.send(embed=embed)

        elif action == "search":
            if not container_name:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Specify `container_name`."))
            results = []
            async with data_lock:
                for uid, lst in vps_data.items():
                    for v in lst:
                        if container_name.lower() in v["container_name"].lower():
                            m = interaction.guild.get_member(int(uid)) if interaction.guild else None
                            results.append(f"• `{v['container_name']}` — {m.mention if m else uid}")
            if not results:
                return await interaction.followup.send(embed=create_info_embed("No Results", f"No containers matching `{container_name}`."))
            return await interaction.followup.send(embed=create_info_embed(f"🔍 Search: `{container_name}`", "\n".join(results[:20])))

        elif action == "server_stats":
            async with data_lock:
                total   = sum(len(v) for v in vps_data.values())
                running = sum(1 for lst in vps_data.values() for v in lst if v.get("status") == "running")
                susp    = sum(1 for lst in vps_data.values() for v in lst if v.get("suspended"))
                users   = len(vps_data)
            embed = discord.Embed(title="📊  Server Stats", color=Theme.PRIMARY, timestamp=datetime.now())
            embed.set_author(name="MoonNodes — Mod", icon_url=Theme.ICON_URL)
            embed.add_field(name="👥 Users with VPS", value=str(users), inline=True)
            embed.add_field(name="🖥️ Total VPS",      value=str(total), inline=True)
            embed.add_field(name="🟢 Running",        value=str(running), inline=True)
            embed.add_field(name="⛔ Suspended",      value=str(susp), inline=True)
            embed.add_field(name="🔴 Stopped",        value=str(total - running - susp), inline=True)
            embed.add_field(name="👮 Staff",          value=str(len(admin_data)), inline=True)
            return await interaction.followup.send(embed=embed)

        elif action == "tickets":
            ch_id = get_setting("ticket_channel")
            if not ch_id:
                return await interaction.followup.send(embed=create_info_embed("Tickets", "No ticket channel configured."))
            ch = interaction.guild.get_channel(int(ch_id)) if interaction.guild else None
            if not ch:
                return await interaction.followup.send(embed=create_error_embed("Gone", "Ticket channel not found."))
            threads = [t for t in interaction.guild.threads if t.parent_id == int(ch_id) and not t.archived]
            if not threads:
                return await interaction.followup.send(embed=create_info_embed("No Tickets", "No open support threads."))
            embed = create_info_embed(f"🎫  Open Tickets ({len(threads)})", "\n".join(f"• {t.mention}" for t in threads[:20]))
            return await interaction.followup.send(embed=embed)

        elif action == "susp_logs":
            logs = []
            async with data_lock:
                for uid, lst in vps_data.items():
                    for v in lst:
                        for h in v.get("suspension_history", [])[-3:]:
                            m = interaction.guild.get_member(int(uid)) if interaction.guild else None
                            try:
                                ts = int(datetime.fromisoformat(h["time"]).timestamp())
                                logs.append(f"• **{v['container_name']}** ({m.display_name if m else uid}) — {h.get('reason','?')} <t:{ts}:R>")
                            except Exception:
                                pass
            if not logs:
                return await interaction.followup.send(embed=create_info_embed("Suspension Logs", "No suspension events recorded."))
            return await interaction.followup.send(embed=create_info_embed("📝  Suspension Logs", "\n".join(logs[:20])))

        elif action == "dm_user":
            if not target_user or not message:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Specify `target_user` and `message`."))
            try:
                dm = discord.Embed(title="📬  Message from MoonNodes Staff", description=message, color=Theme.WARNING, timestamp=datetime.now())
                dm.set_author(name="MoonNodes Moderation", icon_url=Theme.ICON_URL)
                dm.set_footer(text=f"Sent by {interaction.user.display_name}")
                await target_user.send(embed=dm)
                return await interaction.followup.send(embed=create_success_embed("DM Sent", f"Delivered to {target_user.mention}."))
            except discord.Forbidden:
                return await interaction.followup.send(embed=create_error_embed("Failed", f"{target_user.mention} has DMs disabled."))

        elif action == "warn":
            if not target_user or not message:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Specify `target_user` and `message`."))
            conn = get_db(); cur = conn.cursor()
            cur.execute("INSERT INTO warnings (user_id, reason, by_id, at) VALUES (?,?,?,?)",
                        (str(target_user.id), message, str(interaction.user.id), datetime.now().isoformat()))
            conn.commit()
            try:
                dm = discord.Embed(title="⚠️  Warning", description=f"**Reason:** {message}", color=Theme.WARNING, timestamp=datetime.now())
                dm.set_author(name="MoonNodes Moderation", icon_url=Theme.ICON_URL)
                await target_user.send(embed=dm)
            except Exception: pass
            return await interaction.followup.send(embed=create_success_embed("Warning Issued", f"{target_user.mention}: {message}"))

        elif action == "warn_log":
            if not target_user:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Specify `target_user`."))
            conn = get_db(); cur = conn.cursor()
            try:
                cur.execute("SELECT reason, at, by_id FROM warnings WHERE user_id=? ORDER BY at DESC LIMIT 10", (str(target_user.id),))
                rows = cur.fetchall()
            except Exception: rows = []
            if not rows:
                return await interaction.followup.send(embed=create_info_embed("Clean", f"{target_user.mention} has no warnings."))
            embed = create_embed(f"📜  Warnings — {target_user.display_name}", f"{len(rows)} warning(s)")
            for r in rows:
                ts = int(datetime.fromisoformat(r["at"]).timestamp())
                embed.add_field(name=f"<t:{ts}:R>", value=r["reason"], inline=False)
            return await interaction.followup.send(embed=embed)


# ═══════════════════════════════════════════════════════════════════════════════
#  COG: DEV — /dev
# ═══════════════════════════════════════════════════════════════════════════════

class DevCog(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="dev", description="[DEV] Developer tools and diagnostics")
    @app_commands.choices(action=[
        app_commands.Choice(name="⚙️ Config Dump",      value="config"),
        app_commands.Choice(name="🗃️ DB Stats",          value="db_stats"),
        app_commands.Choice(name="🔧 Runtime Info",      value="runtime"),
        app_commands.Choice(name="📡 Test LXC",          value="test_lxc"),
        app_commands.Choice(name="🌡️ Host Stats",        value="host_stats"),
        app_commands.Choice(name="📝 Error Log",         value="log"),
        app_commands.Choice(name="🔄 Reload Cog",        value="reload"),
        app_commands.Choice(name="🔔 Test DM",           value="test_dm"),
        app_commands.Choice(name="🌐 Extension State",   value="ext_state"),
        app_commands.Choice(name="🧹 Purge Cache",       value="purge_cache"),
    ])
    @app_commands.describe(action="Dev action", cog="Cog to reload", option="Extra argument")
    async def dev_cmd(self, interaction: discord.Interaction, action: str, cog: str = None, option: str = None):
        await interaction.response.defer(ephemeral=True)
        if not (_is_owner(interaction.user.id) or admin_data.get(str(interaction.user.id)) in ("Owner", "Dev")):
            return await interaction.followup.send(embed=create_error_embed("Denied", "Developer only."))

        if action == "config":
            attrs = ["DISCORD_TOKEN", "MAIN_ADMIN_ID", "VPS_PREFIX", "MULTI_NODE", "SOSB",
                     "ISTS", "AES", "RR", "A2FA", "MSTC", "UBL_ENABLED", "MARKETPLACE",
                     "ACCOUNT", "VPS_MONITORING", "VPS_RENEWAL"]
            lines = []
            for a in attrs:
                val = getattr(cfg, a, "N/A")
                if a == "DISCORD_TOKEN":
                    val = f"{str(val)[:6]}…" if val else "NOT SET"
                lines.append(f"`{a}` = `{val}`")
            return await interaction.followup.send(embed=create_embed("⚙️  Runtime Config", "\n".join(lines)))

        elif action == "db_stats":
            conn = get_db(); cur = conn.cursor()
            tables = ["settings", "users", "admins", "payments", "marketplace", "warnings", "staff_notes", "mooncoin_rules"]
            lines  = []
            for t in tables:
                try:
                    cur.execute(f"SELECT COUNT(*) FROM {t}"); count = cur.fetchone()[0]
                    lines.append(f"• `{t}` — **{count}** rows")
                except Exception:
                    lines.append(f"• `{t}` — *missing*")
            async with data_lock:
                lines.append(f"• `vps (memory)` — **{sum(len(v) for v in vps_data.values())}** entries")
            return await interaction.followup.send(embed=create_info_embed("🗃️  DB Stats", "\n".join(lines)))

        elif action == "runtime":
            import subprocess as _sp
            rt_path = shutil.which(RUNTIME) or "not found"
            try:
                v   = _sp.run([RUNTIME, "version"], capture_output=True, text=True, timeout=5)
                ver = v.stdout.strip() or v.stderr.strip()
            except Exception as e:
                ver = str(e)
            return await interaction.followup.send(embed=create_info_embed("🔧  Runtime",
                f"Binary: `{RUNTIME}`\nPath: `{rt_path}`\nVersion:\n```{ver[:500]}```"))

        elif action == "test_lxc":
            try:
                out  = await execute_lxc("lxc list --format=csv")
                text = str(out)[:1500] if out and out is not True else "(no containers)"
                return await interaction.followup.send(embed=create_success_embed("✅  LXC Works", f"```{text}```"))
            except Exception as e:
                return await interaction.followup.send(embed=create_error_embed("LXC Failed", str(e)[:2000]))

        elif action == "host_stats":
            from core.lxc import _host_cpu_pct, _host_cpu_cores, _host_ram, _host_disk
            cpu   = _host_cpu_pct()
            cores = _host_cpu_cores()
            ur, tr = _host_ram()
            ud, td = _host_disk()
            embed  = create_embed("🌡️  Host Stats", "")
            embed.add_field(name="CPU",  value=f"{Theme.progress_bar(cpu)}\n`{cpu:.1f}%` ({cores} cores)", inline=False)
            embed.add_field(name="RAM",  value=f"{Theme.progress_bar(ur/tr*100 if tr else 0)}\n`{ur}/{tr} MB`", inline=False)
            embed.add_field(name="Disk", value=f"{Theme.progress_bar(ud/td*100 if td else 0)}\n`{ud}/{td} GB`", inline=False)
            return await interaction.followup.send(embed=embed)

        elif action == "log":
            import os
            if not os.path.exists("bot.log"):
                return await interaction.followup.send(embed=create_error_embed("Not Found", "bot.log not found."))
            with open("bot.log") as f:
                tail = "".join(f.readlines()[-20:])[:1800]
            return await interaction.followup.send(embed=create_info_embed("📝  Last 20 Log Lines", f"```{tail}```"))

        elif action == "reload":
            target = cog or option
            if not target:
                return await interaction.followup.send(embed=create_error_embed("Missing", "Provide a cog path to reload."))
            try:
                await interaction.client.reload_extension(target)
                return await interaction.followup.send(embed=create_success_embed("🔄  Reloaded", f"`{target}` reloaded successfully."))
            except Exception as e:
                return await interaction.followup.send(embed=create_error_embed("Failed", str(e)[:2000]))

        elif action == "test_dm":
            try:
                await interaction.user.send(embed=discord.Embed(
                    title="🔔  Test DM", description="Bot DM system is working correctly.", color=Theme.SUCCESS
                ))
                return await interaction.followup.send(embed=create_success_embed("DM Sent", "Check your DMs!"))
            except discord.Forbidden:
                return await interaction.followup.send(embed=create_error_embed("DM Failed", "You have DMs disabled."))

        elif action == "ext_state":
            ext_attrs = ["MULTI_NODE","SOSB","ISTS","AES","RR","A2FA","MSTC",
                         "UBL_ENABLED","MARKETPLACE","ACCOUNT","VPS_MONITORING","VPS_RENEWAL","VPS_TEMPLATES","MULTILANG"]
            lines = [f"{'🟢' if getattr(cfg, a, False) else '🔴'} `{a}`" for a in ext_attrs]
            return await interaction.followup.send(embed=create_info_embed("🌐  Extension States", "\n".join(lines)))

        elif action == "purge_cache":
            load_vps_data(); load_admin_data()
            return await interaction.followup.send(embed=create_success_embed("Cache Purged", "VPS and admin data reloaded from disk."))


# ═══════════════════════════════════════════════════════════════════════════════
#  ALL SETUPS
# ═══════════════════════════════════════════════════════════════════════════════

# ─── Import the remaining cogs from their individual files ────────────────────
# Staff, User commands, and Node management are imported from the existing
# individual files since they contain complex UI logic (views, modals, etc.)
# that would make this file too large. They still register as part of the bot.

async def setup(bot):
    """Register all command cogs with the bot."""
    await bot.add_cog(RoleCog(bot))
    await bot.add_cog(SystemCog(bot))
    await bot.add_cog(AdminCog(bot))
    await bot.add_cog(DeployCog(bot))
    await bot.add_cog(ModCog(bot))
    await bot.add_cog(DevCog(bot))
