import json
import logging

logger = logging.getLogger("moonnodes_vps_bot")


def load_codes() -> dict:
    try:
        with open("codes.json", "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def save_codes(data: dict):
    try:
        with open("codes.json", "w") as f:
            json.dump(data, f, indent=4)
    except Exception as e:
        logger.error(f"Failed to save codes.json: {e}")
