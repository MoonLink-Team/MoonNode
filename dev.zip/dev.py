import discord
from discord.ext import commands
from discord import app_commands
from bot import has_role, create_success_embed

class DevCmds(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="dev-ping", description="[DEV] Quick system check & permissions evaluation")
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @has_role('Owner', 'Dev')
    async def dev_ping(self, interaction: discord.Interaction):
        await interaction.response.send_message(embed=create_success_embed("Dev Matrix Online", f"Backend Logic Verified.\nLatency: {round(self.bot.latency * 1000)}ms"), ephemeral=True)

async def setup(bot: commands.Bot):
    await bot.add_cog(DevCmds(bot))