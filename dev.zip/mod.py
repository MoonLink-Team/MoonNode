import discord
from discord.ext import commands
from discord import app_commands
from bot import (
    has_role, create_success_embed, create_error_embed, create_info_embed, create_warning_embed,
    execute_lxc, ConfirmView, get_or_create_vps_role, send_log, add_field
)
from database import vps_data, data_lock, save_vps_data

class ModCmds(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="delete", description="[ADMIN/MOD] Permanently glass an asset")
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @has_role('Owner', 'Admin', 'Mod', 'Dev')
    async def delete_vps(self, interaction: discord.Interaction, user: discord.Member, vps_number: int, reason: str = "TOS Enforcement"):
        user_id = str(user.id)
        with data_lock:
            if user_id not in vps_data or vps_number < 1 or vps_number > len(vps_data[user_id]):
                return await interaction.response.send_message(embed=create_error_embed("Pointer Error", "Array out of bounds."), ephemeral=True)
            container_name = vps_data[user_id][vps_number - 1]["container_name"]
        
        view = ConfirmView(str(interaction.user.id))
        await interaction.response.send_message(embed=create_warning_embed("Critical Glassing Request", f"Authorize nuclear wipe of `{container_name}`?"), view=view)
        await view.wait()
        if not view.value: return await interaction.edit_original_response(embed=create_info_embed("Wipe Cancelled", "Safety systems re-engaged."), view=None)

        await interaction.edit_original_response(embed=create_info_embed("Glassing Matrix", f"Scrubbing `{container_name}`..."), view=None)
        try:
            await execute_lxc(f"lxc delete {container_name} --force")
            with data_lock:
                if user_id in vps_data and len(vps_data[user_id]) >= vps_number:
                    del vps_data[user_id][vps_number - 1]
                    if not vps_data[user_id]:
                        del vps_data[user_id]
                        if interaction.guild:
                            role = await get_or_create_vps_role(interaction.guild)
                            if role: try: await user.remove_roles(role) except: pass
            save_vps_data()
            embed = create_success_embed("Sector Glassed")
            add_field(embed, "Network Core", f"`{container_name}`", True)
            add_field(embed, "Justification", reason, False)
            await interaction.edit_original_response(embed=embed)
            await send_log(embed)
        except Exception as e: await interaction.edit_original_response(embed=create_error_embed("Wipe Failed", f"Core Fault: `{str(e)[:4000]}`"))

async def setup(bot: commands.Bot): await bot.add_cog(ModCmds(bot))