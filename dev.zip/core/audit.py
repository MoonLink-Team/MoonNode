"""
core/audit.py — Admin action audit log.

Every admin/staff action that modifies data is recorded here.
Writes to the audit_log table in system.db AND posts to the log channel.

Usage:
    from core.audit import audit

    await audit(
        interaction,
        action  = "VPS Suspended",
        target  = f"`{container_name}`",
        details = f"Reason: {reason}",
    )

Or without an interaction (background tasks):
    from core.audit import audit_bg

    await audit_bg(
        bot     = bot,
        action  = "VPS Auto-Deleted",
        by_id   = "System",
        target  = container_name,
        details = "Grace period expired",
    )
"""

import logging
from datetime import datetime
from typing import Optional

import discord

from core.database import get_db
from core.theme    import Theme

logger = logging.getLogger("moonnodes_vps_bot")

# Set by bot.py after on_ready
_bot_ref        = None
_log_channel_id = None


def set_bot(bot, log_channel_id: Optional[int]):
    global _bot_ref, _log_channel_id
    _bot_ref        = bot
    _log_channel_id = log_channel_id


def _write_db(by_id: str, action: str, target: str, details: str, guild_id: Optional[str]):
    try:
        conn = get_db()
        conn.execute(
            "INSERT INTO audit_log (by_id, action, target, details, guild_id, at) "
            "VALUES (?,?,?,?,?,?)",
            (str(by_id), action, target or "", details or "", guild_id, datetime.now().isoformat()),
        )
        conn.commit()
    except Exception as e:
        logger.warning(f"[audit] DB write failed: {e}")


def _build_embed(
    by: str,
    by_avatar: Optional[str],
    action: str,
    target: str,
    details: str,
    color: int = Theme.WARNING,
) -> discord.Embed:
    embed = discord.Embed(
        title=f"📋 {action}",
        color=color,
        timestamp=datetime.now(),
    )
    embed.add_field(name="👤 By", value=by,              inline=True)
    embed.add_field(name="🎯 Target",        value=target or "—",  inline=True)
    if details:
        embed.add_field(name="📝 Details",   value=details[:1000], inline=False)
    embed.set_footer(text="MoonNodes · Audit")
    if by_avatar:
        embed.set_thumbnail(url=by_avatar)
    return embed


async def _post_log(embed: discord.Embed):
    if not _bot_ref or not _log_channel_id:
        return
    try:
        ch = _bot_ref.get_channel(_log_channel_id) or await _bot_ref.fetch_channel(_log_channel_id)
        if ch:
            await ch.send(embed=embed)
    except Exception as e:
        logger.debug(f"[audit] Log channel post failed: {e}")


async def audit(
    interaction: discord.Interaction,
    action:  str,
    target:  str = "",
    details: str = "",
    color:   int = Theme.WARNING,
):
    """Record an audit entry from a slash command interaction."""
    user      = interaction.user
    by_str    = f"{user.mention} (`{user.id}`)"
    guild_id  = str(interaction.guild_id) if interaction.guild_id else None
    _write_db(str(user.id), action, target, details, guild_id)
    embed = _build_embed(by_str, str(user.display_avatar.url), action, target, details, color)
    await _post_log(embed)


async def audit_bg(
    bot,
    action:  str,
    by_id:   str   = "System",
    target:  str   = "",
    details: str   = "",
    color:   int   = Theme.WARNING,
):
    """Record an audit entry from a background task (no interaction)."""
    _write_db(by_id, action, target, details, None)
    embed = _build_embed(f"`{by_id}`", None, action, target, details, color)
    await _post_log(embed)
