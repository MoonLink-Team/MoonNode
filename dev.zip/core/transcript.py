"""
core/transcript.py — Ticket transcript generator.

Fetches every message from a ticket channel, renders a self-contained
HTML file, then:
  1. Sends it to the configured log channel as an attachment
  2. DMes it to the ticket opener as an attachment

Usage:
    from core.transcript import save_and_send_transcript

    await save_and_send_transcript(
        bot          = self.bot,
        channel      = interaction.channel,
        closer       = interaction.user,
        opener_id    = "123456789",   # user_id string, or None
        ticket_topic = "VPS not booting",
    )
"""

import asyncio
import html
import io
import logging
from datetime import datetime
from typing import Optional

import discord

logger = logging.getLogger("moonnodes_vps_bot")

# ── HTML template ─────────────────────────────────────────────────────────────

_HTML_HEAD = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Ticket Transcript — {channel}</title>
<style>
  :root {{
    --bg:       #1e1f22;
    --bg2:      #2b2d31;
    --bg3:      #313338;
    --border:   #3f4147;
    --accent:   #5865f2;
    --green:    #57f287;
    --text:     #dbdee1;
    --muted:    #949ba4;
    --staff-bg: #25252d;
    --bot-bg:   #1e2433;
  }}
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{
    background: var(--bg);
    color: var(--text);
    font-family: "gg sans","Noto Sans",Arial,sans-serif;
    font-size: 15px;
    line-height: 1.5;
  }}
  .header {{
    background: var(--bg2);
    border-bottom: 2px solid var(--accent);
    padding: 20px 28px;
    display: flex;
    align-items: center;
    gap: 16px;
  }}
  .header-icon {{
    width: 48px; height: 48px;
    border-radius: 50%;
    background: var(--accent);
    display: flex; align-items: center; justify-content: center;
    font-size: 24px;
  }}
  .header-info h1 {{ font-size: 20px; color: #fff; }}
  .header-info p  {{ color: var(--muted); font-size: 13px; margin-top: 2px; }}
  .meta-bar {{
    background: var(--bg3);
    border-bottom: 1px solid var(--border);
    padding: 10px 28px;
    display: flex; gap: 24px; flex-wrap: wrap;
  }}
  .meta-item {{ font-size: 12px; color: var(--muted); }}
  .meta-item strong {{ color: var(--text); }}
  .messages {{
    max-width: 920px; margin: 0 auto;
    padding: 20px 16px 60px;
  }}
  .day-divider {{
    text-align: center;
    color: var(--muted);
    font-size: 12px;
    margin: 24px 0 12px;
    display: flex; align-items: center; gap: 12px;
  }}
  .day-divider::before, .day-divider::after {{
    content: ''; flex: 1; height: 1px; background: var(--border);
  }}
  .msg-group {{ display: flex; gap: 14px; margin: 4px 0; }}
  .msg-group:hover {{ background: rgba(255,255,255,.03); border-radius: 4px; }}
  .msg-group.staff  {{ background: rgba(88,101,242,.05); }}
  .msg-group.bot    {{ background: rgba(88,101,242,.08); }}
  .avatar {{
    width: 40px; height: 40px; border-radius: 50%;
    flex-shrink: 0; margin-top: 2px;
    background: var(--border);
    display: flex; align-items: center; justify-content: center;
    font-size: 18px; overflow: hidden;
  }}
  .avatar img {{ width: 100%; height: 100%; object-fit: cover; }}
  .msg-body {{ flex: 1; min-width: 0; padding: 4px 0; }}
  .msg-meta {{ display: flex; align-items: baseline; gap: 8px; margin-bottom: 2px; }}
  .author   {{ font-weight: 600; font-size: 15px; }}
  .author.staff-tag  {{ color: #5865f2; }}
  .author.bot-tag    {{ color: #57f287; }}
  .role-badge {{
    font-size: 10px; font-weight: 600; letter-spacing: .5px;
    padding: 1px 6px; border-radius: 10px;
    background: rgba(88,101,242,.3); color: #8ea1e1;
    text-transform: uppercase;
  }}
  .timestamp {{ color: var(--muted); font-size: 11px; }}
  .msg-content {{ color: var(--text); word-break: break-word; white-space: pre-wrap; }}
  .msg-content code {{
    background: #2b2d31; padding: 2px 6px; border-radius: 4px;
    font-family: "Consolas","Courier New",monospace; font-size: 13px;
  }}
  .msg-content pre {{
    background: #1e1f22; border: 1px solid var(--border);
    border-radius: 6px; padding: 12px 16px; overflow-x: auto;
    margin-top: 6px;
  }}
  .attach {{
    margin-top: 6px; font-size: 12px; color: var(--muted);
    background: var(--bg3); border-radius: 6px;
    padding: 8px 12px; border-left: 3px solid var(--accent);
  }}
  .attach a {{ color: #00aff4; text-decoration: none; }}
  .attach a:hover {{ text-decoration: underline; }}
  .embed-box {{
    margin-top: 6px; border-left: 4px solid var(--accent);
    background: var(--bg3); border-radius: 4px;
    padding: 10px 14px; max-width: 520px;
    font-size: 13px;
  }}
  .embed-box .e-title {{ font-weight: 700; color: #fff; margin-bottom: 4px; }}
  .embed-box .e-desc  {{ color: var(--text); white-space: pre-wrap; }}
  .system-msg {{
    text-align: center; color: var(--muted);
    font-size: 12px; margin: 16px 0;
    font-style: italic;
  }}
  .footer {{
    text-align: center; color: var(--muted);
    font-size: 12px; padding: 24px;
    border-top: 1px solid var(--border);
  }}
</style>
</head>
<body>
<div class="header">
  <div class="header-icon">🎫</div>
  <div class="header-info">
    <h1>#{channel}</h1>
    <p>MoonNodes Transcript</p>
  </div>
</div>
<div class="meta-bar">
  <div class="meta-item"><strong>Channel:</strong> #{channel}</div>
  <div class="meta-item"><strong>Opened by:</strong> {opener}</div>
  <div class="meta-item"><strong>Closed by:</strong> {closer}</div>
  <div class="meta-item"><strong>Topic:</strong> {topic}</div>
  <div class="meta-item"><strong>Messages:</strong> {msg_count}</div>
  <div class="meta-item"><strong>Exported:</strong> {exported_at}</div>
</div>
<div class="messages">
"""

_HTML_FOOT = """\
</div>
<div class="footer">
  MoonNodes Ticket Transcript &nbsp;·&nbsp; {channel} &nbsp;·&nbsp; {exported_at}
</div>
</body>
</html>
"""

_STAFF_ROLES = {
    "Owner", "Hard Admin", "Admin", "Manager",
    "Hard Mod", "Mod", "Hard Staff", "Staff", "Trial Staff", "Trial Mod",
}


def _is_staff_member(member: discord.Member) -> bool:
    if member is None or member.bot:
        return False
    from core.database import admin_data
    return str(member.id) in admin_data


def _role_badge(member: discord.Member) -> str:
    from core.database import admin_data
    role = admin_data.get(str(member.id), "")
    if role:
        return f'<span class="role-badge">{html.escape(role)}</span>'
    return ""


def _fmt_content(text: str) -> str:
    """Light Discord markdown → HTML."""
    import re
    text = html.escape(text)
    # Code blocks
    text = re.sub(r"```(?:\w+\n)?(.*?)```", lambda m: f"<pre><code>{m.group(1)}</code></pre>", text, flags=re.DOTALL)
    # Inline code
    text = re.sub(r"`([^`]+)`", lambda m: f"<code>{m.group(1)}</code>", text)
    # Bold
    text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
    # Italic
    text = re.sub(r"\*(.+?)\*", r"<em>\1</em>", text)
    # Underline
    text = re.sub(r"__(.+?)__", r"<u>\1</u>", text)
    # Spoiler
    text = re.sub(r"\|\|(.+?)\|\|", r'<span style="background:#000;color:#000">\1</span>', text)
    return text


async def _fetch_messages(channel: discord.TextChannel, limit: int = 1000) -> list:
    messages = []
    try:
        async for msg in channel.history(limit=limit, oldest_first=True):
            messages.append(msg)
    except discord.Forbidden:
        logger.warning(f"[Transcript] No permission to read #{channel.name}")
    except Exception as e:
        logger.warning(f"[Transcript] fetch_messages error: {e}")
    return messages


def _render_html(
    messages:    list,
    channel_name: str,
    opener:      str,
    closer:      str,
    topic:       str,
    exported_at: str,
) -> str:
    body_parts = []
    last_day   = None
    last_author_id = None

    for msg in messages:
        # System messages
        if msg.type in (discord.MessageType.pins_add, discord.MessageType.new_member):
            body_parts.append(f'<div class="system-msg">{html.escape(str(msg.system_content))}</div>')
            continue

        # Day divider
        msg_day = msg.created_at.strftime("%B %d, %Y")
        if msg_day != last_day:
            body_parts.append(f'<div class="day-divider">{msg_day}</div>')
            last_day = msg_day

        # Determine CSS class
        is_bot  = msg.author.bot
        member  = msg.guild.get_member(msg.author.id) if msg.guild else None
        is_staff = _is_staff_member(member) if member else False
        group_cls = "bot" if is_bot else ("staff" if is_staff else "")

        # Avatar
        avatar_url = str(msg.author.display_avatar.url) if msg.author.display_avatar else ""
        if avatar_url:
            avatar_html = f'<img src="{html.escape(avatar_url)}" alt="" loading="lazy">'
        else:
            avatar_html = msg.author.display_name[0].upper()

        # Author colour
        author_cls = "bot-tag" if is_bot else ("staff-tag" if is_staff else "")
        badge_html = _role_badge(member) if member and not is_bot else ("")

        # Timestamp
        ts = msg.created_at.strftime("%H:%M")

        # Content
        content_html = ""
        if msg.content:
            content_html = f'<div class="msg-content">{_fmt_content(msg.content)}</div>'

        # Embeds
        embed_html = ""
        for emb in msg.embeds:
            e_title    = html.escape(emb.title or "")
            e_desc     = html.escape(emb.description or "")
            color      = f"#{emb.colour.value:06X}" if emb.colour else "#5865f2"
            title_part = f'<div class="e-title">{e_title}</div>' if e_title else ""
            desc_part  = f'<div class="e-desc">{e_desc}</div>'   if e_desc  else ""
            embed_html += (
                f'<div class="embed-box" style="border-left-color:{color}">'
                f"{title_part}{desc_part}"
                f"</div>"
            )

        # Attachments
        attach_html = ""
        for att in msg.attachments:
            name = html.escape(att.filename)
            url  = html.escape(att.url)
            if att.content_type and att.content_type.startswith("image/"):
                attach_html += (
                    f'<div class="attach">📎 <a href="{url}" target="_blank">'
                    f'<img src="{url}" alt="{name}" style="max-width:300px;max-height:200px;'
                    f'display:block;border-radius:6px;margin-top:4px"></a></div>'
                )
            else:
                attach_html += f'<div class="attach">📎 <a href="{url}" target="_blank">{name}</a></div>'

        body_parts.append(
            f'<div class="msg-group {group_cls}">'
            f'  <div class="avatar">{avatar_html}</div>'
            f'  <div class="msg-body">'
            f'    <div class="msg-meta">'
            f'      <span class="author {author_cls}">{html.escape(msg.author.display_name)}</span>'
            f'      {badge_html}'
            f'      <span class="timestamp">{ts}</span>'
            f'    </div>'
            f"    {content_html}{embed_html}{attach_html}"
            f"  </div>"
            f"</div>"
        )
        last_author_id = msg.author.id

    head = _HTML_HEAD.format(
        channel=html.escape(channel_name),
        opener=html.escape(opener),
        closer=html.escape(closer),
        topic=html.escape(topic or "No topic"),
        msg_count=len(messages),
        exported_at=html.escape(exported_at),
    )
    foot = _HTML_FOOT.format(
        channel=html.escape(channel_name),
        exported_at=html.escape(exported_at),
    )
    return head + "\n".join(body_parts) + "\n" + foot


async def save_and_send_transcript(
    bot:          discord.Client,
    channel:      discord.TextChannel,
    closer:       discord.User,
    opener_id:    Optional[str] = None,
    ticket_topic: Optional[str] = None,
) -> bool:
    """
    Generate an HTML transcript for `channel`, send it to the log channel
    and DM it to the opener.

    Returns True if at least one delivery succeeded.
    """
    channel_name = channel.name
    exported_at  = datetime.now().strftime("%Y-%m-%d %H:%M UTC")
    filename     = f"transcript-{channel_name}-{datetime.now().strftime('%Y%m%d-%H%M%S')}.html"

    # Resolve opener display name
    opener_name = "Unknown"
    opener_user = None
    if opener_id:
        try:
            opener_user = await bot.fetch_user(int(opener_id))
            opener_name = opener_user.display_name
        except Exception:
            pass

    # Fetch messages
    logger.info(f"[Transcript] Fetching messages for #{channel_name}…")
    messages    = await _fetch_messages(channel)
    logger.info(f"[Transcript] {len(messages)} messages fetched")

    # Render HTML
    html_content = _render_html(
        messages     = messages,
        channel_name = channel_name,
        opener       = opener_name,
        closer       = closer.display_name,
        topic        = ticket_topic or "",
        exported_at  = exported_at,
    )
    html_bytes = html_content.encode("utf-8")

    # Build embeds for log channel + DM
    log_embed = discord.Embed(
        title="🎫 Ticket Closed — Transcript Saved",
        description=(
            f"**Channel:** `#{channel_name}`\n"
            f"**Opened by:** {f'<@{opener_id}>' if opener_id else 'Unknown'}\n"
            f"**Closed by:** {closer.mention}\n"
            f"**Topic:** {ticket_topic or 'No topic'}\n"
            f"**Messages:** {len(messages)}\n"
            f"**Exported:** {exported_at}"
        ),
        color=0x57F287,
        timestamp=datetime.now(),
    )
    log_embed.set_author(name="MoonNodes", icon_url="https://imgur.com/6yfYDTP.png")
    log_embed.set_footer(text="MoonNodes · Tickets")

    dm_embed = discord.Embed(
        title="📄 Your Support Ticket Transcript",
        description=(
            f"Ticket **`#{channel_name}`** closed. Transcript attached.\n"
            "Still need help? Use `/support`."
        ),
        color=0x5865F2,
        timestamp=datetime.now(),
    )
    dm_embed.set_author(name="MoonNodes", icon_url="https://imgur.com/6yfYDTP.png")
    dm_embed.set_footer(text="MoonNodes · Transcript")
    if opener_user and opener_user.display_avatar:
        dm_embed.set_thumbnail(url=str(opener_user.display_avatar.url))

    delivered = False

    # ── Send to log channel ───────────────────────────────────────────────────
    try:
        from core.database import get_setting
        log_ch_id = get_setting("log_channel")
        if log_ch_id:
            log_ch = bot.get_channel(int(log_ch_id)) or await bot.fetch_channel(int(log_ch_id))
            if log_ch:
                file = discord.File(
                    fp=io.BytesIO(html_bytes),
                    filename=filename,
                    description=f"Transcript for #{channel_name}",
                )
                await log_ch.send(embed=log_embed, file=file)
                delivered = True
                logger.info(f"[Transcript] Sent to log channel #{log_ch.name}")
    except Exception as e:
        logger.warning(f"[Transcript] Log channel send failed: {e}")

    # ── DM the opener ─────────────────────────────────────────────────────────
    if opener_user:
        try:
            file = discord.File(
                fp=io.BytesIO(html_bytes),
                filename=filename,
                description="Your ticket transcript",
            )
            await opener_user.send(embed=dm_embed, file=file)
            delivered = True
            logger.info(f"[Transcript] DMed transcript to {opener_user} ({opener_id})")
        except discord.Forbidden:
            logger.info(f"[Transcript] DMs closed for {opener_id} — skipped")
        except Exception as e:
            logger.warning(f"[Transcript] DM send failed: {e}")

    # ── Write to DB ───────────────────────────────────────────────────────────
    try:
        from core.database import close_ticket, get_db
        close_ticket(str(channel.id), str(closer.id), status="closed")
        conn = get_db()
        conn.execute(
            "UPDATE tickets SET topic=? WHERE channel_id=?",
            (ticket_topic, str(channel.id)),
        )
        conn.commit()
    except Exception as e:
        logger.debug(f"[Transcript] DB update: {e}")

    return delivered
