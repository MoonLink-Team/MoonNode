"""
core/ext.py — Extension flag helpers.

All extension checks go through this module so toggling via /system
takes effect immediately without restarting the bot.

Usage:
    from core.ext import ext_enabled
    if not ext_enabled("ISTS"):
        return ...  # show disabled message
"""

import core.config as cfg



def ext_enabled(flag: str) -> bool:
    """
    Check if an extension is enabled.
    Checks runtime cfg attribute first (set by /system), then DB,
    then falls back to the static .env value.
    """
    return bool(getattr(cfg, flag, False))


def ext_disabled_embed(name: str, flag: str):
    """Return a standardised 'extension disabled' error embed."""
    from core.theme import create_error_embed
    return create_error_embed(
        f"🔌  {name} Is Disabled",
        f"This feature is currently turned off.\n\n"
        f"An **Owner** can enable it with:\n"
        f"`/system action:Extension Toggle extension:{name} ext_state:Enable`"
    )


# ── Shorthand helpers ─────────────────────────────────────────────────────────

def ticket_enabled() -> bool:      return ext_enabled("ISTS")
def marketplace_enabled() -> bool: return ext_enabled("MARKETPLACE")
def account_enabled() -> bool:     return ext_enabled("ACCOUNT")
def a2fa_enabled() -> bool:        return ext_enabled("A2FA")
def backup_limit_enabled() -> bool:return ext_enabled("UBL_ENABLED")
def multi_node_enabled() -> bool:  return ext_enabled("MULTI_NODE")
def sosb_enabled() -> bool:        return ext_enabled("SOSB")
def aes_enabled() -> bool:         return ext_enabled("AES")
def rr_enabled() -> bool:          return ext_enabled("RR")
def mstc_enabled() -> bool:        return ext_enabled("MSTC")
def vps_renewal_enabled() -> bool: return ext_enabled("VPS_RENEWAL")
def vps_monitoring_enabled() -> bool: return ext_enabled("VPS_MONITORING")
def vps_templates_enabled() -> bool:  return ext_enabled("VPS_TEMPLATES")
def multilang_enabled() -> bool:   return ext_enabled("MULTILANG")

def dm_commands_enabled() -> bool:  return ext_enabled("DM_COMMANDS")
def block_terminal_enabled() -> bool: return ext_enabled("BLOCK_TERMINAL")
