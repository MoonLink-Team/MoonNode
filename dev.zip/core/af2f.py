"""
core/af2f.py — Admin 2-Factor (AF2F) verification system.

How it works:
  1. A protected command is invoked by a non-owner staff member.
  2. Bot generates a 4-digit code and DMs it to the AF2F channel (owner sees it).
  3. User must call the same command again with /verify code:<CODE> within 5 min.
  4. Bot owner (BOT_OWNER_ID) is always exempt — no AF2F required.

Commands requiring AF2F:
  /mod role::trident: Expire (add/edit/remove)
  /mod role::trident: Suspend VPS / Unsuspend VPS
  /create
  /delete
  /set
  /system
  /node
  /role

Channel:
  Set via /set setting:AF2F channel value:<channel_id>
  Stored in settings table as key "af2f_channel_id".
"""

import random
import string
import json
import logging
from datetime import datetime, timedelta

import discord

from core.database import get_db, get_setting
from core.config import MAIN_ADMIN_ID

logger = logging.getLogger("moonnodes_vps_bot")

# Commands that require AF2F (non-owner staff)
AF2F_COMMANDS = {
    "create", "delete", "set", "system", "node", "role",
    # mod sub-actions requiring AF2F
    "mod:expire", "mod:suspend", "mod:unsuspend",
}

CODE_TTL_SECONDS = 300  # 5 minutes


def is_owner(user_id: int | str) -> bool:
    return str(user_id) == str(MAIN_ADMIN_ID)


def requires_af2f(cmd: str) -> bool:
    return cmd in AF2F_COMMANDS


def _gen_code(length: int = 4) -> str:
    return "".join(random.choices(string.digits, k=length))


def create_pending(user_id: str, cmd: str, args: dict | None = None) -> str:
    """Create an AF2F pending record and return the 4-digit code."""
    code = _gen_code()
    now  = datetime.utcnow()
    exp  = now + timedelta(seconds=CODE_TTL_SECONDS)
    conn = get_db()
    conn.execute(
        "INSERT OR REPLACE INTO af2f_pending (user_id, code, cmd, args, created_at, expires_at) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (user_id, code, cmd, json.dumps(args or {}), now.isoformat(), exp.isoformat()),
    )
    conn.commit()
    logger.info(f"[af2f] Code created for user={user_id} cmd={cmd} expires={exp.isoformat()}")
    return code


def verify_code(user_id: str, code: str) -> dict | None:
    """
    Verify a code for user_id.
    Returns the pending record dict if valid, None if invalid/expired.
    Deletes the record on success.
    """
    conn = get_db()
    cur  = conn.cursor()
    cur.execute(
        "SELECT * FROM af2f_pending WHERE user_id=? AND code=?",
        (user_id, code),
    )
    row = cur.fetchone()
    if not row:
        return None
    exp = datetime.fromisoformat(row["expires_at"])
    if datetime.utcnow() > exp:
        conn.execute("DELETE FROM af2f_pending WHERE user_id=?", (user_id,))
        conn.commit()
        logger.info(f"[af2f] Expired code attempt user={user_id}")
        return None
    # Valid — consume
    conn.execute("DELETE FROM af2f_pending WHERE user_id=?", (user_id,))
    conn.commit()
    logger.info(f"[af2f] Code verified user={user_id} cmd={row['cmd']}")
    return dict(row)


def get_af2f_channel_id() -> int | None:
    """Return the AF2F channel ID from settings, or None."""
    val = get_setting("af2f_channel_id")
    try:
        return int(val) if val else None
    except (ValueError, TypeError):
        return None


async def send_af2f_code(bot: discord.Client, user: discord.User | discord.Member, cmd: str, code: str):
    """
    Send the AF2F code to the AF2F channel (visible to owner only).
    Also DMs the user telling them to check for the code.
    """
    channel_id = get_af2f_channel_id()
    embed_ch = discord.Embed(
        title="🔐 AF2F Verification Code",
        description=(
            f"**User:** {user.mention} (`{user.id}`)\n"
            f"**Command:** `{cmd}`\n"
            f"**Code:** `{code}`\n\n"
            f"⏳ Expires in **{CODE_TTL_SECONDS // 60} minutes**."
        ),
        color=0xEB459E,
        timestamp=datetime.utcnow(),
    )
    embed_ch.set_author(name="MoonNodes AF2F", icon_url="https://imgur.com/6yfYDTP.png")
    embed_ch.set_footer(text="This code is only visible here — do not share it.")

    if channel_id:
        try:
            ch = bot.get_channel(channel_id) or await bot.fetch_channel(channel_id)
            await ch.send(embed=embed_ch)
        except Exception as e:
            logger.warning(f"[af2f] Could not send to AF2F channel {channel_id}: {e}")

    # DM the user: tell them a code was sent to the AF2F channel
    embed_dm = discord.Embed(
        title="🔐 AF2F Required",
        description=(
            f"Your action (`{cmd}`) requires **Admin 2-Factor verification**.\n\n"
            "A **4-digit code** has been sent to the **AF2F channel**.\n\n"
            "Enter the code to proceed:\n"
            f"> `/af2f code:<CODE>`\n\n"
            f"⏳ You have **{CODE_TTL_SECONDS // 60} minutes**."
        ),
        color=0xEB459E,
        timestamp=datetime.utcnow(),
    )
    embed_dm.set_author(name="MoonNodes AF2F", icon_url="https://imgur.com/6yfYDTP.png")
    try:
        await user.send(embed=embed_dm)
    except Exception:
        pass  # DMs may be closed
