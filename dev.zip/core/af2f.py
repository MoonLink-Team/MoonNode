"""
core/af2f.py — Admin 2-Factor (AF2F) verification system.

AF2F required for these commands (non-owner staff only):
  /create  /delete  /node  /payment  /role  /set  /system
  /manage user_id:<someone_else>
  /mod role:Hard Mod action:Suspend VPS | Unsuspend VPS

How it works:
  1. Staff runs a protected command.
  2. Bot generates a 6-digit code, posts it to the AF2F channel.
  3. Staff runs /af2f code:<CODE> within 5 minutes.
  4. On success their session is marked verified for that command.
  5. Bot owner (BOT_OWNER_ID) is ALWAYS exempt — no code needed.
"""

import random
import string
import json
import logging
from datetime import datetime, timedelta

import discord

from core.database import get_db, get_setting
from core.config import MAIN_ADMIN_ID

logger = logging.getLogger("moonnodes_vps_bot")

# Commands that require AF2F for non-owners
AF2F_COMMANDS = {
    "create", "delete", "node", "payment", "role",
    "set", "system",
    "manage",          # only when targeting another user
    "mod:suspend",
    "mod:unsuspend",
}

CODE_TTL_SECONDS = 300   # 5 minutes
CODE_LENGTH      = 6


def is_owner(user_id: int | str) -> bool:
    return str(user_id) == str(MAIN_ADMIN_ID)


def requires_af2f(cmd: str) -> bool:
    return cmd in AF2F_COMMANDS


def _gen_code() -> str:
    return "".join(random.choices(string.digits, k=CODE_LENGTH))


def create_pending(user_id: str, cmd: str, args: dict | None = None) -> str:
    """Generate and store an AF2F pending code. Returns the code."""
    code = _gen_code()
    now  = datetime.utcnow()
    exp  = now + timedelta(seconds=CODE_TTL_SECONDS)
    conn = get_db()
    conn.execute(
        "INSERT OR REPLACE INTO af2f_pending "
        "(user_id, code, cmd, args, created_at, expires_at) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (user_id, code, cmd, json.dumps(args or {}),
         now.isoformat(), exp.isoformat()),
    )
    conn.commit()
    logger.info(f"[af2f] Code issued  user={user_id}  cmd={cmd}  exp={exp.isoformat()}")
    return code


def verify_code(user_id: str, code: str) -> dict | None:
    """
    Verify a submitted code.
    Returns the pending record on success, None on failure/expiry.
    Consumes the record on success.
    """
    conn = get_db()
    cur  = conn.cursor()
    cur.execute(
        "SELECT * FROM af2f_pending WHERE user_id=? AND code=?",
        (user_id, code),
    )
    row = cur.fetchone()
    if not row:
        return None
    if datetime.utcnow() > datetime.fromisoformat(row["expires_at"]):
        conn.execute("DELETE FROM af2f_pending WHERE user_id=?", (user_id,))
        conn.commit()
        logger.info(f"[af2f] Expired code  user={user_id}")
        return None
    conn.execute("DELETE FROM af2f_pending WHERE user_id=?", (user_id,))
    conn.commit()
    logger.info(f"[af2f] Verified  user={user_id}  cmd={row['cmd']}")
    return dict(row)


def get_af2f_channel_id() -> int | None:
    val = get_setting("af2f_channel_id")
    try:
        return int(val) if val else None
    except (ValueError, TypeError):
        return None


async def send_af2f_code(
    bot: discord.Client,
    user: discord.User | discord.Member,
    cmd: str,
    code: str,
):
    """Post the code to the AF2F channel and DM the user instructions."""
    channel_id = get_af2f_channel_id()

    # ── AF2F channel embed (owner sees this) ─────────────────────────────────
    embed_ch = discord.Embed(
        title="🔐 AF2F — New Verification Code",
        description=(
            f"**User:** {user.mention} (`{user.id}`)\n"
            f"**Command:** `/{cmd}`\n\n"
            f"**Code:**\n"
            f"```\n{code}\n```\n"
            f"⏳ Expires in **{CODE_TTL_SECONDS // 60} minutes**."
        ),
        color=0xEB459E,
        timestamp=datetime.utcnow(),
    )
    embed_ch.set_author(name="MoonNodes AF2F", icon_url="https://imgur.com/6yfYDTP.png")
    embed_ch.set_footer(text="Do NOT share this code — for AF2F staff verification only.")

    if channel_id:
        try:
            ch = bot.get_channel(channel_id) or await bot.fetch_channel(channel_id)
            await ch.send(embed=embed_ch)
        except Exception as e:
            logger.warning(f"[af2f] Could not post to AF2F channel {channel_id}: {e}")

    # ── DM the user ───────────────────────────────────────────────────────────
    embed_dm = discord.Embed(
        title="🔐 AF2F Verification Required",
        description=(
            f"Your action **`/{cmd}`** requires **Admin 2-Factor verification**.\n\n"
            "A **6-digit code** has been posted to the **AF2F channel**.\n"
            "Ask the owner for the code, then enter it:\n\n"
            "```\n/af2f code:<6-digit-code>\n```\n\n"
            f"⏳ The code expires in **{CODE_TTL_SECONDS // 60} minutes**.\n"
            "After verifying, **re-run the original command** to proceed."
        ),
        color=0xEB459E,
        timestamp=datetime.utcnow(),
    )
    embed_dm.set_author(name="MoonNodes AF2F", icon_url="https://imgur.com/6yfYDTP.png")
    embed_dm.set_footer(text="Each action requires its own code.")
    try:
        await user.send(embed=embed_dm)
    except Exception:
        pass


async def require_af2f(
    interaction: discord.Interaction,
    cmd: str,
    bot: discord.Client,
) -> bool:
    """
    Gate helper — call at the top of any protected command handler.

    Returns True  → proceed normally (owner, or already verified).
    Returns False → af2f code was issued; handler should return immediately.

    Usage:
        if not await require_af2f(interaction, "create", self.bot):
            return
    """
    uid = str(interaction.user.id)

    # Owner is always exempt
    if is_owner(uid):
        return True

    # Check if there's a valid verified session for this user+cmd
    conn = get_db()
    cur  = conn.cursor()
    cur.execute(
        "SELECT * FROM af2f_pending WHERE user_id=? AND code='VERIFIED' AND cmd=?",
        (uid, cmd),
    )
    row = cur.fetchone()
    if row:
        # Consume the verified session
        conn.execute(
            "DELETE FROM af2f_pending WHERE user_id=? AND code='VERIFIED' AND cmd=?",
            (uid, cmd),
        )
        conn.commit()
        return True

    # Issue a new code
    code = create_pending(uid, cmd)
    await send_af2f_code(bot, interaction.user, cmd, code)

    embed = discord.Embed(
        title="🔐 AF2F Code Sent",
        description=(
            "This command requires **Admin 2-Factor verification**.\n\n"
            "A **6-digit code** has been posted to the **AF2F channel**.\n\n"
            "**Steps:**\n"
            "1. Get the code from the AF2F channel\n"
            f"2. Run `/af2f code:<CODE>`\n"
            "3. Re-run this command\n\n"
            f"⏳ Code expires in **{CODE_TTL_SECONDS // 60} minutes**."
        ),
        color=0xEB459E,
        timestamp=datetime.utcnow(),
    )
    embed.set_author(name="MoonNodes AF2F", icon_url="https://imgur.com/6yfYDTP.png")

    try:
        if not interaction.response.is_done():
            await interaction.response.send_message(embed=embed, ephemeral=True)
        else:
            await interaction.followup.send(embed=embed, ephemeral=True)
    except Exception:
        pass
    return False
