import aiohttp
import logging
from typing import Optional
from core.config import CF_API_TOKEN, CF_ZONE_ID, CF_DOMAIN, HOST_PUBLIC_IP

logger = logging.getLogger("moonnodes_vps_bot")


async def create_cloudflare_subdomain(subdomain_prefix: str) -> Optional[str]:
    if not all([CF_API_TOKEN, CF_ZONE_ID, HOST_PUBLIC_IP]):
        logger.error("[ASM] Missing Cloudflare credentials or Host IP in .env")
        return None

    full_domain = f"{subdomain_prefix}.{CF_DOMAIN}"
    url = f"https://api.cloudflare.com/client/v4/zones/{CF_ZONE_ID}/dns_records"
    headers = {"Authorization": f"Bearer {CF_API_TOKEN}", "Content-Type": "application/json"}
    payload = {"type": "A", "name": full_domain, "content": HOST_PUBLIC_IP, "ttl": 1, "proxied": True}

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, headers=headers, json=payload) as resp:
                if resp.status == 200:
                    logger.info(f"[ASM] DNS record created: {full_domain}")
                    return full_domain
                data = await resp.json()
                errors = data.get("errors", [])
                if errors and errors[0].get("code") == 81057:
                    logger.warning(f"[ASM] DNS already exists: {full_domain}")
                    return full_domain
                logger.error(f"[ASM] Cloudflare error: {data}")
                return None
    except Exception as e:
        logger.error(f"[ASM] HTTP error: {e}")
        return None
