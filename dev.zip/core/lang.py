"""
core/lang.py — Multi-language support.

Usage:
    from core.lang import t, set_user_lang, get_user_lang

    t("expire_title")                        → English string
    t("expire_title", lang="es")             → Spanish string
    t("expire_reminder_body", name="myVPS", ts=1234567890)  → formatted

Languages are stored per-user in the 'users' table (lang column).
Falls back to English for any missing key.
"""

import json
import logging
import os
from functools import lru_cache
from typing import Optional

logger = logging.getLogger("moonnodes_vps_bot")

_TRANSLATIONS_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "translations")
_SUPPORTED = {"en", "es"}
_DEFAULT   = "en"

@lru_cache(maxsize=8)
def _load(lang: str) -> dict:
    path = os.path.join(_TRANSLATIONS_DIR, f"{lang}.json")
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return {}
    except Exception as e:
        logger.warning(f"[lang] Failed to load {lang}.json: {e}")
        return {}


def t(key: str, lang: str = _DEFAULT, **kwargs) -> str:
    """
    Translate a key into the given language.
    Falls back to English if the key is missing.
    Applies .format(**kwargs) if kwargs are provided.
    """
    if lang not in _SUPPORTED:
        lang = _DEFAULT
    val = _load(lang).get(key) or _load(_DEFAULT).get(key) or key
    if kwargs:
        try:
            val = val.format(**kwargs)
        except (KeyError, ValueError):
            pass
    return val


def get_user_lang(uid: str) -> str:
    """Look up a user's preferred language from the DB. Falls back to 'en'."""
    try:
        from core.database import get_db
        cur = get_db().cursor()
        cur.execute("SELECT lang FROM users WHERE user_id=?", (uid,))
        row = cur.fetchone()
        lang = row["lang"] if row and row["lang"] else _DEFAULT
        return lang if lang in _SUPPORTED else _DEFAULT
    except Exception:
        return _DEFAULT


def set_user_lang(uid: str, lang: str):
    """Set a user's preferred language in the DB."""
    if lang not in _SUPPORTED:
        return
    try:
        from core.database import get_db
        conn = get_db()
        conn.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (uid,))
        conn.execute("UPDATE users SET lang=? WHERE user_id=?", (lang, uid))
        conn.commit()
    except Exception as e:
        logger.warning(f"[lang] set_user_lang({uid}, {lang}): {e}")


SUPPORTED_LANGUAGES = {
    "en": "🇬🇧 English",
    "es": "🇪🇸 Español",
}
