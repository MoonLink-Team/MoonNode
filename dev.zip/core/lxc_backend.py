"""
core/lxc_backend.py — LXC/LXD-specific container operations.

Loaded automatically by core/lxc.py when the `lxc` binary is detected.
If Incus is detected instead, core/incus.py is loaded.

Key LXD/LXC differences vs Incus:
  - OS images: use `ubuntu:22.04` or `images:debian/12`
  - FUSE device: must be added explicitly as unix-char when privileged
  - idmap: works by default with `security.privileged=true` set after init
  - Daemon: lxd runs as a system service, managed via the `lxc` client
"""

import asyncio
import re
import shlex
import subprocess
import logging
from typing import Optional

logger = logging.getLogger("moonnodes_vps_bot")

BINARY = "lxc"


# ── Command execution ─────────────────────────────────────────────────────────

def _strip_bad_flags(cmd: str) -> str:
    cmd = re.sub(r"\s+-c\s+[\w,]+", "", cmd)
    cmd = re.sub(r"--format\s+(\w+)", r"--format=\1", cmd)
    return cmd.strip()


async def run(command: str, timeout: int = 120):
    """Execute an lxc command."""
    for prefix in ("lxc ", "incus ", "lxd "):
        if command.startswith(prefix):
            command = BINARY + " " + command[len(prefix):]
            break
    else:
        if not command.startswith(BINARY):
            command = f"{BINARY} {command}"

    command = _strip_bad_flags(command)
    logger.info(f"[lxc] → {command}")
    parts = shlex.split(command)

    try:
        proc = await asyncio.create_subprocess_exec(
            *parts,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        try:
            proc.kill()
            await proc.wait()
        except Exception:
            pass
        raise asyncio.TimeoutError(f"lxc command timed out ({timeout}s): {command}")

    out = stdout.decode().strip() if stdout else ""
    err = stderr.decode().strip() if stderr else ""

    if proc.returncode != 0:
        msg = err or out or "Command failed with no output"
        logger.error(f"[lxc] FAILED: {msg}")
        raise Exception(msg)

    return out if out else True


# ── Remote listing ────────────────────────────────────────────────────────────

BUILTIN_PREFIXES = ("ubuntu", "images", "local", "")


async def list_remotes() -> list:
    """Return user-added remote names only, excluding all built-in remotes."""
    try:
        r = subprocess.run(
            [BINARY, "remote", "list", "--format=csv"],
            capture_output=True, text=True, timeout=10,
        )
        remotes = []
        for line in r.stdout.strip().splitlines():
            raw   = line.split(",")[0].strip()
            clean = re.sub(r"\s*\(.*?\)", "", raw).strip().rstrip("*").strip()
            if not clean:
                continue
            if any(
                clean == b or clean.startswith(b + "-") or
                clean.startswith(b + ":") or clean == "local"
                for b in BUILTIN_PREFIXES
            ):
                continue
            remotes.append(clean)
        return remotes
    except Exception as e:
        logger.warning(f"lxc list_remotes failed: {e}")
        return []


# ── Storage pool detection ────────────────────────────────────────────────────

def detect_storage_pool(default: Optional[str] = None) -> str:
    if default:
        return default
    try:
        r = subprocess.run(
            [BINARY, "storage", "list", "--format=csv"],
            capture_output=True, text=True, timeout=10,
        )
        for line in r.stdout.strip().splitlines():
            name = line.split(",")[0].strip()
            if name and name not in ("", "NAME"):
                return name
    except Exception as e:
        logger.error(f"lxc pool detect failed: {e}")
    return "default"


# ── Host resource stats ───────────────────────────────────────────────────────

def host_cpu_pct() -> float:
    try:
        r = subprocess.run(["top", "-bn1"], capture_output=True, text=True, timeout=5)
        for line in r.stdout.splitlines():
            if "Cpu" in line:
                m = re.search(r"(\d+\.?\d*)\s*id", line)
                if m:
                    return round(100.0 - float(m.group(1)), 1)
    except Exception:
        pass
    return 0.0


def host_cpu_cores() -> int:
    try:
        r = subprocess.run(["nproc"], capture_output=True, text=True, timeout=5)
        return int(r.stdout.strip())
    except Exception:
        return 1


def host_ram() -> tuple:
    try:
        r = subprocess.run(["free", "-m"], capture_output=True, text=True, timeout=5)
        for line in r.stdout.splitlines():
            if line.startswith("Mem:"):
                p = line.split()
                return int(p[2]), int(p[1])
    except Exception:
        pass
    return 0, 0


def host_disk() -> tuple:
    try:
        r = subprocess.run(["df", "-BG", "/"], capture_output=True, text=True, timeout=5)
        for line in r.stdout.splitlines()[1:]:
            p = line.split()
            if len(p) >= 5:
                return int(p[2].replace("G", "")), int(p[1].replace("G", ""))
    except Exception:
        pass
    return 0, 0


# ── Container stats ───────────────────────────────────────────────────────────

async def container_status(name: str, node: str = "local") -> str:
    prefix = f"{node}:" if node != "local" else ""
    try:
        out = await run(f"lxc list {prefix}{name} --format=csv")
        if out and out is not True:
            for line in str(out).splitlines():
                if name in line:
                    p = line.split(",")
                    return p[1].strip().lower() if len(p) > 1 else "unknown"
    except Exception:
        pass
    return "unknown"


async def container_cpu_pct(name: str, node: str = "local") -> float:
    prefix = f"{node}:" if node != "local" else ""
    try:
        out = await run(f"lxc exec {prefix}{name} -- top -bn1")
        if out and out is not True:
            for line in str(out).splitlines():
                if "Cpu" in line:
                    m = re.search(r"(\d+\.?\d*)\s*id", line)
                    if m:
                        return round(100.0 - float(m.group(1)), 1)
    except Exception:
        pass
    return 0.0


async def container_memory(name: str, node: str = "local") -> str:
    prefix = f"{node}:" if node != "local" else ""
    try:
        out = await run(f"lxc exec {prefix}{name} -- free -m")
        if out and out is not True:
            for line in str(out).splitlines():
                if line.startswith("Mem:"):
                    p     = line.split()
                    total = int(p[1]); used = int(p[2])
                    pct   = round(used / total * 100, 1) if total else 0
                    return f"{used}/{total} MB ({pct}%)"
    except Exception:
        pass
    return "N/A"


async def container_disk(name: str, node: str = "local") -> str:
    prefix = f"{node}:" if node != "local" else ""
    try:
        out = await run(f"lxc exec {prefix}{name} -- df -h /")
        if out and out is not True:
            for line in str(out).splitlines()[1:]:
                p = line.split()
                if len(p) >= 5:
                    return f"{p[2]}/{p[1]} ({p[4]})"
    except Exception:
        pass
    return "N/A"


async def container_uptime(name: str, node: str = "local") -> str:
    prefix = f"{node}:" if node != "local" else ""
    try:
        out = await run(f"lxc exec {prefix}{name} -- uptime -p")
        return str(out).strip() if out and out is not True else "N/A"
    except Exception:
        return "N/A"


# ── Deployment ────────────────────────────────────────────────────────────────

async def deploy(
    container_name: str,
    os_image: str,
    ram_gb: int,
    cpu: int,
    disk_gb: int,
    storage_pool: str = "default",
    node: str = "local",
) -> None:
    """Create, configure, and start an LXC container."""
    prefix    = f"{node}:" if node != "local" else ""
    pool_flag = f" -s {storage_pool}" if storage_pool and storage_pool != "default" else ""

    # Init container
    await run(f"lxc init {os_image} {prefix}{container_name}{pool_flag}", timeout=300)

    # Privileged mode — must be set before start
    await run(f"lxc config set {prefix}{container_name} security.privileged true")
    await run(f"lxc config set {prefix}{container_name} security.nesting true")

    # Resource limits
    await run(f"lxc config set {prefix}{container_name} limits.memory {ram_gb * 1024}MB")
    await run(f"lxc config set {prefix}{container_name} limits.cpu {cpu}")

    # Disk quota — override the profile's root device
    try:
        pool = detect_storage_pool()
        await run(
            f"lxc config device add {prefix}{container_name} root disk"
            f" path=/ pool={pool} size={disk_gb}GB"
        )
    except Exception as e:
        logger.warning(f"[lxc.deploy] disk quota non-fatal: {e}")

    # Security syscalls for Docker
    for cfg_key in [
        "security.syscalls.intercept.mknod true",
        "linux.kernel_modules overlay,loop,nf_nat,ip_tables,ip6_tables",
    ]:
        try:
            await run(f"lxc config set {prefix}{container_name} {cfg_key}")
        except Exception as e:
            logger.warning(f"[lxc.deploy] non-fatal: {e}")

    # FUSE device — LXC/LXD needs this explicitly for Docker support
    try:
        await run(
            f"lxc config device add {prefix}{container_name} fuse unix-char path=/dev/fuse"
        )
    except Exception as e:
        logger.warning(f"[lxc.deploy] fuse device non-fatal: {e}")

    # Network bridge
    for _bridge in ("lxdbr0", "incusbr0", "virbr0", "br0"):
        try:
            await run(
                f"lxc config device add {prefix}{container_name} eth0 nic "
                f"nictype=bridged parent={_bridge} name=eth0"
            )
            logger.info(f"[lxc.deploy] Network eth0 → {_bridge}")
            break
        except Exception as e:
            if "not found" in str(e).lower() or "already exists" in str(e).lower():
                break
            continue

    # Start
    await run(f"lxc start {prefix}{container_name}", timeout=60)
