"""
core/lxc.py — Runtime router.

Auto-detects whether Incus or LXC (LXD) is installed and loads the
correct backend:

    Incus detected  →  core/incus.py
    LXC detected    →  core/lxc_backend.py

All other modules import from core.lxc only.
"""

import os
import re
import shutil
import logging
from typing import Optional

logger = logging.getLogger("moonnodes_vps_bot")


# ── Runtime detection ─────────────────────────────────────────────────────────

def _detect() -> tuple:
    for path in ("/usr/bin/incus", "/usr/local/bin/incus", shutil.which("incus") or ""):
        if path and os.path.isfile(path):
            logger.info(f"🟢 Runtime: Incus ({path})  →  backend: core/incus.py")
            return "incus", path
    for path in ("/usr/bin/lxc", "/snap/bin/lxc", "/usr/local/bin/lxc", shutil.which("lxc") or ""):
        if path and os.path.isfile(path):
            logger.info(f"🟢 Runtime: LXC ({path})  →  backend: core/lxc_backend.py")
            return "lxc", path
    logger.warning("⚠️  No container runtime found. Install Incus or LXD first.")
    return "lxc", "lxc"


RUNTIME, RUNTIME_BIN = _detect()
IS_INCUS = (RUNTIME == "incus")


# ── Load the correct backend ──────────────────────────────────────────────────

if IS_INCUS:
    import core.incus as _backend
    _backend.BINARY = RUNTIME_BIN
    from core.incus import (
        run             as _run,
        deploy          as _deploy,
        normalize_image as normalize_os,
        list_remotes    as list_lxd_remotes,
        detect_storage_pool as get_auto_storage_pool,
        host_cpu_pct    as _host_cpu_pct,
        host_cpu_cores  as _host_cpu_cores,
        host_ram        as _host_ram,
        host_disk       as _host_disk,
        container_status  as _cstatus,
        container_cpu_pct as _ccpu,
        container_memory  as _cmem,
        container_disk    as _cdisk,
        container_uptime  as _cuptime,
    )
else:
    import core.lxc_backend as _backend
    _backend.BINARY = RUNTIME_BIN
    from core.lxc_backend import (
        run             as _run,
        deploy          as _deploy,
        list_remotes    as list_lxd_remotes,
        detect_storage_pool as get_auto_storage_pool,
        host_cpu_pct    as _host_cpu_pct,
        host_cpu_cores  as _host_cpu_cores,
        host_ram        as _host_ram,
        host_disk       as _host_disk,
        container_status  as _cstatus,
        container_cpu_pct as _ccpu,
        container_memory  as _cmem,
        container_disk    as _cdisk,
        container_uptime  as _cuptime,
    )
    def normalize_os(image: str) -> str: return image


# ── Unified public API ────────────────────────────────────────────────────────

async def execute_lxc(command: str, timeout: int = 120):
    return await _run(command, timeout=timeout)

async def get_container_status(name: str, node: str = "local") -> str:
    return await _cstatus(name, node)

async def get_container_cpu_pct(name: str, node: str = "local") -> float:
    return await _ccpu(name, node)

async def get_container_cpu_raw(name: str, node: str = "local") -> float:
    return await _ccpu(name, node)

async def get_container_memory(name: str, node: str = "local") -> str:
    return await _cmem(name, node)

async def get_container_memory_raw(name: str, node: str = "local") -> tuple:
    text = await _cmem(name, node)
    pct  = 0.0
    m    = re.search(r"\((\d+\.?\d*)%\)", text)
    if m: pct = float(m.group(1))
    return text, pct

async def get_container_disk(name: str, node: str = "local") -> str:
    return await _cdisk(name, node)

async def get_container_uptime(name: str, node: str = "local") -> str:
    return await _cuptime(name, node)


# ── Advanced permissions ──────────────────────────────────────────────────────

async def apply_advanced_permissions(container_name: str, node: str = "local"):
    node   = (node or "local").strip().rstrip(":") or "local"
    prefix = f"{node}:" if node != "local" else ""
    for cfg in [
        "security.privileged true",
        "security.nesting true",
        "security.syscalls.intercept.mknod true",
        "linux.kernel_modules overlay,loop,nf_nat,ip_tables,ip6_tables",
    ]:
        try:
            await execute_lxc(f"lxc config set {prefix}{container_name} {cfg}")
        except Exception as e:
            logger.warning(f"apply_advanced_permissions non-fatal: {e}")
    if not IS_INCUS:
        try:
            await execute_lxc(
                f"lxc config device add {prefix}{container_name} fuse unix-char path=/dev/fuse"
            )
        except Exception: pass


# ── Node stats ────────────────────────────────────────────────────────────────

async def get_node_stats(node: str = "local") -> dict:
    d = {
        "cpu_pct": 0.0, "cpu_cores": 1,
        "used_ram_mb": 0, "total_ram_mb": 0, "ram_pct": 0.0,
        "used_disk_gb": 0, "total_disk_gb": 0, "disk_pct": 0.0,
        "vps_count": 0, "vps_running": 0,
    }
    node = (node or "local").strip().rstrip(":") or "local"

    if node == "local":
        d["cpu_pct"]   = _host_cpu_pct()
        d["cpu_cores"] = _host_cpu_cores()
        ur, tr = _host_ram()
        ud, td = _host_disk()
        d["used_ram_mb"]  = ur; d["total_ram_mb"]  = tr
        d["used_disk_gb"] = ud; d["total_disk_gb"] = td
        d["ram_pct"]  = round(ur / tr * 100, 1) if tr else 0.0
        d["disk_pct"] = round(ud / td * 100, 1) if td else 0.0

    prefix = f"{node}:" if node != "local" else ""
    try:
        # FIX: space between prefix and --format flag
        out = await execute_lxc(f"lxc list {prefix} --format=csv")
        if out and out is not True:
            lines = [l for l in str(out).splitlines() if l.strip()]
            d["vps_count"]   = len(lines)
            d["vps_running"] = sum(1 for l in lines if "RUNNING" in l.upper())
    except Exception:
        pass
    return d


# ── Best node selector ────────────────────────────────────────────────────────

async def get_best_node(multi_node: bool = False) -> str:
    if not multi_node: return "local"
    remotes = await list_lxd_remotes()
    best, best_ram = "local", float("inf")
    for n in ["local"] + remotes:
        try:
            s = await get_node_stats(n)
            if s["ram_pct"] < best_ram:
                best_ram = s["ram_pct"]; best = n
        except Exception: continue
    return best


# ── Deployment facade ─────────────────────────────────────────────────────────

async def deploy_container(
    user_id: str,
    username: str,
    ram: int,
    cpu: int,
    disk: int,
    os_version: str = "ubuntu:22.04",
    validity_days: Optional[int] = None,
    target_node: str = "local",
    storage_pool: str = "default",
) -> dict:
    """Create and start a container. Returns the VPS dict entry."""
    import re as _re
    from datetime import datetime, timedelta
    from core.database import vps_data, async_save_vps_data, data_lock
    from core.config import VPS_PREFIX

    os_image = normalize_os(os_version)

    # Strip trailing colon from target_node (node_select passes "node2:")
    target_node = (target_node or "local").strip().rstrip(":").strip() or "local"

    # Safe username: alphanumeric only, max 10 chars
    safe_name   = _re.sub(r"[^a-z0-9]", "", username.lower())[:10] or "user"
    # Safe prefix: alphanumeric + hyphen, no leading/trailing hyphens
    safe_prefix = _re.sub(r"[^a-z0-9-]", "-", VPS_PREFIX.lower()).strip("-") or "vps"

    async with data_lock:
        vps_num = len(vps_data.get(user_id, [])) + 1

    # Container name: only alphanumeric and hyphens (Incus requirement)
    container_name = f"{safe_prefix}-{safe_name}-{vps_num}"
    container_name = _re.sub(r"[^a-z0-9-]", "-", container_name)
    container_name = _re.sub(r"-{2,}", "-", container_name).strip("-")

    logger.info(f"[deploy] container_name={container_name!r} node={target_node!r}")

    await _deploy(
        container_name = container_name,
        os_image       = os_image,
        ram_gb         = ram,
        cpu            = cpu,
        disk_gb        = disk,
        storage_pool   = storage_pool,
        node           = target_node,
    )

    expiry = (datetime.now() + timedelta(days=validity_days)).isoformat() if validity_days else None

    entry = {
        "container_name":     container_name,
        "ram":                f"{ram}GB",
        "cpu":                str(cpu),
        "storage":            f"{disk}GB",
        "config":             f"{ram}GB RAM / {cpu} CPU / {disk}GB Disk",
        "os_version":         os_image,
        "status":             "running",
        "suspended":          False,
        "whitelisted":        False,
        "node":               target_node,
        "created_at":         datetime.now().isoformat(),
        "expiry":             expiry,
        "shared_with":        [],
        "suspension_history": [],
        "id":                 None,
    }

    async with data_lock:
        vps_data.setdefault(user_id, []).append(entry)
    await async_save_vps_data()
    return entry
