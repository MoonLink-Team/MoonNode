"""
core/lxc.py — Container runtime abstraction (Incus or LXD auto-detected).

Key design decisions:
  - RUNTIME = "incus" or "lxc"
  - Incus uses `images:ubuntu/XX.XX` not `ubuntu:XX.XX`
  - For local-node stats we use subprocess directly (not exec-into-"local")
  - Remote prefix for local node is always "" (empty), never "local:"
  - _fix_args strips ALL -c flag variants before every command
"""

import asyncio
import subprocess
import shlex
import shutil
import re
import logging
from datetime import datetime, timedelta
from typing import Optional

logger = logging.getLogger("moonnodes_vps_bot")

# ── Runtime detection ─────────────────────────────────────────────────────────

def _detect_runtime() -> str:
    if shutil.which("incus"):
        logger.info("🟢 Container runtime: Incus")
        return "incus"
    if shutil.which("lxc"):
        logger.info("🟢 Container runtime: LXD (lxc)")
        return "lxc"
    logger.warning("No container runtime found — commands will fail until installed")
    return "lxc"

RUNTIME = _detect_runtime()
IS_INCUS = (RUNTIME == "incus")


def _cmd(command: str) -> str:
    """Replace leading runtime binary with the detected one."""
    for p in ("lxc ", "lxd ", "incus "):
        if command.startswith(p):
            return RUNTIME + " " + command[len(p):]
    return command


def _fix_args(command: str) -> str:
    """
    Strip flags that differ between Incus and LXD builds:
    - Remove -c <cols> / -c n,u / -c n,s etc (column filter — not always supported)
    - Normalise --format csv  →  --format=csv
    """
    command = re.sub(r"\s+-c\s+[\w,]+", "", command)   # -c n,u  or  -c name
    command = re.sub(r"--format\s+(\w+)", r"--format=\1", command)
    return command.strip()


def normalize_os(os_version: str) -> str:
    """
    Convert LXD-style image aliases to Incus-compatible ones when running Incus.
      ubuntu:22.04  →  images:ubuntu/22.04
      ubuntu:24.04  →  images:ubuntu/24.04
    LXD-style (lxc) keeps them as-is.
    """
    if not IS_INCUS:
        return os_version
    # Map ubuntu:XX.XX → images:ubuntu/XX.XX
    m = re.match(r"^ubuntu:(\d+\.\d+)$", os_version)
    if m:
        return f"images:ubuntu/{m.group(1)}"
    # ubuntu-daily:XX.XX  →  images:ubuntu/XX.XX/daily
    m = re.match(r"^ubuntu-daily:(\d+\.\d+)$", os_version)
    if m:
        return f"images:ubuntu/{m.group(1)}/daily"
    return os_version   # already in images: format or non-ubuntu


# ── Core executor ─────────────────────────────────────────────────────────────

async def execute_lxc(command: str, timeout: int = 120):
    command = _cmd(command)
    command = _fix_args(command)
    logger.info(f"[{RUNTIME}] → {command}")
    cmd = shlex.split(command)
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        try:
            proc.kill()
            await proc.wait()
        except Exception:
            pass
        raise asyncio.TimeoutError(f"Command timed out after {timeout}s: {command}")

    out = stdout.decode().strip() if stdout else ""
    err = stderr.decode().strip() if stderr else ""

    if proc.returncode != 0:
        msg = err or out or "Command failed with no output"
        logger.error(f"[{RUNTIME}] FAILED: {msg}")
        raise Exception(msg)

    return out if out else True


# ── Pool detection ────────────────────────────────────────────────────────────

def get_auto_storage_pool(default_pool: Optional[str] = None) -> str:
    if default_pool:
        return default_pool
    try:
        r = subprocess.run(
            [RUNTIME, "storage", "list", "--format=csv"],
            capture_output=True, text=True, timeout=10,
        )
        lines = r.stdout.strip().splitlines()
        for line in lines:
            name = line.split(",")[0].strip()
            if name and name not in ("", "NAME"):
                return name
    except Exception as e:
        logger.error(f"Pool detect failed: {e}")
    return "default"


# ── Remote listing ────────────────────────────────────────────────────────────

BUILTIN_REMOTES = {
    "local", "ubuntu", "ubuntu-daily", "ubuntu-minimal",
    "images", "local (current)", "",
}

async def list_lxd_remotes() -> list:
    """Return user-added remote names (excludes built-ins and local)."""
    try:
        r = subprocess.run(
            [RUNTIME, "remote", "list", "--format=csv"],
            capture_output=True, text=True, timeout=10,
        )
        remotes = []
        for line in r.stdout.strip().splitlines():
            # Incus: "local (current),https://..."  or  "node-sg,https://..."
            raw = line.split(",")[0].strip().rstrip("*").strip()
            clean = re.sub(r"\s*\(.*?\)", "", raw).strip()   # strip "(current)"
            if clean and clean not in BUILTIN_REMOTES:
                remotes.append(clean)
        return remotes
    except Exception as e:
        logger.warning(f"list_lxd_remotes failed: {e}")
        return []


# ── Local host stats (direct subprocess — no exec-into-"local") ───────────────

def _host_cpu_pct() -> float:
    try:
        r = subprocess.run(["top", "-bn1"], capture_output=True, text=True, timeout=5)
        for line in r.stdout.splitlines():
            if "Cpu" in line:
                m = re.search(r"(\d+\.?\d*)\s*id", line)
                if m:
                    return round(100.0 - float(m.group(1)), 1)
    except Exception:
        pass
    return 0.0


def _host_cpu_cores() -> int:
    try:
        r = subprocess.run(["nproc"], capture_output=True, text=True, timeout=5)
        return int(r.stdout.strip())
    except Exception:
        return 1


def _host_ram() -> tuple:
    """Returns (used_mb, total_mb)."""
    try:
        r = subprocess.run(["free", "-m"], capture_output=True, text=True, timeout=5)
        for line in r.stdout.splitlines():
            if line.startswith("Mem:"):
                p = line.split()
                return int(p[2]), int(p[1])
    except Exception:
        pass
    return 0, 0


def _host_disk() -> tuple:
    """Returns (used_gb, total_gb)."""
    try:
        r = subprocess.run(["df", "-BG", "/"], capture_output=True, text=True, timeout=5)
        for line in r.stdout.splitlines()[1:]:
            p = line.split()
            if len(p) >= 5:
                return int(p[2].replace("G", "")), int(p[1].replace("G", ""))
    except Exception:
        pass
    return 0, 0


# ── Node stats ────────────────────────────────────────────────────────────────

async def get_node_stats(node: str = "local") -> dict:
    """Return CPU/RAM/disk/VPS counts for a node."""
    defaults = {
        "cpu_pct": 0.0, "cpu_cores": 1,
        "used_ram_mb": 0, "total_ram_mb": 0, "ram_pct": 0.0,
        "used_disk_gb": 0, "total_disk_gb": 0, "disk_pct": 0.0,
        "vps_count": 0, "vps_running": 0,
    }

    is_local = (node == "local")

    if is_local:
        # Use direct host calls — never try to exec into "local" as a container name
        defaults["cpu_pct"]   = _host_cpu_pct()
        defaults["cpu_cores"] = _host_cpu_cores()

        used_ram, total_ram = _host_ram()
        defaults["used_ram_mb"]  = used_ram
        defaults["total_ram_mb"] = total_ram
        defaults["ram_pct"]      = round(used_ram / total_ram * 100, 1) if total_ram else 0.0

        used_disk, total_disk = _host_disk()
        defaults["used_disk_gb"]  = used_disk
        defaults["total_disk_gb"] = total_disk
        defaults["disk_pct"]      = round(used_disk / total_disk * 100, 1) if total_disk else 0.0

    else:
        # Remote node — exec into the host via the remote (node: prefix)
        prefix = f"{node}:"
        try:
            out = await execute_lxc(f"lxc exec {prefix}$(incus list {prefix} --format=csv | head -1 | cut -d, -f1) -- free -m")
        except Exception:
            pass  # Remote host stats not critical

    # VPS count — works for both local and remote
    prefix = f"{node}:" if not is_local else ""
    try:
        out = await execute_lxc(f"lxc list {prefix}--format=csv")
        if out and out is not True:
            lines = [l for l in str(out).splitlines() if l.strip()]
            defaults["vps_count"]   = len(lines)
            defaults["vps_running"] = sum(1 for l in lines if "RUNNING" in l.upper())
    except Exception:
        pass

    return defaults


# ── Container stats ───────────────────────────────────────────────────────────

async def get_container_status(container_name: str, node: str = "local") -> str:
    prefix = f"{node}:" if node != "local" else ""
    try:
        out = await execute_lxc(f"lxc list {prefix}{container_name} --format=csv")
        if out and out is not True:
            for line in str(out).splitlines():
                if container_name in line:
                    parts = line.split(",")
                    return parts[1].strip().lower() if len(parts) > 1 else "unknown"
    except Exception:
        pass
    return "unknown"


async def get_container_cpu_pct(container_name: str, node: str = "local") -> float:
    prefix = f"{node}:" if node != "local" else ""
    try:
        out = await execute_lxc(f"lxc exec {prefix}{container_name} -- top -bn1")
        if out and out is not True:
            for line in str(out).splitlines():
                if "Cpu" in line:
                    m = re.search(r"(\d+\.?\d*)\s*id", line)
                    if m:
                        return round(100.0 - float(m.group(1)), 1)
    except Exception:
        pass
    return 0.0


async def get_container_memory(container_name: str, node: str = "local") -> str:
    prefix = f"{node}:" if node != "local" else ""
    try:
        out = await execute_lxc(f"lxc exec {prefix}{container_name} -- free -m")
        if out and out is not True:
            for line in str(out).splitlines():
                if line.startswith("Mem:"):
                    p     = line.split()
                    total = int(p[1])
                    used  = int(p[2])
                    pct   = round(used / total * 100, 1) if total else 0
                    return f"{used}/{total} MB ({pct}%)"
    except Exception:
        pass
    return "N/A"


async def get_container_disk(container_name: str, node: str = "local") -> str:
    prefix = f"{node}:" if node != "local" else ""
    try:
        out = await execute_lxc(f"lxc exec {prefix}{container_name} -- df -h /")
        if out and out is not True:
            for line in str(out).splitlines()[1:]:
                p = line.split()
                if len(p) >= 5:
                    return f"{p[2]}/{p[1]} ({p[4]})"
    except Exception:
        pass
    return "N/A"


async def get_container_uptime(container_name: str, node: str = "local") -> str:
    prefix = f"{node}:" if node != "local" else ""
    try:
        out = await execute_lxc(f"lxc exec {prefix}{container_name} -- uptime -p")
        return str(out).strip() if out and out is not True else "N/A"
    except Exception:
        return "N/A"


# ── Best node ─────────────────────────────────────────────────────────────────

async def get_best_node(multi_node: bool = False) -> str:
    if not multi_node:
        return "local"
    remotes   = await list_lxd_remotes()
    all_nodes = ["local"] + remotes
    best, best_ram = "local", float("inf")
    for n in all_nodes:
        try:
            s = await get_node_stats(n)
            if s["ram_pct"] < best_ram:
                best_ram = s["ram_pct"]
                best     = n
        except Exception:
            continue
    return best


# ── Permissions ───────────────────────────────────────────────────────────────

async def apply_advanced_permissions(container_name: str, node: str = "local"):
    prefix = f"{node}:" if node != "local" else ""
    security_cmds = [
        f"lxc config set {prefix}{container_name} security.nesting true",
        f"lxc config set {prefix}{container_name} security.privileged true",
        f"lxc config set {prefix}{container_name} security.syscalls.intercept.mknod true",
        f"lxc config set {prefix}{container_name} linux.kernel_modules overlay,loop,nf_nat,ip_tables,ip6_tables",
    ]
    for cmd in security_cmds:
        try:
            await execute_lxc(cmd)
        except Exception as e:
            logger.warning(f"Permission cmd warning: {e}")
    try:
        await execute_lxc(
            f"lxc config device add {prefix}{container_name} fuse unix-char path=/dev/fuse"
        )
    except Exception:
        pass  # Already exists or not supported — non-fatal


# ── Deployment ────────────────────────────────────────────────────────────────

async def deploy_container(
    user_id: str,
    username: str,
    ram: int,
    cpu: int,
    disk: int,
    os_version: str = "ubuntu:22.04",
    validity_days: Optional[int] = None,
    target_node: str = "local",
    storage_pool: str = "default",
) -> dict:
    """Create, configure, and start a container. Returns the VPS entry dict."""
    from core.database import vps_data, save_vps_data, data_lock
    from core.config import VPS_PREFIX

    # Normalise OS image for Incus
    os_image = normalize_os(os_version)

    prefix     = f"{target_node}:" if target_node and target_node != "local" else ""
    with data_lock:
        vps_num = len(vps_data.get(user_id, [])) + 1
    container_name = f"{VPS_PREFIX}-{user_id}-{vps_num}"
    pool_flag = f" -s {storage_pool}" if storage_pool and storage_pool != "default" else ""

    await execute_lxc(f"lxc init {os_image} {prefix}{container_name}{pool_flag}", timeout=300)
    await execute_lxc(f"lxc config set {prefix}{container_name} limits.memory {ram * 1024}MB")
    await execute_lxc(f"lxc config set {prefix}{container_name} limits.cpu {cpu}")
    await execute_lxc(f"lxc config device set {prefix}{container_name} root size={disk}GB")
    await apply_advanced_permissions(container_name, target_node)
    await execute_lxc(f"lxc start {prefix}{container_name}", timeout=60)

    expiry = (datetime.now() + timedelta(days=validity_days)).isoformat() if validity_days else None

    entry = {
        "container_name": container_name,
        "ram":    f"{ram}GB",
        "cpu":    str(cpu),
        "storage": f"{disk}GB",
        "config":  f"{ram}GB RAM / {cpu} CPU / {disk}GB Disk",
        "os_version": os_image,
        "status":    "running",
        "suspended": False,
        "whitelisted": False,
        "node":      target_node or "local",
        "created_at": datetime.now().isoformat(),
        "expiry":    expiry,
        "shared_with": [],
        "suspension_history": [],
        "id": None,
    }

    with data_lock:
        vps_data.setdefault(user_id, []).append(entry)
    save_vps_data()
    return entry
