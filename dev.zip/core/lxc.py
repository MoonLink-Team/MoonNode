"""
core/lxc.py — Runtime router.

Detects whether Incus or LXD is installed and delegates all operations
to the appropriate implementation:
  - core/incus.py  — Incus-specific logic
  - core/lxd.py    — LXD-specific logic

All other modules import from core.lxc only — they don't need to know
which runtime is active.
"""

import os
import shutil
import logging
import re
from typing import Optional

logger = logging.getLogger("moonnodes_vps_bot")


# ── Runtime detection ─────────────────────────────────────────────────────────

def _detect() -> tuple:
    """
    Detect runtime and return (runtime_name, full_binary_path).
    Uses full path to survive systemd services where /snap/bin is not in PATH.
    Common locations: /usr/bin/incus, /usr/bin/lxc, /snap/bin/lxc
    """
    # Check incus first (preferred)
    for path in ("/usr/bin/incus", "/usr/local/bin/incus", shutil.which("incus") or ""):
        if path and os.path.isfile(path):
            logger.info(f"🟢 Runtime: Incus ({path})")
            return "incus", path

    # Fall back to LXD
    for path in ("/usr/bin/lxc", "/snap/bin/lxc", "/usr/local/bin/lxc", shutil.which("lxc") or ""):
        if path and os.path.isfile(path):
            logger.info(f"🟢 Runtime: LXD — {path}")
            return "lxc", path

    logger.warning("⚠️  No container runtime found. Install Incus or LXD first.")
    return "lxc", "lxc"  # fallback — will fail gracefully on commands


RUNTIME, RUNTIME_BIN = _detect()
IS_INCUS = (RUNTIME == "incus")


# ── Load the right backend ────────────────────────────────────────────────────

if IS_INCUS:
    import core.incus as _incus_mod
    _incus_mod.BINARY = RUNTIME_BIN   # use full resolved path
    from core.incus import (
        run             as _run,
        deploy          as _deploy,
        normalize_image as normalize_os,
        list_remotes    as list_lxd_remotes,
        detect_storage_pool as get_auto_storage_pool,
        host_cpu_pct    as _host_cpu_pct,
        host_cpu_cores  as _host_cpu_cores,
        host_ram        as _host_ram,
        host_disk       as _host_disk,
        container_status  as _cstatus,
        container_cpu_pct as _ccpu,
        container_memory  as _cmem,
        container_disk    as _cdisk,
        container_uptime  as _cuptime,
    )
else:
    import core.lxd as _lxd_mod
    _lxd_mod.BINARY = RUNTIME_BIN   # use full resolved path
    from core.lxd import (
        run             as _run,
        deploy          as _deploy,
        list_remotes    as list_lxd_remotes,
        detect_storage_pool as get_auto_storage_pool,
        host_cpu_pct    as _host_cpu_pct,
        host_cpu_cores  as _host_cpu_cores,
        host_ram        as _host_ram,
        host_disk       as _host_disk,
        container_status  as _cstatus,
        container_cpu_pct as _ccpu,
        container_memory  as _cmem,
        container_disk    as _cdisk,
        container_uptime  as _cuptime,
    )

    def normalize_os(image: str) -> str:
        """LXD uses images as-is."""
        return image


# ── Unified public API (all callers use these) ────────────────────────────────

async def execute_lxc(command: str, timeout: int = 120):
    """Execute a container runtime command via the active backend."""
    return await _run(command, timeout=timeout)


async def get_container_status(container_name: str, node: str = "local") -> str:
    return await _cstatus(container_name, node)


async def get_container_cpu_pct(container_name: str, node: str = "local") -> float:
    return await _ccpu(container_name, node)


async def get_container_cpu_raw(container_name: str, node: str = "local") -> float:
    """Alias used by manage_view."""
    return await _ccpu(container_name, node)


async def get_container_memory(container_name: str, node: str = "local") -> str:
    return await _cmem(container_name, node)


async def get_container_memory_raw(container_name: str, node: str = "local") -> tuple:
    """Returns (display_str, pct_float) used by manage_view."""
    text = await _cmem(container_name, node)
    pct  = 0.0
    m    = re.search(r"\((\d+\.?\d*)%\)", text)
    if m:
        pct = float(m.group(1))
    return text, pct


async def get_container_disk(container_name: str, node: str = "local") -> str:
    return await _cdisk(container_name, node)


async def get_container_uptime(container_name: str, node: str = "local") -> str:
    return await _cuptime(container_name, node)


# ── Advanced permissions (kept for compatibility) ─────────────────────────────

async def apply_advanced_permissions(container_name: str, node: str = "local"):
    """
    Apply Docker-ready permissions to an existing container.
    Safe to call on running or stopped containers.
    """
    prefix = f"{node}:" if node != "local" else ""
    configs = [
        "security.privileged true",
        "security.nesting true",
        "security.syscalls.intercept.mknod true",
        "linux.kernel_modules overlay,loop,nf_nat,ip_tables,ip6_tables",
    ]
    for cfg in configs:
        try:
            await execute_lxc(f"lxc config set {prefix}{container_name} {cfg}")
        except Exception as e:
            logger.warning(f"apply_advanced_permissions non-fatal: {e}")

    # FUSE device — only for LXD. Incus privileged containers get /dev/fuse
    # via cgroup2 automatically; adding it explicitly crashes when the host
    # path doesn't exist.
    if not IS_INCUS:
        try:
            await execute_lxc(
                f"lxc config device add {prefix}{container_name} fuse unix-char path=/dev/fuse"
            )
        except Exception:
            pass  # Already exists — non-fatal


# ── Node stats ────────────────────────────────────────────────────────────────

async def get_node_stats(node: str = "local") -> dict:
    """Return live resource stats for a node."""
    d = {
        "cpu_pct": 0.0, "cpu_cores": 1,
        "used_ram_mb": 0, "total_ram_mb": 0, "ram_pct": 0.0,
        "used_disk_gb": 0, "total_disk_gb": 0, "disk_pct": 0.0,
        "vps_count": 0, "vps_running": 0,
    }

    # Host stats (always from local subprocess — not exec into containers)
    if node == "local":
        d["cpu_pct"]    = _host_cpu_pct()
        d["cpu_cores"]  = _host_cpu_cores()
        ur, tr          = _host_ram()
        ud, td          = _host_disk()
        d["used_ram_mb"]   = ur; d["total_ram_mb"]   = tr
        d["used_disk_gb"]  = ud; d["total_disk_gb"]  = td
        d["ram_pct"]   = round(ur / tr * 100, 1) if tr else 0.0
        d["disk_pct"]  = round(ud / td * 100, 1) if td else 0.0

    # VPS count (works for local and remote)
    node   = (node or "local").strip() or "local"
    prefix = f"{node}:" if node != "local" else ""
    try:
        out = await execute_lxc(f"lxc list {prefix}--format=csv")
        if out and out is not True:
            lines = [l for l in str(out).splitlines() if l.strip()]
            d["vps_count"]   = len(lines)
            d["vps_running"] = sum(1 for l in lines if "RUNNING" in l.upper())
    except Exception:
        pass

    return d


# ── Best node selector ────────────────────────────────────────────────────────

async def get_best_node(multi_node: bool = False) -> str:
    if not multi_node:
        return "local"
    remotes = await list_lxd_remotes()
    best, best_ram = "local", float("inf")
    for n in ["local"] + remotes:
        try:
            s = await get_node_stats(n)
            if s["ram_pct"] < best_ram:
                best_ram = s["ram_pct"]
                best     = n
        except Exception:
            continue
    return best


# ── Deployment facade ─────────────────────────────────────────────────────────

async def deploy_container(
    user_id: str,
    username: str,
    ram: int,
    cpu: int,
    disk: int,
    os_version: str = "ubuntu:22.04",
    validity_days: Optional[int] = None,
    target_node: str = "local",
    storage_pool: str = "default",
) -> dict:
    """Create and start a container. Returns the VPS dict entry."""
    import re as _re
    from datetime import datetime, timedelta
    from core.database import vps_data, async_save_vps_data, data_lock
    from core.config import VPS_PREFIX

    os_image   = normalize_os(os_version)
    safe_name  = _re.sub(r"[^a-z0-9]", "", username.lower())[:12] or "user"

    # Always resolve empty/None node to "local" to prevent ":container" prefix
    if not target_node or target_node.strip() in ("", "local"):
        target_node = "local"

    async with data_lock:
        vps_num = len(vps_data.get(user_id, [])) + 1

    container_name = f"{VPS_PREFIX}-{safe_name}-{vps_num}"

    # Delegate creation to the correct backend
    await _deploy(
        container_name = container_name,
        os_image       = os_image,
        ram_gb         = ram,
        cpu            = cpu,
        disk_gb        = disk,
        storage_pool   = storage_pool,
        node           = target_node,
    )

    expiry = (datetime.now() + timedelta(days=validity_days)).isoformat() if validity_days else None

    entry = {
        "container_name": container_name,
        "ram":     f"{ram}GB",
        "cpu":     str(cpu),
        "storage": f"{disk}GB",
        "config":  f"{ram}GB RAM / {cpu} CPU / {disk}GB Disk",
        "os_version":  os_image,
        "status":      "running",
        "suspended":   False,
        "whitelisted": False,
        "node":        target_node or "local",
        "created_at":  datetime.now().isoformat(),
        "expiry":      expiry,
        "shared_with": [],
        "suspension_history": [],
        "id": None,
    }

    async with data_lock:
        vps_data.setdefault(user_id, []).append(entry)
    await async_save_vps_data()
    return entry
