import os
import logging
import sys
import shutil
from pathlib import Path
from dotenv import load_dotenv

# Always resolve .env relative to this file's directory (the project root),
# regardless of where the bot process was launched from.
_BASE = Path(__file__).resolve().parent.parent   # project root
_ENV_FILE = _BASE / ".env"

if not _ENV_FILE.exists():
    # Write a .env template so the user knows exactly what to fill in
    _TEMPLATE = """\
# ╔══════════════════════════════════════════════════════════════════════════╗
# ║            MoonNodes VPS Manager — Environment Configuration            ║
# ║                                                                          ║
# ║  1. Copy this file:  cp .env.example .env                               ║
# ║  2. Fill in the values below                                             ║
# ║  3. Run the bot:     python bot.py                                       ║
# ║                                                                          ║
# ║  Channels & extensions can also be changed LIVE with:                   ║
# ║    /set   — channels & DM settings                                       ║
# ║    /system action:Extension Toggle — enable/disable features             ║
# ╚══════════════════════════════════════════════════════════════════════════╝


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  REQUIRED — bot will NOT start without these
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Discord bot token — discord.com/developers/applications → Bot → Token
DISCORD_TOKEN=your_bot_token_here

# Your Discord User ID — right-click your name → Copy ID (enable Dev Mode first)
BOT_OWNER_ID=your_discord_user_id

# Your Discord server (guild) ID — right-click server icon → Copy ID
# Leave blank to sync commands globally (takes up to 1 hour)
GUILD_ID=your_guild_id


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  CONTAINER RUNTIME
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# Container name prefix  (e.g. "vps" → vps-username-1)
VPS_PREFIX=vps

# Storage pool for new containers — run: incus storage list
# Leave blank to use the default pool
DEFAULT_STORAGE_POOL=

# Your server's public IP (shown in SSH connection strings)
# Run: curl -s ifconfig.me
HOST_PUBLIC_IP=


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  RESOURCE LIMITS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

MAX_RAM_GB=16
MAX_CPU_CORES=8
CPU_THRESHOLD=90
RAM_THRESHOLD=90
ENFORCE_RESOURCE_LIMITS=True


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  CORE FEATURES
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PLANS=True
CLAIM_FREE=True
CLAIM_PREMIUM=True


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  EXTENSIONS  (toggle live: /system action:Extension Toggle)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SOSB=False                # Scheduled Off-Site Backups
ISTS=False                # Integrated Support Ticket System
AES=False                 # Auto Expire & Suspend
RR=False                  # Renewal Reminders (14/7/3/1 days before expiry)
GRACE_HOURS=24            # Hours after expiry before suspending
DELETE_DAYS=7             # Days after suspension before deleting
A2FA=False                # Bot 2FA — require PIN for admin commands
MSTC=False                # Multi-Server Ticket Creator
UBL_ENABLED=False         # User Backup Limits
BACKUP_LIMIT=1
MARKETPLACE=True          # VPS marketplace
ACCOUNT=True              # Account & MoonCoin system
VPS_MONITORING=False      # CPU/RAM alert DMs
DM_COMMANDS=False         # Allow slash commands in DMs
DM_PREFIX=!
MULTILANG=False           # Multi-language support


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  CLOUDFLARE  (optional)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

CF_API_TOKEN=
CF_ZONE_ID=
CF_DOMAIN=


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  APPEARANCE
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

BOT_COLOR=5865F2


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#  CHANNEL IDs  (leave blank — configure with /set after first boot)
#  To get a channel ID: right-click channel → Copy ID (Dev Mode must be on)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

# LOG_CHANNEL=            # Bot activity log
# MAIN_CHAT_ID=           # Main chat (MoonCoin rewards)
# PAYMENT_CHANNEL=        # Payment proofs
# TICKET_CHANNEL=         # Support ticket category
# UPDATE_CHANNEL=         # Maintenance announcements
# CLAIM_CHANNEL=          # Free VPS claims
# AF2F_CHANNEL=           # AF2F 2-factor code channel (owner-visible only)
"""
    try:
        _ENV_FILE.write_text(_TEMPLATE)
        print(
            f"\n{'='*60}\n"
            f"  .env file not found — created a template at:\n"
            f"  {_ENV_FILE}\n\n"
            f"  Fill in DISCORD_TOKEN, BOT_OWNER_ID, and GUILD_ID,\n"
            f"  then restart the bot.\n"
            f"{'='*60}\n"
        )
    except Exception:
        print(
            f"\n{'='*60}\n"
            f"  ERROR: .env file not found at {_ENV_FILE}\n"
            f"  Create it and add:\n"
            f"    DISCORD_TOKEN=your_token\n"
            f"    BOT_OWNER_ID=your_user_id\n"
            f"    GUILD_ID=your_server_id\n"
            f"{'='*60}\n"
        )
    sys.exit(1)

# Load .env from the explicit path — works regardless of cwd
load_dotenv(dotenv_path=_ENV_FILE, override=False)

# ── Discord ───────────────────────────────────────────────────────────────────
GUILD_ID       = int(os.getenv("GUILD_ID", "0")) or None
DISCORD_TOKEN  = os.getenv("DISCORD_TOKEN")
MAIN_ADMIN_ID  = int(os.getenv("BOT_OWNER_ID", "0"))

# ── Discord Role IDs (set in .env — 0 = not configured) ──────────────────────
VPS_USER_ROLE_ID    = int(os.getenv("VPS_USER_ROLE_ID",   "0"))
OWNER_ROLE_ID       = int(os.getenv("OWNER_ROLE_ID",      "0"))
HARD_ADMIN_ROLE_ID  = int(os.getenv("HARD_ADMIN_ROLE_ID", "0"))
ADMIN_ROLE_ID       = int(os.getenv("ADMIN_ROLE_ID",      "0"))
MANAGER_ROLE_ID     = int(os.getenv("MANAGER_ROLE_ID",    "0"))
HARD_MOD_ROLE_ID    = int(os.getenv("HARD_MOD_ROLE_ID",   "0"))
MOD_ROLE_ID         = int(os.getenv("MOD_ROLE_ID",        "0"))
HARD_STAFF_ROLE_ID  = int(os.getenv("HARD_STAFF_ROLE_ID", "0"))
STAFF_ROLE_ID       = int(os.getenv("STAFF_ROLE_ID",      "0"))
TRIAL_STAFF_ROLE_ID = int(os.getenv("TRIAL_STAFF_ROLE_ID","0"))
TRIAL_MOD_ROLE_ID   = int(os.getenv("TRIAL_MOD_ROLE_ID",  "0"))
PARTNER_ROLE_ID     = int(os.getenv("PARTNER_ROLE_ID",    "0"))
VIP_ROLE_ID         = int(os.getenv("VIP_ROLE_ID",        "0"))

# ── Bot appearance ────────────────────────────────────────────────────────────
_raw_color = os.getenv("BOT_COLOR", "5865F2").replace("#", "")
try:    CUSTOM_BOT_COLOR = int(_raw_color, 16)
except: CUSTOM_BOT_COLOR = 0x5865F2

# ── LXC / Container ───────────────────────────────────────────────────────────
DEFAULT_STORAGE_POOL = os.getenv("DEFAULT_STORAGE_POOL", None)
VPS_PREFIX           = os.getenv("VPS_PREFIX", "vps").strip() or "vps"

# ── Features ──────────────────────────────────────────────────────────────────
ENABLE_PLANS  = os.getenv("PLANS",         "True").lower() == "true"
CLAIM_PREMIUM = os.getenv("CLAIM_PREMIUM", "True").lower() == "true"
CLAIM_FREE    = os.getenv("CLAIM_FREE",    "True").lower() == "true"

# ── Resource limits ───────────────────────────────────────────────────────────
ENFORCE_RESOURCE_LIMITS = os.getenv("ENFORCE_RESOURCE_LIMITS","True").lower() == "true"
MAX_RAM_LIMIT  = int(os.getenv("MAX_RAM_GB",    "16"))
MAX_CPU_LIMIT  = int(os.getenv("MAX_CPU_CORES", "8"))
CPU_THRESHOLD  = float(os.getenv("CPU_THRESHOLD","90"))
RAM_THRESHOLD  = float(os.getenv("RAM_THRESHOLD","90"))

# ── Extensions ────────────────────────────────────────────────────────────────
ASM         = os.getenv("ASM",         "False").lower() == "true"
MULTI_NODE  = os.getenv("Multi-Node",  "False").lower() == "true"
SOSB        = os.getenv("SOSB",        "False").lower() == "true"
ABEI        = os.getenv("ABEI",        "False").lower() == "true"
ISTS        = os.getenv("ISTS",        "False").lower() == "true"
AES         = os.getenv("AES",         "False").lower() == "true"
RR          = os.getenv("RR",          "False").lower() == "true"
GRACE_HOURS = int(os.getenv("GRACE_HOURS", "24"))    # hours after expiry before suspending
DELETE_DAYS = int(os.getenv("DELETE_DAYS", "7"))     # days after suspension before deleting
RA          = os.getenv("RA",          "False").lower() == "true"
A2FA        = os.getenv("A2FA",        "False").lower() == "true"
CPCS        = os.getenv("CPCS",        "False").lower() == "true"
MSTC        = os.getenv("MSTC",        "False").lower() == "true"
PUDC        = os.getenv("PUDC",        "False").lower() == "true"
MARKETPLACE = os.getenv("MARKETPLACE", "True").lower()  == "true"
ACCOUNT     = os.getenv("ACCOUNT",     "True").lower()  == "true"
MAIN_CHAT_ID = int(os.getenv("MAIN_CHAT_ID", "0"))
UBL_ENABLED = os.getenv("UBL_ENABLED", "False").lower() == "true"
UBL_LIMIT   = int(os.getenv("BACKUP_LIMIT", "1"))
VPS_RENEWAL    = os.getenv("VPS_RENEWAL",    "False").lower() == "true"
VPS_MONITORING = os.getenv("VPS_MONITORING", "False").lower() == "true"
VPS_TEMPLATES  = os.getenv("VPS_TEMPLATES",  "False").lower() == "true"
MULTILANG      = os.getenv("MULTILANG",      "False").lower() == "true"
DM_COMMANDS    = os.getenv("DM_COMMANDS",    "False").lower() == "true"
DM_PREFIX      = os.getenv("DM_PREFIX",      "!")  # Prefix for DM commands when DM_COMMANDS=True
BLOCK_TERMINAL = os.getenv("BLOCK_TERMINAL", "False").lower() == "true"

# ── Cloudflare ────────────────────────────────────────────────────────────────
CF_API_TOKEN   = os.getenv("CF_API_TOKEN")
CF_ZONE_ID     = os.getenv("CF_ZONE_ID")
CF_DOMAIN      = os.getenv("CF_DOMAIN", "moonlink.qzz.io")
HOST_PUBLIC_IP = os.getenv("HOST_PUBLIC_IP")

# ── OS Options ───────────────────────────────────────────────────────────────
OS_OPTIONS = [
    {"label": "Ubuntu 20.04 LTS",    "value": "ubuntu:20.04",      "emoji": "🐧", "desc": "Stable, widely supported"},
    {"label": "Ubuntu 22.04 LTS",    "value": "ubuntu:22.04",      "emoji": "🐧", "desc": "Standard recommendation"},
    {"label": "Ubuntu 24.04 LTS",    "value": "ubuntu:24.04",      "emoji": "🐧", "desc": "Latest LTS release"},
    {"label": "Debian 11 (Bullseye)","value": "images:debian/11",  "emoji": "🍥", "desc": "Old stable"},
    {"label": "Debian 12 (Bookworm)","value": "images:debian/12",  "emoji": "🍥", "desc": "Current stable"},
    {"label": "Debian 13 (Trixie)",  "value": "images:debian/13",  "emoji": "🍥", "desc": "Testing / Next stable"},
]

# ── Maintenance Mode (runtime flag) ──────────────────────────────────────────
MAINTENANCE_MODE = False

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("bot.log"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger("moonnodes_vps_bot")
logging.getLogger("discord.voice_client").setLevel(logging.ERROR)
logging.getLogger("discord.gateway").setLevel(logging.WARNING)
logging.getLogger("nacl").setLevel(logging.ERROR)

import warnings
warnings.filterwarnings("ignore", message=".*PyNaCl.*")
warnings.filterwarnings("ignore", message=".*voice.*")

if not shutil.which("lxc") and not shutil.which("incus"):
    logger.critical("No container runtime found (lxc/incus). Install LXD or Incus first.")
    sys.exit(1)
