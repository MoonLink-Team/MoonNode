import os
import logging
import sys
import shutil
from dotenv import load_dotenv

load_dotenv()

# ── Discord ───────────────────────────────────────────────────────────────────
GUILD_ID       = int(os.getenv("GUILD_ID", "0")) or None
DISCORD_TOKEN  = os.getenv("DISCORD_TOKEN")
MAIN_ADMIN_ID  = int(os.getenv("BOT_OWNER_ID", "0"))

# ── Discord Role IDs (set in .env — 0 = not configured) ──────────────────────
VPS_USER_ROLE_ID    = int(os.getenv("VPS_USER_ROLE_ID",   "0"))
OWNER_ROLE_ID       = int(os.getenv("OWNER_ROLE_ID",      "0"))
HARD_ADMIN_ROLE_ID  = int(os.getenv("HARD_ADMIN_ROLE_ID", "0"))
ADMIN_ROLE_ID       = int(os.getenv("ADMIN_ROLE_ID",      "0"))
MANAGER_ROLE_ID     = int(os.getenv("MANAGER_ROLE_ID",    "0"))
HARD_MOD_ROLE_ID    = int(os.getenv("HARD_MOD_ROLE_ID",   "0"))
MOD_ROLE_ID         = int(os.getenv("MOD_ROLE_ID",        "0"))
HARD_STAFF_ROLE_ID  = int(os.getenv("HARD_STAFF_ROLE_ID", "0"))
STAFF_ROLE_ID       = int(os.getenv("STAFF_ROLE_ID",      "0"))
TRIAL_STAFF_ROLE_ID = int(os.getenv("TRIAL_STAFF_ROLE_ID","0"))
TRIAL_MOD_ROLE_ID   = int(os.getenv("TRIAL_MOD_ROLE_ID",  "0"))
PARTNER_ROLE_ID     = int(os.getenv("PARTNER_ROLE_ID",    "0"))
VIP_ROLE_ID         = int(os.getenv("VIP_ROLE_ID",        "0"))

# ── Bot appearance ────────────────────────────────────────────────────────────
_raw_color = os.getenv("BOT_COLOR", "5865F2").replace("#", "")
try:    CUSTOM_BOT_COLOR = int(_raw_color, 16)
except: CUSTOM_BOT_COLOR = 0x5865F2

# ── LXC / Container ───────────────────────────────────────────────────────────
DEFAULT_STORAGE_POOL = os.getenv("DEFAULT_STORAGE_POOL", None)
VPS_PREFIX           = os.getenv("VPS_PREFIX", "vps").strip() or "vps"

# ── Features ──────────────────────────────────────────────────────────────────
ENABLE_PLANS  = os.getenv("PLANS",         "True").lower() == "true"
CLAIM_PREMIUM = os.getenv("CLAIM_PREMIUM", "True").lower() == "true"
CLAIM_FREE    = os.getenv("CLAIM_FREE",    "True").lower() == "true"

# ── Resource limits ───────────────────────────────────────────────────────────
ENFORCE_RESOURCE_LIMITS = os.getenv("ENFORCE_RESOURCE_LIMITS","True").lower() == "true"
MAX_RAM_LIMIT  = int(os.getenv("MAX_RAM_GB",    "16"))
MAX_CPU_LIMIT  = int(os.getenv("MAX_CPU_CORES", "8"))
CPU_THRESHOLD  = float(os.getenv("CPU_THRESHOLD","90"))
RAM_THRESHOLD  = float(os.getenv("RAM_THRESHOLD","90"))

# ── Extensions ────────────────────────────────────────────────────────────────
ASM         = os.getenv("ASM",         "False").lower() == "true"
MULTI_NODE  = os.getenv("Multi-Node",  "False").lower() == "true"
SOSB        = os.getenv("SOSB",        "False").lower() == "true"
ABEI        = os.getenv("ABEI",        "False").lower() == "true"
ISTS        = os.getenv("ISTS",        "False").lower() == "true"
AES         = os.getenv("AES",         "False").lower() == "true"
RR          = os.getenv("RR",          "False").lower() == "true"
RA          = os.getenv("RA",          "False").lower() == "true"
A2FA        = os.getenv("A2FA",        "False").lower() == "true"
CPCS        = os.getenv("CPCS",        "False").lower() == "true"
MSTC        = os.getenv("MSTC",        "False").lower() == "true"
PUDC        = os.getenv("PUDC",        "False").lower() == "true"
MARKETPLACE = os.getenv("MARKETPLACE", "True").lower()  == "true"
ACCOUNT     = os.getenv("ACCOUNT",     "True").lower()  == "true"
MAIN_CHAT_ID = int(os.getenv("MAIN_CHAT_ID", "0"))
UBL_ENABLED = os.getenv("UBL_ENABLED", "False").lower() == "true"
UBL_LIMIT   = int(os.getenv("BACKUP_LIMIT", "1"))
VPS_RENEWAL    = os.getenv("VPS_RENEWAL",    "False").lower() == "true"
VPS_MONITORING = os.getenv("VPS_MONITORING", "False").lower() == "true"
VPS_TEMPLATES  = os.getenv("VPS_TEMPLATES",  "False").lower() == "true"
MULTILANG      = os.getenv("MULTILANG",      "False").lower() == "true"
DM_COMMANDS    = os.getenv("DM_COMMANDS",    "False").lower() == "true"
BLOCK_TERMINAL = os.getenv("BLOCK_TERMINAL", "False").lower() == "true"

# ── Cloudflare ────────────────────────────────────────────────────────────────
CF_API_TOKEN   = os.getenv("CF_API_TOKEN")
CF_ZONE_ID     = os.getenv("CF_ZONE_ID")
CF_DOMAIN      = os.getenv("CF_DOMAIN", "moonlink.qzz.io")
HOST_PUBLIC_IP = os.getenv("HOST_PUBLIC_IP")

# ── OS Options ───────────────────────────────────────────────────────────────
OS_OPTIONS = [
    {"label": "Ubuntu 20.04 LTS",    "value": "ubuntu:20.04",      "emoji": "🐧", "desc": "Stable, widely supported"},
    {"label": "Ubuntu 22.04 LTS",    "value": "ubuntu:22.04",      "emoji": "🐧", "desc": "Standard recommendation"},
    {"label": "Ubuntu 24.04 LTS",    "value": "ubuntu:24.04",      "emoji": "🐧", "desc": "Latest LTS release"},
    {"label": "Debian 11 (Bullseye)","value": "images:debian/11",  "emoji": "🍥", "desc": "Old stable"},
    {"label": "Debian 12 (Bookworm)","value": "images:debian/12",  "emoji": "🍥", "desc": "Current stable"},
    {"label": "Debian 13 (Trixie)",  "value": "images:debian/13",  "emoji": "🍥", "desc": "Testing / Next stable"},
]

# ── Maintenance Mode (runtime flag) ──────────────────────────────────────────
MAINTENANCE_MODE = False

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("bot.log"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger("moonnodes_vps_bot")
logging.getLogger("discord.voice_client").setLevel(logging.ERROR)
logging.getLogger("discord.gateway").setLevel(logging.WARNING)
logging.getLogger("nacl").setLevel(logging.ERROR)

import warnings
warnings.filterwarnings("ignore", message=".*PyNaCl.*")
warnings.filterwarnings("ignore", message=".*voice.*")

if not shutil.which("lxc") and not shutil.which("incus"):
    logger.critical("No container runtime found (lxc/incus). Install LXD or Incus first.")
    sys.exit(1)
