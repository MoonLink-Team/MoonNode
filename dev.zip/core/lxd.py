"""
core/lxd.py — Compatibility shim.
Imports from here still work: `from core.lxd import run`
"""
from core.lxc_backend import (
    run, deploy, list_remotes, detect_storage_pool,
    host_cpu_pct, host_cpu_cores, host_ram, host_disk,
    container_status, container_cpu_pct, container_memory,
    container_disk, container_uptime, BINARY,
)

__all__ = [
    "run", "deploy", "list_remotes", "detect_storage_pool",
    "host_cpu_pct", "host_cpu_cores", "host_ram", "host_disk",
    "container_status", "container_cpu_pct", "container_memory",
    "container_disk", "container_uptime", "BINARY",
]
