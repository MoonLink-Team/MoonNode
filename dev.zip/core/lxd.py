"""
core/lxd.py — Compatibility shim.

The LXC/LXD backend has been moved to core/lxc_backend.py.
This file re-exports everything from there so any old import paths
continue to work without changes.

    from core.lxd import run      ← still works
    from core.lxc_backend import run  ← new canonical path
"""
from core.lxc_backend import *          # noqa: F401, F403
from core.lxc_backend import (
    run,
    deploy,
    list_remotes,
    detect_storage_pool,
    host_cpu_pct,
    host_cpu_cores,
    host_ram,
    host_disk,
    container_status,
    container_cpu_pct,
    container_memory,
    container_disk,
    container_uptime,
    BINARY,
)
