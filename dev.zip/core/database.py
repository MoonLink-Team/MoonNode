"""
core/database.py — Unified SQLite-backed data layer (system.db).

ALL bot data lives in system.db — no more split JSON / SQLite.
VPS records are stored in the vps_entries table.
The in-memory vps_data dict is kept for fast access and synced on every write.

Fixes:
  - data_lock → asyncio.Lock (never threading.Lock)
  - async_save_vps_data() is now async INSERT/UPDATE into system.db
  - vps_data loaded from system.db on startup, falls back to legacy vps_data.json migration
  - All helpers (coins, invites, settings) use system.db
"""

import asyncio
import json
import logging
import os
import sqlite3
import threading
from datetime import datetime
from typing import Optional

logger = logging.getLogger("moonnodes_vps_bot")

# ── In-memory cache ───────────────────────────────────────────────────────────
vps_data:         dict = {}   # {user_id: [vps_dict, ...]}
admin_data:       dict = {}   # {user_id: role_str}
active_giveaways: dict = {}

data_lock = asyncio.Lock()   # MUST be asyncio.Lock — threading.Lock deadlocks async code

_BASE_DIR        = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH          = os.path.join(_BASE_DIR, "system.db")          # unified DB
_LEGACY_VPS_JSON = os.path.join(_BASE_DIR, "vps_data.json")
_LEGACY_ADM_JSON = os.path.join(_BASE_DIR, "admin_data.json")

CPU_THRESHOLD = 90.0
RAM_THRESHOLD = 90.0

_local = threading.local()


# ── Connection pool ───────────────────────────────────────────────────────────

def get_db() -> sqlite3.Connection:
    conn = getattr(_local, "conn", None)
    if conn is not None:
        try:
            conn.execute("SELECT 1")
            return conn
        except Exception:
            try: conn.close()
            except Exception: pass
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA synchronous=NORMAL")
    _local.conn = conn
    return conn


# ── Schema ────────────────────────────────────────────────────────────────────

def init_db():
    conn = get_db(); cur = conn.cursor()
    cur.executescript("""
        CREATE TABLE IF NOT EXISTS settings (
            key   TEXT PRIMARY KEY,
            value TEXT
        );
        CREATE TABLE IF NOT EXISTS users (
            user_id         TEXT PRIMARY KEY,
            credits         INTEGER DEFAULT 0,
            mooncoin        INTEGER DEFAULT 0,
            invites_used    INTEGER DEFAULT 0,
            invite_count    INTEGER DEFAULT 0,
            last_chat_coin  TEXT    DEFAULT NULL,
            total_referrals INTEGER DEFAULT 0,
            referred_by     TEXT    DEFAULT NULL,
            joined_at       TEXT    DEFAULT NULL
        );
        CREATE TABLE IF NOT EXISTS admins (
            user_id TEXT PRIMARY KEY,
            role    TEXT DEFAULT 'Admin',
            pin     TEXT DEFAULT '0000'
        );
        CREATE TABLE IF NOT EXISTS payments (
            name      TEXT PRIMARY KEY,
            image_url TEXT
        );
        CREATE TABLE IF NOT EXISTS vps_entries (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id        TEXT    NOT NULL,
            vps_index      INTEGER NOT NULL,
            container_name TEXT    NOT NULL,
            ram            TEXT,
            cpu            TEXT,
            storage        TEXT,
            config         TEXT,
            os_version     TEXT,
            status         TEXT    DEFAULT 'stopped',
            suspended      INTEGER DEFAULT 0,
            whitelisted    INTEGER DEFAULT 0,
            node           TEXT    DEFAULT 'local',
            created_at     TEXT,
            expiry         TEXT,
            shared_with    TEXT    DEFAULT '[]',
            suspension_history TEXT DEFAULT '[]',
            extra          TEXT    DEFAULT '{}',
            UNIQUE (user_id, vps_index)
        );
        CREATE TABLE IF NOT EXISTS marketplace (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            seller_id      TEXT    NOT NULL,
            sell_name      TEXT    UNIQUE NOT NULL,
            container_name TEXT    NOT NULL,
            price          TEXT    NOT NULL,
            price_type     TEXT    NOT NULL,
            validity       TEXT,
            description    TEXT,
            listed_at      TEXT    NOT NULL,
            active         INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS warnings (
            id      INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            reason  TEXT,
            by_id   TEXT,
            at      TEXT
        );
        CREATE TABLE IF NOT EXISTS staff_notes (
            id      INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            note    TEXT,
            by      TEXT,
            at      TEXT
        );
        CREATE TABLE IF NOT EXISTS mooncoin_rules (
            name     TEXT PRIMARY KEY,
            amount   INTEGER DEFAULT 1,
            cooldown INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS invite_tracking (
            inviter_id   TEXT NOT NULL,
            invitee_id   TEXT NOT NULL,
            joined_at    TEXT NOT NULL,
            left_at      TEXT DEFAULT NULL,
            valid        INTEGER DEFAULT 1,
            PRIMARY KEY (inviter_id, invitee_id)
        );
        CREATE TABLE IF NOT EXISTS claim_requests (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id       TEXT NOT NULL,
            plan_name     TEXT NOT NULL,
            plan_type     TEXT NOT NULL,
            ram_gb        INTEGER NOT NULL,
            cpu_cores     INTEGER NOT NULL,
            disk_gb       INTEGER NOT NULL,
            validity_days INTEGER DEFAULT NULL,
            proof_url     TEXT,
            status        TEXT DEFAULT 'pending',
            created_at    TEXT NOT NULL,
            handled_by    TEXT DEFAULT NULL,
            cancel_reason TEXT DEFAULT NULL
        );
        CREATE TABLE IF NOT EXISTS blocked_commands (
            cmd       TEXT PRIMARY KEY,
            added_by  TEXT,
            added_at  TEXT
        );
        CREATE TABLE IF NOT EXISTS af2f_pending (
            user_id    TEXT PRIMARY KEY,
            code       TEXT NOT NULL,
            cmd        TEXT NOT NULL,
            args       TEXT DEFAULT '{}',
            created_at TEXT NOT NULL,
            expires_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS vps_expiry_overrides (
            container_name TEXT PRIMARY KEY,
            expiry         TEXT,
            set_by         TEXT,
            set_at         TEXT
        );
    """)
    _migrate(cur, "users", [
        ("mooncoin",        "INTEGER DEFAULT 0"),
        ("invites_used",    "INTEGER DEFAULT 0"),
        ("invite_count",    "INTEGER DEFAULT 0"),
        ("last_chat_coin",  "TEXT DEFAULT NULL"),
        ("total_referrals", "INTEGER DEFAULT 0"),
        ("referred_by",     "TEXT DEFAULT NULL"),
        ("joined_at",       "TEXT DEFAULT NULL"),
    ])
    conn.commit()

    # Seed default mooncoin rules
    cur.execute("SELECT COUNT(*) as cnt FROM mooncoin_rules")
    if cur.fetchone()["cnt"] == 0:
        cur.executemany(
            "INSERT OR IGNORE INTO mooncoin_rules (name,amount,cooldown) VALUES (?,?,?)",
            [("invite",5,0),("chat",1,300),("giveaway",3,0),("event",7,0)]
        )
        conn.commit()

    # ── Performance indexes ──────────────────────────────────────────────────
    cur.executescript("""
        CREATE INDEX IF NOT EXISTS idx_vps_user     ON vps_entries(user_id);
        CREATE INDEX IF NOT EXISTS idx_vps_status   ON vps_entries(status);
        CREATE INDEX IF NOT EXISTS idx_vps_expiry   ON vps_entries(expiry);
        CREATE INDEX IF NOT EXISTS idx_vps_node     ON vps_entries(node);
        CREATE INDEX IF NOT EXISTS idx_users_id     ON users(user_id);
        CREATE INDEX IF NOT EXISTS idx_admins_id    ON admins(user_id);
        CREATE INDEX IF NOT EXISTS idx_af2f_user    ON af2f_pending(user_id);
        CREATE INDEX IF NOT EXISTS idx_market_active ON marketplace(active, seller_id);
        CREATE INDEX IF NOT EXISTS idx_claim_status ON claim_requests(status, user_id);
    """)
    conn.commit()
    logger.info(f"Database ready: {DB_PATH}")


def _migrate(cur, table: str, columns: list):
    cur.execute(f"PRAGMA table_info({table})")
    existing = {row["name"] for row in cur.fetchall()}
    for col_name, col_def in columns:
        if col_name not in existing:
            cur.execute(f"ALTER TABLE {table} ADD COLUMN {col_name} {col_def}")
            logger.info(f"DB migration: +{col_name} → {table}")


# ── VPS data: load from system.db (with JSON migration) ──────────────────────

def load_vps_data():
    """
    Load vps_data from system.db/vps_entries.
    If vps_entries is empty and legacy vps_data.json exists → migrate it.
    """
    conn = get_db(); cur = conn.cursor()
    cur.execute("SELECT COUNT(*) as cnt FROM vps_entries")
    count = cur.fetchone()["cnt"]

    if count == 0 and os.path.exists(_LEGACY_VPS_JSON):
        _migrate_json_to_db()
        cur.execute("SELECT COUNT(*) as cnt FROM vps_entries")
        count = cur.fetchone()["cnt"]

    cur.execute("SELECT user_id, vps_index, container_name, ram, cpu, storage, config, "
                "os_version, status, suspended, whitelisted, node, created_at, expiry, "
                "shared_with, suspension_history, extra FROM vps_entries ORDER BY user_id, vps_index")
    rows = cur.fetchall()
    vps_data.clear()
    for r in rows:
        uid  = r["user_id"]
        entry = {
            "container_name":     r["container_name"],
            "ram":                r["ram"],
            "cpu":                r["cpu"],
            "storage":            r["storage"],
            "config":             r["config"],
            "os_version":         r["os_version"],
            "status":             r["status"],
            "suspended":          bool(r["suspended"]),
            "whitelisted":        bool(r["whitelisted"]),
            "node":               r["node"],
            "created_at":         r["created_at"],
            "expiry":             r["expiry"],
            "shared_with":        _j(r["shared_with"], []),
            "suspension_history": _j(r["suspension_history"], []),
            "id":                 None,
        }
        try:
            extra = _j(r["extra"], {})
            entry.update(extra)
        except Exception: pass
        vps_data.setdefault(uid, []).append(entry)
    logger.info(f"Loaded {count} VPS records from system.db")


def _j(val, default):
    if val is None: return default
    try: return json.loads(val)
    except Exception: return default


def _migrate_json_to_db():
    """One-time migration: vps_data.json → system.db/vps_entries."""
    try:
        with open(_LEGACY_VPS_JSON) as f:
            data = json.load(f)
        conn = get_db(); cur = conn.cursor()
        n = 0
        for uid, lst in data.items():
            for idx, v in enumerate(lst):
                cur.execute(
                    "INSERT OR IGNORE INTO vps_entries "
                    "(user_id,vps_index,container_name,ram,cpu,storage,config,os_version,"
                    "status,suspended,whitelisted,node,created_at,expiry,shared_with,suspension_history) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (uid, idx, v.get("container_name",""), v.get("ram",""), v.get("cpu",""),
                     v.get("storage",""), v.get("config",""), v.get("os_version",""),
                     v.get("status","stopped"), int(v.get("suspended",False)),
                     int(v.get("whitelisted",False)), v.get("node","local"),
                     v.get("created_at",""), v.get("expiry"),
                     json.dumps(v.get("shared_with",[])),
                     json.dumps(v.get("suspension_history",[])))
                )
                n += 1
        conn.commit()
        logger.info(f"Migrated {n} VPS records from vps_data.json → system.db")
        os.rename(_LEGACY_VPS_JSON, _LEGACY_VPS_JSON + ".migrated")
    except Exception as e:
        logger.error(f"JSON migration failed: {e}")


def save_vps_data():
    """Sync in-memory vps_data back to system.db/vps_entries."""
    try:
        conn = get_db(); cur = conn.cursor()
        cur.execute("DELETE FROM vps_entries")
        for uid, lst in vps_data.items():
            for idx, v in enumerate(lst):
                cur.execute(
                    "INSERT INTO vps_entries "
                    "(user_id,vps_index,container_name,ram,cpu,storage,config,os_version,"
                    "status,suspended,whitelisted,node,created_at,expiry,shared_with,suspension_history) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (uid, idx, v.get("container_name",""), v.get("ram",""), v.get("cpu",""),
                     v.get("storage",""), v.get("config",""), v.get("os_version",""),
                     v.get("status","stopped"), int(v.get("suspended",False)),
                     int(v.get("whitelisted",False)), v.get("node","local"),
                     v.get("created_at",""), v.get("expiry"),
                     json.dumps(v.get("shared_with",[])),
                     json.dumps(v.get("suspension_history",[])))
                )
        conn.commit()
    except Exception as e:
        logger.error(f"save_vps_data failed: {e}")


async def async_save_vps_data():
    loop = asyncio.get_event_loop()
    await loop.run_in_executor(None, save_vps_data)


# ── Admin data ────────────────────────────────────────────────────────────────

def load_admin_data():
    # Try legacy JSON first, migrate to DB admins table
    if os.path.exists(_LEGACY_ADM_JSON):
        try:
            with open(_LEGACY_ADM_JSON) as f:
                loaded = json.load(f)
            admin_data.clear(); admin_data.update(loaded)
            # Sync to DB
            conn = get_db(); cur = conn.cursor()
            for uid, role in loaded.items():
                cur.execute("INSERT OR REPLACE INTO admins (user_id,role) VALUES (?,?)",(uid,role))
            conn.commit()
            os.rename(_LEGACY_ADM_JSON, _LEGACY_ADM_JSON + ".migrated")
            return
        except Exception: pass
    # Load from DB
    try:
        conn = get_db(); cur = conn.cursor()
        cur.execute("SELECT user_id, role FROM admins")
        for r in cur.fetchall():
            admin_data[r["user_id"]] = r["role"]
    except Exception as e:
        logger.error(f"load_admin_data: {e}")

def save_admin_data():
    try:
        conn = get_db(); cur = conn.cursor()
        for uid, role in admin_data.items():
            cur.execute("INSERT OR REPLACE INTO admins (user_id,role) VALUES (?,?)",(uid,role))
        conn.commit()
    except Exception as e:
        logger.error(f"save_admin_data: {e}")


# ── Settings helpers ──────────────────────────────────────────────────────────

def get_setting(key: str) -> Optional[str]:
    try:
        cur = get_db().cursor()
        cur.execute("SELECT value FROM settings WHERE key=?", (key,))
        row = cur.fetchone()
        return row["value"] if row else None
    except Exception as e:
        logger.error(f"get_setting({key}): {e}")
        return None

def set_setting(key: str, value: str):
    try:
        conn = get_db()
        conn.execute("INSERT OR REPLACE INTO settings (key,value) VALUES (?,?)",(key,value))
        conn.commit()
    except Exception as e:
        logger.error(f"set_setting({key}): {e}")

def get_payments() -> list:
    try:
        cur = get_db().cursor()
        cur.execute("SELECT * FROM payments")
        return [dict(r) for r in cur.fetchall()]
    except Exception: return []

def is_admin_check(user_id: int, main_admin_id: int) -> bool:
    if int(user_id) == int(main_admin_id): return True
    return admin_data.get(str(user_id),"") in ("Owner","Admin","Dev","Hard Admin")


# ── MoonCoin helpers ──────────────────────────────────────────────────────────

def get_coins(uid: str) -> int:
    try:
        cur = get_db().cursor()
        cur.execute("SELECT mooncoin FROM users WHERE user_id=?", (uid,))
        row = cur.fetchone(); return row["mooncoin"] if row else 0
    except Exception: return 0

def add_coins(uid: str, amount: int):
    try:
        conn = get_db()
        conn.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (uid,))
        conn.execute("UPDATE users SET mooncoin = MAX(0, mooncoin + ?) WHERE user_id=?", (amount, uid))
        conn.commit()
    except Exception as e:
        logger.error(f"add_coins: {e}")

def get_invite_count(uid: str) -> int:
    try:
        cur = get_db().cursor()
        cur.execute("SELECT COUNT(*) as cnt FROM invite_tracking WHERE inviter_id=? AND valid=1", (uid,))
        row = cur.fetchone(); return row["cnt"] if row else 0
    except Exception: return 0

def get_blocked_commands() -> list:
    try:
        cur = get_db().cursor()
        cur.execute("SELECT cmd FROM blocked_commands")
        return [r["cmd"] for r in cur.fetchall()]
    except Exception: return []
