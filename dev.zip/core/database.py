"""
core/database.py — Thread-safe, async-compatible data layer.

Fixes applied:
  - data_lock → asyncio.Lock (threading.Lock deadlocks in async code)
  - async_save_vps_data() offloads disk I/O to thread pool
  - get_db() per-thread connection cache + WAL mode
  - New tables: dark_market, invite_tracking, node_sections
"""

import asyncio
import json
import logging
import os
import sqlite3
import tempfile
import threading
from typing import Optional

logger = logging.getLogger("moonnodes_vps_bot")

# ── In-memory stores ─────────────────────────────────────────────────────────
vps_data:         dict = {}
admin_data:       dict = {}
active_giveaways: dict = {}

data_lock = asyncio.Lock()  # asyncio.Lock — NOT threading.Lock

_BASE_DIR       = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VPS_DATA_FILE   = os.path.join(_BASE_DIR, "vps_data.json")
ADMIN_DATA_FILE = os.path.join(_BASE_DIR, "admin_data.json")
_DB_PATH        = os.path.join(_BASE_DIR, "moonnodes.db")

CPU_THRESHOLD = 90.0
RAM_THRESHOLD = 90.0

_local = threading.local()


def get_db() -> sqlite3.Connection:
    conn = getattr(_local, "conn", None)
    if conn is not None:
        try:
            conn.execute("SELECT 1")
            return conn
        except Exception:
            try: conn.close()
            except Exception: pass
    conn = sqlite3.connect(_DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    _local.conn = conn
    return conn


# ── JSON helpers ─────────────────────────────────────────────────────────────

def load_vps_data():
    try:
        with open(VPS_DATA_FILE, "r") as f:
            loaded = json.load(f)
        vps_data.clear(); vps_data.update(loaded)
    except FileNotFoundError: pass
    except json.JSONDecodeError as e:
        logger.error(f"vps_data.json corrupt: {e}. Starting empty.")

def save_vps_data():
    try:
        dir_path = os.path.dirname(VPS_DATA_FILE)
        with tempfile.NamedTemporaryFile("w", dir=dir_path, delete=False, suffix=".tmp") as tmp:
            json.dump(vps_data, tmp, indent=2)
            tmp_path = tmp.name
        os.replace(tmp_path, VPS_DATA_FILE)
    except Exception as e:
        logger.error(f"Failed to save vps_data: {e}")

async def async_save_vps_data():
    loop = asyncio.get_event_loop()
    await loop.run_in_executor(None, save_vps_data)

def load_admin_data():
    try:
        with open(ADMIN_DATA_FILE, "r") as f:
            loaded = json.load(f)
        admin_data.clear(); admin_data.update(loaded)
    except FileNotFoundError: pass
    except json.JSONDecodeError as e:
        logger.error(f"admin_data.json corrupt: {e}.")

def save_admin_data():
    try:
        with open(ADMIN_DATA_FILE, "w") as f:
            json.dump(admin_data, f, indent=2)
    except Exception as e:
        logger.error(f"Failed to save admin_data: {e}")


# ── Schema init ───────────────────────────────────────────────────────────────

def init_db():
    conn = get_db()
    cur  = conn.cursor()
    cur.executescript("""
        CREATE TABLE IF NOT EXISTS settings (
            key   TEXT PRIMARY KEY,
            value TEXT
        );
        CREATE TABLE IF NOT EXISTS users (
            user_id         TEXT PRIMARY KEY,
            credits         INTEGER DEFAULT 0,
            mooncoin        INTEGER DEFAULT 0,
            invites_used    INTEGER DEFAULT 0,
            invite_count    INTEGER DEFAULT 0,
            last_chat_coin  TEXT    DEFAULT NULL,
            total_referrals INTEGER DEFAULT 0,
            referred_by     TEXT    DEFAULT NULL,
            joined_at       TEXT    DEFAULT NULL
        );
        CREATE TABLE IF NOT EXISTS admins (
            user_id TEXT PRIMARY KEY,
            role    TEXT DEFAULT 'Admin',
            pin     TEXT DEFAULT '0000'
        );
        CREATE TABLE IF NOT EXISTS payments (
            name      TEXT PRIMARY KEY,
            image_url TEXT
        );
        CREATE TABLE IF NOT EXISTS marketplace (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            seller_id      TEXT    NOT NULL,
            sell_name      TEXT    UNIQUE NOT NULL,
            container_name TEXT    NOT NULL,
            price          TEXT    NOT NULL,
            price_type     TEXT    NOT NULL,
            validity       TEXT,
            description    TEXT,
            listed_at      TEXT    NOT NULL,
            active         INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS dark_market (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            added_by       TEXT    NOT NULL,
            title          TEXT    NOT NULL,
            description    TEXT,
            ram_gb         INTEGER NOT NULL,
            cpu_cores      INTEGER NOT NULL,
            disk_gb        INTEGER NOT NULL,
            os_image       TEXT    NOT NULL,
            price_coin     INTEGER DEFAULT 0,
            validity_days  INTEGER DEFAULT 30,
            backup         INTEGER DEFAULT 0,
            stock          INTEGER DEFAULT 1,
            node           TEXT    DEFAULT 'local',
            listed_at      TEXT    NOT NULL,
            active         INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS warnings (
            id      INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            reason  TEXT,
            by_id   TEXT,
            at      TEXT
        );
        CREATE TABLE IF NOT EXISTS staff_notes (
            id      INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            note    TEXT,
            by      TEXT,
            at      TEXT
        );
        CREATE TABLE IF NOT EXISTS mooncoin_rules (
            name     TEXT PRIMARY KEY,
            amount   INTEGER DEFAULT 1,
            cooldown INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS invite_tracking (
            inviter_id   TEXT NOT NULL,
            invitee_id   TEXT NOT NULL,
            joined_at    TEXT NOT NULL,
            left_at      TEXT DEFAULT NULL,
            valid        INTEGER DEFAULT 1,
            PRIMARY KEY (inviter_id, invitee_id)
        );
        CREATE TABLE IF NOT EXISTS claim_requests (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id      TEXT NOT NULL,
            plan_name    TEXT NOT NULL,
            plan_type    TEXT NOT NULL,
            ram_gb       INTEGER NOT NULL,
            cpu_cores    INTEGER NOT NULL,
            disk_gb      INTEGER NOT NULL,
            validity_days INTEGER DEFAULT NULL,
            proof_url    TEXT,
            status       TEXT DEFAULT 'pending',
            created_at   TEXT NOT NULL,
            handled_by   TEXT DEFAULT NULL,
            cancel_reason TEXT DEFAULT NULL
        );
    """)
    _migrate(cur, "users", [
        ("mooncoin",        "INTEGER DEFAULT 0"),
        ("invites_used",    "INTEGER DEFAULT 0"),
        ("invite_count",    "INTEGER DEFAULT 0"),
        ("last_chat_coin",  "TEXT    DEFAULT NULL"),
        ("total_referrals", "INTEGER DEFAULT 0"),
        ("referred_by",     "TEXT    DEFAULT NULL"),
        ("joined_at",       "TEXT    DEFAULT NULL"),
    ])
    _migrate(cur, "marketplace", [("description", "TEXT")])
    conn.commit()

    # Seed default mooncoin rules if empty
    cur.execute("SELECT COUNT(*) as cnt FROM mooncoin_rules")
    if cur.fetchone()["cnt"] == 0:
        defaults = [
            ("invite",  5, 0),
            ("chat",    1, 300),   # 5 min cooldown
            ("giveaway",3, 0),
            ("event",   7, 0),
        ]
        cur.executemany(
            "INSERT OR IGNORE INTO mooncoin_rules (name, amount, cooldown) VALUES (?,?,?)",
            defaults
        )
        conn.commit()

    logger.info("Database initialised / migrated.")


def _migrate(cur, table: str, columns: list):
    cur.execute(f"PRAGMA table_info({table})")
    existing = {row["name"] for row in cur.fetchall()}
    for col_name, col_def in columns:
        if col_name not in existing:
            cur.execute(f"ALTER TABLE {table} ADD COLUMN {col_name} {col_def}")
            logger.info(f"DB migration: added '{col_name}' to '{table}'")


# ── Settings ──────────────────────────────────────────────────────────────────

def get_setting(key: str) -> Optional[str]:
    try:
        conn = get_db()
        cur  = conn.cursor()
        cur.execute("SELECT value FROM settings WHERE key=?", (key,))
        row = cur.fetchone()
        return row["value"] if row else None
    except Exception as e:
        logger.error(f"get_setting({key!r}) failed: {e}")
        return None

def set_setting(key: str, value: str):
    try:
        conn = get_db()
        cur  = conn.cursor()
        cur.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, value))
        conn.commit()
    except Exception as e:
        logger.error(f"set_setting({key!r}) failed: {e}")

def get_payments() -> list:
    try:
        conn = get_db()
        cur  = conn.cursor()
        cur.execute("SELECT * FROM payments")
        return [dict(r) for r in cur.fetchall()]
    except Exception as e:
        logger.error(f"get_payments() failed: {e}")
        return []

def is_admin_check(user_id: int, main_admin_id: int) -> bool:
    role = admin_data.get(str(user_id))
    return int(user_id) == int(main_admin_id) or role in ("Owner", "Admin", "Dev")


# ── MoonCoin helpers ──────────────────────────────────────────────────────────

def get_coins(user_id: str) -> int:
    try:
        conn = get_db()
        cur  = conn.cursor()
        cur.execute("SELECT mooncoin FROM users WHERE user_id=?", (user_id,))
        row = cur.fetchone()
        return row["mooncoin"] if row else 0
    except Exception: return 0

def add_coins(user_id: str, amount: int):
    try:
        conn = get_db()
        cur  = conn.cursor()
        cur.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (user_id,))
        cur.execute("UPDATE users SET mooncoin = mooncoin + ? WHERE user_id=?", (amount, user_id))
        conn.commit()
    except Exception as e:
        logger.error(f"add_coins failed: {e}")

def get_invite_count(user_id: str) -> int:
    """Return valid (stayed > 7 days) invite count for user."""
    try:
        conn = get_db()
        cur  = conn.cursor()
        cur.execute(
            "SELECT COUNT(*) as cnt FROM invite_tracking WHERE inviter_id=? AND valid=1",
            (user_id,)
        )
        row = cur.fetchone()
        return row["cnt"] if row else 0
    except Exception: return 0
