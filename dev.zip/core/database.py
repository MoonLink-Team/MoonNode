import sqlite3
import json
import threading
import logging
from typing import Optional

logger = logging.getLogger("moonnodes_vps_bot")

# ── In-memory VPS data ──────────────────────────────────────────────────────
vps_data: dict = {}
data_lock = threading.Lock()
admin_data: dict = {}
active_giveaways: dict = {}

import os as _os
_BASE_DIR    = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
VPS_DATA_FILE   = _os.path.join(_BASE_DIR, "vps_data.json")
ADMIN_DATA_FILE = _os.path.join(_BASE_DIR, "admin_data.json")

# ── Resource threshold runtime values (overridable by /set) ─────────────────
CPU_THRESHOLD = 90.0
RAM_THRESHOLD = 90.0


def load_vps_data():
    """
    Load VPS data from JSON and update the global dict IN-PLACE.
    This is critical — other modules hold references to the `vps_data` dict.
    Replacing it with `vps_data = {...}` would break those references.
    """
    global vps_data
    try:
        with open(VPS_DATA_FILE, "r") as f:
            loaded = json.load(f)
        vps_data.clear()
        vps_data.update(loaded)
    except FileNotFoundError:
        pass  # First run — no file yet, start empty
    except json.JSONDecodeError as e:
        logger.error(f"vps_data.json is corrupt: {e}. Starting with empty data.")


def save_vps_data():
    """Write current vps_data to disk atomically."""
    try:
        import tempfile, os
        dir_path = os.path.dirname(VPS_DATA_FILE)
        with tempfile.NamedTemporaryFile("w", dir=dir_path, delete=False, suffix=".tmp") as tmp:
            json.dump(vps_data, tmp, indent=2)
            tmp_path = tmp.name
        os.replace(tmp_path, VPS_DATA_FILE)  # atomic on Linux
    except Exception as e:
        logger.error(f"Failed to save vps_data: {e}")


def load_admin_data():
    """Load admin data in-place so module references stay valid."""
    global admin_data
    try:
        with open(ADMIN_DATA_FILE, "r") as f:
            loaded = json.load(f)
        admin_data.clear()
        admin_data.update(loaded)
    except FileNotFoundError:
        pass
    except json.JSONDecodeError as e:
        logger.error(f"admin_data.json is corrupt: {e}.")


def save_admin_data():
    try:
        with open(ADMIN_DATA_FILE, "w") as f:
            json.dump(admin_data, f, indent=2)
    except Exception as e:
        logger.error(f"Failed to save admin_data: {e}")


# ── SQLite helpers ───────────────────────────────────────────────────────────

def get_db() -> sqlite3.Connection:
    conn = sqlite3.connect("moonnodes.db")
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    cur = conn.cursor()
    cur.executescript("""
        CREATE TABLE IF NOT EXISTS settings (
            key   TEXT PRIMARY KEY,
            value TEXT
        );
        CREATE TABLE IF NOT EXISTS users (
            user_id         TEXT PRIMARY KEY,
            credits         INTEGER DEFAULT 0,
            mooncoin        INTEGER DEFAULT 0,
            invites_used    INTEGER DEFAULT 0,
            invite_count    INTEGER DEFAULT 0,
            last_chat_coin  TEXT    DEFAULT NULL,
            total_referrals INTEGER DEFAULT 0,
            referred_by     TEXT    DEFAULT NULL
        );
        CREATE TABLE IF NOT EXISTS admins (
            user_id TEXT PRIMARY KEY,
            role    TEXT DEFAULT 'Admin',
            pin     TEXT DEFAULT '0000'
        );
        CREATE TABLE IF NOT EXISTS payments (
            name      TEXT PRIMARY KEY,
            image_url TEXT
        );
        CREATE TABLE IF NOT EXISTS marketplace (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            seller_id      TEXT    NOT NULL,
            sell_name      TEXT    UNIQUE NOT NULL,
            container_name TEXT    NOT NULL,
            price          TEXT    NOT NULL,
            price_type     TEXT    NOT NULL,
            validity       TEXT,
            listed_at      TEXT    NOT NULL,
            active         INTEGER DEFAULT 1
        );
    """)

    # ── Safe migrations: add new columns if upgrading from an older DB ────────
    _migrate(cur, "users", [
        ("mooncoin",       "INTEGER DEFAULT 0"),
        ("invites_used",   "INTEGER DEFAULT 0"),
        ("invite_count",   "INTEGER DEFAULT 0"),
        ("last_chat_coin", "TEXT    DEFAULT NULL"),
    ])

    conn.commit()
    conn.close()
    logger.info("Database initialised / migrated.")


def _migrate(cur, table: str, columns: list):
    """Add missing columns to an existing table without breaking existing data."""
    cur.execute(f"PRAGMA table_info({table})")
    existing = {row["name"] for row in cur.fetchall()}
    for col_name, col_def in columns:
        if col_name not in existing:
            cur.execute(f"ALTER TABLE {table} ADD COLUMN {col_name} {col_def}")
            logger.info(f"DB migration: added column '{col_name}' to '{table}'")


def get_setting(key: str) -> Optional[str]:
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT value FROM settings WHERE key=?", (key,))
    row = cur.fetchone()
    conn.close()
    return row["value"] if row else None


def set_setting(key: str, value: str):
    conn = get_db()
    cur = conn.cursor()
    cur.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, value))
    conn.commit()
    conn.close()


def get_payments() -> list:
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT * FROM payments")
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


def is_admin_check(user_id: int, main_admin_id: int) -> bool:
    role = admin_data.get(str(user_id))
    return role in ["Owner", "Admin", "Dev"] or str(user_id) == str(main_admin_id)
