"""
core/database.py — Unified SQLite data layer (system.db)

All bot state lives here. No JSON files, no split storage.

Tables saved:
  vps_entries         — every VPS: spec, status, expiry, SSH password, plan, node
  users               — Discord users: mooncoin, credits, tier, referrals, cooldowns
  admins              — staff: role, PIN
  settings            — key/value config (channels, thresholds, ext flags)
  mooncoin_rules      — earn rules (name, amount, cooldown)
  coin_ledger         — EVERY mooncoin change with reason + balance (audit trail)
  warnings            — mod warnings per user
  staff_notes         — internal staff notes per user
  muted_users         — active mutes with optional expiry
  blocklist           — users banned from all commands
  dm_settings         — per-command DM allow/block rules + global mode
  af2f_pending        — admin 2FA pending codes
  marketplace         — VPS marketplace listings
  claim_requests      — free VPS claim submissions
  invite_tracking     — who invited whom
  payments            — accepted payment methods
  vps_expiry_overrides — per-container expiry overrides
  nodes               — registered LXD/Incus remote nodes (was CSV in settings)
  giveaways           — active/past giveaways — survives restarts
  vps_snapshots       — snapshot/backup records per container
  tickets             — support ticket records
  blocked_commands    — globally disabled slash commands

Changes vs v1:
  + vps_entries: ip_address, password, plan_name, plan_type, renewal_count, last_renewed
  + users: tier (premium key), vps_limit, last_seen
  + muted_users moved from inline CREATE in mod_tools.py into main schema
  + nodes table replaces comma-string in settings key 'registered_nodes'
  + giveaways table so active giveaways survive bot restarts
  + vps_snapshots table for proper backup/snapshot tracking
  + tickets table for support ticket records
  + coin_ledger for full audit trail on every mooncoin change
  + add_coins() now writes to coin_ledger automatically
  + save_vps_data() uses a single atomic transaction (no partial writes)
  + async_save_vps_data() is debounced to collapse rapid successive calls
  + checkpoint_db() for periodic WAL cleanup
  + get_nodes() / save_node() / remove_node() helpers
  + get_all_settings() helper
  + save_giveaway() / end_giveaway() helpers
  + save_snapshot() / get_snapshots() / delete_snapshot_record() helpers
  + open_ticket() / close_ticket() helpers
  + Full index coverage on every commonly-queried column
"""

import asyncio
import json
import logging
import os
import sqlite3
import threading
import time
from datetime import datetime
from typing import Optional

logger = logging.getLogger("moonnodes_vps_bot")

# ── In-memory caches ──────────────────────────────────────────────────────────
vps_data:         dict = {}   # {user_id: [vps_dict, ...]}
admin_data:       dict = {}   # {user_id: role_str}
active_giveaways: dict = {}   # {g_id: {task, end, msg, entries}}

data_lock = asyncio.Lock()    # asyncio.Lock — never threading.Lock in async code

_BASE_DIR        = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH          = os.path.join(_BASE_DIR, "system.db")
_LEGACY_VPS_JSON = os.path.join(_BASE_DIR, "vps_data.json")
_LEGACY_ADM_JSON = os.path.join(_BASE_DIR, "admin_data.json")

CPU_THRESHOLD = 90.0
RAM_THRESHOLD = 90.0

_local            = threading.local()
_pending_save     = False
_last_save_time   = 0.0
_SAVE_DEBOUNCE_S  = 2.0


# ── Thread-local connection pool ──────────────────────────────────────────────

def get_db() -> sqlite3.Connection:
    """
    Return a thread-local SQLite connection to system.db.
    Never call .close() on it — the connection belongs to the pool.
    """
    conn = getattr(_local, "conn", None)
    if conn is not None:
        try:
            conn.execute("SELECT 1")
            return conn
        except Exception:
            try: conn.close()
            except Exception: pass
    conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA cache_size=-32000")
    conn.execute("PRAGMA temp_store=MEMORY")
    conn.execute("PRAGMA auto_vacuum=INCREMENTAL")
    _local.conn = conn
    return conn


# ── Schema ────────────────────────────────────────────────────────────────────

def init_db():
    conn = get_db()
    cur  = conn.cursor()

    cur.executescript("""
        CREATE TABLE IF NOT EXISTS settings (
            key   TEXT PRIMARY KEY,
            value TEXT
        );
        CREATE TABLE IF NOT EXISTS users (
            user_id         TEXT    PRIMARY KEY,
            credits         INTEGER DEFAULT 0,
            mooncoin        INTEGER DEFAULT 0,
            tier            TEXT    DEFAULT NULL,
            vps_limit       INTEGER DEFAULT 0,
            invites_used    INTEGER DEFAULT 0,
            invite_count    INTEGER DEFAULT 0,
            last_chat_coin  TEXT    DEFAULT NULL,
            total_referrals INTEGER DEFAULT 0,
            referred_by     TEXT    DEFAULT NULL,
            joined_at       TEXT    DEFAULT NULL,
            last_seen       TEXT    DEFAULT NULL
        );
        CREATE TABLE IF NOT EXISTS admins (
            user_id TEXT    PRIMARY KEY,
            role    TEXT    DEFAULT 'Admin',
            pin     TEXT    DEFAULT '0000'
        );
        CREATE TABLE IF NOT EXISTS payments (
            name      TEXT PRIMARY KEY,
            image_url TEXT
        );
        CREATE TABLE IF NOT EXISTS vps_entries (
            id                 INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id            TEXT    NOT NULL,
            vps_index          INTEGER NOT NULL,
            container_name     TEXT    NOT NULL,
            ram                TEXT,
            cpu                TEXT,
            storage            TEXT,
            config             TEXT,
            os_version         TEXT,
            status             TEXT    DEFAULT 'stopped',
            suspended          INTEGER DEFAULT 0,
            whitelisted        INTEGER DEFAULT 0,
            node               TEXT    DEFAULT 'local',
            created_at         TEXT,
            expiry             TEXT,
            shared_with        TEXT    DEFAULT '[]',
            suspension_history TEXT    DEFAULT '[]',
            ip_address         TEXT    DEFAULT NULL,
            password           TEXT    DEFAULT NULL,
            plan_name          TEXT    DEFAULT NULL,
            plan_type          TEXT    DEFAULT NULL,
            renewal_count      INTEGER DEFAULT 0,
            last_renewed       TEXT    DEFAULT NULL,
            extra              TEXT    DEFAULT '{}',
            UNIQUE (user_id, vps_index)
        );
        CREATE TABLE IF NOT EXISTS marketplace (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            seller_id      TEXT    NOT NULL,
            sell_name      TEXT    UNIQUE NOT NULL,
            container_name TEXT    NOT NULL,
            price          TEXT    NOT NULL,
            price_type     TEXT    NOT NULL,
            validity       TEXT,
            description    TEXT,
            listed_at      TEXT    NOT NULL,
            active         INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS warnings (
            id      INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            reason  TEXT,
            by_id   TEXT,
            at      TEXT
        );
        CREATE TABLE IF NOT EXISTS staff_notes (
            id      INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            note    TEXT,
            by      TEXT,
            at      TEXT
        );
        CREATE TABLE IF NOT EXISTS muted_users (
            user_id TEXT    PRIMARY KEY,
            reason  TEXT,
            by_id   TEXT,
            expires TEXT    DEFAULT NULL,
            at      TEXT
        );
        CREATE TABLE IF NOT EXISTS blocklist (
            user_id  TEXT PRIMARY KEY,
            reason   TEXT,
            added_by TEXT,
            added_at TEXT
        );
        CREATE TABLE IF NOT EXISTS mooncoin_rules (
            name     TEXT    PRIMARY KEY,
            amount   INTEGER DEFAULT 1,
            cooldown INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS coin_ledger (
            id      INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT    NOT NULL,
            delta   INTEGER NOT NULL,
            balance INTEGER NOT NULL,
            reason  TEXT    DEFAULT NULL,
            by_id   TEXT    DEFAULT NULL,
            at      TEXT    NOT NULL
        );
        CREATE TABLE IF NOT EXISTS tickets (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    TEXT    NOT NULL,
            channel_id TEXT    NOT NULL,
            category   TEXT    DEFAULT 'General',
            status     TEXT    DEFAULT 'open',
            created_at TEXT    NOT NULL,
            closed_at  TEXT    DEFAULT NULL,
            closed_by  TEXT    DEFAULT NULL,
            topic      TEXT    DEFAULT NULL
        );
        CREATE TABLE IF NOT EXISTS claim_requests (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id       TEXT    NOT NULL,
            plan_name     TEXT    NOT NULL,
            plan_type     TEXT    NOT NULL,
            ram_gb        INTEGER NOT NULL,
            cpu_cores     INTEGER NOT NULL,
            disk_gb       INTEGER NOT NULL,
            validity_days INTEGER DEFAULT NULL,
            proof_url     TEXT,
            status        TEXT    DEFAULT 'pending',
            created_at    TEXT    NOT NULL,
            handled_by    TEXT    DEFAULT NULL,
            cancel_reason TEXT    DEFAULT NULL
        );
        CREATE TABLE IF NOT EXISTS invite_tracking (
            inviter_id TEXT    NOT NULL,
            invitee_id TEXT    NOT NULL,
            joined_at  TEXT    NOT NULL,
            left_at    TEXT    DEFAULT NULL,
            valid      INTEGER DEFAULT 1,
            PRIMARY KEY (inviter_id, invitee_id)
        );
        CREATE TABLE IF NOT EXISTS af2f_pending (
            user_id    TEXT PRIMARY KEY,
            code       TEXT NOT NULL,
            cmd        TEXT NOT NULL,
            args       TEXT DEFAULT '{}',
            created_at TEXT NOT NULL,
            expires_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS dm_settings (
            key   TEXT PRIMARY KEY,
            value TEXT
        );
        CREATE TABLE IF NOT EXISTS vps_expiry_overrides (
            container_name TEXT PRIMARY KEY,
            expiry         TEXT,
            set_by         TEXT,
            set_at         TEXT
        );
        CREATE TABLE IF NOT EXISTS nodes (
            name      TEXT PRIMARY KEY,
            runtime   TEXT    DEFAULT 'incus',
            api_key   TEXT    DEFAULT NULL,
            added_by  TEXT    DEFAULT NULL,
            added_at  TEXT    DEFAULT NULL,
            last_seen TEXT    DEFAULT NULL,
            online    INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS giveaways (
            id          TEXT    PRIMARY KEY,
            channel_id  TEXT    NOT NULL,
            message_id  TEXT    DEFAULT NULL,
            message_url TEXT    DEFAULT NULL,
            prize       TEXT    NOT NULL,
            end_time    TEXT    NOT NULL,
            created_by  TEXT    NOT NULL,
            status      TEXT    DEFAULT 'active',
            winner_id   TEXT    DEFAULT NULL,
            entries     TEXT    DEFAULT '[]',
            created_at  TEXT    NOT NULL
        );
        CREATE TABLE IF NOT EXISTS vps_snapshots (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id        TEXT    NOT NULL,
            container_name TEXT    NOT NULL,
            snapshot_name  TEXT    NOT NULL,
            node           TEXT    DEFAULT 'local',
            created_at     TEXT    NOT NULL,
            created_by     TEXT    DEFAULT NULL,
            size_mb        INTEGER DEFAULT NULL,
            note           TEXT    DEFAULT NULL,
            UNIQUE (container_name, snapshot_name)
        );
        CREATE TABLE IF NOT EXISTS blocked_commands (
            cmd      TEXT PRIMARY KEY,
            added_by TEXT,
            added_at TEXT
        );
    """)

    # ── Safe column migrations ────────────────────────────────────────────────
    _migrate(cur, "users", [
        ("mooncoin",        "INTEGER DEFAULT 0"),
        ("tier",            "TEXT DEFAULT NULL"),
        ("vps_limit",       "INTEGER DEFAULT 0"),
        ("invites_used",    "INTEGER DEFAULT 0"),
        ("invite_count",    "INTEGER DEFAULT 0"),
        ("last_chat_coin",  "TEXT DEFAULT NULL"),
        ("total_referrals", "INTEGER DEFAULT 0"),
        ("referred_by",     "TEXT DEFAULT NULL"),
        ("joined_at",       "TEXT DEFAULT NULL"),
        ("last_seen",       "TEXT DEFAULT NULL"),
    ])
    _migrate(cur, "vps_entries", [
        ("ip_address",    "TEXT DEFAULT NULL"),
        ("password",      "TEXT DEFAULT NULL"),
        ("plan_name",     "TEXT DEFAULT NULL"),
        ("plan_type",     "TEXT DEFAULT NULL"),
        ("renewal_count", "INTEGER DEFAULT 0"),
        ("last_renewed",  "TEXT DEFAULT NULL"),
        ("extra",         "TEXT DEFAULT '{}'"),
    ])
    _migrate(cur, "admins",        [("pin", "TEXT DEFAULT '0000'")])
    _migrate(cur, "marketplace",   [("validity", "TEXT"), ("description", "TEXT")])
    _migrate(cur, "claim_requests",[("cancel_reason", "TEXT DEFAULT NULL"), ("handled_by", "TEXT DEFAULT NULL")])
    _migrate(cur, "giveaways",     [("entries", "TEXT DEFAULT '[]'"), ("winner_id", "TEXT DEFAULT NULL"), ("message_id", "TEXT DEFAULT NULL")])

    conn.commit()

    # ── Default mooncoin rules ────────────────────────────────────────────────
    cur.execute("SELECT COUNT(*) as cnt FROM mooncoin_rules")
    if cur.fetchone()["cnt"] == 0:
        cur.executemany(
            "INSERT OR IGNORE INTO mooncoin_rules (name,amount,cooldown) VALUES (?,?,?)",
            [("invite", 5, 0), ("chat", 1, 300), ("giveaway", 3, 0), ("event", 7, 0)],
        )
        conn.commit()

    # ── Seed local node ───────────────────────────────────────────────────────
    cur.execute(
        "INSERT OR IGNORE INTO nodes (name,runtime,added_at) VALUES (?,?,?)",
        ("local", "local", datetime.now().isoformat()),
    )
    conn.commit()

    # ── Migrate registered_nodes CSV → nodes table ────────────────────────────
    _migrate_nodes_from_settings(cur, conn)

    # ── Indexes ───────────────────────────────────────────────────────────────
    cur.executescript("""
        CREATE INDEX IF NOT EXISTS idx_vps_user         ON vps_entries(user_id);
        CREATE INDEX IF NOT EXISTS idx_vps_status       ON vps_entries(status);
        CREATE INDEX IF NOT EXISTS idx_vps_expiry       ON vps_entries(expiry);
        CREATE INDEX IF NOT EXISTS idx_vps_node         ON vps_entries(node);
        CREATE INDEX IF NOT EXISTS idx_vps_name         ON vps_entries(container_name);
        CREATE INDEX IF NOT EXISTS idx_vps_suspended    ON vps_entries(suspended);
        CREATE INDEX IF NOT EXISTS idx_users_tier       ON users(tier);
        CREATE INDEX IF NOT EXISTS idx_users_coin       ON users(mooncoin);
        CREATE INDEX IF NOT EXISTS idx_admins_role      ON admins(role);
        CREATE INDEX IF NOT EXISTS idx_af2f_expires     ON af2f_pending(expires_at);
        CREATE INDEX IF NOT EXISTS idx_market_active    ON marketplace(active, seller_id);
        CREATE INDEX IF NOT EXISTS idx_market_name      ON marketplace(sell_name);
        CREATE INDEX IF NOT EXISTS idx_claim_status     ON claim_requests(status, user_id);
        CREATE INDEX IF NOT EXISTS idx_claim_user       ON claim_requests(user_id);
        CREATE INDEX IF NOT EXISTS idx_warnings_user    ON warnings(user_id);
        CREATE INDEX IF NOT EXISTS idx_notes_user       ON staff_notes(user_id);
        CREATE INDEX IF NOT EXISTS idx_ledger_user      ON coin_ledger(user_id);
        CREATE INDEX IF NOT EXISTS idx_ledger_at        ON coin_ledger(at);
        CREATE INDEX IF NOT EXISTS idx_invite_inviter   ON invite_tracking(inviter_id, valid);
        CREATE INDEX IF NOT EXISTS idx_invite_invitee   ON invite_tracking(invitee_id);
        CREATE INDEX IF NOT EXISTS idx_snap_container   ON vps_snapshots(container_name);
        CREATE INDEX IF NOT EXISTS idx_snap_user        ON vps_snapshots(user_id);
        CREATE INDEX IF NOT EXISTS idx_tickets_user     ON tickets(user_id, status);
        CREATE INDEX IF NOT EXISTS idx_tickets_channel  ON tickets(channel_id);
        CREATE INDEX IF NOT EXISTS idx_giveaway_status  ON giveaways(status);
    """)
    conn.commit()
    logger.info(f"Database ready: {DB_PATH}")


def _migrate(cur, table: str, columns: list):
    """Add new columns to an existing table. Never removes or changes existing columns."""
    cur.execute(f"PRAGMA table_info({table})")
    existing = {row["name"] for row in cur.fetchall()}
    for col_name, col_def in columns:
        if col_name not in existing:
            try:
                cur.execute(f"ALTER TABLE {table} ADD COLUMN {col_name} {col_def}")
                logger.info(f"DB migration: added {col_name} to {table}")
            except Exception as e:
                logger.warning(f"Migration skipped {table}.{col_name}: {e}")


def _migrate_nodes_from_settings(cur, conn):
    """Move registered_nodes CSV from settings into the nodes table (one-time)."""
    try:
        cur.execute("SELECT value FROM settings WHERE key='registered_nodes'")
        row = cur.fetchone()
        if not row or not row["value"]:
            return
        names = [n.strip() for n in row["value"].split(",") if n.strip()]
        for name in names:
            cur.execute(
                "INSERT OR IGNORE INTO nodes (name,runtime,added_at,online) VALUES (?,?,?,1)",
                (name, "incus", datetime.now().isoformat()),
            )
        cur.execute("DELETE FROM settings WHERE key='registered_nodes'")
        conn.commit()
        logger.info(f"Migrated {len(names)} node(s) from settings to nodes table")
    except Exception as e:
        logger.debug(f"Node migration skipped: {e}")


# ── JSON helper ───────────────────────────────────────────────────────────────

def _j(val, default):
    if val is None: return default
    try: return json.loads(val)
    except Exception: return default


# ── Columns that have dedicated fields in vps_entries ────────────────────────
_VPS_KNOWN_COLS = frozenset({
    "container_name", "ram", "cpu", "storage", "config", "os_version",
    "status", "suspended", "whitelisted", "node", "created_at", "expiry",
    "shared_with", "suspension_history", "ip_address", "password",
    "plan_name", "plan_type", "renewal_count", "last_renewed", "id",
})


# ── VPS load ──────────────────────────────────────────────────────────────────

def load_vps_data():
    conn = get_db()
    cur  = conn.cursor()

    cur.execute("SELECT COUNT(*) as cnt FROM vps_entries")
    count = cur.fetchone()["cnt"]

    if count == 0 and os.path.exists(_LEGACY_VPS_JSON):
        _migrate_json_to_db()
        cur.execute("SELECT COUNT(*) as cnt FROM vps_entries")
        count = cur.fetchone()["cnt"]

    cur.execute("""
        SELECT user_id, vps_index,
               container_name, ram, cpu, storage, config, os_version,
               status, suspended, whitelisted, node, created_at, expiry,
               shared_with, suspension_history,
               ip_address, password, plan_name, plan_type,
               renewal_count, last_renewed, extra
        FROM vps_entries
        ORDER BY user_id, vps_index
    """)
    vps_data.clear()
    for r in cur.fetchall():
        uid   = r["user_id"]
        entry = {
            "container_name":     r["container_name"],
            "ram":                r["ram"],
            "cpu":                r["cpu"],
            "storage":            r["storage"],
            "config":             r["config"],
            "os_version":         r["os_version"],
            "status":             r["status"] or "stopped",
            "suspended":          bool(r["suspended"]),
            "whitelisted":        bool(r["whitelisted"]),
            "node":               r["node"] or "local",
            "created_at":         r["created_at"],
            "expiry":             r["expiry"],
            "shared_with":        _j(r["shared_with"], []),
            "suspension_history": _j(r["suspension_history"], []),
            "ip_address":         r["ip_address"],
            "password":           r["password"],
            "plan_name":          r["plan_name"],
            "plan_type":          r["plan_type"],
            "renewal_count":      r["renewal_count"] or 0,
            "last_renewed":       r["last_renewed"],
            "id":                 None,
        }
        extra = _j(r["extra"], {})
        if extra:
            entry.update(extra)
        vps_data.setdefault(uid, []).append(entry)

    logger.info(f"Loaded {count} VPS record(s) from system.db")


def _migrate_json_to_db():
    try:
        with open(_LEGACY_VPS_JSON) as f:
            data = json.load(f)
        conn = get_db(); cur = conn.cursor(); n = 0
        for uid, lst in data.items():
            for idx, v in enumerate(lst):
                extra = {k: val for k, val in v.items() if k not in _VPS_KNOWN_COLS}
                cur.execute(
                    "INSERT OR IGNORE INTO vps_entries "
                    "(user_id,vps_index,container_name,ram,cpu,storage,config,os_version,"
                    "status,suspended,whitelisted,node,created_at,expiry,shared_with,suspension_history,extra) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (uid, idx, v.get("container_name",""), v.get("ram",""), v.get("cpu",""),
                     v.get("storage",""), v.get("config",""), v.get("os_version",""),
                     v.get("status","stopped"), int(v.get("suspended",False)),
                     int(v.get("whitelisted",False)), v.get("node","local"),
                     v.get("created_at",""), v.get("expiry"),
                     json.dumps(v.get("shared_with",[])),
                     json.dumps(v.get("suspension_history",[])),
                     json.dumps(extra) if extra else "{}"),
                )
                n += 1
        conn.commit()
        logger.info(f"Migrated {n} VPS record(s) from vps_data.json")
        os.rename(_LEGACY_VPS_JSON, _LEGACY_VPS_JSON + ".migrated")
    except Exception as e:
        logger.error(f"JSON migration failed: {e}")


# ── VPS save ──────────────────────────────────────────────────────────────────

def save_vps_data():
    """
    Atomic sync of in-memory vps_data → system.db.
    Uses a single transaction — either all rows are written or none are.
    """
    try:
        conn = get_db()
        with conn:   # BEGIN / COMMIT (or ROLLBACK on exception)
            cur = conn.cursor()

            # Remove rows that no longer exist in memory
            current_keys = {
                (uid, idx)
                for uid, lst in vps_data.items()
                for idx in range(len(lst))
            }
            cur.execute("SELECT user_id, vps_index FROM vps_entries")
            for r in cur.fetchall():
                if (r["user_id"], r["vps_index"]) not in current_keys:
                    cur.execute(
                        "DELETE FROM vps_entries WHERE user_id=? AND vps_index=?",
                        (r["user_id"], r["vps_index"]),
                    )

            # Upsert every current entry
            for uid, lst in vps_data.items():
                for idx, v in enumerate(lst):
                    extra = {k: val for k, val in v.items() if k not in _VPS_KNOWN_COLS}
                    cur.execute(
                        """
                        INSERT INTO vps_entries
                            (user_id,vps_index,container_name,ram,cpu,storage,config,os_version,
                             status,suspended,whitelisted,node,created_at,expiry,
                             shared_with,suspension_history,
                             ip_address,password,plan_name,plan_type,
                             renewal_count,last_renewed,extra)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                        ON CONFLICT(user_id,vps_index) DO UPDATE SET
                            container_name=excluded.container_name, ram=excluded.ram,
                            cpu=excluded.cpu, storage=excluded.storage,
                            config=excluded.config, os_version=excluded.os_version,
                            status=excluded.status, suspended=excluded.suspended,
                            whitelisted=excluded.whitelisted, node=excluded.node,
                            created_at=excluded.created_at, expiry=excluded.expiry,
                            shared_with=excluded.shared_with,
                            suspension_history=excluded.suspension_history,
                            ip_address=excluded.ip_address, password=excluded.password,
                            plan_name=excluded.plan_name, plan_type=excluded.plan_type,
                            renewal_count=excluded.renewal_count,
                            last_renewed=excluded.last_renewed, extra=excluded.extra
                        """,
                        (uid, idx,
                         v.get("container_name",""), v.get("ram",""), v.get("cpu",""),
                         v.get("storage",""), v.get("config",""), v.get("os_version",""),
                         v.get("status","stopped"),
                         int(bool(v.get("suspended",False))),
                         int(bool(v.get("whitelisted",False))),
                         v.get("node","local"), v.get("created_at",""), v.get("expiry"),
                         json.dumps(v.get("shared_with",[])),
                         json.dumps(v.get("suspension_history",[])),
                         v.get("ip_address"), v.get("password"),
                         v.get("plan_name"), v.get("plan_type"),
                         int(v.get("renewal_count",0)), v.get("last_renewed"),
                         json.dumps(extra) if extra else "{}"),
                    )
        global _last_save_time
        _last_save_time = time.monotonic()
    except Exception as e:
        logger.error(f"save_vps_data failed: {e}", exc_info=True)


async def async_save_vps_data():
    """Debounced async wrapper — collapses rapid calls into one write."""
    global _pending_save
    if _pending_save:
        return
    _pending_save = True

    async def _do():
        global _pending_save
        await asyncio.sleep(_SAVE_DEBOUNCE_S)
        _pending_save = False
        await asyncio.get_event_loop().run_in_executor(None, save_vps_data)

    asyncio.get_event_loop().create_task(_do())


# ── Admin data ────────────────────────────────────────────────────────────────

def load_admin_data():
    if os.path.exists(_LEGACY_ADM_JSON):
        try:
            with open(_LEGACY_ADM_JSON) as f:
                loaded = json.load(f)
            admin_data.clear(); admin_data.update(loaded)
            conn = get_db(); cur = conn.cursor()
            for uid, role in loaded.items():
                cur.execute("INSERT OR REPLACE INTO admins (user_id,role) VALUES (?,?)", (uid, role))
            conn.commit()
            os.rename(_LEGACY_ADM_JSON, _LEGACY_ADM_JSON + ".migrated")
            return
        except Exception: pass
    try:
        conn = get_db(); cur = conn.cursor()
        cur.execute("SELECT user_id, role FROM admins")
        for r in cur.fetchall():
            admin_data[r["user_id"]] = r["role"]
    except Exception as e:
        logger.error(f"load_admin_data: {e}")


def save_admin_data():
    try:
        conn = get_db(); cur = conn.cursor()
        for uid, role in admin_data.items():
            cur.execute("INSERT OR REPLACE INTO admins (user_id,role) VALUES (?,?)", (uid, role))
        conn.commit()
    except Exception as e:
        logger.error(f"save_admin_data: {e}")


# ── Settings ──────────────────────────────────────────────────────────────────

def get_setting(key: str) -> Optional[str]:
    try:
        cur = get_db().cursor()
        cur.execute("SELECT value FROM settings WHERE key=?", (key,))
        row = cur.fetchone()
        return row["value"] if row else None
    except Exception as e:
        logger.error(f"get_setting({key}): {e}")
        return None


def set_setting(key: str, value: str):
    try:
        conn = get_db()
        conn.execute("INSERT OR REPLACE INTO settings (key,value) VALUES (?,?)", (key, value))
        conn.commit()
    except Exception as e:
        logger.error(f"set_setting({key}): {e}")


def get_all_settings() -> dict:
    try:
        cur = get_db().cursor()
        cur.execute("SELECT key, value FROM settings")
        return {r["key"]: r["value"] for r in cur.fetchall()}
    except Exception:
        return {}


# ── Nodes ─────────────────────────────────────────────────────────────────────

def get_nodes() -> list:
    """Return list of online node names. 'local' is always first."""
    try:
        cur = get_db().cursor()
        cur.execute("SELECT name FROM nodes WHERE online=1 ORDER BY name")
        names = [r["name"] for r in cur.fetchall()]
        if "local" in names: names.remove("local")
        return ["local"] + names
    except Exception:
        return ["local"]


def save_node(name: str, runtime: str = "incus", api_key: str = None, added_by: str = None):
    try:
        conn = get_db()
        conn.execute(
            "INSERT OR REPLACE INTO nodes (name,runtime,api_key,added_by,added_at,online) VALUES (?,?,?,?,?,1)",
            (name, runtime, api_key, added_by, datetime.now().isoformat()),
        )
        conn.commit()
    except Exception as e:
        logger.error(f"save_node({name}): {e}")


def remove_node(name: str):
    if name == "local": return
    try:
        conn = get_db()
        conn.execute("UPDATE nodes SET online=0 WHERE name=?", (name,))
        conn.commit()
    except Exception as e:
        logger.error(f"remove_node({name}): {e}")


# ── Payments ──────────────────────────────────────────────────────────────────

def get_payments() -> list:
    try:
        cur = get_db().cursor()
        cur.execute("SELECT * FROM payments")
        return [dict(r) for r in cur.fetchall()]
    except Exception: return []


# ── Helpers ───────────────────────────────────────────────────────────────────

def is_admin_check(user_id: int, main_admin_id: int) -> bool:
    if int(user_id) == int(main_admin_id): return True
    return admin_data.get(str(user_id), "") in ("Owner", "Admin", "Dev", "Hard Admin")


def get_coins(uid: str) -> int:
    try:
        cur = get_db().cursor()
        cur.execute("SELECT mooncoin FROM users WHERE user_id=?", (uid,))
        row = cur.fetchone()
        return row["mooncoin"] if row else 0
    except Exception: return 0


def add_coins(uid: str, amount: int, reason: str = None, by_id: str = None):
    """Add/subtract MoonCoins. Writes an audit record to coin_ledger. Balance never < 0."""
    try:
        conn = get_db()
        conn.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (uid,))
        conn.execute(
            "UPDATE users SET mooncoin = MAX(0, mooncoin + ?) WHERE user_id=?",
            (amount, uid),
        )
        row = conn.execute("SELECT mooncoin FROM users WHERE user_id=?", (uid,)).fetchone()
        balance = row["mooncoin"] if row else 0
        conn.execute(
            "INSERT INTO coin_ledger (user_id,delta,balance,reason,by_id,at) VALUES (?,?,?,?,?,?)",
            (uid, amount, balance, reason, by_id, datetime.now().isoformat()),
        )
        conn.commit()
    except Exception as e:
        logger.error(f"add_coins({uid},{amount}): {e}")


def get_invite_count(uid: str) -> int:
    try:
        cur = get_db().cursor()
        cur.execute("SELECT COUNT(*) as cnt FROM invite_tracking WHERE inviter_id=? AND valid=1", (uid,))
        row = cur.fetchone()
        return row["cnt"] if row else 0
    except Exception: return 0


def get_blocked_commands() -> list:
    try:
        cur = get_db().cursor()
        cur.execute("SELECT cmd FROM blocked_commands")
        return [r["cmd"] for r in cur.fetchall()]
    except Exception: return []


# ── Giveaway helpers ──────────────────────────────────────────────────────────

def save_giveaway(g_id: str, data: dict):
    """Persist a giveaway so it survives bot restarts."""
    try:
        conn = get_db()
        conn.execute(
            """INSERT OR REPLACE INTO giveaways
               (id,channel_id,message_id,message_url,prize,end_time,
                created_by,status,winner_id,entries,created_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
            (g_id, data.get("channel_id",""), data.get("message_id"),
             data.get("msg"), data.get("prize","VPS"), data.get("end",""),
             data.get("created_by",""), data.get("status","active"),
             data.get("winner_id"), json.dumps(data.get("entries",[])),
             data.get("created_at", datetime.now().isoformat())),
        )
        conn.commit()
    except Exception as e:
        logger.error(f"save_giveaway({g_id}): {e}")


def end_giveaway(g_id: str, winner_id: str = None):
    try:
        conn = get_db()
        conn.execute(
            "UPDATE giveaways SET status='ended', winner_id=? WHERE id=?",
            (winner_id, g_id),
        )
        conn.commit()
    except Exception as e:
        logger.error(f"end_giveaway({g_id}): {e}")


# ── Snapshot helpers ──────────────────────────────────────────────────────────

def save_snapshot(user_id: str, container_name: str, snapshot_name: str,
                  node: str = "local", created_by: str = None,
                  size_mb: int = None, note: str = None):
    try:
        conn = get_db()
        conn.execute(
            "INSERT OR IGNORE INTO vps_snapshots "
            "(user_id,container_name,snapshot_name,node,created_at,created_by,size_mb,note) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (user_id, container_name, snapshot_name, node,
             datetime.now().isoformat(), created_by, size_mb, note),
        )
        conn.commit()
    except Exception as e:
        logger.error(f"save_snapshot({container_name}/{snapshot_name}): {e}")


def get_snapshots(container_name: str) -> list:
    try:
        cur = get_db().cursor()
        cur.execute(
            "SELECT * FROM vps_snapshots WHERE container_name=? ORDER BY created_at DESC",
            (container_name,),
        )
        return [dict(r) for r in cur.fetchall()]
    except Exception: return []


def delete_snapshot_record(container_name: str, snapshot_name: str):
    try:
        conn = get_db()
        conn.execute(
            "DELETE FROM vps_snapshots WHERE container_name=? AND snapshot_name=?",
            (container_name, snapshot_name),
        )
        conn.commit()
    except Exception as e:
        logger.error(f"delete_snapshot_record: {e}")


# ── Ticket helpers ────────────────────────────────────────────────────────────

def open_ticket(user_id: str, channel_id: str, category: str = "General", topic: str = None):
    try:
        conn = get_db()
        conn.execute(
            "INSERT OR IGNORE INTO tickets (user_id,channel_id,category,topic,created_at) VALUES (?,?,?,?,?)",
            (user_id, channel_id, category, topic, datetime.now().isoformat()),
        )
        conn.commit()
    except Exception as e:
        logger.error(f"open_ticket: {e}")


def close_ticket(channel_id: str, closed_by: str, status: str = "closed"):
    try:
        conn = get_db()
        conn.execute(
            "UPDATE tickets SET status=?, closed_at=?, closed_by=? WHERE channel_id=?",
            (status, datetime.now().isoformat(), closed_by, channel_id),
        )
        conn.commit()
    except Exception as e:
        logger.error(f"close_ticket: {e}")


# ── WAL checkpoint ────────────────────────────────────────────────────────────

def checkpoint_db():
    """Run a WAL checkpoint to reclaim disk space. Call every ~30 min from a background task."""
    try:
        get_db().execute("PRAGMA wal_checkpoint(INCREMENTAL)")
    except Exception as e:
        logger.debug(f"WAL checkpoint: {e}")
