"""
core/incus.py — Incus container operations backend.

Key fixes in this version:
  - "No root device" error: always attach root disk device with explicit pool
    during init via --device flag (not after the fact)
  - snapshot syntax: Incus ≥0.5 uses `incus snapshot create <container> <name>`
    not the old `incus snapshot <container> <name>`
  - strip double-colon on node prefix
  - name sanitisation enforced
  - cgroup2/BPF fix via raw.lxc
"""

import asyncio
import re
import shlex
import subprocess
import logging
from typing import Optional

logger = logging.getLogger("moonnodes_vps_bot")

BINARY = "incus"


# ── Image alias normalisation ─────────────────────────────────────────────────

def normalize_image(image: str) -> str:
    m = re.match(r"^ubuntu:(\d+\.\d+)$", image)
    if m: return f"images:ubuntu/{m.group(1)}"
    m = re.match(r"^ubuntu-daily:(\d+\.\d+)$", image)
    if m: return f"images:ubuntu/{m.group(1)}/daily"
    return image


# ── Command execution ─────────────────────────────────────────────────────────

def _normalise_cmd(command: str) -> str:
    """Rewrite lxc/lxd prefix to the active binary."""
    for prefix in ("incus ", "lxc ", "lxd "):
        if command.startswith(prefix):
            return BINARY + " " + command[len(prefix):]
    if not command.startswith(BINARY):
        return f"{BINARY} {command}"
    return command


async def run(command: str, timeout: int = 120):
    command = _normalise_cmd(command)
    # strip legacy -c flag and normalise --format spacing
    command = re.sub(r"\s+-c\s+[\w,]+", "", command)
    command = re.sub(r"--format\s+(\w+)", r"--format=\1", command).strip()
    logger.info(f"[incus] {command}")
    parts = shlex.split(command)
    try:
        proc = await asyncio.create_subprocess_exec(
            *parts,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        try: proc.kill(); await proc.wait()
        except Exception: pass
        raise asyncio.TimeoutError(f"incus timed out ({timeout}s): {command}")

    out = stdout.decode().strip() if stdout else ""
    err = stderr.decode().strip() if stderr else ""

    if proc.returncode != 0:
        msg = err or out or "Command failed"
        logger.error(f"[incus] FAILED: {msg}")
        raise Exception(msg)
    return out if out else True


# ── Remote listing ────────────────────────────────────────────────────────────

BUILTIN_REMOTES = {"local", "images", "ubuntu", "ubuntu-daily", "ubuntu-minimal", ""}

async def list_remotes() -> list:
    try:
        r = subprocess.run(
            [BINARY, "remote", "list", "--format=csv"],
            capture_output=True, text=True, timeout=10,
        )
        remotes = []
        for line in r.stdout.strip().splitlines():
            raw   = line.split(",")[0].strip()
            clean = re.sub(r"\s*\(.*?\)", "", raw).strip().rstrip("*").strip()
            if clean and clean not in BUILTIN_REMOTES:
                remotes.append(clean)
        return remotes
    except Exception as e:
        logger.warning(f"incus list_remotes failed: {e}")
        return []


# ── Storage pool detection ────────────────────────────────────────────────────

def detect_storage_pool(default: Optional[str] = None) -> str:
    if default and default not in ("", "default"): return default
    try:
        r = subprocess.run(
            [BINARY, "storage", "list", "--format=csv"],
            capture_output=True, text=True, timeout=10,
        )
        for line in r.stdout.strip().splitlines():
            name = line.split(",")[0].strip()
            if name and name not in ("", "NAME"):
                logger.info(f"[incus] Auto-detected storage pool: {name!r}")
                return name
    except Exception as e:
        logger.error(f"incus pool detect failed: {e}")
    return "default"


# ── Snapshot helpers (Incus ≥0.5 uses subcommand syntax) ─────────────────────

async def snapshot_create(container: str, snap_name: str, node: str = "local") -> str:
    """
    Create a snapshot.
    Incus ≥0.5: incus snapshot create <container> <name>
    Falls back to old syntax if subcommand fails.
    """
    prefix = f"{node}:" if node and node != "local" else ""
    full   = f"{prefix}{container}"
    try:
        await run(f"incus snapshot create {full} {snap_name}", timeout=60)
    except Exception as e:
        if "unknown command" in str(e).lower() or "unknown subcommand" in str(e).lower():
            # Old Incus / LXD fallback
            await run(f"incus snapshot {full} {snap_name}", timeout=60)
        else:
            raise
    return snap_name


async def snapshot_list(container: str, node: str = "local") -> list:
    """Return list of snapshot names for a container."""
    prefix = f"{node}:" if node and node != "local" else ""
    full   = f"{prefix}{container}"
    try:
        out = await run(f"incus info {full}")
        if out and out is not True:
            snaps = [l.strip() for l in str(out).splitlines() if "backup-" in l]
            return snaps
    except Exception: pass
    return []


async def snapshot_restore(container: str, snap_name: str, node: str = "local"):
    """Restore a named snapshot."""
    prefix = f"{node}:" if node and node != "local" else ""
    full   = f"{prefix}{container}"
    try:
        await run(f"incus snapshot restore {full} {snap_name}", timeout=120)
    except Exception as e:
        if "unknown command" in str(e).lower():
            await run(f"incus restore {full} {snap_name}", timeout=120)
        else:
            raise


# ── Host resource stats ───────────────────────────────────────────────────────

def host_cpu_pct() -> float:
    try:
        r = subprocess.run(["top", "-bn1"], capture_output=True, text=True, timeout=5)
        for line in r.stdout.splitlines():
            if "Cpu" in line:
                m = re.search(r"(\d+\.?\d*)\s*id", line)
                if m: return round(100.0 - float(m.group(1)), 1)
    except Exception: pass
    return 0.0

def host_cpu_cores() -> int:
    try:
        r = subprocess.run(["nproc"], capture_output=True, text=True, timeout=5)
        return int(r.stdout.strip())
    except Exception: return 1

def host_ram() -> tuple:
    try:
        r = subprocess.run(["free", "-m"], capture_output=True, text=True, timeout=5)
        for line in r.stdout.splitlines():
            if line.startswith("Mem:"):
                p = line.split()
                return int(p[2]), int(p[1])
    except Exception: pass
    return 0, 0

def host_disk() -> tuple:
    try:
        r = subprocess.run(["df", "-BG", "/"], capture_output=True, text=True, timeout=5)
        for line in r.stdout.splitlines()[1:]:
            p = line.split()
            if len(p) >= 5:
                return int(p[2].replace("G","")), int(p[1].replace("G",""))
    except Exception: pass
    return 0, 0


# ── Container stats ───────────────────────────────────────────────────────────

async def container_status(name: str, node: str = "local") -> str:
    node   = (node or "local").strip().rstrip(":") or "local"
    prefix = f"{node}:" if node != "local" else ""
    try:
        out = await run(f"incus list {prefix}{name} --format=csv")
        if out and out is not True:
            for line in str(out).splitlines():
                if name in line:
                    p = line.split(",")
                    return p[1].strip().lower() if len(p) > 1 else "unknown"
    except Exception: pass
    return "unknown"

async def container_cpu_pct(name: str, node: str = "local") -> float:
    node   = (node or "local").strip().rstrip(":") or "local"
    prefix = f"{node}:" if node != "local" else ""
    try:
        out = await run(f"incus exec {prefix}{name} -- top -bn1")
        if out and out is not True:
            for line in str(out).splitlines():
                if "Cpu" in line:
                    m = re.search(r"(\d+\.?\d*)\s*id", line)
                    if m: return round(100.0 - float(m.group(1)), 1)
    except Exception: pass
    return 0.0

async def container_memory(name: str, node: str = "local") -> str:
    node   = (node or "local").strip().rstrip(":") or "local"
    prefix = f"{node}:" if node != "local" else ""
    try:
        out = await run(f"incus exec {prefix}{name} -- free -m")
        if out and out is not True:
            for line in str(out).splitlines():
                if line.startswith("Mem:"):
                    p = line.split()
                    total = int(p[1]); used = int(p[2])
                    pct   = round(used / total * 100, 1) if total else 0
                    return f"{used}/{total} MB ({pct}%)"
    except Exception: pass
    return "N/A"

async def container_disk(name: str, node: str = "local") -> str:
    node   = (node or "local").strip().rstrip(":") or "local"
    prefix = f"{node}:" if node != "local" else ""
    try:
        out = await run(f"incus exec {prefix}{name} -- df -h /")
        if out and out is not True:
            for line in str(out).splitlines()[1:]:
                p = line.split()
                if len(p) >= 5:
                    return f"{p[2]}/{p[1]} ({p[4]})"
    except Exception: pass
    return "N/A"

async def container_uptime(name: str, node: str = "local") -> str:
    node   = (node or "local").strip().rstrip(":") or "local"
    prefix = f"{node}:" if node != "local" else ""
    try:
        out = await run(f"incus exec {prefix}{name} -- uptime -p")
        return str(out).strip() if out and out is not True else "N/A"
    except Exception: return "N/A"


# ── Deployment ────────────────────────────────────────────────────────────────

async def deploy(
    container_name: str,
    os_image: str,
    ram_gb: int,
    cpu: int,
    disk_gb: int,
    storage_pool: str = "default",
    node: str = "local",
) -> None:
    """
    Create, configure, and start an Incus container.

    Root-device fix: Incus requires a storage pool to be attached at init time
    via --device, OR the profile must have a root disk device already.
    We detect the actual pool and pass it as a --device flag during `incus init`
    so we never hit "No root device could be found".
    """
    node      = (node or "local").strip().rstrip(":").strip() or "local"
    prefix    = f"{node}:" if node != "local" else ""
    image     = normalize_image(os_image)

    # Always detect real pool — never rely on caller's "default" string
    pool = detect_storage_pool(storage_pool)

    # Sanitise name: Incus only allows [a-z0-9-], no leading/trailing hyphen
    safe_name = re.sub(r"[^a-z0-9-]", "-", container_name.lower())
    safe_name = re.sub(r"-{2,}", "-", safe_name).strip("-") or "vps-1"

    logger.info(
        f"[incus.deploy] node={node!r} prefix={prefix!r} "
        f"container={safe_name!r} image={image!r} pool={pool!r} "
        f"ram={ram_gb}GB cpu={cpu} disk={disk_gb}GB"
    )

    # ── Init — basic container creation ───────────────────────────────────────
    # NOTE: --device inline flag is broken in many Incus versions.
    # We init WITHOUT --device, then attach root disk via `incus config device add`.
    await run(
        f"incus init {image} {prefix}{safe_name}"
        f" --config security.privileged=true"
        f" --config security.nesting=true",
        timeout=300,
    )

    # ── Root disk device — must be added BEFORE start ────────────────────────
    # This is the correct two-step approach for all Incus versions.
    try:
        await run(
            f"incus config device add {prefix}{safe_name} root disk"
            f" path=/ pool={pool} size={disk_gb}GB"
        )
        logger.info(f"[incus.deploy] Root disk attached: pool={pool} size={disk_gb}GB")
    except Exception as e:
        logger.warning(f"[incus.deploy] root disk non-fatal (may already exist): {e}")

    # ── Resource limits ───────────────────────────────────────────────────────
    await run(f"incus config set {prefix}{safe_name} limits.memory {ram_gb * 1024}MB")
    await run(f"incus config set {prefix}{safe_name} limits.cpu {cpu}")

    # ── Docker / kernel compat ────────────────────────────────────────────────
    for cfg_key in [
        "security.syscalls.intercept.mknod true",
        "linux.kernel_modules overlay,loop,nf_nat,ip_tables,ip6_tables",
    ]:
        try:
            await run(f"incus config set {prefix}{safe_name} {cfg_key}")
        except Exception as e:
            logger.warning(f"[incus.deploy] non-fatal config: {e}")

    # ── BPF/cgroup2 fix — suppresses lxc.log "Failed to load bpf program" ───
    try:
        await run(
            f'incus config set {prefix}{safe_name} raw.lxc '
            f'"lxc.cgroup2.devices.allow = a"'
        )
    except Exception as e:
        logger.warning(f"[incus.deploy] cgroup2 raw.lxc non-fatal: {e}")

    # ── Network device — auto-add if no eth0 configured ─────────────────────
    for bridge in ("incusbr0", "lxdbr0", "virbr0", "br0"):
        try:
            r = subprocess.run(["ip","link","show", bridge],
                capture_output=True, text=True, timeout=5)
            if r.returncode == 0:
                await run(
                    f"incus config device add {prefix}{safe_name} eth0 nic "
                    f"nictype=bridged parent={bridge} name=eth0"
                )
                logger.info(f"[incus.deploy] Network eth0 → {bridge}")
                break
        except Exception as ne:
            logger.debug(f"[incus.deploy] bridge {bridge} check: {ne}")

    # ── Start ─────────────────────────────────────────────────────────────────
    await run(f"incus start {prefix}{safe_name}", timeout=60)
