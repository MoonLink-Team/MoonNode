"""
core/incus.py — Incus-specific container operations.

Key Incus differences vs LXD:
  - OS images: use `images:ubuntu/22.04` not `ubuntu:22.04`
  - Remote list output includes "(current)" annotations — stripped
  - FUSE device: privileged containers get /dev/fuse automatically
  - idmap: set security.privileged=true via --config during `incus init`
  - No lxd daemon — uses unix socket at /var/lib/incus/unix.socket
"""

import asyncio
import os
import re
import shlex
import shutil
import subprocess
import logging
from typing import Optional

logger = logging.getLogger("moonnodes_vps_bot")

BINARY = "incus"


# ── Image alias normalisation ─────────────────────────────────────────────────

def normalize_image(image: str) -> str:
    m = re.match(r"^ubuntu:(\d+\.\d+)$", image)
    if m: return f"images:ubuntu/{m.group(1)}"
    m = re.match(r"^ubuntu-daily:(\d+\.\d+)$", image)
    if m: return f"images:ubuntu/{m.group(1)}/daily"
    return image


# ── Command execution ─────────────────────────────────────────────────────────

def _strip_bad_flags(cmd: str) -> str:
    cmd = re.sub(r"\s+-c\s+[\w,]+", "", cmd)
    cmd = re.sub(r"--format\s+(\w+)", r"--format=\1", cmd)
    return cmd.strip()


async def run(command: str, timeout: int = 120):
    for prefix in ("incus ", "lxc ", "lxd "):
        if command.startswith(prefix):
            command = BINARY + " " + command[len(prefix):]
            break
    else:
        if not command.startswith(BINARY):
            command = f"{BINARY} {command}"

    command = _strip_bad_flags(command)
    logger.info(f"[incus] {command}")
    parts = shlex.split(command)

    try:
        proc = await asyncio.create_subprocess_exec(
            *parts,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        try: proc.kill(); await proc.wait()
        except Exception: pass
        raise asyncio.TimeoutError(f"incus timed out ({timeout}s): {command}")

    out = stdout.decode().strip() if stdout else ""
    err = stderr.decode().strip() if stderr else ""

    if proc.returncode != 0:
        msg = err or out or "Command failed"
        logger.error(f"[incus] FAILED: {msg}")
        raise Exception(msg)

    return out if out else True


# ── Remote listing ────────────────────────────────────────────────────────────

BUILTIN_REMOTES = {"local", "images", "ubuntu", "ubuntu-daily", "ubuntu-minimal", ""}

async def list_remotes() -> list:
    try:
        r = subprocess.run(
            [BINARY, "remote", "list", "--format=csv"],
            capture_output=True, text=True, timeout=10,
        )
        remotes = []
        for line in r.stdout.strip().splitlines():
            raw   = line.split(",")[0].strip()
            clean = re.sub(r"\s*\(.*?\)", "", raw).strip().rstrip("*").strip()
            if clean and clean not in BUILTIN_REMOTES:
                remotes.append(clean)
        return remotes
    except Exception as e:
        logger.warning(f"incus list_remotes failed: {e}")
        return []


# ── Storage pool detection ────────────────────────────────────────────────────

def detect_storage_pool(default: Optional[str] = None) -> str:
    if default: return default
    try:
        r = subprocess.run(
            [BINARY, "storage", "list", "--format=csv"],
            capture_output=True, text=True, timeout=10,
        )
        for line in r.stdout.strip().splitlines():
            name = line.split(",")[0].strip()
            if name and name not in ("", "NAME"):
                return name
    except Exception as e:
        logger.error(f"incus pool detect failed: {e}")
    return "default"


# ── Host resource stats ───────────────────────────────────────────────────────

def host_cpu_pct() -> float:
    try:
        r = subprocess.run(["top", "-bn1"], capture_output=True, text=True, timeout=5)
        for line in r.stdout.splitlines():
            if "Cpu" in line:
                m = re.search(r"(\d+\.?\d*)\s*id", line)
                if m: return round(100.0 - float(m.group(1)), 1)
    except Exception: pass
    return 0.0

def host_cpu_cores() -> int:
    try:
        r = subprocess.run(["nproc"], capture_output=True, text=True, timeout=5)
        return int(r.stdout.strip())
    except Exception: return 1

def host_ram() -> tuple:
    try:
        r = subprocess.run(["free", "-m"], capture_output=True, text=True, timeout=5)
        for line in r.stdout.splitlines():
            if line.startswith("Mem:"):
                p = line.split()
                return int(p[2]), int(p[1])
    except Exception: pass
    return 0, 0

def host_disk() -> tuple:
    try:
        r = subprocess.run(["df", "-BG", "/"], capture_output=True, text=True, timeout=5)
        for line in r.stdout.splitlines()[1:]:
            p = line.split()
            if len(p) >= 5:
                return int(p[2].replace("G","")), int(p[1].replace("G",""))
    except Exception: pass
    return 0, 0


# ── Container stats ───────────────────────────────────────────────────────────

async def container_status(name: str, node: str = "local") -> str:
    prefix = f"{node}:" if node and node != "local" else ""
    try:
        out = await run(f"incus list {prefix}{name} --format=csv")
        if out and out is not True:
            for line in str(out).splitlines():
                if name in line:
                    p = line.split(",")
                    return p[1].strip().lower() if len(p) > 1 else "unknown"
    except Exception: pass
    return "unknown"

async def container_cpu_pct(name: str, node: str = "local") -> float:
    prefix = f"{node}:" if node and node != "local" else ""
    try:
        out = await run(f"incus exec {prefix}{name} -- top -bn1")
        if out and out is not True:
            for line in str(out).splitlines():
                if "Cpu" in line:
                    m = re.search(r"(\d+\.?\d*)\s*id", line)
                    if m: return round(100.0 - float(m.group(1)), 1)
    except Exception: pass
    return 0.0

async def container_memory(name: str, node: str = "local") -> str:
    prefix = f"{node}:" if node and node != "local" else ""
    try:
        out = await run(f"incus exec {prefix}{name} -- free -m")
        if out and out is not True:
            for line in str(out).splitlines():
                if line.startswith("Mem:"):
                    p     = line.split()
                    total = int(p[1]); used = int(p[2])
                    pct   = round(used / total * 100, 1) if total else 0
                    return f"{used}/{total} MB ({pct}%)"
    except Exception: pass
    return "N/A"

async def container_disk(name: str, node: str = "local") -> str:
    prefix = f"{node}:" if node and node != "local" else ""
    try:
        out = await run(f"incus exec {prefix}{name} -- df -h /")
        if out and out is not True:
            for line in str(out).splitlines()[1:]:
                p = line.split()
                if len(p) >= 5:
                    return f"{p[2]}/{p[1]} ({p[4]})"
    except Exception: pass
    return "N/A"

async def container_uptime(name: str, node: str = "local") -> str:
    prefix = f"{node}:" if node and node != "local" else ""
    try:
        out = await run(f"incus exec {prefix}{name} -- uptime -p")
        return str(out).strip() if out and out is not True else "N/A"
    except Exception: return "N/A"


# ── Deployment ────────────────────────────────────────────────────────────────

async def deploy(
    container_name: str,
    os_image: str,
    ram_gb: int,
    cpu: int,
    disk_gb: int,
    storage_pool: str = "default",
    node: str = "local",
) -> None:
    """Create, configure, and start an Incus container."""
    # --- CRITICAL: strip trailing colon so we don't get node2::container ---
    node      = (node or "local").strip().rstrip(":").strip() or "local"
    prefix    = f"{node}:" if node != "local" else ""
    pool_flag = f" -s {storage_pool}" if storage_pool and storage_pool not in ("", "default") else ""
    image     = normalize_image(os_image)

    # --- CRITICAL: container names must be alphanumeric + hyphen only --------
    # Incus rejects underscores, double hyphens, leading/trailing hyphens, etc.
    safe_name = re.sub(r"[^a-z0-9-]", "-", container_name.lower())
    safe_name = re.sub(r"-{2,}", "-", safe_name).strip("-") or "vps-1"

    logger.info(f"[incus.deploy] node={node!r} prefix={prefix!r} container={safe_name!r} image={image!r}")

    # Init with privileged inline — prevents idmap errors
    await run(
        f"incus init {image} {prefix}{safe_name}{pool_flag}"
        f" --config security.privileged=true"
        f" --config security.nesting=true",
        timeout=300,
    )

    # Resource limits
    await run(f"incus config set {prefix}{safe_name} limits.memory {ram_gb * 1024}MB")
    await run(f"incus config set {prefix}{safe_name} limits.cpu {cpu}")

    # Disk quota
    try:
        pool = detect_storage_pool()
        await run(
            f"incus config device add {prefix}{safe_name} root disk"
            f" path=/ pool={pool} size={disk_gb}GB"
        )
    except Exception as e:
        logger.warning(f"[incus.deploy] disk quota non-fatal: {e}")

    # Docker / kernel compat
    for cfg_key in [
        "security.syscalls.intercept.mknod true",
        "linux.kernel_modules overlay,loop,nf_nat,ip_tables,ip6_tables",
    ]:
        try:
            await run(f"incus config set {prefix}{safe_name} {cfg_key}")
        except Exception as e:
            logger.warning(f"[incus.deploy] non-fatal config: {e}")

    # BPF / cgroup2 fix — suppresses "Failed to load bpf program" lxc.log errors
    try:
        await run(f"incus config set {prefix}{safe_name} raw.lxc lxc.cgroup2.devices.allow = a")
    except Exception as e:
        logger.warning(f"[incus.deploy] cgroup2 raw.lxc non-fatal: {e}")

    # Start
    await run(f"incus start {prefix}{safe_name}", timeout=60)
