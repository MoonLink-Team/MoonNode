"""
core/theme.py — Unified visual design system for MoonNodes.

All embeds go through this module to ensure consistent branding.
"""

import discord
from datetime import datetime


# ── Brand colours ─────────────────────────────────────────────────────────────

class Theme:
    PRIMARY   = 0x5865F2   # Discord blurple
    SUCCESS   = 0x57F287   # Green
    WARNING   = 0xFEE75C   # Yellow
    ERROR     = 0xED4245   # Red
    INFO      = 0x5DADE2   # Blue
    ACCENT    = 0xEB459E   # Pink/magenta
    DARK      = 0x2B2D31   # Dark grey

    # Progress bar
    FILLED  = "█"
    EMPTY   = "░"

    # Icons
    CPU     = "🖥️"
    RAM     = "🧬"
    DISK    = "💾"
    LOADING = "⏳"
    ONLINE  = "🟢"
    OFFLINE = "🔴"
    WARNING_ICON = "🟡"

    # Divider
    DIVIDER = "━━━━━━━━━━━━━━━━━━━━━━━━"

    ICON_URL = "https://imgur.com/6yfYDTP.png"
    FOOTER   = "MoonNodes VPS Manager"

    @staticmethod
    def progress_bar(pct: float, size: int = 12) -> str:
        filled = int(pct / 100 * size)
        empty  = size - filled
        bar    = Theme.FILLED * filled + Theme.EMPTY * empty
        color  = "🟢" if pct < 60 else "🟡" if pct < 85 else "🔴"
        return f"{color} `{bar}` **{pct:.1f}%**"


def _base(title: str, description: str, color: int) -> discord.Embed:
    embed = discord.Embed(
        title=title,
        description=description or None,
        color=color,
        timestamp=datetime.now(),
    )
    embed.set_author(name=Theme.FOOTER, icon_url=Theme.ICON_URL)
    embed.set_footer(text=Theme.FOOTER)
    return embed


def create_embed(title: str, description: str = "", color: int = Theme.PRIMARY) -> discord.Embed:
    return _base(title, description, color)

def create_success_embed(title: str, description: str = "") -> discord.Embed:
    return _base(f"✅  {title}", description, Theme.SUCCESS)

def create_error_embed(title: str, description: str = "") -> discord.Embed:
    return _base(f"❌  {title}", description, Theme.ERROR)

def create_info_embed(title: str, description: str = "") -> discord.Embed:
    return _base(f"ℹ️  {title}", description, Theme.INFO)

def create_warning_embed(title: str, description: str = "") -> discord.Embed:
    return _base(f"⚠️  {title}", description, Theme.WARNING)

def create_loading_embed(title: str, description: str = "") -> discord.Embed:
    return _base(f"⏳  {title}", description, Theme.PRIMARY)


def add_field(embed: discord.Embed, name: str, value: str, inline: bool = False) -> discord.Embed:
    """Add a field, auto-truncating to Discord's 1024 char limit."""
    value = str(value)
    if len(value) > 1024:
        value = value[:1021] + "…"
    embed.add_field(name=str(name)[:256], value=value, inline=inline)
    return embed
