import discord
from datetime import datetime
from core.config import CUSTOM_BOT_COLOR


class Theme:
    PRIMARY  = CUSTOM_BOT_COLOR
    ACCENT   = CUSTOM_BOT_COLOR
    SUCCESS  = 0x00FF7F
    ERROR    = 0xFF3366
    WARNING  = 0xFFCC00
    DARK     = 0x1E1F22

    ONLINE   = "🟢"
    OFFLINE  = "🔴"
    LOADING  = "⏳"
    CPU      = "💠"
    RAM      = "🧬"
    DISK     = "💽"
    NET      = "🌐"
    SECURE   = "🛡️"
    DIVIDER  = "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    @staticmethod
    def get_status_color(status, suspended=False):
        if suspended:          return Theme.ERROR
        if status == "running": return Theme.SUCCESS
        if status == "stopped": return Theme.DARK
        return Theme.WARNING

    @staticmethod
    def progress_bar(percentage: float, size: int = 12) -> str:
        percentage = max(0, min(100, percentage))
        filled = int((percentage / 100) * size)
        empty  = size - filled
        return f"`{'█' * filled}{'▒' * empty}` **{percentage:.1f}%**"


def create_embed(title: str, description: str = "", color: int = Theme.PRIMARY) -> discord.Embed:
    title       = str(title)[:256]
    description = str(description)
    if len(description) > 4096:
        description = description[:4093] + "..."
    embed = discord.Embed(title=title, description=description, color=color, timestamp=datetime.now())
    embed.set_author(name="MoonNodes VPS Manager", icon_url="https://imgur.com/6yfYDTP.png")
    embed.set_footer(text="System Status • Online",  icon_url="https://imgur.com/6yfYDTP.png")
    return embed


def add_field(embed: discord.Embed, name: str, value: str, inline: bool = False) -> discord.Embed:
    name  = str(name)[:256]
    value = str(value)
    if len(value) > 1024:
        value = value[:1021] + "…"
    embed.add_field(name=name, value=value, inline=inline)
    return embed


def create_success_embed(title: str, description: str = "") -> discord.Embed:
    return create_embed(f"✅  {title}", description, color=Theme.SUCCESS)

def create_error_embed(title: str, description: str = "") -> discord.Embed:
    return create_embed(f"⚠️  {title}", description, color=Theme.ERROR)

def create_info_embed(title: str, description: str = "") -> discord.Embed:
    return create_embed(f"ℹ️  {title}", description, color=Theme.ACCENT)

def create_warning_embed(title: str, description: str = "") -> discord.Embed:
    return create_embed(f"⚡  {title}", description, color=Theme.WARNING)
