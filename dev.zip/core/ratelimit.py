"""
core/ratelimit.py — Per-user per-command rate limiting.

Usage:
    from core.ratelimit import rate_limit

    @app_commands.command(...)
    @rate_limit(seconds=30)
    async def my_cmd(self, interaction, ...):
        ...

The decorator checks a per-user cooldown bucket and responds with a
localised embed if the user is on cooldown. The check happens BEFORE
any defer() so it never burns an interaction token.
"""

import asyncio
import functools
import logging
import time
from typing import Dict, Tuple

import discord
from discord import app_commands

logger = logging.getLogger("moonnodes_vps_bot")

# {(user_id, cmd_name): reset_timestamp}
_cooldown_buckets: Dict[Tuple[int, str], float] = {}
_lock = asyncio.Lock()


def rate_limit(seconds: int = 30, admin_bypass: bool = True):
    """
    Decorator factory.

    Parameters
    ----------
    seconds      : Cooldown in seconds between uses per user.
    admin_bypass : If True, bot owner + admins are never rate-limited.
    """
    def decorator(func):
        @functools.wraps(func)
        async def wrapper(self_or_cog, interaction: discord.Interaction, *args, **kwargs):
            from core.database import admin_data
            from core.config  import MAIN_ADMIN_ID
            from core.lang    import t, get_user_lang

            uid      = interaction.user.id
            cmd_name = getattr(interaction.command, "name", "?")

            # Admin / owner bypass
            if admin_bypass:
                is_admin = (
                    uid == MAIN_ADMIN_ID
                    or str(uid) in admin_data
                )
                if is_admin:
                    return await func(self_or_cog, interaction, *args, **kwargs)

            key     = (uid, cmd_name)
            now     = time.monotonic()
            reset   = _cooldown_buckets.get(key, 0)

            if now < reset:
                # On cooldown — send ephemeral error WITHOUT defer (token still fresh)
                remaining = reset - now
                unix_reset = int(time.time() + remaining)
                lang  = get_user_lang(str(uid))
                msg   = t("rate_limit_msg", lang=lang, cmd=cmd_name, reset=unix_reset)
                embed = discord.Embed(
                    description=msg,
                    color=0xFEE75C,
                )
                embed.set_author(name="MoonNodes · Cooldown")
                try:
                    if not interaction.response.is_done():
                        await interaction.response.send_message(embed=embed, ephemeral=True)
                    else:
                        await interaction.followup.send(embed=embed, ephemeral=True)
                except Exception:
                    pass
                return

            # Not on cooldown — set bucket and proceed
            _cooldown_buckets[key] = now + seconds
            return await func(self_or_cog, interaction, *args, **kwargs)

        return wrapper
    return decorator


def clear_cooldown(user_id: int, cmd_name: str):
    """Manually clear a user's cooldown (e.g. after an error)."""
    _cooldown_buckets.pop((user_id, cmd_name), None)


def get_remaining(user_id: int, cmd_name: str) -> float:
    """Return seconds remaining on cooldown, or 0 if not cooling down."""
    reset = _cooldown_buckets.get((user_id, cmd_name), 0)
    remaining = reset - time.monotonic()
    return max(0.0, remaining)
