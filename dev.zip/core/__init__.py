"""
core package – exposes ACTIVE_STORAGE_POOL for use by lxc.py.
"""
from core.config import DEFAULT_STORAGE_POOL
import subprocess, shlex, logging

logger = logging.getLogger("moonnodes_vps_bot")

def _detect_pool(default=None):
    if default:
        return default
    try:
        r = subprocess.run(shlex.split("lxc profile device get default root pool"), capture_output=True, text=True)
        p = r.stdout.strip()
        if p:
            return p
        r = subprocess.run(shlex.split("lxc storage list --format csv -c n"), capture_output=True, text=True)
        pools = r.stdout.strip().splitlines()
        if pools:
            return pools[0]
    except Exception as e:
        logger.error(f"Pool detect error: {e}")
    return "default"

ACTIVE_STORAGE_POOL = _detect_pool(DEFAULT_STORAGE_POOL)

# Expose via config alias so lxc.py can import it
import core.config as _cfg
_cfg.ACTIVE_STORAGE_POOL_REF = ACTIVE_STORAGE_POOL
