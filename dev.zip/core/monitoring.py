import asyncio
import threading
import subprocess
import shutil
import time
import logging
from typing import Optional

logger = logging.getLogger("moonnodes_vps_bot")

resource_monitor_active = True


def get_cpu_usage_sync() -> float:
    try:
        if shutil.which("mpstat"):
            r = subprocess.run(["mpstat", "1", "1"], capture_output=True, text=True)
            for line in r.stdout.split("\n"):
                if "all" in line and "%" in line:
                    return 100.0 - float(line.split()[-1])
        else:
            r = subprocess.run(["top", "-bn1"], capture_output=True, text=True)
            for line in r.stdout.split("\n"):
                if "%Cpu(s):" in line:
                    return 100.0 - float(line.split()[7])
    except Exception:
        pass
    return 0.0


def get_ram_usage_sync() -> float:
    try:
        r = subprocess.run(["free", "-m"], capture_output=True, text=True)
        lines = r.stdout.splitlines()
        if len(lines) > 1:
            mem = lines[1].split()
            return (int(mem[2]) / int(mem[1]) * 100) if int(mem[1]) > 0 else 0.0
    except Exception:
        pass
    return 0.0


async def get_cpu_usage_async() -> float:
    return await asyncio.to_thread(get_cpu_usage_sync)


async def get_ram_usage_async() -> float:
    return await asyncio.to_thread(get_ram_usage_sync)


async def get_uptime_async() -> str:
    try:
        proc = await asyncio.create_subprocess_exec("uptime", "-p", stdout=asyncio.subprocess.PIPE)
        stdout, _ = await proc.communicate()
        return stdout.decode().strip() if stdout else "Unknown"
    except Exception:
        return "Unknown"


def start_resource_monitor(bot_loop, cpu_threshold: float, ram_threshold: float,
                            vps_data_ref: dict, data_lock_ref, save_fn, send_log_fn):
    """Starts the background thread that auto-stops VPS on high load."""

    def _monitor():
        global resource_monitor_active
        while resource_monitor_active:
            try:
                if get_cpu_usage_sync() > cpu_threshold or get_ram_usage_sync() > ram_threshold:
                    logger.warning("[Monitor] High resource usage – stopping all VPS containers.")
                    subprocess.run(["lxc", "stop", "--all", "--force"])
                    with data_lock_ref:
                        for lst in vps_data_ref.values():
                            for vps in lst:
                                if vps.get("status") == "running":
                                    vps["status"] = "stopped"
                    save_fn()
                    from core.theme import create_error_embed
                    asyncio.run_coroutine_threadsafe(
                        send_log_fn(create_error_embed(
                            "Critical Resource Limit",
                            "All VPS instances stopped due to high server load."
                        )),
                        bot_loop
                    )
            except Exception:
                pass
            time.sleep(60)

    t = threading.Thread(target=_monitor, daemon=True)
    t.start()
    return t
