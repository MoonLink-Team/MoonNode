"""
core/monitoring.py — Resource monitoring (logging ONLY, no auto-stop).

The auto-stop feature was removed because it indiscriminately killed all
containers when the host was under normal load. Use /account admin_action:VPS
vps_action:Suspend to manually suspend individual containers.
"""

import asyncio
import threading
import subprocess
import shutil
import time
import logging

logger = logging.getLogger("moonnodes_vps_bot")

resource_monitor_active = True


def get_cpu_usage_sync() -> float:
    try:
        if shutil.which("mpstat"):
            r = subprocess.run(["mpstat", "1", "1"], capture_output=True, text=True, timeout=10)
            for line in r.stdout.split("\n"):
                if "all" in line and "%" in line:
                    return round(100.0 - float(line.split()[-1]), 1)
        r = subprocess.run(["top", "-bn1"], capture_output=True, text=True, timeout=10)
        for line in r.stdout.split("\n"):
            if "%Cpu(s):" in line or "Cpu(s):" in line:
                import re
                m = re.search(r"(\d+\.?\d*)\s*id", line)
                if m:
                    return round(100.0 - float(m.group(1)), 1)
    except Exception:
        pass
    return 0.0


def get_ram_usage_sync() -> float:
    try:
        r = subprocess.run(["free", "-m"], capture_output=True, text=True, timeout=5)
        lines = r.stdout.splitlines()
        if len(lines) > 1:
            mem = lines[1].split()
            return round((int(mem[2]) / int(mem[1]) * 100), 1) if int(mem[1]) > 0 else 0.0
    except Exception:
        pass
    return 0.0


async def get_cpu_usage_async() -> float:
    return await asyncio.to_thread(get_cpu_usage_sync)


async def get_ram_usage_async() -> float:
    return await asyncio.to_thread(get_ram_usage_sync)


async def get_uptime_async() -> str:
    try:
        proc = await asyncio.create_subprocess_exec(
            "uptime", "-p",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await proc.communicate()
        return stdout.decode().strip() if stdout else "Unknown"
    except Exception:
        return "Unknown"


def start_resource_monitor(
    bot_loop, cpu_threshold: float, ram_threshold: float,
    vps_data_ref: dict, data_lock_ref, save_fn, send_log_fn
):
    """
    Start a background monitoring thread.

    This thread ONLY logs warnings when thresholds are exceeded.
    It does NOT stop, suspend, or modify any containers.
    Use VPS Monitoring Alerts extension (/system action:Extension Toggle)
    to DM users when their individual VPS exceeds thresholds.
    """

    def _monitor():
        global resource_monitor_active
        check_interval = 60  # seconds

        while resource_monitor_active:
            try:
                cpu = get_cpu_usage_sync()
                ram = get_ram_usage_sync()

                if cpu > cpu_threshold:
                    logger.warning(f"[Monitor] ⚠️  Host CPU high: {cpu:.1f}% (threshold: {cpu_threshold}%)")

                if ram > ram_threshold:
                    logger.warning(f"[Monitor] ⚠️  Host RAM high: {ram:.1f}% (threshold: {ram_threshold}%)")

                if cpu > cpu_threshold or ram > ram_threshold:
                    # Send a log embed — do NOT stop any containers
                    from core.theme import create_warning_embed, add_field
                    embed = create_warning_embed(
                        "⚠️  High Host Resource Usage",
                        f"The host server is under heavy load. No containers were stopped.\n"
                        f"Use `/account admin_action:VPS` to manually suspend specific VPS."
                    )
                    add_field(embed, "CPU", f"`{cpu:.1f}%` (limit: {cpu_threshold}%)", True)
                    add_field(embed, "RAM", f"`{ram:.1f}%` (limit: {ram_threshold}%)", True)
                    asyncio.run_coroutine_threadsafe(send_log_fn(embed), bot_loop)

                else:
                    logger.debug(f"[Monitor] OK — CPU: {cpu:.1f}%, RAM: {ram:.1f}%")

            except Exception as e:
                logger.error(f"[Monitor] Error: {e}")

            time.sleep(check_interval)

    t = threading.Thread(target=_monitor, daemon=True)
    t.start()
    return t
