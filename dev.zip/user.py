import discord
from discord.ext import commands
from discord import app_commands
import time
import re
from bot import (
    create_embed, create_error_embed, create_success_embed, create_info_embed, create_warning_embed,
    check_maintenance, add_field, Theme, get_cpu_usage_async, get_ram_usage_async, get_uptime_async,
    ManageView, ENABLE_PLANS, PLANS, ABEI, CLAIM_PREMIUM, CLAIM_FREE, get_setting, MAIN_ADMIN_ID,
    OSSelectView, execute_lxc, is_admin_check, ISTS
)
from database import vps_data, data_lock, save_vps_data

class UserCmds(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="ping", description="Ping Global Quantum Hubs")
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @check_maintenance()
    async def ping(self, interaction: discord.Interaction):
        await interaction.response.send_message(embed=create_success_embed("Gateway Online", f"Hypervisor Backbone Latency: `{round(self.bot.latency * 1000)}ms`"))

    @app_commands.command(name="status", description="Pull architecture health readouts")
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @check_maintenance()
    async def status(self, interaction: discord.Interaction):
        await interaction.response.defer()
        cpu, ram, uptime = await get_cpu_usage_async(), await get_ram_usage_async(), await get_uptime_async()
        embed = create_embed("🌐 Aegis Global Matrix Telemetry")
        add_field(embed, f"{Theme.NET} API Heartbeat", f"`{round(self.bot.latency * 1000)}ms`", True)
        add_field(embed, "⏱️ Cluster Uptime", f"`{uptime}`", True)
        add_field(embed, f"{Theme.CPU} Aggregated CPU Pool", Theme.progress_bar(cpu), False)
        add_field(embed, f"{Theme.RAM} Memory Sector Allocation", Theme.progress_bar(ram), False)
        await interaction.followup.send(embed=embed)

    @app_commands.command(name="list", description="Access your allocated network assets")
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @check_maintenance()
    async def list_vps(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        with data_lock: vps_list = vps_data.get(str(interaction.user.id), [])
        if not vps_list: return await interaction.followup.send(embed=create_error_embed("Registry Empty", "You do not hold any verified Quantum Nodes within the cluster."))
        embed = create_embed(f"📦 Architect Repository - {interaction.user.name}")
        for i, vps in enumerate(vps_list):
            is_suspended = vps.get('suspended', False)
            status_icon, status_text = (Theme.OFFLINE, "LOCKED") if is_suspended else ((Theme.ONLINE, "Routing") if vps.get('status') == 'running' else (Theme.OFFLINE, "Dormant"))
            details = f"> 🆔 **Node Key:** `{vps['container_name']}`\n> 📊 **Telemetry:** {status_icon} `{status_text}`\n> ⚙️ **Matrix:** `{vps.get('config', 'Custom')}`"
            add_field(embed, f"Asset [{i+1}]", details, False)
        add_field(embed, Theme.DIVIDER, "🔽 **Select an asset ID from the dashboard below to manage.**", False)
        await interaction.followup.send(embed=embed, view=ManageView(str(interaction.user.id), vps_list))

    @app_commands.command(name="manage", description="Access your primary control deck")
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @check_maintenance()
    async def manage_vps(self, interaction: discord.Interaction, user: discord.Member = None):
        await interaction.response.defer()
        target_id = str(user.id) if user and is_admin_check(interaction.user.id) else str(interaction.user.id)
        with data_lock: vps_list = vps_data.get(target_id, [])
        if not vps_list: return await interaction.followup.send(embed=create_error_embed("Empty Return", "Target lacks infrastructure." if user else "You have zero dedicated blocks."), ephemeral=True)
        view = ManageView(str(interaction.user.id), vps_list, is_admin=bool(user), owner_id=target_id)
        await interaction.followup.send(embed=await view.get_initial_embed(), view=view)

    @app_commands.command(name="manage-shared", description="Interface with linked network hardware")
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @check_maintenance()
    async def manage_shared_vps(self, interaction: discord.Interaction, owner: discord.Member, vps_number: int):
        await interaction.response.defer()
        owner_id = str(owner.id)
        with data_lock:
            if owner_id not in vps_data or vps_number < 1 or vps_number > len(vps_data[owner_id]): return await interaction.followup.send(embed=create_error_embed("Fault", "Target is ghosted."), ephemeral=True)
            vps = vps_data[owner_id][vps_number - 1]
        if str(interaction.user.id) not in vps.get("shared_with", []): return await interaction.followup.send(embed=create_error_embed("Firewall Blocked", "You do not hold decryption keys for this architecture."), ephemeral=True)
        view = ManageView(str(interaction.user.id), [vps], is_shared=True, owner_id=owner_id, actual_index=vps_number-1)
        await interaction.followup.send(embed=await view.get_initial_embed(), view=view)

    @app_commands.command(name="claim", description="Acquire a Node configuration from the Catalog")
    @app_commands.checks.cooldown(1, 10.0, key=lambda i: i.user.id)
    @app_commands.choices(plan_type=[app_commands.Choice(name="Premium Hardware", value="premium"), app_commands.Choice(name="Free Tier", value="free")])
    async def claim_vps_cmd(self, interaction: discord.Interaction, plan_type: str, plan_name: str, proof: discord.Attachment = None):
        await interaction.response.defer(ephemeral=True)
        if plan_type == "premium" and not CLAIM_PREMIUM: return await interaction.followup.send(embed=create_error_embed("Allocation Offline", "Premium network allocations disabled."), ephemeral=True)
        if plan_type == "free" and not CLAIM_FREE: return await interaction.followup.send(embed=create_error_embed("Allocation Offline", "Free tier matrix allocations disabled."), ephemeral=True)
        if plan_type == "premium" and not ABEI: return await interaction.followup.send(embed=create_error_embed("Billing Offline", "Premium network purchases blocked."), ephemeral=True)
        if not ENABLE_PLANS or plan_name.lower() not in PLANS.get(plan_type, {}): return await interaction.followup.send(embed=create_error_embed("Invalid Blueprint", "Requested plan does not exist."), ephemeral=True)
        
        p = PLANS[plan_type][plan_name.lower()]
        if plan_type == "premium":
            payment_ch_id = get_setting('payment_channel')
            if not payment_ch_id or payment_ch_id == '0': return await interaction.followup.send(embed=create_error_embed("Routing Failure", "No financial relay channel set up."))
            target_channel = interaction.guild.get_channel(int(payment_ch_id))
            if not target_channel: return await interaction.followup.send(embed=create_error_embed("Routing Failure", "Financial relay channel missing."))
            embed = create_info_embed("💳 New Node Acquisition Logged")
            embed.add_field(name="Target Architect", value=interaction.user.mention, inline=True)
            embed.add_field(name="Hardware Block", value=f"`{plan_name}`", inline=True)
            if proof: embed.set_image(url=proof.url)
            try:
                await target_channel.send(content=f"<@{MAIN_ADMIN_ID}> Acquisition Request", embed=embed)
                await interaction.followup.send(embed=create_success_embed("Transmission Secure", "Your request has been beamed to our financial network."))
            except Exception as e: await interaction.followup.send(embed=create_error_embed("Packet Loss", f"Transmission failed: {e}"))
        elif plan_type == "free":
            req_invites = 0
            match = re.search(r'invite\s+(\d+)', p.get('price', '').lower())
            if match: req_invites = int(match.group(1))
            if req_invites > 0:
                try:
                    invites = await interaction.guild.invites()
                    user_invites = sum(i.uses for i in invites if i.inviter == interaction.user)
                    if user_invites < req_invites: return await interaction.followup.send(embed=create_error_embed("Clearance Denied", f"Requires **{req_invites} network invites**.\nYour tally: **{user_invites}**."))
                except: return await interaction.followup.send(embed=create_error_embed("API Fault", "Requires `Manage Server` permissions to authenticate invites."))
            await interaction.edit_original_response(embed=create_info_embed("Sector Approved", f"Select the core OS for **{plan_name}**:"), view=OSSelectView(p['ram'], p['cpu'], p['disk'], interaction.user, interaction, plan_name))

    @app_commands.command(name="plans", description="Browse commercial hosting architectures")
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @app_commands.choices(plan_type=[app_commands.Choice(name="Premium", value="premium"), app_commands.Choice(name="Free", value="free")])
    @app_commands.choices(action=[app_commands.Choice(name="list", value="list")])
    async def manage_plans(self, interaction: discord.Interaction, plan_type: str, action: str):
        if not ENABLE_PLANS: return await interaction.response.send_message(embed=create_error_embed("Module Disabled", "Marketplace sub-system is deactivated."), ephemeral=True)
        if action == "list":
            embed = create_info_embed(f"💳 Corporate {plan_type.capitalize()} Hardware Catalog")
            desc = ""
            target_dict = PLANS.get(plan_type, {})
            if not target_dict: desc = f"No {plan_type} configurations found."
            else:
                for name, data in target_dict.items():
                    p_price = f" - {data.get('price', '')}" if data.get('price') else ""
                    desc += f"**{data.get('emoji', '📦')} {name.title()} Block{p_price}**\n• **{data.get('ram')}GB** DDR4/DDR5 Sector\n• **{data.get('cpu')}** Quantum Cores\n• **{data.get('disk')}GB** Ultra-NVMe Storage\n\n"
            embed.description = desc
            await interaction.response.send_message(embed=embed)

    @app_commands.command(name="backup", description="Archive deep sector data")
    @app_commands.checks.cooldown(1, 30.0, key=lambda i: i.user.id)
    @check_maintenance()
    async def backup(self, interaction: discord.Interaction, action: str, vps_index: int):
        await interaction.response.defer()
        with data_lock:
            vps_list = vps_data.get(str(interaction.user.id), [])
            if vps_index < 1 or vps_index > len(vps_list): return await interaction.followup.send(embed=create_error_embed("Index Error", "Pointer detached from matrix."))
            name = vps_list[vps_index-1]['container_name']
        try:
            if action == "create":
                snap_name = f"backup-{int(time.time())}"
                await execute_lxc(f"lxc snapshot {name} {snap_name}")
                await interaction.followup.send(embed=create_success_embed("Snapshot Isolated", f"Deep freeze `{snap_name}` logged."))
            elif action == "restore":
                await execute_lxc(f"lxc restore {name} $(lxc info {name} | grep backup- | tail -1 | awk '{{print $1}}')")
                await interaction.followup.send(embed=create_success_embed("Rollback Executed", "Asset state successfully restored."))
        except Exception as e: await interaction.followup.send(embed=create_error_embed("IO Break", str(e)[:4000]))

    @app_commands.command(name="share-user", description="Embed keys for a subnet identity")
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @check_maintenance()
    async def share_user(self, interaction: discord.Interaction, shared_user: discord.Member, vps_number: int):
        await interaction.response.defer()
        uid = str(interaction.user.id)
        with data_lock:
            if uid not in vps_data or vps_number < 1: return await interaction.followup.send(embed=create_error_embed("Index Fault", "Hardware disconnected."), ephemeral=True)
            vps = vps_data[uid][vps_number - 1]
            if "shared_with" not in vps: vps["shared_with"] = []
            if str(shared_user.id) not in vps["shared_with"]: vps["shared_with"].append(str(shared_user.id))
        save_vps_data()
        await interaction.followup.send(embed=create_success_embed("Access Matrix Woven", f"I/O keys distributed to {shared_user.mention}"))

    @app_commands.command(name="help", description="Access the Aegis Network Manual")
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    async def show_help(self, interaction: discord.Interaction):
        await interaction.response.defer()
        user_desc = "> 🖥️ `/list` - Ping active nodes\n> 🎛️ `/manage` - Control infrastructure\n> 💾 `/backup` - Encrypt storage volumes\n> 🤝 `/share-user` - Map access keys\n> 💳 `/plans` - Query corporate hardware\n> 🚀 `/claim` - Lock-in your allocations\n> 🌐 `/status` - Hypervisor health readout"
        embed = create_embed("📚 Enterprise Aegis Matrix", "Command line interfaces approved for your identity.")
        add_field(embed, "Network Terminals", user_desc, False)
        if is_admin_check(interaction.user.id): add_field(embed, "Root Level Functions", "> 🛡️ `/admin`\n> ⚙️ `/set`\n> 🔨 `/create`\n> 🗑️ `/delete`\n> 🎉 `/giveaway`\n> ⚖️ `/vps`\n> 📂 `/list-all`", False)
        await interaction.followup.send(embed=embed)

    @app_commands.command(name="support", description="Pipe an emergency ticket to engineering")
    @app_commands.checks.cooldown(1, 10.0, key=lambda i: i.user.id)
    async def support_cmd(self, interaction: discord.Interaction, issue: str):
        if not ISTS:
            return await interaction.response.send_message(embed=create_error_embed("Offline", "Internal ticketing matrix is decoupled."), ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        if not isinstance(interaction.channel, discord.TextChannel):
            return await interaction.followup.send(embed=create_error_embed("Location Fault", "Execute within an open matrix channel."))
        try:
            thread = await interaction.channel.create_thread(name=f"ticket-{interaction.user.name}", type=discord.ChannelType.private_thread)
            await thread.add_user(interaction.user)
            vps_info_str = "No arrays detected."
            with data_lock:
                if str(interaction.user.id) in vps_data:
                    vps_list = vps_data[str(interaction.user.id)]
                    if vps_list:
                        vps_info_str = "\n".join([f"• `{v['container_name']}` (Firmware: {v.get('os_version', 'Unknown')}, Load: {v.get('config', 'Unknown')})" for v in vps_list])
            embed = create_info_embed(f"🎫 Priority Transmission: {interaction.user.name}", f"**Payload String:**\n{issue}\n\n**Tethered Hardware:**\n{vps_info_str}")
            await thread.send(f"<@{MAIN_ADMIN_ID}> Level 1 Alert from {interaction.user.mention}", embed=embed)
            await interaction.followup.send(embed=create_success_embed("Tunnel Linked", f"Secure thread opened: {thread.mention}"), ephemeral=True)
        except Exception as e:
            await interaction.followup.send(embed=create_error_embed("Fault", str(e)[:4000]), ephemeral=True)

    @app_commands.command(name="share-ruser", description="Revoke subnet identity keys")
    @app_commands.checks.cooldown(1, 5.0, key=lambda i: i.user.id)
    @check_maintenance()
    async def revoke_share(self, interaction: discord.Interaction, shared_user: discord.Member, vps_number: int):
        await interaction.response.defer()
        user_id = str(interaction.user.id)
        with data_lock:
            if user_id not in vps_data: return await interaction.followup.send(embed=create_error_embed("Index Fault", "Hardware disconnected."), ephemeral=True)
            vps = vps_data[user_id][vps_number - 1]
            if str(shared_user.id) in vps.get("shared_with", []): vps["shared_with"].remove(str(shared_user.id))
        save_vps_data()
        await interaction.followup.send(embed=create_success_embed("Network Sealed", f"Keys successfully stripped from {shared_user.mention}"))

async def setup(bot: commands.Bot): await bot.add_cog(UserCmds(bot))